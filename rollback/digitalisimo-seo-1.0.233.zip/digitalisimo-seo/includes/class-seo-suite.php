<?php
defined( 'ABSPATH' ) || exit;

/** Suite SEO nativa: ajustes, editor, metadatos, schema, social, sitemap y diagnóstico. */
class Digitalisimo_Integrations_SEO_Suite {
	const P = 'digitalisimo_seo_';
	const UNIFY_HELP = 'Reúne en un solo grafo el JSON-LD que publican el tema y otros plugins (por ejemplo las FAQ de DIGITALÍSIMO Elements o el producto de WooCommerce): retira duplicados de la organización, del sitio y de la página, tipos que no existen en Schema.org y preguntas que no se ven en la página. Desactivado, sólo se publica el grafo de Digitalísimo y lo demás queda intacto.';
	const LOCAL_TYPE_HELP = 'Tipos oficiales de Schema.org. Si ninguno describe tu negocio, usa LocalBusiness. Sólo se publica cuando el negocio tiene nombre, ciudad, dirección o código postal y teléfono o coordenadas.';
	const ENTITY_HELP = 'Quién publica el sitio. Organización para empresas y marcas; Negocio local sólo se publica como LocalBusiness si SEO Local tiene dirección y teléfono o coordenadas; Persona para sitios personales o profesionales independientes.';
	const SITEMAP_IMAGES_HELP = 'Añade a cada URL su imagen destacada y las imágenes del contenido alojadas en este sitio (hasta 20 por URL). Una imagen marcada como excluida en la Biblioteca de Medios no se publica.';
	/** Una sola definición de cada bloque nuevo para el sitio (f) y la red (nf). */
	private static function field( $network, $key, $label, $type = 'text', $help = '', $choices = array() ) { if ( $network ) self::nf( $key, $label, $type, $help, $choices ); else self::f( $key, $label, $type, $help, $choices ); }
	private static function verification_fields( $network ) {
		echo '<tr><th colspan="2"><h2>Verificación de buscadores</h2><p class="description">Pega el código o la etiqueta completa que te da cada buscador: sólo se guarda el código. Se publica únicamente en la portada.</p></th></tr>';
		foreach ( Digitalisimo_Integrations_Verification::engines() as $key => $engine ) self::field( $network, $key, $engine[0] );
		self::field( $network, Digitalisimo_Integrations_Verification::CUSTOM, 'Otras etiquetas', 'textarea', 'Una por línea con el formato nombre|contenido, por ejemplo facebook-domain-verification|abc123. Sólo se publican como <meta name>.' );
	}
	private static function advanced_robots_fields( $network ) {
		echo '<tr><th colspan="2"><h2>Robots avanzados</h2><p class="description">Cada contenido puede cambiar los límites del fragmento y añadir noarchive, noimageindex o nosnippet desde su editor SEO → Avanzado.</p></th></tr>';
		self::field( $network, 'seo_noindex_paginated', 'Páginas 2 y siguientes de los archivos', 'checkbox', 'Publica noindex en /page/2/ y siguientes de blog, categorías y otros archivos. Los enlaces se siguen rastreando.' );
		self::field( $network, 'seo_noindex_password', 'Contenidos protegidos con contraseña', 'checkbox' );
		self::field( $network, 'seo_max_snippet', 'Máximo de caracteres del fragmento', 'number', 'Vacío no publica la directiva; -1 sin límite; 0 sin fragmento.' );
		self::field( $network, 'seo_max_video_preview', 'Máximo de segundos de vista previa de vídeo', 'number', 'Vacío no publica la directiva; -1 sin límite.' );
		self::field( $network, 'seo_disable_author_archives', 'Desactivar los archivos de autor', 'checkbox', 'Redirigen (301) a la portada. Úsalo en sitios de un solo autor.' );
		self::field( $network, 'seo_disable_date_archives', 'Desactivar los archivos por fecha', 'checkbox', 'Redirigen (301) a la portada.' );
	}
	private static function redirect_fields( $network ) {
		self::field( $network, 'seo_redirect_enabled', 'Redirecciones', 'checkbox', 'Aplica las reglas de cada sitio. Sin reglas activas no hace ninguna consulta.' );
		self::field( $network, 'seo_redirect_slug_watch', 'Redirigir al cambiar un enlace', 'checkbox', 'Al cambiar el enlace de un contenido o término publicado, crea una 301 de la dirección anterior a la nueva.' );
		self::field( $network, 'seo_redirect_default_code', 'Respuesta predeterminada', 'select', 'Se propone al crear una regla y se usa en la redirección de 404.', array( 301 => '301 · permanente', 302 => '302 · temporal', 307 => '307 · temporal (conserva el método)' ) );
		self::field( $network, 'seo_redirect_fallback_url', 'Redirigir los 404 a', 'text', 'Vacío: los 404 responden 404 (recomendado). Una ruta como /contacto/ redirige ahí las URLs que no existen. Nunca se ofrece la portada: Google lo trata como soft 404.' );
		if ( $network ) echo '<tr><th scope="row">Reglas</th><td><p class="description">Las reglas son de cada sitio: se crean y revisan en Digitalisimo → SEO → Redirecciones de ese sitio.</p></td></tr>';
	}
	private static function monitor_fields( $network ) {
		self::field( $network, 'seo_404_enabled', 'Registrar los 404', 'checkbox', 'Anota cada URL que responde 404, con su contador, la última procedencia y el navegador. No guarda IPs.' );
		self::field( $network, 'seo_404_ignore_query', 'Ignorar la query string', 'checkbox', 'Registra /pagina?utm=1 y /pagina?utm=2 como una sola URL.' );
		self::field( $network, 'seo_404_limit', 'Máximo de URLs registradas', 'number', 'Entre 50 y 20 000. Se conservan las más visitadas.' );
		self::field( $network, 'seo_404_retention', 'Días que se conserva cada URL', 'number', 'Entre 1 y 365 días desde su última visita.' );
		self::field( $network, 'seo_404_exclude', 'No registrar', 'textarea', 'Un fragmento de URL por línea, por ejemplo .map o /wp-content/cache/.' );
		if ( $network ) echo '<tr><th scope="row">Registro</th><td><p class="description">Cada sitio guarda y muestra su propio registro en Digitalisimo → SEO → Monitor 404.</p></td></tr>';
	}
	public static function entity_type_choices() { return array( 'Organization' => 'Organización', 'LocalBusiness' => 'Negocio local', 'Person' => 'Persona' ); }
	public static function separator_choices() { return array( '|' => '|', '-' => '-', '–' => '–', '·' => '·' ); }
	/** LocalBusiness y sus subtipos oficiales. */
	public static function local_type_choices() { $out = array( 'LocalBusiness' => 'LocalBusiness (genérico)' ); foreach ( Digitalisimo_Integrations_Schema_Vocabulary::subtypes( 'LocalBusiness' ) as $type ) if ( 'LocalBusiness' !== $type ) $out[ $type ] = $type; return $out; }
	public static function init() {
		// El sitemap propio sustituye las rutas técnicas del núcleo de WordPress.
		add_filter( 'wp_sitemaps_enabled', array( __CLASS__, 'sitemap_enabled' ), PHP_INT_MAX );
		if ( ! Digitalisimo_Integrations_Settings::get( 'enable_seo' ) ) return;
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 25 );
		add_action( 'add_meta_boxes', array( __CLASS__, 'metaboxes' ) ); add_action( 'save_post', array( __CLASS__, 'save_post' ), 15 ); add_action( 'wp_after_insert_post', array( __CLASS__, 'ensure_post_author' ), 15, 4 ); 
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'editor_assets' ) );
		// El editor de snippet es el panel principal de SEO: nunca debe quedar
		// perdido por una preferencia heredada del usuario en Gutenberg.
		add_filter( 'hidden_meta_boxes', array( __CLASS__, 'keep_snippet_visible' ), 10, 2 );
		add_action( 'init', array( __CLASS__, 'taxonomies' ) ); add_action( 'created_term', array( __CLASS__, 'save_term' ), 10, 3 ); add_action( 'edited_term', array( __CLASS__, 'save_term' ), 10, 3 );
		remove_action( 'wp_head', 'rel_canonical' ); add_filter( 'pre_get_document_title', array( __CLASS__, 'title' ), 20 ); add_action( 'wp_head', array( __CLASS__, 'mobile_horizontal_scroll_css' ), 0 ); add_action( 'wp_head', array( __CLASS__, 'head' ), 1 ); add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
		add_action( 'template_redirect', array( __CLASS__, 'attachment_redirect' ) ); add_action( 'template_redirect', array( __CLASS__, 'archive_redirect' ), 1 ); add_shortcode( 'digitalisimo_breadcrumbs', array( __CLASS__, 'breadcrumb_shortcode' ) );
		if ( is_multisite() ) { add_action( 'network_admin_edit_digitalisimo_save_network_seo', array( __CLASS__, 'save_network' ) ); add_action( 'admin_post_digitalisimo_clone_site', array( __CLASS__, 'create_clone' ) ); add_action( 'network_admin_menu', array( __CLASS__, 'clone_menu' ), 40 ); add_action( 'digitalisimo_seo_clone_site', array( __CLASS__, 'run_clone' ) ); add_filter( 'manage_sites_action_links', array( __CLASS__, 'site_clone_action' ), 20, 3 ); }
	}
	private static function o( $key, $default = '' ) { return Digitalisimo_Integrations_Settings::get( $key, $default ); }
	private static function m( $id, $key, $default = '' ) { return Digitalisimo_Integrations_SEO_Resolver::post( $id, $key, $default ); }
	/** Referencia visible para las plantillas de títulos y descripciones. */
	private static function template_variables_help() {
		echo '<tr><th colspan="2"><h2>Variables disponibles</h2><p class="description">Puedes combinarlas en títulos y descripciones. Cada variable se sustituye al mostrar la página pública.</p><ul class="digitalisimo-template-variables"><li><code>%title%</code> Título del contenido, página o archivo actual.</li><li><code>%sitename%</code> Nombre SEO configurado para este sitio; si no existe, el nombre de WordPress.</li><li><code>%sep%</code> Separador de títulos configurado en Identidad.</li><li><code>%excerpt%</code> Extracto del contenido; si no hay extracto, usa el resumen disponible.</li><li><code>%term%</code> Nombre de la categoría, etiqueta u otro término que se está consultando.</li><li><code>%description%</code> Descripción del término o archivo actual.</li><li><code>%page%</code> Número de página de la paginación, sólo cuando aplica.</li></ul></th></tr>';
	}
	/** WordPress conserva el autor asignado; sólo rellena publicaciones nuevas que lleguen sin autor. */
	public static function ensure_post_author( $post_id, $post, $update, $post_before ) { if ( $update || ! $post || ! in_array( $post->post_type, self::editable_types(), true ) || absint( $post->post_author ) || ! get_current_user_id() ) return; remove_action( 'wp_after_insert_post', array( __CLASS__, 'ensure_post_author' ), 15 ); wp_update_post( array( 'ID' => $post_id, 'post_author' => get_current_user_id() ) ); add_action( 'wp_after_insert_post', array( __CLASS__, 'ensure_post_author' ), 15, 4 ); }
	private static function list_value( $key ) { return array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', (string) self::o( $key ) ) ) ) ); }
	/** Admite comas, espacios o saltos de línea para no vaciar el sitemap por formato. */
	public static function sanitize_sitemap_list( $raw ) { $values = array(); foreach ( preg_split( '/[\s,;]+/', is_scalar( $raw ) ? (string) $raw : '', -1, PREG_SPLIT_NO_EMPTY ) as $item ) { $item = sanitize_key( $item ); if ( $item ) $values[ $item ] = true; } return implode( ',', array_slice( array_keys( $values ), 0, 50 ) ); }
	private static function editable_types() { return get_post_types( array( 'public' => true, 'show_ui' => true ), 'names' ); }
	public static function menu() {
		// Un único acceso SEO. Los ajustes viven en pestañas para no dispersar la navegación.
		add_submenu_page( 'digitalisimo', 'SEO', 'SEO', 'manage_options', 'digitalisimo-seo', array( __CLASS__, 'page' ) );
		$advanced = array( 'digitalisimo-seo-general', 'digitalisimo-seo-titles', 'digitalisimo-seo-appearance', 'digitalisimo-seo-schema', 'digitalisimo-seo-local', 'digitalisimo-seo-social', 'digitalisimo-seo-sitemap', 'digitalisimo-seo-robots', 'digitalisimo-seo-indexing', 'digitalisimo-seo-breadcrumbs', 'digitalisimo-seo-diagnostic', 'digitalisimo-seo-performance', 'digitalisimo-seo-tools', 'digitalisimo-seo-audit', 'digitalisimo-seo-redirections', 'digitalisimo-seo-monitor404', 'digitalisimo-seo-import' );
		foreach ( $advanced as $slug ) add_submenu_page( null, 'SEO', 'SEO', 'manage_options', $slug, array( __CLASS__, 'page' ) );
		$editorial = array( 'digitalisimo-content' => array( 'Contenido', 'content_page' ), 'digitalisimo-keywords' => array( 'Keywords', 'keywords_page' ), 'digitalisimo-clusters' => array( 'Clusters', 'clusters_page' ), 'digitalisimo-intents' => array( 'Intención SEO', 'intents_page' ) );
		foreach ( $editorial as $slug => $page ) add_submenu_page( null, $page[0], $page[0], 'manage_options', $slug, array( 'Digitalisimo_Integrations_SEO', $page[1] ) );
	}
	/** Una navegación persistente para los ajustes y la estrategia editorial de SEO. */
	private static function navigation_items() { return array( 'dashboard' => 'Resumen', 'general' => 'Identidad', 'titles' => 'Títulos', 'schema' => 'Schema', 'social' => 'Social', 'local' => 'Local', 'indexing' => 'Indexación', 'sitemap' => 'Sitemap', 'robots' => 'Robots', 'redirections' => 'Redirecciones', 'monitor404' => 'Monitor 404', 'breadcrumbs' => 'Breadcrumbs', 'import' => 'Importar', 'content' => 'Contenido', 'audit' => 'Auditoría' ); }
	/** Mismo componente de navegación para sitio y red; sólo cambia el destino de los enlaces. */
	public static function navigation_tabs( $active = 'dashboard', $network = false ) {
		echo '<h2 class="nav-tab-wrapper digitalisimo-tabs">'; foreach ( self::navigation_items() as $tab => $label ) { $target = 'dashboard' === $tab ? 'digitalisimo-seo' : ( 'content' === $tab ? 'digitalisimo-content' : 'digitalisimo-seo-' . $tab ); $url = $network ? network_admin_url( 'admin.php?page=digitalisimo-network-seo&tab=' . $tab ) : admin_url( 'admin.php?page=' . $target ); echo '<a class="nav-tab ' . ( $active === $tab ? 'nav-tab-active' : '' ) . '"' . ( $network ? ' data-tab="' . esc_attr( $tab ) . '"' : '' ) . ' href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>'; } echo '</h2>';
	}
	/**
	 * «Clonar sitio» bajo Red → Digitalisimo (el menú de red que crea el núcleo compartido). El enlace «Duplicar» de Red →
	 * Sitios abre esta página: sin registrarla, WordPress responde «no tienes permisos para acceder a esta página».
	 */
	public static function clone_menu() { add_submenu_page( 'digitalisimo-network', 'Clonar sitio', 'Clonar sitio', 'manage_network_options', 'digitalisimo-network-seo-clone', array( __CLASS__, 'clone_page' ) ); }
	/** Enlace contextual en Red → Sitios; sólo lo ven los superadministradores. */
	public static function site_clone_action( $actions, $site_id, $blogname = '' ) { $site_id = absint( $site_id ); if ( ! is_network_admin() || ! current_user_can( 'manage_network_options' ) || ! is_super_admin() || ! $site_id ) return $actions; $actions['digitalisimo_clone'] = '<a href="' . esc_url( add_query_arg( array( 'page' => 'digitalisimo-network-seo-clone', 'source_site' => $site_id ), network_admin_url( 'admin.php' ) ) ) . '">Duplicar</a>'; return $actions; }
	/** La clonación sólo existe en el administrador de red y nunca se expone dentro de un sitio. */
	public static function clone_page() {
		if ( ! is_multisite() || ! is_network_admin() || ! current_user_can( 'manage_network_options' ) || ! is_super_admin() ) return;
		$sites = get_sites( array( 'number' => 0, 'orderby' => 'domain', 'order' => 'ASC' ) ); $selected_source = absint( $_GET['source_site'] ?? 0 ); $status = sanitize_key( $_GET['clone_status'] ?? '' );
		echo '<div class="wrap digitalisimo-admin-shell"><h1>Clonar sitio</h1><p>Copia un sitio completo de esta red para usarlo como nueva base SEO. Incluye contenido, medios, tema, diseños de DIGITALÍSIMO Elements (kit, plantillas y CSS), opciones, configuración SEO y permisos del sitio origen. El destino permanece privado hasta terminar la copia.</p>';
		if ( 'queued' === $status ) echo '<div class="notice notice-info"><p>El clon se creó y la copia quedó programada. Recarga esta pantalla para ver su estado.</p></div>'; elseif ( 'complete' === $status ) echo '<div class="notice notice-success"><p>La clonación terminó correctamente.</p></div>'; elseif ( 'error' === $status ) echo '<div class="notice notice-error"><p>No fue posible completar la clonación. Revisa el estado mostrado abajo.</p></div>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="digitalisimo_clone_site">'; wp_nonce_field( 'digitalisimo_clone_site' ); echo '<table class="form-table"><tr><th><label for="digitalisimo_clone_source">Sitio origen</label></th><td><select id="digitalisimo_clone_source" name="source_site" required>'; foreach ( $sites as $site ) echo '<option value="' . esc_attr( $site->blog_id ) . '" ' . selected( $selected_source, $site->blog_id, false ) . '>' . esc_html( get_site_url( $site->blog_id, '/' ) . ' · ' . get_blog_option( $site->blog_id, 'blogname' ) ) . '</option>'; echo '</select></td></tr><tr><th><label for="digitalisimo_clone_url">Nueva URL o subdominio</label></th><td><input class="regular-text" id="digitalisimo_clone_url" name="destination" required placeholder="https://nuevo.ejemplo.com/ o nuevo"><p class="description">Usa una URL completa. También puedes escribir sólo un subdominio si la red está configurada por subdominios.</p></td></tr><tr><th>Confirmación</th><td><label><input type="checkbox" name="confirm" value="1" required> Entiendo que se copiará todo el sitio origen al destino.</label></td></tr></table>'; submit_button( 'Crear clon del sitio', 'primary', 'submit', false ); echo '</form>';
		$jobs = (array) get_site_option( 'digitalisimo_seo_clone_jobs', array() ); if ( $jobs ) { echo '<h2>Clonaciones recientes</h2><table class="widefat striped"><thead><tr><th>Destino</th><th>Origen</th><th>Estado</th><th>Detalle</th></tr></thead><tbody>'; foreach ( array_reverse( $jobs, true ) as $job ) echo '<tr><td>' . esc_html( $job['destination'] ?? '' ) . '</td><td>' . esc_html( $job['source_url'] ?? '' ) . '</td><td>' . esc_html( $job['status'] ?? '' ) . '</td><td>' . esc_html( $job['message'] ?? '' ) . '</td></tr>'; echo '</tbody></table>'; }
		echo '</div>';
	}
	private static function clone_destination( $raw ) {
		$raw = trim( (string) $raw ); if ( ! $raw ) return new WP_Error( 'digitalisimo_clone_url', 'Escribe la nueva URL o subdominio.' );
		if ( false === strpos( $raw, '://' ) ) { if ( false === strpos( $raw, '.' ) && is_subdomain_install() ) { $network = get_network(); $raw .= '.' . $network->domain; } $raw = 'https://' . $raw; }
		$parts = wp_parse_url( $raw ); $domain = strtolower( $parts['host'] ?? '' ); $path = '/' . trim( (string) ( $parts['path'] ?? '' ), '/' ) . '/'; if ( '/' === $path ) $path = '/';
		if ( ! $domain || ! preg_match( '/^[a-z0-9.-]+$/', $domain ) ) return new WP_Error( 'digitalisimo_clone_url', 'La URL de destino no es válida.' );
		return array( 'domain' => $domain, 'path' => $path );
	}
	public static function create_clone() {
		if ( ! is_multisite() || ! current_user_can( 'manage_network_options' ) || ! is_super_admin() || ! check_admin_referer( 'digitalisimo_clone_site' ) ) wp_die( 'No autorizado.' );
		$source_id = absint( $_POST['source_site'] ?? 0 ); $source = get_site( $source_id ); $destination = self::clone_destination( wp_unslash( $_POST['destination'] ?? '' ) );
		if ( ! $source || is_wp_error( $destination ) || empty( $_POST['confirm'] ) ) { wp_safe_redirect( add_query_arg( array( 'page' => 'digitalisimo-network-seo-clone', 'clone_status' => 'error' ), network_admin_url( 'admin.php' ) ) ); exit; }
		if ( get_site_by_path( $destination['domain'], $destination['path'], 1 ) ) { wp_safe_redirect( add_query_arg( array( 'page' => 'digitalisimo-network-seo-clone', 'clone_status' => 'error' ), network_admin_url( 'admin.php' ) ) ); exit; }
		$title = get_blog_option( $source_id, 'blogname', $source->domain ); $target_id = wpmu_create_blog( $destination['domain'], $destination['path'], $title, get_current_user_id(), array( 'public' => 0 ), get_current_network_id() );
		if ( is_wp_error( $target_id ) ) { wp_safe_redirect( add_query_arg( array( 'page' => 'digitalisimo-network-seo-clone', 'clone_status' => 'error' ), network_admin_url( 'admin.php' ) ) ); exit; }
		$jobs = (array) get_site_option( 'digitalisimo_seo_clone_jobs', array() ); $jobs[ $target_id ] = array( 'source_id' => $source_id, 'source_url' => get_site_url( $source_id, '/' ), 'destination' => get_site_url( $target_id, '/' ), 'status' => 'queued', 'message' => 'Esperando la tarea de clonación.', 'created' => time() ); update_site_option( 'digitalisimo_seo_clone_jobs', $jobs ); wp_schedule_single_event( time() + 5, 'digitalisimo_seo_clone_site', array( $target_id ) ); spawn_cron(); wp_safe_redirect( add_query_arg( array( 'page' => 'digitalisimo-network-seo-clone', 'clone_status' => 'queued' ), network_admin_url( 'admin.php' ) ) ); exit;
	}
	private static function clone_tables( $source_id ) { global $wpdb; $prefix = $wpdb->get_blog_prefix( $source_id ); $like = $wpdb->esc_like( $prefix ) . '%'; $tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) ); if ( 1 === (int) $source_id ) $tables = array_filter( $tables, function( $table ) use ( $prefix ) { return ! preg_match( '/^' . preg_quote( $prefix, '/' ) . '[0-9]+_/', $table ); } ); return array_values( $tables ); }
	private static function clone_replace_value( $value, $replacements ) { if ( ! is_string( $value ) || '' === $value ) return $value; if ( is_serialized( $value ) ) { $unserialized = maybe_unserialize( $value ); $walk = function( $item ) use ( &$walk, $replacements ) { if ( is_array( $item ) ) { foreach ( $item as $key => $value ) $item[ $key ] = $walk( $value ); return $item; } if ( is_object( $item ) ) { foreach ( get_object_vars( $item ) as $key => $value ) $item->$key = $walk( $value ); return $item; } return is_string( $item ) ? strtr( $item, $replacements ) : $item; }; return serialize( $walk( $unserialized ) ); } return strtr( $value, $replacements ); }
	private static function clone_members( $source_id, $target_id ) { global $wpdb; $source_prefix = $wpdb->get_blog_prefix( $source_id ); $target_prefix = $wpdb->get_blog_prefix( $target_id ); foreach ( array( 'capabilities', 'user_level' ) as $suffix ) { $rows = $wpdb->get_results( $wpdb->prepare( "SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = %s", $source_prefix . $suffix ), ARRAY_A ); foreach ( $rows as $row ) update_user_meta( $row['user_id'], $target_prefix . $suffix, maybe_unserialize( $row['meta_value'] ) ); } }
	/** Copia tablas con prefijo del sitio, archivos de uploads y referencias URL, sin tocar tablas globales de la red. */
	public static function run_clone( $target_id ) {
		global $wpdb; $target_id = absint( $target_id ); $jobs = (array) get_site_option( 'digitalisimo_seo_clone_jobs', array() ); $job = $jobs[ $target_id ] ?? null; if ( ! $job || 'queued' !== $job['status'] ) return; $source_id = absint( $job['source_id'] ?? 0 ); if ( ! get_site( $source_id ) || ! get_site( $target_id ) ) return;
		$jobs[ $target_id ]['status'] = 'running'; $jobs[ $target_id ]['message'] = 'Copiando tablas, medios y configuración.'; update_site_option( 'digitalisimo_seo_clone_jobs', $jobs );
		try {
			$source_prefix = $wpdb->get_blog_prefix( $source_id ); $target_prefix = $wpdb->get_blog_prefix( $target_id ); $old_url = get_site_url( $source_id, '/' ); $new_url = get_site_url( $target_id, '/' );
			switch_to_blog( $source_id ); $source_uploads = wp_upload_dir(); restore_current_blog(); switch_to_blog( $target_id ); $target_uploads = wp_upload_dir(); restore_current_blog();
			$replacements = array( untrailingslashit( $source_uploads['baseurl'] ) => untrailingslashit( $target_uploads['baseurl'] ), untrailingslashit( $old_url ) => untrailingslashit( $new_url ) ); uksort( $replacements, function( $a, $b ) { return strlen( $b ) <=> strlen( $a ); } );
			foreach ( self::clone_tables( $source_id ) as $source_table ) { $suffix = substr( $source_table, strlen( $source_prefix ) ); $target_table = $target_prefix . $suffix; $wpdb->query( "DROP TABLE IF EXISTS `{$target_table}`" ); if ( false === $wpdb->query( "CREATE TABLE `{$target_table}` LIKE `{$source_table}`" ) ) throw new Exception( 'No se pudo crear la tabla ' . $suffix . '.' ); $columns = $wpdb->get_results( "SHOW COLUMNS FROM `{$source_table}`", ARRAY_A ); $text_columns = array(); foreach ( $columns as $column ) if ( preg_match( '/char|text|json/i', $column['Type'] ) ) $text_columns[] = $column['Field']; $rows = $wpdb->get_results( "SELECT * FROM `{$source_table}`", ARRAY_A ); foreach ( $rows as $row ) { foreach ( $text_columns as $column ) if ( array_key_exists( $column, $row ) ) $row[ $column ] = self::clone_replace_value( $row[ $column ], $replacements ); if ( false === $wpdb->insert( $target_table, $row ) ) throw new Exception( 'No se pudo copiar datos de ' . $suffix . '.' ); } }
			$wpdb->query( $wpdb->prepare( "UPDATE `{$target_prefix}options` SET option_name = REPLACE(option_name, %s, %s) WHERE option_name LIKE %s", $source_prefix, $target_prefix, $wpdb->esc_like( $source_prefix ) . '%' ) ); self::clone_members( $source_id, $target_id );
			if ( is_dir( $source_uploads['basedir'] ) ) { require_once ABSPATH . 'wp-admin/includes/file.php'; wp_mkdir_p( $target_uploads['basedir'] ); $copied = copy_dir( $source_uploads['basedir'], $target_uploads['basedir'] ); if ( is_wp_error( $copied ) ) throw new Exception( $copied->get_error_message() ); }
			$source_site = get_site( $source_id ); update_blog_status( $target_id, 'public', (int) $source_site->public ); clean_blog_cache( $target_id ); $jobs[ $target_id ]['status'] = 'complete'; $jobs[ $target_id ]['message'] = 'Sitio clonado correctamente.';
		} catch ( Throwable $error ) { $jobs[ $target_id ]['status'] = 'error'; $jobs[ $target_id ]['message'] = $error->getMessage(); update_blog_status( $target_id, 'public', 0 ); }
		update_site_option( 'digitalisimo_seo_clone_jobs', $jobs );
	}
	public static function network_page() {
		if ( ! is_multisite() || ! current_user_can( 'manage_network_options' ) || ! is_super_admin() ) return;
		$tab = sanitize_key( $_GET['tab'] ?? 'dashboard' ); $tabs = self::navigation_items(); if ( ! isset( $tabs[ $tab ] ) ) $tab = 'dashboard';
		echo '<div class="wrap digitalisimo-admin-shell"><h1>SEO · Digitalisimo · Red</h1><p>Estas reglas comunes se heredan en los sitios que no tengan una personalización propia. La identidad SEO e imágenes predeterminadas se configuran siempre dentro de cada sitio.</p>';
		self::navigation_tabs( $tab, true ); echo '<form method="post" action="' . esc_url( network_admin_url( 'edit.php?action=digitalisimo_save_network_seo' ) ) . '">'; wp_nonce_field( 'digitalisimo_network_seo' ); echo '<input type="hidden" class="digitalisimo-active-tab" name="digitalisimo_active_tab" value="' . esc_attr( $tab ) . '">';
		foreach ( $tabs as $slug => $name ) { echo '<div class="digitalisimo-panel" data-tab="' . esc_attr( $slug ) . '"' . ( $slug === $tab ? '' : ' hidden' ) . '><table class="form-table" role="presentation">'; self::network_site_fields( $slug ); echo '</table></div>'; } submit_button( 'Guardar configuración de red' ); echo '</form></div>';
	}
	/** Claves y credenciales de la red: nunca se devuelven al formulario en claro. */
	private static function secret_keys() { return array( 'openai_api_key', 'namecheap_api_key', 'ipinfo_tokens' ); }
	/** Opciones cuyo valor es la URL de un archivo. */
	public static function media_keys() { return array( 'seo_logo', 'seo_default_image', 'seo_favicon_source' ); }
	private static $network_tracking_prefill = array();
	private static function nf( $key, $label, $type = 'text', $help = '' ) { $all = (array) get_site_option( Digitalisimo_Integrations_Settings::OPTION, array() ); $defaults = Digitalisimo_Integrations_Settings::defaults(); $value = $all[ $key ] ?? ( $defaults[ $key ] ?? '' ); $site_kit_prefilled = '' === (string) $value && ! empty( self::$network_tracking_prefill[ $key ] ); if ( $site_kit_prefilled ) $value = self::$network_tracking_prefill[ $key ]; $secret = in_array( $key, self::secret_keys(), true ); $is_default = ! $site_kit_prefilled && ( ! array_key_exists( $key, $all ) || $value == ( $defaults[ $key ] ?? null ) ); $class = $is_default ? ' digitalisimo-default-value' : ''; $name = 'digitalisimo_network[' . $key . ']'; echo '<tr' . ( 'perf_font_guard_allowlist' === $key ? ' class="digitalisimo-font-manual-row"' : '' ) . '><th scope="row"><label for="network_' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>'; if ( 'media' === $type ) { Digitalisimo_Media_Field::render( 'network_' . $key, $name, $value, false, trim( $class ) ); } elseif ( 'checkbox' === $type ) echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="0"><label><input class="' . esc_attr( trim( $class ) ) . '" type="checkbox" id="network_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, 1, false ) . '> Activar</label>'; elseif ( 'select' === $type ) { $choices = func_get_arg( 4 ); echo '<select class="' . esc_attr( trim( $class ) ) . '" id="network_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">'; foreach ( (array) $choices as $option => $text ) echo '<option value="' . esc_attr( $option ) . '" ' . selected( $value, $option, false ) . '>' . esc_html( $text ) . '</option>'; echo '</select>'; } elseif ( $secret && 'textarea' === $type ) echo '<textarea class="large-text' . esc_attr( $class ) . '" rows="4" id="network_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" placeholder="Uno por línea"></textarea>'; elseif ( 'textarea' === $type ) echo '<textarea class="large-text' . esc_attr( $class ) . '" rows="' . ( 'seo_robots_rules' === $key ? '12' : '4' ) . '" id="network_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">' . esc_textarea( $value ) . '</textarea>'; elseif ( $secret ) echo '<input class="regular-text' . esc_attr( $class ) . '" type="password" autocomplete="new-password" id="network_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="" placeholder="' . esc_attr( ! empty( $value ) ? Digitalisimo_Integrations_Settings::MASK : 'API Key' ) . '">'; else echo '<input class="regular-text' . esc_attr( $class ) . '" type="' . esc_attr( $type ) . '" id="network_' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">'; if ( $secret ) echo ' <span class="digitalisimo-secret ' . ( ! empty( $value ) ? 'is-set' : 'is-empty' ) . '">' . esc_html( ! empty( $value ) ? 'Guardada · escribe una nueva sólo si quieres reemplazarla' : 'Sin configurar' ) . '</span>'; if ( $help ) echo '<p class="description">' . esc_html( $help ) . '</p>'; if ( $is_default ) echo '<p class="description digitalisimo-default-note">Valor predeterminado del plugin.</p>'; echo '</td></tr>'; }
	private static function network_cluster_field() { $key = 'default_cluster_pillar'; $all = (array) get_site_option( Digitalisimo_Integrations_Settings::OPTION, array() ); $value = (string) ( $all[ $key ] ?? '' ); echo '<tr><th scope="row"><label for="network_default_cluster_pillar">Contenido pilar predeterminado</label></th><td>'; Digitalisimo_Integrations_Editorial::cluster_slug_select( 'digitalisimo_network[' . $key . ']', $value, 'network_default_cluster_pillar' ); echo '<p class="description">Se guarda por slug y se vincula al contenido publicado equivalente de cada sitio que hereda la configuración de red. Se asigna sólo a contenido nuevo.</p></td></tr>'; }
	/** En red se muestra el sitemap del sitio principal; cada subsitio muestra el suyo. */
	public static function sitemap_link_row( $network = false ) {
		$url = $network ? get_home_url( get_main_site_id(), '/sitemap.xml' ) : home_url( '/sitemap.xml' );
		echo '<tr><th scope="row">URL del sitemap</th><td><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $url ) . '</a> <a class="button button-secondary" href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">Ver sitemap</a>';
		if ( $network ) echo '<p class="description">Este enlace abre el sitemap del sitio principal. Cada sitio de la red tiene su propio enlace en Digitalisimo → SEO → Sitemap.</p>';
		elseif ( ! is_multisite() ) {
			echo '<p class="description">Sitemaps por tipo de contenido:</p><ul>';
			foreach ( Digitalisimo_Integrations_Sitemap::filenames() as $filename ) {
				$part_url = home_url( '/' . $filename );
				echo '<li><a href="' . esc_url( $part_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $part_url ) . '</a></li>';
			}
			echo '</ul>';
		}
		echo '</td></tr>';
	}
	/** El archivo público se abre en otra pestaña; un archivo físico anula esta salida dinámica. */
	public static function robots_info_row( $network = false ) {
		$url = $network ? get_home_url( get_main_site_id(), '/robots.txt' ) : home_url( '/robots.txt' );
		echo '<tr><th scope="row">robots.txt público</th><td><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $url ) . '</a> <a class="button button-secondary" href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">Ver robots.txt</a>';
		if ( $network ) echo '<p class="description">La red define reglas predeterminadas. Cada sitio puede heredarlas o personalizarlas; este enlace abre el sitio principal.</p>';
		if ( $network ) echo '<p class="description">Las reglas automáticas de bots se cambian en <a href="' . esc_url( network_admin_url( 'admin.php?page=digitalisimo-network-seo-ai-crawlers' ) ) . '">SEO AI → Rastreadores</a>.</p>';
		else echo '<p class="description">Las reglas automáticas de bots se cambian en <a href="' . esc_url( admin_url( 'admin.php?page=digitalisimo-seo-ai-crawlers' ) ) . '">SEO AI → Rastreadores</a>.</p>';
		if ( ! $network ) {
			$blocked = array();
			foreach ( Digitalisimo_Integrations_SEO_AI::crawlers() as $id => $crawler ) if ( 'disallow' === Digitalisimo_Integrations_SEO_AI::crawler_rule( $id, $crawler ) ) $blocked[] = $crawler['name'];
			if ( $blocked ) echo '<p class="notice notice-warning inline"><strong>Bloqueos específicos guardados:</strong> ' . esc_html( implode( ', ', $blocked ) ) . '. Para retirarlos, aplica «Máxima visibilidad» en SEO AI → Rastreadores. Si este sitio hereda de la red, desmarca la herencia para personalizarlo. Google-Extended se controla abajo.</p>';
		}
		if ( file_exists( ABSPATH . 'robots.txt' ) ) echo '<p class="notice notice-warning inline"><strong>Hay un robots.txt físico.</strong> Puede prevalecer sobre las reglas dinámicas; este editor no modifica ese archivo.</p>';
		if ( ! $network && '/' !== wp_parse_url( home_url( '/' ), PHP_URL_PATH ) ) echo '<p class="notice notice-warning inline">Los buscadores consultan robots.txt en la raíz del dominio. En un sitio bajo subdirectorio, configura las reglas del dominio en el sitio principal.</p>';
		echo '</td></tr>';
	}
	public static function robots_preview_row() {
		echo '<tr><th scope="row">Salida actual</th><td><p class="description">Vista previa de las reglas guardadas. Los cambios del formulario aparecerán después de guardar.</p><pre style="max-height:360px;overflow:auto;white-space:pre-wrap;background:#fff;border:1px solid var(--digi-line,#dce4ff);padding:12px">' . esc_html( Digitalisimo_Integrations_Robots::preview() ) . '</pre></td></tr>';
	}
	/** La red replica las pestañas del sitio y omite identidad e imágenes exclusivas de cada sitio. */
	private static function network_site_fields( $tab ) {
		if ( 'dashboard' === $tab ) { echo '<tr><td colspan="2"><p>Configura valores compartidos desde las mismas secciones que aparecen en cada sitio. El nombre SEO y las imágenes predeterminadas se configuran siempre dentro de cada sitio.</p></td></tr>'; return; }
		if ( 'general' === $tab ) { self::nf( 'seo_separator', 'Separador de títulos', 'select', '', self::separator_choices() ); self::nf( 'seo_organization_type', 'Tipo de entidad', 'select', self::ENTITY_HELP, self::entity_type_choices() ); self::nf( 'seo_organization_name', 'Nombre de organización' ); self::nf( 'seo_organization_url', 'URL principal', 'url' ); self::nf( 'seo_organization_email', 'Email' ); self::nf( 'seo_logo', 'Logotipo', 'media' ); Digitalisimo_Integrations_Social_Profiles::network_fields(); self::nf( 'seo_knowledge_urls', 'Otros perfiles', 'textarea', 'Sólo para perfiles sin campo propio. Uno por línea.' ); self::verification_fields( true ); return; }
		if ( 'titles' === $tab ) { self::template_variables_help(); self::nf( 'seo_title_post', 'Título de entradas' ); self::nf( 'seo_description_post', 'Descripción de entradas', 'textarea' ); self::nf( 'seo_title_page', 'Título de páginas' ); self::nf( 'seo_description_page', 'Descripción de páginas', 'textarea' ); self::nf( 'seo_title_archive', 'Título de archivos' ); self::nf( 'seo_description_archive', 'Descripción de archivos', 'textarea' ); return; }
		if ( 'schema' === $tab ) { self::nf( 'seo_schema_enabled', 'Schema JSON-LD', 'checkbox' ); self::nf( 'seo_schema_unify', 'Unificar el schema de la página', 'checkbox', self::UNIFY_HELP ); self::nf( 'seo_alt_optimize', 'Optimizar ALT en la salida', 'checkbox' ); self::nf( 'seo_alt_keyword_mode', 'Palabra clave de apoyo para ALT', 'select', 'La palabra clave se define en cada sitio.', array( 'off' => 'Desactivado', 'fallback' => 'Sólo fallback', 'contextual' => 'Contextual' ) ); return; }
		if ( 'social' === $tab ) { self::nf( 'seo_open_graph', 'Open Graph activo', 'checkbox' ); self::nf( 'seo_twitter_enabled', 'Twitter Cards activas', 'checkbox' ); self::nf( 'seo_twitter_user', 'Usuario X/Twitter' ); echo '<tr><th scope="row">Imagen predeterminada</th><td><p class="description">Se configura en cada sitio para no mezclar marcas, bibliotecas y dominios.</p></td></tr>'; return; }
		if ( 'local' === $tab ) { self::nf( 'seo_local_enabled', 'Activar SEO local', 'checkbox' ); self::nf( 'seo_local_type', 'Tipo de negocio', 'select', self::LOCAL_TYPE_HELP, self::local_type_choices() ); self::nf( 'seo_local_name', 'Nombre comercial' ); echo '<tr><th scope="row">Teléfono</th><td>'; Digitalisimo_Integrations_Local_Business::network_phone_field(); echo '</td></tr>'; self::nf( 'seo_local_address', 'Calle y número', 'textarea' ); self::nf( 'seo_local_city', 'Ciudad' ); self::nf( 'seo_local_region', 'Estado / región' ); self::nf( 'seo_local_postal', 'Código postal' ); self::nf( 'seo_local_country', 'País ISO' ); self::nf( 'seo_local_latitude', 'Latitud' ); self::nf( 'seo_local_longitude', 'Longitud' ); echo '<tr><th scope="row">Horario</th><td>'; Digitalisimo_Integrations_Local_Business::network_schedule_field(); echo '</td></tr>'; self::nf( 'seo_local_price_range', 'Rango de precio' ); return; }
		if ( 'indexing' === $tab ) { foreach ( array( 'noindex_search' => 'Resultados de búsqueda internos', 'noindex_authors' => 'Archivos de autor', 'noindex_empty_tags' => 'Etiquetas vacías', 'noindex_date_archives' => 'Archivos por fecha', 'noindex_attachments' => 'Páginas de adjuntos', 'noindex_elementor' => 'Plantillas del constructor (DIGITALÍSIMO Elements)', 'noindex_woo_pages' => 'Carrito, checkout, gracias y mi cuenta' ) as $key => $label ) self::nf( $key, $label, 'checkbox' ); self::nf( 'noindex_page_slugs', 'Slugs noindex', 'textarea' ); self::nf( 'noindex_page_ids', 'IDs noindex', 'textarea' ); self::advanced_robots_fields( true ); return; }
		if ( 'redirections' === $tab ) { self::redirect_fields( true ); return; }
		if ( 'monitor404' === $tab ) { self::monitor_fields( true ); return; }
		if ( 'import' === $tab ) { Digitalisimo_Integrations_RankMath_Import::render_network(); return; }
		if ( 'sitemap' === $tab ) { self::sitemap_link_row( true ); self::nf( 'sitemap_enabled', 'Activar sitemap XML', 'checkbox' ); self::nf( 'sitemap_post_types', 'Tipos incluidos', 'textarea', 'Auto incluye entradas, páginas, productos y otros tipos públicos indexables. Las páginas siempre se incluyen.' ); self::nf( 'sitemap_exclude_ids', 'IDs excluidos', 'textarea' ); self::nf( 'seo_sitemap_images', 'Imágenes en el sitemap', 'checkbox', self::SITEMAP_IMAGES_HELP ); return; }
		if ( 'robots' === $tab ) { self::robots_info_row( true ); self::nf( 'seo_ai_google_extended_policy', 'Google-Extended', 'select', 'Permitir favorece la presencia en Gemini; bloquear limita entrenamiento y grounding en Gemini, pero no afecta Google Search.', array( 'allow' => 'Permitir (máxima visibilidad en Gemini)', 'disallow' => 'Bloquear uso por Gemini' ) ); self::nf( 'seo_robots_rules', 'Reglas adicionales', 'textarea', 'Admite User-agent, Allow y Disallow. El sitemap y las reglas automáticas de WordPress y SEO AI se conservan.' ); return; }
		if ( 'breadcrumbs' === $tab ) { self::nf( 'seo_breadcrumbs', 'Activar breadcrumbs', 'checkbox' ); echo '<tr><th>Uso</th><td><code>[digitalisimo_breadcrumbs]</code><p class="description">También se integra en el JSON-LD de cada contenido.</p></td></tr>'; return; }
		if ( 'performance' === $tab ) { self::performance_network_fields(); return; }
		if ( 'audit' === $tab ) { Digitalisimo_Integrations_SEO_Audit_Hub::render_network(); return; }
		if ( 'content' === $tab ) { self::nf( 'keyword_post_types', 'Tipos de contenido con keywords', 'textarea' ); self::nf( 'keyword_max_count', 'Máximo de keywords objetivo', 'number', 'Máximo 5: una principal y hasta cuatro secundarias de la misma intención.' ); self::nf( 'keyword_auto_from_title', 'Usar título como keyword inicial', 'checkbox' ); self::network_cluster_field(); return; }
	}
	public static function save_network() { if ( ! is_multisite() || ! current_user_can( 'manage_network_options' ) || ! is_super_admin() || ! check_admin_referer( 'digitalisimo_network_seo' ) ) wp_die( 'No autorizado.' ); $input = (array) wp_unslash( $_POST['digitalisimo_network'] ?? array() ); $current = (array) get_site_option( Digitalisimo_Integrations_Settings::OPTION, array() ); $checkboxes = array( 'enable_seo', 'enable_woocommerce', 'enable_ipinfo', 'keyword_auto_from_title', 'seo_local_enabled', 'seo_schema_enabled', 'seo_open_graph', 'seo_twitter_enabled', 'seo_breadcrumbs', 'sitemap_enabled', 'seo_redirect_attachments', 'seo_mobile_prevent_horizontal_scroll', 'noindex_search', 'noindex_authors', 'noindex_empty_tags', 'noindex_date_archives', 'noindex_attachments', 'noindex_elementor', 'noindex_woo_pages', 'require_domain_hosting', 'replace_hosting', 'simplify_checkout', 'perf_safe_mode', 'perf_gutenberg', 'perf_emojis', 'perf_embeds', 'perf_dashicons', 'perf_font_swap', 'perf_css_defer', 'perf_hero_critical', 'perf_caption_normal', 'perf_custom_css_paused', 'perf_tracking_enabled', 'perf_img_enabled', 'perf_img_srcset', 'perf_img_sizes', 'perf_img_dimensions', 'perf_img_lazy', 'perf_img_backgrounds', 'perf_touch_guard', 'seo_ai_llms_enabled', 'seo_sitemap_images', 'seo_redirect_enabled', 'seo_redirect_slug_watch', 'seo_404_enabled', 'seo_404_ignore_query', 'seo_noindex_paginated', 'seo_noindex_password', 'seo_disable_author_archives', 'seo_disable_date_archives', 'seo_alt_optimize', 'seo_schema_unify' ); foreach ( $input as $key => $value ) { if ( ! array_key_exists( $key, Digitalisimo_Integrations_Settings::defaults() ) || in_array( $key, Digitalisimo_Integrations_SEO_Resolver::site_only_keys(), true ) ) continue; if ( in_array( $key, $checkboxes, true ) ) { $current[ $key ] = empty( $value ) ? 0 : 1; continue; } // Un secreto vacío conserva el valor almacenado en lugar de borrarlo.
			if ( 'keyword_max_count' === $key ) { $current[ $key ] = min( 5, max( 1, absint( $value ) ) ); continue; }
			// Redirecciones, 404, verificación y robots avanzados: las mismas reglas que el formulario del sitio.
			if ( 'seo_redirect_default_code' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Redirections::sanitize_code( $value ); continue; }
			if ( 'seo_redirect_fallback_url' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Redirections::sanitize_target( $value ); continue; }
			if ( 'seo_404_limit' === $key ) { $current[ $key ] = Digitalisimo_Integrations_404_Monitor::sanitize_limit( $value ); continue; }
			if ( 'seo_404_retention' === $key ) { $current[ $key ] = Digitalisimo_Integrations_404_Monitor::sanitize_retention( $value ); continue; }
			if ( 'seo_404_exclude' === $key ) { $current[ $key ] = Digitalisimo_Integrations_404_Monitor::sanitize_exclusions( $value ); continue; }
			if ( array_key_exists( $key, Digitalisimo_Integrations_Verification::engines() ) ) { $current[ $key ] = Digitalisimo_Integrations_Verification::sanitize_code( $value ); continue; }
			if ( Digitalisimo_Integrations_Verification::CUSTOM === $key ) { $current[ $key ] = Digitalisimo_Integrations_Verification::sanitize_custom( $value ); continue; }
			if ( in_array( $key, array( 'seo_max_snippet', 'seo_max_video_preview' ), true ) ) { $current[ $key ] = self::sanitize_robots_number( $value ); continue; }
			if ( 'default_cluster_pillar' === $key ) { $pillar = Digitalisimo_Integrations_Editorial::cluster_candidate_id( $value ); $current[ $key ] = $pillar ? get_post_field( 'post_name', $pillar ) : ''; continue; }
			if ( in_array( $key, Digitalisimo_Integrations_Settings::template_default_keys(), true ) && '' === trim( (string) $value ) ) { $defaults = Digitalisimo_Integrations_Settings::defaults(); $current[ $key ] = $defaults[ $key ]; continue; }
			if ( in_array( $key, self::secret_keys(), true ) && '' === trim( (string) $value ) ) continue; // La ruta de acceso necesita su propia validación: un valor reservado dejaría la red sin escritorio.
			if ( Digitalisimo_Integrations_Hide_Login::KEY === $key ) { $current[ $key ] = Digitalisimo_Integrations_Hide_Login::sanitize_slug( $value ); continue; }
			if ( 'seo_default_image_alt' === $key ) { $current[ $key ] = sanitize_text_field( $value ); continue; }
			if ( 'seo_organization_type' === $key ) { $current[ $key ] = array_key_exists( $value, self::entity_type_choices() ) ? $value : 'Organization'; continue; }
			if ( 'seo_separator' === $key ) { $current[ $key ] = array_key_exists( $value, self::separator_choices() ) ? $value : '|'; continue; }
			if ( 'seo_local_type' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Schema_Vocabulary::local_type( sanitize_text_field( $value ) ); continue; }
			if ( 'seo_alt_keyword_mode' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Image_Alt::sanitize_mode( $value ); continue; }
			if ( 'perf_css_defer_handles' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_CSS::sanitize_handles( $value ); continue; }
			if ( Digitalisimo_Integrations_Robots::KEY === $key ) { $current[ $key ] = Digitalisimo_Integrations_Robots::sanitize( $value ); continue; }
			if ( 'seo_ai_google_extended_policy' === $key ) { $current[ $key ] = Digitalisimo_Integrations_SEO_AI::sanitize_google_extended_policy( $value ); continue; }
			if ( in_array( $key, array( 'sitemap_post_types', 'seo_sitemap_taxonomies' ), true ) ) { $current[ $key ] = self::sanitize_sitemap_list( $value ); continue; }
			if ( 'perf_css_defer_exclusions' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_CSS::sanitize_exclusions( $value ); continue; }
			if ( 'perf_custom_css' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_CSS::sanitize_custom_css( $value ); continue; }
			if ( 'perf_font_guard_mode' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Font_Guard::sanitize_mode( $value ); continue; }
			if ( 'perf_font_guard_allowlist' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Font_Guard::sanitize_allowlist( $value ); continue; }
			if ( 'perf_js_jquery_mode' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_JavaScript::sanitize_mode( $value ); continue; }
			if ( 'perf_touch_selectors' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Quality_Audit::sanitize_selectors( $value ); continue; }
			if ( 'seo_ai_llms_mode' === $key ) { $current[ $key ] = Digitalisimo_Integrations_LLMS::sanitize_mode( $value ); continue; }
			if ( 'seo_ai_llms_urls' === $key ) { $current[ $key ] = Digitalisimo_Integrations_LLMS::sanitize_urls( $value ); continue; }
			if ( 'perf_img_mode' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Images::sanitize_mode( $value ); continue; }
			if ( 'perf_img_exclusions' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Images::sanitize_exclusions( $value ); continue; }
			if ( 'perf_font_icon_families' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Font_Guard::sanitize_icon_families( $value ); continue; }
			if ( 'perf_preload_mode' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Preloads::sanitize_mode( $value ); continue; }
			if ( 'perf_preload_paths' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Preloads::sanitize_paths( $value ); continue; }
			if ( 'perf_preload_limit' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Preloads::sanitize_limit( $value ); continue; }
			if ( in_array( $key, array( 'perf_gt_id', 'perf_ga4_id', 'perf_gtm_id' ), true ) ) { $kind = array( 'perf_gt_id' => 'gt', 'perf_ga4_id' => 'ga4', 'perf_gtm_id' => 'gtm' ); $current[ $key ] = Digitalisimo_Integrations_Performance_Tracking::sanitize_id( $value, $kind[ $key ] ); continue; }
			if ( 'perf_tracking_mode' === $key ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Tracking::sanitize_mode( $value ); continue; }
			if ( in_array( $key, array( 'perf_tracking_delay', 'perf_tracking_fallback' ), true ) ) { $current[ $key ] = Digitalisimo_Integrations_Performance_Tracking::sanitize_seconds( $value ); continue; }
			// Las URLs de archivo se guardan como URL, no como texto plano.
			if ( in_array( $key, self::media_keys(), true ) ) { $current[ $key ] = esc_url_raw( trim( (string) $value ) ); continue; }
			if ( Digitalisimo_Integrations_Social_Profiles::KEY === $key ) { $current[ $key ] = Digitalisimo_Integrations_Social_Profiles::sanitize( $value, $current[ $key ] ?? array() ); continue; }
			if ( Digitalisimo_Integrations_Social_Profiles::LEGACY === $key ) { $current[ $key ] = Digitalisimo_Integrations_Social_Profiles::sanitize_extras( $value ); continue; }
			if ( Digitalisimo_Integrations_Local_Business::SCHEDULE === $key ) { $current[ $key ] = Digitalisimo_Integrations_Local_Business::sanitize_schedule( $value ); continue; }
			if ( Digitalisimo_Integrations_Local_Business::PHONE_CC === $key ) { $current[ $key ] = Digitalisimo_Integrations_Local_Business::sanitize_code( $value ); continue; }
			if ( Digitalisimo_Integrations_Local_Business::PHONE === $key ) { $current[ $key ] = Digitalisimo_Integrations_Local_Business::sanitize_phone( $value ); continue; }
			$current[ $key ] = sanitize_textarea_field( $value ); }
		update_site_option( Digitalisimo_Integrations_Settings::OPTION, $current );
		$return = sanitize_key( $_POST['digitalisimo_return'] ?? '' );
		$performance = in_array( $return, array( 'css', 'fonts', 'tracking', 'preloads', 'images', 'javascript', 'a11y' ), true );
		$target = $performance ? network_admin_url( 'admin.php?page=digitalisimo-network-performance&section=' . $return . '&updated=1' ) : network_admin_url( 'admin.php?page=digitalisimo-network-seo&updated=1&tab=' . sanitize_key( $_POST['digitalisimo_active_tab'] ?? 'general' ) );
		$site_id = $performance ? absint( $_POST['digitalisimo_site_id'] ?? 0 ) : 0;
		if ( $site_id && get_site( $site_id ) ) $target = add_query_arg( 'site_id', $site_id, $target );
		wp_safe_redirect( $target );
		exit;
	}
	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) return; $slug = sanitize_key( $_GET['page'] ?? 'digitalisimo-seo' ); $map = array( 'digitalisimo-seo' => 'dashboard', 'digitalisimo-seo-general' => 'general', 'digitalisimo-seo-titles' => 'titles', 'digitalisimo-seo-appearance' => 'appearance', 'digitalisimo-seo-schema' => 'schema', 'digitalisimo-seo-local' => 'local', 'digitalisimo-seo-social' => 'social', 'digitalisimo-seo-sitemap' => 'sitemap', 'digitalisimo-seo-robots' => 'robots', 'digitalisimo-seo-indexing' => 'indexing', 'digitalisimo-seo-breadcrumbs' => 'breadcrumbs', 'digitalisimo-seo-performance' => 'performance', 'digitalisimo-seo-tools' => 'audit', 'digitalisimo-seo-diagnostic' => 'audit', 'digitalisimo-seo-audit' => 'audit', 'digitalisimo-seo-redirections' => 'redirections', 'digitalisimo-seo-monitor404' => 'monitor404', 'digitalisimo-seo-import' => 'import' ); $section = $map[ $slug ] ?? 'dashboard';
		echo '<div class="wrap digitalisimo-admin-shell"><h1>SEO · Digitalisimo</h1><p>Configura las señales SEO del sitio desde un solo lugar.</p>'; self::navigation_tabs( $section );
		if ( 'dashboard' === $section ) { self::dashboard(); echo '</div>'; return; } if ( 'audit' === $section ) { Digitalisimo_Integrations_SEO_Audit_Hub::render(); echo '</div>'; return; } if ( 'import' === $section ) { Digitalisimo_Integrations_RankMath_Import::render(); echo '</div>'; return; }
		if ( 'performance' === $section ) echo '<p>Optimización contextual y reversible. En modo seguro no se retiran recursos centrales del constructor, Swiper ni WooCommerce.</p>';
		echo '<form method="post" action="options.php">'; settings_fields( 'digitalisimo_integrations' ); echo '<table class="form-table" role="presentation">'; self::settings_fields( $section ); echo '</table>'; submit_button( 'Guardar cambios SEO' ); echo '</form>'; if ( 'redirections' === $section ) Digitalisimo_Integrations_Redirections::render_manager(); if ( 'monitor404' === $section ) Digitalisimo_Integrations_404_Monitor::render_log(); if ( 'general' === $section ) Digitalisimo_Integrations_Favicon::render(); if ( 'performance' === $section ) { echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=digitalisimo-performance&section=status' ) ) . '">Abrir diagnóstico de assets</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=digitalisimo-performance&section=measurements' ) ) . '">Abrir mediciones externas</a></p>'; Digitalisimo_Integrations_Performance_Manager::render_log(); } echo '<script>document.querySelectorAll(".digitalisimo-network-inherit").forEach(function(c){var f=document.getElementById(c.dataset.field);function s(){if(f)f.disabled=c.checked;}c.addEventListener("change",s);s();});</script></div>';
	}
	private static function f( $key, $label, $type = 'text', $help = '' ) {
		$value = self::o( $key ); $name = Digitalisimo_Integrations_Settings::OPTION . '[' . $key . ']';
		$site_kit_detected = false;
		if ( in_array( $key, array( 'perf_gt_id', 'perf_ga4_id', 'perf_gtm_id' ), true ) && '' === (string) $value ) {
			$detected = Digitalisimo_Integrations_Performance_Tracking::site_kit_ids();
			if ( ! empty( $detected[ $key ] ) ) { $value = $detected[ $key ]; $site_kit_detected = true; }
		}
		$site_only = in_array( $key, Digitalisimo_Integrations_SEO_Resolver::site_only_keys(), true );
		$inherit = is_multisite() && Digitalisimo_Integrations_SEO_Resolver::inherits_network( $key ); $disabled = $inherit ? ' disabled' : '';
		$defaults = Digitalisimo_Integrations_Settings::defaults(); $is_default = ! $inherit && array_key_exists( $key, $defaults ) && $value == $defaults[ $key ];
		$class = 'digitalisimo-inheritable' . ( $inherit ? ' digitalisimo-inherited-value' : ( $is_default ? ' digitalisimo-default-value' : '' ) );
		echo '<tr' . ( 'perf_font_guard_allowlist' === $key ? ' class="digitalisimo-font-manual-row"' : '' ) . '><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'checkbox' === $type ) echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="0"><label><input class="' . esc_attr( $class ) . '" type="checkbox" id="' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, 1, false ) . $disabled . '> Activar</label>';
		elseif ( 'textarea' === $type ) echo '<textarea class="large-text ' . esc_attr( $class ) . '" rows="' . ( 'seo_robots_rules' === $key ? '12' : '4' ) . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '"' . $disabled . '>' . esc_textarea( $value ) . '</textarea>';
		elseif ( 'media' === $type ) Digitalisimo_Media_Field::render( $key, $name, $value, (bool) $inherit, $class );
		elseif ( 'select' === $type ) { $choices = func_get_arg( 4 ); echo '<select class="' . esc_attr( $class ) . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '"' . $disabled . '>'; foreach ( (array) $choices as $v => $l ) echo '<option value="' . esc_attr( $v ) . '" ' . selected( $value, $v, false ) . '>' . esc_html( $l ) . '</option>'; echo '</select>'; }
		else echo '<input class="regular-text ' . esc_attr( $class ) . '" type="' . esc_attr( $type ) . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . $disabled . '>';
		if ( $help ) echo '<p class="description">' . esc_html( $help ) . '</p>';
		if ( $site_kit_detected ) echo '<p class="description">ID detectado automáticamente de Site Kit para este sitio.</p>';
		if ( $is_default ) echo '<p class="description digitalisimo-default-note">Valor predeterminado del plugin.</p>';
		if ( is_multisite() && ! $site_only ) { $origin = Digitalisimo_Integrations_SEO_Resolver::option_with_origin( $key ); $effective = 'seo_robots_rules' === $key ? ( empty( $origin['value'] ) ? 'Sin reglas adicionales' : 'Reglas disponibles' ) : ( is_scalar( $origin['value'] ) ? (string) $origin['value'] : '' );
			if ( 'checkbox' === $type ) $effective = '<span class="digitalisimo-effective-state ' . ( ! empty( $origin['value'] ) ? 'is-active' : 'is-inactive' ) . '">' . ( ! empty( $origin['value'] ) ? 'Activo' : 'Inactivo' ) . '</span>';
			else $effective = '<strong>' . esc_html( $effective ) . '</strong>';
			echo '<p class="digitalisimo-inheritance"><input type="hidden" name="' . esc_attr( Digitalisimo_Integrations_Settings::OPTION ) . '[network_inherit][' . esc_attr( $key ) . ']" value="0"><label><input class="digitalisimo-network-inherit" data-field="' . esc_attr( $key ) . '" type="checkbox" name="' . esc_attr( Digitalisimo_Integrations_Settings::OPTION ) . '[network_inherit][' . esc_attr( $key ) . ']" value="1" ' . checked( $inherit, true, false ) . '> Heredar de la red</label><br><span class="description">Valor efectivo: ' . $effective . ' · Origen: ' . esc_html( $origin['label'] ) . '</span></p>'; }
		echo '</td></tr>';
	}
	private static function performance_mode_choices( $key ) {
		$choices = array(
			'perf_font_guard_mode' => array( 'off' => 'Apagado', 'auto' => 'Seguro · detectar, permitir y registrar', 'strict' => 'Estricto · sólo variantes autorizadas', 'manual' => 'Manual · sólo la lista' ),
			'perf_preload_mode' => array( 'off' => 'Apagado', 'auto' => 'Automático', 'manual' => 'Manual' ),
			'perf_tracking_mode' => array( 'normal' => 'Normal', 'domcontentloaded' => 'Después de DOMContentLoaded', 'load' => 'Después de window.load', 'interaction' => 'Después de interacción', 'delay' => 'Retraso tras window.load' ),
		);
		return $choices[ $key ] ?? array();
	}

	public static function performance_site_fields() {
		echo '<tr><th colspan="2"><h2>Modo seguro</h2><p>Las opciones siguientes actúan sólo en el frontend público. Editor, administración y vistas previas se excluyen.</p></th></tr>';
		self::f( 'perf_safe_mode', 'Modo seguro', 'checkbox', 'Protege los recursos del constructor (DIGITALÍSIMO Elements), Swiper, formularios, menús y WooCommerce. Las futuras reglas avanzadas no actuarán mientras esté encendido.' );
		echo '<tr><th colspan="2"><h2>WordPress</h2></th></tr>';
		self::f( 'perf_gutenberg', 'Desactivar CSS de Gutenberg fuera del blog', 'checkbox', 'Sólo en páginas confirmadas como hechas con el constructor, sin bloques, shortcodes ni dependientes encolados. Blog y editor se conservan.' );
		self::f( 'perf_emojis', 'Desactivar recursos de emojis', 'checkbox', 'Los caracteres emoji del navegador siguen funcionando.' );
		self::f( 'perf_embeds', 'Desactivar wp-embed cuando no se usa', 'checkbox', 'Sólo en páginas confirmadas como hechas con el constructor, sin embeds ni dependientes.' );
		self::f( 'perf_dashicons', 'No cargar Dashicons para invitados', 'checkbox', 'Sólo sin barra de administración ni dependientes encolados.' );
		echo '<tr><th colspan="2"><h2>Fuentes</h2></th></tr>';
		self::f( 'perf_font_swap', 'font-display: swap en fuentes del constructor', 'checkbox', 'Se aplica a las fuentes Google locales y a las fuentes personalizadas del constructor. Tras activarlo, borra la caché de fuentes y regenera el CSS desde DIGITALÍSIMO Elements → Herramientas → Vaciar archivos y datos. No altera fuentes ajenas.' );
		self::font_display_state_row();
		echo '<tr><th colspan="2"><h2>CSS no crítico</h2><p>Las primeras dos visitas miden las reglas CSS y el primer viewport sin diferir nada. Sólo las hojas verificadas podrán diferirse en visitas posteriores con la misma URL y tamaño; cualquier duda conserva el CSS normal.</p></th></tr>';
		self::f( 'perf_css_defer', 'Detectar y diferir CSS no crítico', 'checkbox', 'Desactivado por defecto. Respeta dependencias de WordPress y conserva <noscript>.' );
		self::f( 'perf_hero_critical', 'CSS crítico del Hero', 'checkbox', 'Activo sólo si se identifica con seguridad el primer H1 y su contenedor en una página hecha con el constructor. Se calcula en segundo plano y se imprime antes de los estilos normales; no difiere CSS del constructor.' );
		self::f( 'perf_css_defer_exclusions', 'Excluir hojas del diferimiento', 'textarea', 'Handles de WordPress, uno por línea. Esta lista tiene prioridad sobre la detección automática.' );
		self::f( 'perf_caption_normal', 'Normalizar leyendas de los carruseles', 'checkbox', 'Aplica font-style: normal a los captions. No bloquea fuentes por sí solo.' );
		self::f( 'perf_custom_css', 'CSS técnico personalizado', 'textarea', 'Se hereda de la red o se reemplaza por sitio. Máximo 20 KiB. No admite HTML, @import ni url().' );
		self::f( 'perf_custom_css_paused', 'Pausar CSS técnico personalizado', 'checkbox', 'Úsalo mientras pasas el Código personalizado del constructor a DIGITALÍSIMO SEO. El CSS guardado no se imprime hasta desactivar esta pausa después de revisar el resultado.' );
		echo '<tr><th colspan="2"><h2>Constructor y WooCommerce</h2><p>Los recursos del constructor, Swiper y WooCommerce se conservan. El diagnóstico contextual se desarrollará antes de habilitar reglas de descarga.</p></th></tr>';
	}
	public static function performance_network_fields() {
		echo '<tr><th colspan="2"><h2>Rendimiento · valores de red</h2><p>Cada sitio hereda estos valores hasta que desactiva «Heredar de la red» en su pestaña Rendimiento.</p></th></tr>';
		self::nf( 'perf_safe_mode', 'Modo seguro', 'checkbox' );
		self::nf( 'perf_gutenberg', 'Desactivar CSS de Gutenberg fuera del blog', 'checkbox', 'Sólo páginas confirmadas como hechas con el constructor, sin bloques ni dependientes.' );
		self::nf( 'perf_emojis', 'Desactivar recursos de emojis', 'checkbox' );
		self::nf( 'perf_embeds', 'Desactivar wp-embed cuando no se usa', 'checkbox' );
		self::nf( 'perf_dashicons', 'No cargar Dashicons para invitados', 'checkbox' );
		self::nf( 'perf_font_swap', 'font-display: swap en fuentes del constructor', 'checkbox', 'Requiere regenerar el CSS y la caché de fuentes del constructor para los archivos ya creados (DIGITALÍSIMO Elements → Herramientas → Vaciar archivos y datos).' );
		self::font_display_network_note();
		self::nf( 'perf_css_defer', 'Detectar y diferir CSS no crítico', 'checkbox', 'Las primeras dos visitas analizan sin diferir. Sólo se diferirá con evidencia por sitio, URL y viewport.' );
		self::nf( 'perf_hero_critical', 'CSS crítico del Hero', 'checkbox', 'Predeterminado de red. Cada sitio sólo imprime el CSS si su propia página hecha con el constructor supera la detección segura.' );
		self::nf( 'perf_css_defer_exclusions', 'Excluir hojas del diferimiento', 'textarea', 'Handles de WordPress, uno por línea. Cada sitio puede personalizar esta lista.' );
		self::nf( 'perf_caption_normal', 'Normalizar leyendas de los carruseles', 'checkbox' );
		self::nf( 'perf_custom_css', 'CSS técnico de red', 'textarea', 'Los sitios pueden heredarlo o reemplazarlo. Sin HTML, @import ni url().' );
		self::nf( 'perf_custom_css_paused', 'Pausar CSS técnico personalizado', 'checkbox', 'Los sitios pueden heredar esta pausa o definirla individualmente.' );
	}
	private static function font_display_origins() {
		return array(
			'seo'      => 'Lo fuerza esta casilla de DIGITALÍSIMO SEO, por encima de los ajustes del constructor.',
			'builder'  => 'Elegido en los ajustes del constructor.',
			'elements' => 'Valor por defecto de DIGITALÍSIMO Elements, sólo para las fuentes de Google; se desactiva en DIGITALÍSIMO Elements → Rendimiento.',
			'default'  => 'Valor por defecto del constructor: este sitio nunca lo eligió.',
		);
	}
	/**
	 * font-display de las fuentes de Google del constructor y quién lo decide, sólo con funciones de WordPress:
	 * esta casilla (su `pre_option_` gana), la fila que guardan los ajustes del constructor, un valor por defecto
	 * añadido con `default_option_` (DIGITALÍSIMO Elements) o «auto». Sin Elements: «auto» o lo guardado.
	 *
	 * @return array{value:string,origin:string,base:string,base_origin:string}
	 */
	public static function font_display_state() {
		global $wpdb;
		$option = 'elementor_font_display';
		// Sin get_option(): pasaría por el pre_option_ de esta casilla y no distinguiría una fila de un valor por defecto.
		$stored      = is_object( $wpdb ) ? $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", $option ) ) : null;
		$base        = 'auto';
		$base_origin = 'default';
		if ( null !== $stored ) { $base = (string) $stored; $base_origin = 'builder'; }
		elseif ( has_filter( 'default_option_' . $option ) ) {
			// Lo que devuelve get_option( 'elementor_font_display', 'auto' ) cuando la fila no existe.
			$filtered = (string) apply_filters( 'default_option_' . $option, 'auto', $option, true );
			if ( '' !== $filtered && 'auto' !== $filtered ) { $base = $filtered; $base_origin = 'elements'; }
		}
		$seo = (bool) Digitalisimo_Integrations_SEO_Resolver::option( 'perf_font_swap' );
		return array( 'value' => $seo ? 'swap' : $base, 'origin' => $seo ? 'seo' : $base_origin, 'base' => $base, 'base_origin' => $base_origin );
	}
	/** Bajo la casilla del sitio. Sin campos: no repite ningún `name` del formulario. */
	private static function font_display_state_row() {
		$state   = self::font_display_state();
		$origins = self::font_display_origins();
		echo '<tr class="digitalisimo-font-display-state"><th scope="row">font-display en vigor</th><td><span class="digitalisimo-effective-state ' . ( 'swap' === $state['value'] ? 'is-active' : 'is-inactive' ) . '">' . esc_html( $state['value'] ) . '</span> <span class="description">' . esc_html( $origins[ $state['origin'] ] ) . '</span>';
		if ( 'seo' === $state['origin'] ) echo '<p class="description">Sin esta casilla: ' . esc_html( $state['base'] ) . ' · ' . esc_html( $origins[ $state['base_origin'] ] ) . '</p>';
		echo '</td></tr>';
	}
	/** La red no tiene un valor único: cada sitio guarda el suyo en los ajustes del constructor. */
	private static function font_display_network_note() {
		echo '<tr class="digitalisimo-font-display-state"><th scope="row">font-display en cada sitio</th><td><p class="description">Con esta casilla apagada, cada sitio usa el font-display que eligió en los ajustes del constructor; si nunca lo eligió, el valor por defecto de DIGITALÍSIMO Elements (swap, sólo para las fuentes de Google; se desactiva en DIGITALÍSIMO Elements → Rendimiento) o, sin él, auto. Activada, aplica swap en los sitios que la heredan, por encima de los ajustes del constructor. Cada sitio muestra bajo esta casilla su valor en vigor y su origen.</p></td></tr>';
	}
	public static function performance_tracking_site_fields() {
		echo '<tr><th colspan="2"><h2>Google Tracking</h2><p>Apagado por defecto. Primero ejecuta la auditoría de Custom Code. Si Site Kit está activo o existe un ID publicado en el Código personalizado del constructor, Digitalísimo no imprime tracking para evitar duplicados.</p></th></tr>';
		self::f( 'perf_tracking_enabled', 'Activar tracking de Digitalísimo', 'checkbox' );
		self::f( 'perf_gt_id', 'Google Tag ID', 'text', 'Formato GT-XXXXXXXX.' );
		self::f( 'perf_ga4_id', 'GA4 ID', 'text', 'Formato G-XXXXXXXX. Si GTM envía GA4, déjalo vacío.' );
		self::f( 'perf_gtm_id', 'GTM ID', 'text', 'Formato GTM-XXXXXXX. Incluye noscript en wp_body_open.' );
		self::f( 'perf_tracking_mode', 'Modo de carga', 'select', 'DataLayer y gtag() se crean inmediatamente. Interacción usa scroll, touchstart, keydown o click; nunca mousemove.', self::performance_mode_choices( 'perf_tracking_mode' ) );
		self::f( 'perf_tracking_delay', 'Delay personalizado (segundos)', 'number', 'Sólo para el modo Delay; 1–120 segundos.' );
		self::f( 'perf_tracking_fallback', 'Fallback interacción (segundos)', 'number', 'Tras window.load; por defecto 12 segundos.' );
	}
	public static function performance_image_site_fields() {
		echo '<tr><th colspan="2"><h2>Imágenes responsive</h2><p>Completa el HTML de cada imagen con lo que la Biblioteca de Medios ya tiene: srcset, sizes, width, height y prioridad de carga. No genera, convierte ni reemplaza archivos, y no cambia lo que eligió el diseñador en el constructor. Una imagen que no se puede vincular a un adjunto de este sitio queda intacta.</p></th></tr>';
		self::f( 'perf_img_enabled', 'Optimización responsive de imágenes', 'checkbox', 'Interruptor general. Apagado por defecto.' );
		self::f( 'perf_img_srcset', 'Añadir srcset', 'checkbox', 'Sólo con los tamaños que WordPress ya generó para ese adjunto.' );
		self::f( 'perf_img_sizes', 'Añadir sizes', 'checkbox', 'Usa el layout del constructor (columnas, contenedores, ancho en caja) cuando se conoce; si no, el de WordPress.' );
		self::f( 'perf_img_dimensions', 'Añadir width y height', 'checkbox', 'Reserva el espacio y reduce el CLS. No toca estilos ni proporciones configuradas.' );
		self::f( 'perf_img_lazy', 'Carga diferida inteligente', 'checkbox', 'Logo y primeras imágenes sin diferir, una sola candidata a LCP con fetchpriority alto, el resto lazy.' );
		self::f( 'perf_img_backgrounds', 'Fondos del constructor', 'checkbox', 'Opcional. Añade una variante menor para tablet y móvil sólo cuando alcanza para viewport × DPR 2. Los fondos «cover» conservan el original. Requiere regenerar el CSS del constructor, que se hace al cambiar esta opción.' );
		self::f( 'perf_img_mode', 'Modo', 'select', 'Seguro declara 100vw hasta tablet y respeta cualquier loading existente. Estricto declara 100vw sólo en móvil y quita el lazy de la candidata a LCP.', array( 'safe' => 'Seguro', 'strict' => 'Estricto' ) );
		self::f( 'perf_img_exclusions', 'Exclusiones', 'textarea', 'Una por línea: .clase, #id, [atributo], id:123 (adjunto) o un fragmento de URL.' );
	}
	public static function performance_image_network_fields() {
		echo '<tr><th colspan="2"><h2>Imágenes responsive · defaults de red</h2><p>Cada sitio procesa sus propias imágenes con su propia Biblioteca de Medios; aquí sólo se definen los valores que heredan.</p></th></tr>';
		self::nf( 'perf_img_enabled', 'Optimización responsive de imágenes', 'checkbox' );
		self::nf( 'perf_img_srcset', 'Añadir srcset', 'checkbox' );
		self::nf( 'perf_img_sizes', 'Añadir sizes', 'checkbox' );
		self::nf( 'perf_img_dimensions', 'Añadir width y height', 'checkbox' );
		self::nf( 'perf_img_lazy', 'Carga diferida inteligente', 'checkbox' );
		self::nf( 'perf_img_backgrounds', 'Fondos del constructor', 'checkbox' );
		self::nf( 'perf_img_mode', 'Modo', 'select', '', array( 'safe' => 'Seguro', 'strict' => 'Estricto' ) );
		self::nf( 'perf_img_exclusions', 'Exclusiones', 'textarea', 'Una por línea: .clase, #id, [atributo], id:123 o un fragmento de URL.' );
	}
	public static function performance_js_site_fields() {
		echo '<tr><th colspan="2"><h2>JavaScript · experimento</h2><p>Difiere jQuery y todo lo que depende de él con la estrategia nativa de WordPress, conservando el orden. No elimina jQuery ni usa async. Si una página tiene código que necesitaría jQuery antes de tiempo, esa página carga normal; si un visitante registra «jQuery is not defined», el sitio vuelve a la carga normal hasta que lo reactives.</p></th></tr>';
		self::f( 'perf_js_jquery_mode', 'Optimización jQuery', 'select', 'Desactivada por defecto. Pruébala primero en un sitio de pruebas.', array( 'off' => 'Desactivada', 'defer' => 'Defer seguro experimental' ) );
	}
	public static function performance_js_network_fields() {
		echo '<tr><th colspan="2"><h2>JavaScript · defaults de red</h2><p>Experimental. Déjalo desactivado en la red y actívalo sólo en el sitio que estés probando.</p></th></tr>';
		self::nf( 'perf_js_jquery_mode', 'Optimización jQuery', 'select', '', array( 'off' => 'Desactivada', 'defer' => 'Defer seguro experimental' ) );
	}
	public static function performance_a11y_site_fields() {
		echo '<tr><th colspan="2"><h2>Objetivos táctiles</h2><p>Apagado por defecto. Agranda sólo el área que recibe el toque (24 × 24 px como mínimo) con un pseudo-elemento centrado: el control no cambia de tamaño ni de posición. Úsalo únicamente con componentes que no tengan un ::after propio.</p></th></tr>';
		self::f( 'perf_touch_guard', 'Protección mínima de objetivos táctiles', 'checkbox' );
		self::f( 'perf_touch_selectors', 'Componentes', 'textarea', 'Un selector por línea (clases, ids o etiquetas). Por defecto: iconos sociales y paginación de carruseles.' );
	}
	public static function performance_a11y_network_fields() {
		echo '<tr><th colspan="2"><h2>Objetivos táctiles · defaults de red</h2></th></tr>';
		self::nf( 'perf_touch_guard', 'Protección mínima de objetivos táctiles', 'checkbox' );
		self::nf( 'perf_touch_selectors', 'Componentes', 'textarea', 'Un selector por línea.' );
	}
	public static function performance_preload_site_fields() {
		echo '<tr><th colspan="2"><h2>Preloads críticos WOFF2</h2><p>Primero analiza Fuentes y Custom Code. Sólo se imprimen fuentes locales del inventario cuyo CSS esté encolado en la página. Si el constructor ya publica el mismo preload, se omite. Apagado por defecto.</p></th></tr>';
		self::f( 'perf_preload_mode', 'Modo', 'select', 'Automático precarga las variantes críticas que declara el Kit de este sitio (cuerpo, texto global, H1), siempre que estén autorizadas. Manual usa las rutas indicadas abajo.', self::performance_mode_choices( 'perf_preload_mode' ) );
		self::f( 'perf_preload_limit', 'Máximo de fuentes', 'number', 'Entre 1 y 2 por página.' );
		self::f( 'perf_preload_paths', 'Rutas WOFF2 manuales', 'textarea', 'Una ruta relativa a uploads por línea, por ejemplo elementor/google-fonts/fonts/archivo.woff2. Usa las rutas del inventario de este sitio.' );
	}
	public static function performance_font_site_fields() {
		echo '<tr><th colspan="2"><h2>Fuentes locales del constructor</h2><p>Cada sitio detecta sus familias, estilos y pesos en el Kit y en el contenido publicado, y genera su CSS sólo con las variantes autorizadas. Los originales no se modifican y los icon fonts nunca se filtran.</p></th></tr>';
		self::f( 'perf_font_guard_mode', 'Modo', 'select', 'Seguro recorta las variantes que no usan las familias detectadas y conserva —registrándolas— las que no detectó. Estricto elimina cualquier @font-face no autorizado. Manual usa sólo la lista.', self::performance_mode_choices( 'perf_font_guard_mode' ) );
		self::f( 'perf_font_guard_allowlist', 'Excepciones manuales', 'textarea', 'Una familia por línea: Familia|pesos|estilos, por ejemplo Mi Fuente|400,700|normal,italic. En Seguro y Estricto se suman a lo detectado; en Manual son la lista completa.' );
		self::f( 'perf_font_icon_families', 'Icon fonts adicionales', 'textarea', 'Una familia por línea. Se suman a los icon fonts reconocidos (eicons, Font Awesome, Material Icons/Symbols, Dashicons…) y nunca se filtran ni se precargan.' );
	}
	public static function performance_font_network_fields() {
		echo '<tr><th colspan="2"><h2>Fuentes locales · red</h2><p>Valores predeterminados de la red. Cada sitio detecta sus propias fuentes y genera su propio CSS; nunca se copia la whitelist de un sitio a otro.</p></th></tr>';
		self::nf( 'perf_font_guard_mode', 'Modo', 'select', 'Elige el valor predeterminado para los sitios de la red.', self::performance_mode_choices( 'perf_font_guard_mode' ) );
		self::nf( 'perf_font_guard_allowlist', 'Excepciones manuales', 'textarea', 'Familia|pesos|estilos por línea. Se suman a lo que detecta cada sitio; en modo Manual son la lista completa.' );
		self::nf( 'perf_font_icon_families', 'Icon fonts adicionales', 'textarea', 'Una familia por línea. Nunca se filtran ni se precargan en ningún sitio que herede este valor.' );
	}
	public static function performance_preload_network_fields() {
		echo '<tr><th colspan="2"><h2>Preloads críticos · defaults de red</h2><p>Las rutas son relativas a uploads; cada sitio sólo usa sus propias fuentes inventariadas.</p></th></tr>';
		self::nf( 'perf_preload_mode', 'Modo', 'select', 'Elige el valor predeterminado para los sitios de la red.', self::performance_mode_choices( 'perf_preload_mode' ) );
		self::nf( 'perf_preload_limit', 'Máximo de fuentes', 'number', 'Entre 1 y 2 por página.' );
		self::nf( 'perf_preload_paths', 'Rutas WOFF2 manuales', 'textarea', 'Rutas relativas a uploads, una por línea.' );
	}
	public static function performance_tracking_network_fields() {
		$site_id = absint( $_GET['site_id'] ?? get_current_blog_id() );
		if ( ! get_site( $site_id ) ) $site_id = get_current_blog_id();
		self::$network_tracking_prefill = Digitalisimo_Integrations_Performance_Tracking::site_kit_ids_for_site( $site_id );
		echo '<tr><th colspan="2"><h2>Google Tracking · defaults de red</h2><p>Los sitios pueden heredar o sobrescribir cada valor. Site Kit y Custom Code publicados bloquean la salida duplicada por sitio.</p>';
		if ( array_filter( self::$network_tracking_prefill ) ) echo '<p>IDs detectados en ' . esc_html( get_home_url( $site_id, '/' ) ) . ': se muestran en los campos vacíos. Al guardar se aplicarán como defaults a los sitios que heredan de la red.</p>';
		echo '</th></tr>';
		self::nf( 'perf_tracking_enabled', 'Activar tracking de Digitalísimo', 'checkbox' );
		self::nf( 'perf_gt_id', 'Google Tag ID' );
		self::nf( 'perf_ga4_id', 'GA4 ID' );
		self::nf( 'perf_gtm_id', 'GTM ID' );
		self::nf( 'perf_tracking_mode', 'Modo de carga', 'select', 'Elige el valor predeterminado para los sitios de la red.', self::performance_mode_choices( 'perf_tracking_mode' ) );
		self::nf( 'perf_tracking_delay', 'Delay personalizado (segundos)', 'number' );
		self::nf( 'perf_tracking_fallback', 'Fallback interacción (segundos)', 'number' );
		self::$network_tracking_prefill = array();
	}
	private static function settings_fields( $s ) {
		if ( 'general' === $s ) { self::f( 'seo_site_name', 'Nombre SEO del sitio', 'text', 'Vacío = nombre de WordPress.' ); self::f( 'seo_separator', 'Separador de títulos', 'select', '', self::separator_choices() ); self::f( 'seo_organization_type', 'Tipo de entidad', 'select', self::ENTITY_HELP, self::entity_type_choices() ); self::f( 'seo_organization_name', 'Nombre de organización', 'text' ); self::f( 'seo_logo', 'Logotipo', 'media' ); Digitalisimo_Integrations_Social_Profiles::site_fields(); self::f( 'seo_knowledge_urls', 'Otros perfiles', 'textarea', 'Sólo para perfiles sin campo propio. Uno por línea.' ); self::verification_fields( false ); }
		elseif ( 'titles' === $s ) { self::template_variables_help(); self::f( 'seo_title_post', 'Título de entradas', 'text' ); self::f( 'seo_description_post', 'Descripción de entradas', 'textarea' ); self::f( 'seo_title_page', 'Título de páginas', 'text' ); self::f( 'seo_description_page', 'Descripción de páginas', 'textarea' ); self::f( 'seo_title_archive', 'Título de archivos', 'text' ); self::f( 'seo_description_archive', 'Descripción de archivos', 'textarea' ); self::f( 'seo_title_taxonomy', 'Título de taxonomías', 'text' ); self::f( 'seo_description_taxonomy', 'Descripción de taxonomías', 'textarea' ); }
		elseif ( 'appearance' === $s ) { self::f( 'sitemap_post_types', 'Tipos públicos indexables', 'textarea', 'Separados por comas. Ejemplo: post,page,product.' ); self::f( 'seo_taxonomies', 'Taxonomías SEO', 'textarea', 'Separadas por comas. Ejemplo: category,post_tag,product_cat.' ); self::f( 'noindex_authors', 'Noindex archivos de autor', 'checkbox' ); self::f( 'noindex_date_archives', 'Noindex archivos de fecha', 'checkbox' ); }
		elseif ( 'schema' === $s ) { self::f( 'seo_schema_enabled', 'Schema JSON-LD', 'checkbox', 'Publica un solo @graph con Organization (o LocalBusiness con datos reales), WebSite, WebPage, BreadcrumbList en páginas internas y la entidad del contenido, relacionados por @id.' ); self::f( 'seo_schema_unify', 'Unificar el schema de la página', 'checkbox', self::UNIFY_HELP ); self::f( 'seo_default_image', 'Imagen social predeterminada', 'media' ); self::f( 'seo_alt_optimize', 'Optimizar ALT en la salida', 'checkbox', 'Completa en la página el ALT de las imágenes que no lo tienen, con su propio contexto (título, archivo, widget, encabezado cercano). Nunca sobrescribe un ALT manual ni modifica la Biblioteca de Medios. Si el ALT repite el caption visible, la página publica alt="".' ); self::f( 'seo_alt_keyword_mode', 'Palabra clave de apoyo para ALT', 'select', 'Desactivado: nunca se añade. Sólo fallback: se usa únicamente cuando una imagen sin ALT no tiene ningún otro contexto. Contextual (recomendado): se añade como mucho a una imagen por página y sólo si comparte palabras con ella. Ningún ALT manual se modifica.', array( 'off' => 'Desactivado', 'fallback' => 'Sólo fallback', 'contextual' => 'Contextual' ) ); self::f( 'seo_alt_keyword', 'Palabra clave de apoyo', 'text', 'Propia de este sitio. Vacío: se usa la keyword principal de cada contenido.' ); }
		elseif ( 'local' === $s ) { self::f( 'seo_local_enabled', 'Activar SEO local', 'checkbox' ); self::f( 'seo_local_type', 'Tipo de negocio', 'select', self::LOCAL_TYPE_HELP, self::local_type_choices() ); self::f( 'seo_local_name', 'Nombre comercial', 'text' ); echo '<tr><th scope="row">Teléfono</th><td>'; Digitalisimo_Integrations_Local_Business::phone_field(); echo '</td></tr>'; self::f( 'seo_local_address', 'Calle y número', 'textarea' ); self::f( 'seo_local_city', 'Ciudad', 'text' ); self::f( 'seo_local_region', 'Estado / región', 'text' ); self::f( 'seo_local_postal', 'Código postal', 'text' ); self::f( 'seo_local_country', 'País ISO', 'text' ); self::f( 'seo_local_latitude', 'Latitud', 'text' ); self::f( 'seo_local_longitude', 'Longitud', 'text' ); echo '<tr><th scope="row">Horario</th><td>'; Digitalisimo_Integrations_Local_Business::schedule_field(); echo '</td></tr>'; self::f( 'seo_local_price_range', 'Rango de precio', 'text', 'Ejemplo: $$.' ); }
		elseif ( 'social' === $s ) { self::f( 'seo_open_graph', 'Open Graph', 'checkbox' ); self::f( 'seo_twitter_enabled', 'Twitter Cards', 'checkbox' ); self::f( 'seo_twitter_card', 'Tarjeta X/Twitter', 'select', '', array( 'summary' => 'Summary', 'summary_large_image' => 'Summary con imagen grande' ) ); self::f( 'seo_twitter_user', 'Usuario X/Twitter', 'text', 'Ejemplo: @digitalisimo.' ); self::f( 'seo_default_image', 'Imagen predeterminada', 'media' ); }
		elseif ( 'sitemap' === $s ) { self::sitemap_link_row(); self::f( 'sitemap_enabled', 'Activar sitemap XML', 'checkbox', 'Disponible en /sitemap.xml.' ); self::f( 'sitemap_post_types', 'Tipos incluidos', 'textarea', 'Auto incluye entradas, páginas, productos y otros tipos públicos indexables. Las páginas siempre se incluyen.' ); self::f( 'sitemap_exclude_ids', 'IDs excluidos', 'textarea' ); self::f( 'seo_sitemap_images', 'Imágenes en el sitemap', 'checkbox', self::SITEMAP_IMAGES_HELP ); }
		elseif ( 'robots' === $s ) { self::robots_info_row(); self::f( 'seo_ai_google_extended_policy', 'Google-Extended', 'select', 'Permitir favorece la presencia en Gemini; bloquear limita entrenamiento y grounding en Gemini, pero no afecta Google Search.', array( 'allow' => 'Permitir (máxima visibilidad en Gemini)', 'disallow' => 'Bloquear uso por Gemini' ) ); self::f( 'seo_robots_rules', 'Reglas adicionales', 'textarea', 'Escribe grupos User-agent, Allow y Disallow. Si omites User-agent se aplican a todos. Sitemap y reglas automáticas permanecen intactos.' ); self::robots_preview_row(); }
		elseif ( 'indexing' === $s ) { self::f( 'noindex_search', 'Resultados de búsqueda internos', 'checkbox' ); self::f( 'noindex_authors', 'Archivos de autor', 'checkbox' ); self::f( 'noindex_empty_tags', 'Etiquetas vacías', 'checkbox' ); self::f( 'noindex_date_archives', 'Archivos por fecha', 'checkbox' ); self::f( 'noindex_attachments', 'Páginas de adjuntos', 'checkbox' ); self::f( 'noindex_elementor', 'Plantillas del constructor (DIGITALÍSIMO Elements)', 'checkbox' ); self::f( 'noindex_woo_pages', 'Carrito, checkout, gracias y mi cuenta', 'checkbox' ); self::f( 'noindex_page_slugs', 'Slugs noindex', 'textarea', 'Uno por línea.' ); self::f( 'noindex_page_ids', 'IDs noindex', 'textarea' ); self::advanced_robots_fields( false ); }
		elseif ( 'breadcrumbs' === $s ) { self::f( 'seo_breadcrumbs', 'Activar breadcrumbs', 'checkbox' ); echo '<tr><th>Uso</th><td><code>[digitalisimo_breadcrumbs]</code><p class="description">También se integra en el JSON-LD de cada contenido.</p></td></tr>'; }
		elseif ( 'redirections' === $s ) { self::redirect_fields( false ); }
		elseif ( 'monitor404' === $s ) { self::monitor_fields( false ); }
		elseif ( 'performance' === $s ) { self::performance_site_fields(); }
	}
	/** Aviso mientras DIGITALÍSIMO Tools no administra las opciones que salieron de SEO. */
	private static function moved_options_notice() {
		if ( Digitalisimo_Integrations_Settings::tools_handles_site_options() ) return;
		echo '<div class="notice notice-info inline"><p><strong>Ruta privada de acceso, redirección de adjuntos y bloqueo del desplazamiento móvil</strong> ahora se administran en DIGITALÍSIMO Tools → Ajustes del sitio. Mientras Tools no esté instalado y activo, siguen funcionando con su configuración actual.</p></div>';
	}
	private static function dashboard() { self::moved_options_notice(); $types = self::editable_types(); $published = count( get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids' ) ) ); $noindex = count( get_posts( array( 'post_type' => $types, 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => self::P . 'robots', 'meta_value' => 'noindex', 'compare' => 'LIKE' ) ) ); $keywords = count( get_posts( array( 'post_type' => $types, 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => self::P . 'keywords', 'compare' => 'EXISTS' ) ) ); echo '<p>Configuración SEO nativa por sitio. En Multisite, cada subsitio conserva sus propios valores.</p><div class="notice notice-info inline"><p><strong>Sitemap:</strong> <a href="' . esc_url( home_url( '/sitemap.xml' ) ) . '" target="_blank" rel="noopener">' . esc_html( home_url( '/sitemap.xml' ) ) . '</a></p></div><table class="widefat striped"><tr><th>Contenidos publicados</th><td>' . esc_html( $published ) . '</td></tr><tr><th>Con keywords</th><td>' . esc_html( $keywords ) . '</td></tr><tr><th>Noindex editorial</th><td>' . esc_html( $noindex ) . '</td></tr><tr><th>Schema</th><td>' . ( self::o( 'seo_schema_enabled' ) ? 'Activo' : 'Inactivo' ) . '</td></tr></table>'; }
	public static function metaboxes() {
		foreach ( self::editable_types() as $type ) {
			// Se muestra completo en la barra lateral: Gutenberg mantiene ese panel siempre accesible.
			add_meta_box( 'digitalisimo_native_seo', 'SEO de Digitalisimo', array( __CLASS__, 'metabox' ), $type, 'side', 'high' );
		}
	}
	public static function editor_assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) return;
		// Esta base visual también cubre los metaboxes de otros módulos activos y
		// cualquier panel futuro cuyo ID comience con digitalisimo- o digitalisimo_.
		wp_enqueue_style( 'digitalisimo-editor-ui', DIGITALISIMO_INTEGRATIONS_URL . 'assets/editor-ui.css', function_exists( 'digitalisimo_ui_dependency' ) ? digitalisimo_ui_dependency() : array(), DIGITALISIMO_INTEGRATIONS_VERSION );
		wp_enqueue_style( 'digitalisimo-seo-snippet-editor', DIGITALISIMO_INTEGRATIONS_URL . 'assets/snippet-editor.css', function_exists( 'digitalisimo_ui_dependency' ) ? digitalisimo_ui_dependency() : array(), DIGITALISIMO_INTEGRATIONS_VERSION );
		wp_enqueue_style( 'digitalisimo-seo-snippet-modal', DIGITALISIMO_INTEGRATIONS_URL . 'assets/snippet-modal.css', array( 'digitalisimo-seo-snippet-editor' ), DIGITALISIMO_INTEGRATIONS_VERSION );
		wp_enqueue_script( 'digitalisimo-seo-snippet-editor', DIGITALISIMO_INTEGRATIONS_URL . 'assets/snippet-editor.js', array(), DIGITALISIMO_INTEGRATIONS_VERSION, true );
	}
	/** Mantiene visible el único editor SEO del módulo en entradas y páginas. */
	public static function keep_snippet_visible( $hidden, $screen ) {
		if ( ! is_object( $screen ) || ! in_array( $screen->base ?? '', array( 'post', 'post-new' ), true ) ) return $hidden;
		return array_values( array_diff( (array) $hidden, array( 'digitalisimo_native_seo' ) ) );
	}
	public static function metabox( $post ) {
		wp_nonce_field( 'digitalisimo_native_seo', 'digitalisimo_native_seo_nonce' );
		$v = function( $key ) use ( $post ) { return get_post_meta( $post->ID, self::P . $key, true ); };
		$written_excerpt = self::written_excerpt( $post );
		$excerpt = $written_excerpt ?: wp_trim_words( wp_strip_all_tags( $post->post_content ), 30, '' );
		$fallback_title = self::replace( self::o( 'seo_title_' . ( 'page' === $post->post_type ? 'page' : 'post' ) ), array( 'title' => $post->post_title, 'excerpt' => $excerpt ) ) ?: $post->post_title;
		$fallback_description = $excerpt ?: get_bloginfo( 'description' );
		$description_value = $v( 'description' ) ?: $written_excerpt;
		$permalink = get_permalink( $post );
		$path = wp_parse_url( $permalink, PHP_URL_PATH ) ?: '/';
		$keywords = array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, self::P . 'keywords', true ) ) ) );
		echo '<div class="digitalisimo-snippet-launch"><strong>Snippet SEO</strong><p>Edita título, URL, meta descripción, Social y opciones avanzadas en una ventana amplia.</p><button type="button" class="button button-primary" data-snippet-expand data-snippet-target="digitalisimo-snippet-editor">Editar snippet <span aria-hidden="true">⤢</span></button></div>';
		echo '<div id="digitalisimo-snippet-editor" class="digitalisimo-snippet-editor" data-site-url="' . esc_attr( home_url( '/' ) ) . '" data-default-title="' . esc_attr( $fallback_title ) . '" data-default-description="' . esc_attr( $fallback_description ) . '" data-written-excerpt="' . esc_attr( $written_excerpt ) . '">';
		echo '<div class="digitalisimo-snippet-tabs" role="tablist"><button type="button" class="is-active" data-snippet-tab="general">Snippet SEO</button><button type="button" data-snippet-tab="social">Social</button><button type="button" data-snippet-tab="advanced">Avanzado</button><button type="button" class="digitalisimo-snippet-expand" data-snippet-expand aria-label="Abrir editor de snippet en ventana amplia" title="Abrir ventana amplia"><span aria-hidden="true">⤢</span><span class="screen-reader-text">Abrir ventana amplia</span></button></div>';
		echo '<section class="digitalisimo-snippet-preview"><div class="digitalisimo-snippet-preview-label">Vista previa en Google</div><div class="digitalisimo-snippet-url" data-snippet-preview="url">' . esc_html( home_url( $path ) ) . '</div><div class="digitalisimo-snippet-title" data-snippet-preview="title">' . esc_html( $v( 'title' ) ?: $fallback_title ) . '</div><p data-snippet-preview="description">' . esc_html( $v( 'description' ) ?: $fallback_description ) . '</p></section>';
		echo '<section class="digitalisimo-snippet-panel is-active" data-snippet-panel="general"><div class="digitalisimo-snippet-grid">';
		echo '<label>Título SEO <span class="digitalisimo-snippet-count" data-snippet-count="title"></span><input type="text" name="digitalisimo_native_title" data-snippet-input="title" value="' . esc_attr( $v( 'title' ) ) . '" placeholder="' . esc_attr( $fallback_title ) . '"><small>Ideal: 50–60 caracteres. Vacío usa la plantilla global.</small></label>';
		echo '<label>Enlace permanente <span class="digitalisimo-snippet-count" data-snippet-count="slug"></span><span class="digitalisimo-snippet-slug-prefix">' . esc_html( home_url( '/' ) ) . '</span><input type="text" name="digitalisimo_native_slug" data-snippet-input="slug" value="' . esc_attr( $post->post_name ) . '" placeholder="url-del-contenido"><small>Modificarlo cambia la URL pública. WordPress conservará la redirección si está disponible.</small></label>';
		echo '<label class="digitalisimo-snippet-wide">Meta descripción <span class="digitalisimo-snippet-count" data-snippet-count="description"></span><textarea rows="4" name="digitalisimo_native_description" data-snippet-input="description" placeholder="' . esc_attr( $fallback_description ) . '">' . esc_textarea( $description_value ) . '</textarea><small>Ideal: 120–160 caracteres. Si está vacía, se completa con el extracto escrito; puedes modificarla sin cambiar el extracto.</small></label>';
		if ( $written_excerpt ) echo '<div class="digitalisimo-snippet-wide"><button type="button" class="button" data-snippet-use-excerpt>Usar extracto como meta descripción</button></div>';
		echo '</div><div class="digitalisimo-snippet-keyword"><strong>Keyword principal</strong><span>' . esc_html( $keywords[0] ?? 'Define la keyword en el panel Palabras clave.' ) . '</span></div></section>';
		echo '<section class="digitalisimo-snippet-panel" data-snippet-panel="social"><div class="digitalisimo-snippet-grid"><label>Título social<input name="digitalisimo_native_social_title" value="' . esc_attr( $v( 'social_title' ) ) . '" placeholder="Usa el título SEO si queda vacío"></label><label class="digitalisimo-snippet-wide">Descripción social<textarea rows="4" name="digitalisimo_native_social_description" placeholder="Usa la meta descripción si queda vacía">' . esc_textarea( $v( 'social_description' ) ) . '</textarea></label><div class="digitalisimo-snippet-wide"><label for="digitalisimo_native_social_image">Imagen social</label>'; Digitalisimo_Media_Field::render( 'digitalisimo_native_social_image', 'digitalisimo_native_social_image', $v( 'social_image' ) ); echo '</div></div></section>';
		echo '<section class="digitalisimo-snippet-panel" data-snippet-panel="advanced"><div class="digitalisimo-snippet-grid"><label class="digitalisimo-snippet-wide">URL canonical<input type="url" name="digitalisimo_native_canonical" value="' . esc_attr( $v( 'canonical' ) ) . '" placeholder="' . esc_attr( $permalink ) . '"><small>Vacío publica la URL canónica normal de esta entrada o página.</small></label><fieldset class="digitalisimo-snippet-wide"><legend>Robots</legend><label><input type="checkbox" name="digitalisimo_native_noindex" value="1" ' . checked( '1', $v( 'noindex' ), false ) . '> Evitar indexación (noindex)</label><label><input type="checkbox" name="digitalisimo_native_nofollow" value="1" ' . checked( '1', $v( 'nofollow' ), false ) . '> Indicar nofollow</label><label><input type="checkbox" name="digitalisimo_native_noarchive" value="1" ' . checked( '1', $v( 'noarchive' ), false ) . '> Sin copia en caché (noarchive)</label><label><input type="checkbox" name="digitalisimo_native_noimageindex" value="1" ' . checked( '1', $v( 'noimageindex' ), false ) . '> No indexar sus imágenes (noimageindex)</label><label><input type="checkbox" name="digitalisimo_native_nosnippet" value="1" ' . checked( '1', $v( 'nosnippet' ), false ) . '> Sin fragmento en resultados (nosnippet)</label></fieldset><label>Máximo de caracteres del fragmento<input type="number" min="-1" name="digitalisimo_native_max_snippet" value="' . esc_attr( $v( 'max_snippet' ) ) . '" placeholder="Ajuste del sitio"><small>-1 sin límite, 0 sin fragmento. Vacío usa el ajuste del sitio.</small></label><label>Máximo de segundos de vista previa de vídeo<input type="number" min="-1" name="digitalisimo_native_max_video_preview" value="' . esc_attr( $v( 'max_video_preview' ) ) . '" placeholder="Ajuste del sitio"></label><label>Tipo de schema<select name="digitalisimo_native_schema_type">';
		foreach ( array( '' => 'Automático', 'Article' => 'Artículo', 'WebPage' => 'Página web', 'FAQPage' => 'FAQ', 'Service' => 'Servicio', 'Product' => 'Producto', 'LocalBusiness' => 'Negocio local', 'Person' => 'Perfil de persona' ) as $key => $label ) echo '<option value="' . esc_attr( $key ) . '" ' . selected( strtolower( $v( 'schema_type' ) ), strtolower( $key ), false ) . '>' . esc_html( $label ) . '</option>';
		echo '</select></label><label class="digitalisimo-snippet-wide">JSON-LD adicional (opcional)<textarea rows="5" name="digitalisimo_native_schema_custom" placeholder="{\"@type\": \"FAQPage\"}">' . esc_textarea( $v( 'schema_custom' ) ) . '</textarea></label>'; Digitalisimo_Integrations_Schema_Audit::editor_button( $post ); echo '</div></section><div class="digitalisimo-snippet-actions"><span>Los cambios se guardan en esta entrada.</span><button type="button" class="button button-primary" data-snippet-save>Guardar cambios</button></div></div>'; Digitalisimo_Integrations_Editorial::editor_panels( $post );
	}
	public static function save_post( $id ) {
		if ( wp_is_post_revision( $id ) || ! isset( $_POST['digitalisimo_native_seo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['digitalisimo_native_seo_nonce'] ) ), 'digitalisimo_native_seo' ) || ! current_user_can( 'edit_post', $id ) ) return;
		foreach ( array( 'title', 'description', 'social_title', 'social_description', 'local_note' ) as $key ) if ( isset( $_POST[ 'digitalisimo_native_' . $key ] ) ) update_post_meta( $id, self::P . $key, sanitize_textarea_field( wp_unslash( $_POST[ 'digitalisimo_native_' . $key ] ) ) );
		foreach ( array( 'canonical', 'social_image' ) as $key ) if ( isset( $_POST[ 'digitalisimo_native_' . $key ] ) ) update_post_meta( $id, self::P . $key, esc_url_raw( wp_unslash( $_POST[ 'digitalisimo_native_' . $key ] ) ) );
		foreach ( array( 'noindex', 'nofollow', 'noarchive', 'noimageindex', 'nosnippet' ) as $key ) update_post_meta( $id, self::P . $key, isset( $_POST[ 'digitalisimo_native_' . $key ] ) ? '1' : '' );
		foreach ( array( 'max_snippet', 'max_video_preview' ) as $key ) if ( isset( $_POST[ 'digitalisimo_native_' . $key ] ) ) update_post_meta( $id, self::P . $key, self::sanitize_robots_number( wp_unslash( $_POST[ 'digitalisimo_native_' . $key ] ) ) );
		$schema_type = sanitize_text_field( wp_unslash( $_POST['digitalisimo_native_schema_type'] ?? '' ) );
		update_post_meta( $id, self::P . 'schema_type', in_array( $schema_type, array( '', 'Article', 'WebPage', 'FAQPage', 'Service', 'Product', 'LocalBusiness', 'Person' ), true ) ? $schema_type : '' );
		$json = trim( wp_unslash( $_POST['digitalisimo_native_schema_custom'] ?? '' ) );
		update_post_meta( $id, self::P . 'schema_custom', json_decode( $json, true ) ? wp_json_encode( json_decode( $json, true ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) : '' );
		$slug = sanitize_title( wp_unslash( $_POST['digitalisimo_native_slug'] ?? '' ) );
		$post = get_post( $id );
		if ( $slug && $post && $slug !== $post->post_name ) {
			remove_action( 'save_post', array( __CLASS__, 'save_post' ), 15 );
			wp_update_post( array( 'ID' => $id, 'post_name' => $slug ) );
			add_action( 'save_post', array( __CLASS__, 'save_post' ), 15 );
		}
	}
	public static function taxonomies() { foreach ( self::list_value( 'seo_taxonomies' ) as $tax ) if ( taxonomy_exists( $tax ) ) { add_action( $tax . '_add_form_fields', array( __CLASS__, 'term_fields' ) ); add_action( $tax . '_edit_form_fields', array( __CLASS__, 'term_fields' ) ); } }
	public static function term_fields( $term ) { $id = is_object( $term ) ? $term->term_id : 0; $get = function( $k ) use ( $id ) { return $id ? get_term_meta( $id, self::P . $k, true ) : ''; }; wp_nonce_field( 'digitalisimo_term_seo', 'digitalisimo_term_seo_nonce' ); echo '<div class="form-field"><label>Título SEO</label><input name="digitalisimo_term_title" value="' . esc_attr( $get( 'title' ) ) . '"></div><div class="form-field"><label>Meta descripción</label><textarea name="digitalisimo_term_description">' . esc_textarea( $get( 'description' ) ) . '</textarea></div><div class="form-field"><label><input type="checkbox" name="digitalisimo_term_noindex" value="1" ' . checked( '1', $get( 'noindex' ), false ) . '> noindex</label></div>'; }
	public static function save_term( $id ) { if ( ! isset( $_POST['digitalisimo_term_seo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['digitalisimo_term_seo_nonce'] ) ), 'digitalisimo_term_seo' ) ) return; update_term_meta( $id, self::P . 'title', sanitize_text_field( wp_unslash( $_POST['digitalisimo_term_title'] ?? '' ) ) ); update_term_meta( $id, self::P . 'description', sanitize_textarea_field( wp_unslash( $_POST['digitalisimo_term_description'] ?? '' ) ) ); update_term_meta( $id, self::P . 'noindex', isset( $_POST['digitalisimo_term_noindex'] ) ? '1' : '' ); }
	private static function written_excerpt( $post ) { return $post ? trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( strip_shortcodes( (string) $post->post_excerpt ) ) ) ) : ''; }
	private static function replace( $template, $context = array() ) { $site = self::o( 'seo_site_name' ) ?: get_bloginfo( 'name' ); $repl = array( '%sitename%' => $site, '%sep%' => self::o( 'seo_separator' ) ?: '|', '%title%' => $context['title'] ?? '', '%term%' => $context['term'] ?? '', '%excerpt%' => $context['excerpt'] ?? '', '%description%' => $context['description'] ?? '', '%page%' => is_paged() ? 'Página ' . get_query_var( 'paged' ) : '' ); return trim( preg_replace( '/\s+/', ' ', strtr( (string) $template, $repl ) ) ); }
	private static function current() { if ( is_singular() ) { $id = get_queried_object_id(); $p = get_post( $id ); $type = $p ? $p->post_type : 'post'; $fallback = 'page' === $type ? 'page' : 'post'; $excerpt = $p ? ( self::written_excerpt( $p ) ?: wp_trim_words( wp_strip_all_tags( $p->post_content ), 30, '' ) ) : ''; $vars = array( 'title' => get_the_title( $id ), 'excerpt' => $excerpt ); $title = self::replace( get_post_meta( $id, self::P . 'title', true ) ?: self::o( 'seo_title_' . $fallback ), $vars ); $description = self::replace( get_post_meta( $id, self::P . 'description', true ) ?: self::o( 'seo_description_' . $fallback ), $vars ); $title = $title ?: get_the_title( $id ); $description = $description ?: ( $excerpt ?: get_bloginfo( 'description' ) ); return array( 'id' => $id, 'title' => $title, 'description' => $description, 'canonical' => get_post_meta( $id, self::P . 'canonical', true ) ?: get_permalink( $id ) ); } if ( is_tax() || is_category() || is_tag() ) { $t = get_queried_object(); $desc = term_description( $t ); return array( 'term' => $t, 'title' => self::replace( get_term_meta( $t->term_id, self::P . 'title', true ) ?: self::o( 'seo_title_taxonomy' ), array( 'term' => $t->name, 'title' => $t->name, 'description' => wp_strip_all_tags( $desc ) ) ), 'description' => self::replace( get_term_meta( $t->term_id, self::P . 'description', true ) ?: self::o( 'seo_description_taxonomy' ), array( 'term' => $t->name, 'title' => $t->name, 'description' => wp_strip_all_tags( $desc ) ) ), 'canonical' => get_term_link( $t ) ); } $object = get_queried_object(); $base = is_search() ? sprintf( 'Resultados para: %s', get_search_query() ) : ( is_author() && $object ? $object->display_name : ( is_post_type_archive() && $object ? $object->labels->name : get_bloginfo( 'name' ) ) ); return array( 'title' => self::replace( self::o( 'seo_title_archive' ), array( 'title' => $base ) ), 'description' => self::replace( self::o( 'seo_description_archive' ), array( 'title' => $base ) ), 'canonical' => self::canonical_url() ); }
	/** Título, descripción y canonical efectivos de la petición actual. */
	public static function context() { return self::current(); }
	public static function title( $title ) { $c = self::current(); return $c['title'] ?: $title; }
	private static function canonical_url() { global $wp; return home_url( add_query_arg( array(), $wp->request ?? '' ) ); }
	private static function should_noindex() { if ( is_search() && self::o( 'noindex_search' ) ) return true; if ( is_author() && self::o( 'noindex_authors' ) ) return true; if ( is_date() && self::o( 'noindex_date_archives' ) ) return true; if ( is_attachment() && self::o( 'noindex_attachments' ) ) return true; if ( is_singular( 'elementor_library' ) && self::o( 'noindex_elementor' ) ) return true; if ( is_tag() && self::o( 'noindex_empty_tags' ) && ! (int) get_queried_object()->count ) return true; if ( self::o( 'seo_noindex_paginated' ) && is_paged() && ! is_singular() ) return true; if ( self::o( 'seo_noindex_password' ) && is_singular() && '' !== (string) get_post_field( 'post_password', get_queried_object_id() ) ) return true; if ( self::o( 'noindex_woo_pages' ) && ( ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) || ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) ) ) return true; if ( is_singular() ) { $id = get_queried_object_id(); $legacy_robots = (array) get_post_meta( $id, self::P . 'robots', true ); if ( '1' === get_post_meta( $id, self::P . 'noindex', true ) || in_array( 'noindex', $legacy_robots, true ) ) return true; $slugs = preg_split( '/\r\n|\r|\n/', (string) self::o( 'noindex_page_slugs' ) ); $ids = array_map( 'absint', explode( ',', (string) self::o( 'noindex_page_ids' ) ) ); if ( in_array( get_post_field( 'post_name', $id ), array_map( 'sanitize_title', $slugs ), true ) || in_array( $id, $ids, true ) ) return true; } if ( ( is_tax() || is_category() || is_tag() ) && '1' === get_term_meta( get_queried_object_id(), self::P . 'noindex', true ) ) return true; return false; }
	public static function robots( $robots ) {
		if ( self::should_noindex() ) $robots['noindex'] = true;
		$id = is_singular() ? get_queried_object_id() : 0;
		if ( $id && '1' === get_post_meta( $id, self::P . 'nofollow', true ) ) $robots['nofollow'] = true;
		foreach ( array( 'noarchive', 'noimageindex', 'nosnippet' ) as $flag ) if ( $id && '1' === get_post_meta( $id, self::P . $flag, true ) ) $robots[ $flag ] = true;
		// Límites del fragmento: los del contenido ganan a los del sitio; vacío no publica nada.
		foreach ( array( 'max-snippet' => 'max_snippet', 'max-video-preview' => 'max_video_preview' ) as $directive => $key ) {
			if ( 'max-snippet' === $directive && ! empty( $robots['nosnippet'] ) ) continue;
			$value = $id ? (string) get_post_meta( $id, self::P . $key, true ) : '';
			if ( '' === $value ) $value = (string) self::o( 'seo_' . $key, '' );
			if ( '' !== $value ) $robots[ $directive ] = (string) (int) $value;
		}
		return $robots;
	}
	/** '' (sin límite publicado) o un entero desde -1 (-1 = sin límite explícito). */
	public static function sanitize_robots_number( $value ) { $value = trim( is_scalar( $value ) ? (string) $value : '' ); return '' === $value || ! preg_match( '/^-?\d+$/', $value ) ? '' : (string) max( -1, min( 100000, (int) $value ) ); }
	/** Archivos de autor o por fecha desactivados: 301 a la portada. */
	public static function archive_redirect() { if ( ( is_author() && self::o( 'seo_disable_author_archives' ) ) || ( is_date() && self::o( 'seo_disable_date_archives' ) ) ) { wp_safe_redirect( home_url( '/' ), 301 ); exit; } }
	public static function mobile_horizontal_scroll_css() { if ( is_admin() || is_feed() || Digitalisimo_Integrations_Settings::tools_handles_site_options() || ! self::o( 'seo_mobile_prevent_horizontal_scroll', 0 ) ) return; echo '<style id="digitalisimo-mobile-horizontal-scroll">@media (max-width:767px){html,body{width:100%;max-width:100%;overflow-x:clip;overscroll-behavior-x:none}body{touch-action:pan-y pinch-zoom}.swiper,.swiper-wrapper,.elementor-swiper,.elementor-image-carousel-wrapper,.elementor-slides-wrapper,.elementor-main-swiper{touch-action:pan-x pan-y pinch-zoom}}</style>' . "\n"; }
	public static function head() { if ( is_admin() || is_feed() ) return; $c = self::current(); if ( ! empty( $c['description'] ) ) { echo '<meta name="description" content="' . esc_attr( wp_strip_all_tags( $c['description'] ) ) . '">' . "\n"; self::release_theme_description(); } if ( ! empty( $c['id'] ) && ( $keywords = get_post_meta( $c['id'], self::P . 'keywords', true ) ) ) echo '<meta name="keywords" content="' . esc_attr( wp_strip_all_tags( is_array( $keywords ) ? implode( ', ', $keywords ) : $keywords ) ) . '">' . "\n"; if ( ! empty( $c['id'] ) && ( $post = get_post( $c['id'] ) ) && ( $author = get_userdata( $post->post_author ) ) ) echo '<meta name="author" content="' . esc_attr( $author->display_name ) . '">' . "\n"; $publisher = self::o( 'seo_organization_name' ) ?: ( self::o( 'seo_site_name' ) ?: get_bloginfo( 'name' ) ); if ( $publisher ) echo '<meta name="publisher" content="' . esc_attr( $publisher ) . '">' . "\n"; if ( ! empty( $c['canonical'] ) && ! is_wp_error( $c['canonical'] ) ) echo '<link rel="canonical" href="' . esc_url( $c['canonical'] ) . '">' . "\n"; if ( self::o( 'seo_open_graph' ) ) self::social( $c ); if ( self::o( 'seo_schema_enabled' ) ) Digitalisimo_Integrations_Schema_Graph::head(); }
	/** SEO imprime la descripción (wp_head, 1): se retira la del tema Hello (wp_head, 10) para no duplicarla. */
	public static function release_theme_description() { remove_action( 'wp_head', 'hello_elementor_add_description_meta_tag', 10 ); }
	private static function social( $c ) { $id = $c['id'] ?? 0; $title = $id ? ( get_post_meta( $id, self::P . 'social_title', true ) ?: $c['title'] ) : $c['title']; $desc = $id ? ( get_post_meta( $id, self::P . 'social_description', true ) ?: $c['description'] ) : $c['description']; $image = $id ? ( get_post_meta( $id, self::P . 'social_image', true ) ?: get_the_post_thumbnail_url( $id, 'full' ) ) : ''; $image = $image ?: self::o( 'seo_default_image' ); echo '<meta property="og:locale" content="' . esc_attr( str_replace( '-', '_', get_locale() ) ) . '">' . "\n" . '<meta property="og:type" content="' . ( is_singular( 'post' ) ? 'article' : 'website' ) . '">' . "\n"; if ( $title ) echo '<meta property="og:title" content="' . esc_attr( wp_strip_all_tags( $title ) ) . '">' . "\n"; if ( $desc ) echo '<meta property="og:description" content="' . esc_attr( wp_strip_all_tags( $desc ) ) . '">' . "\n"; echo '<meta property="og:url" content="' . esc_url( $c['canonical'] ) . '">' . "\n" . '<meta property="og:site_name" content="' . esc_attr( self::o( 'seo_site_name' ) ?: get_bloginfo( 'name' ) ) . '">' . "\n"; if ( $image ) echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n"; if ( self::o( 'seo_twitter_enabled', 1 ) ) { echo '<meta name="twitter:card" content="' . esc_attr( self::o( 'seo_twitter_card' ) ?: 'summary_large_image' ) . '">' . "\n"; if ( self::o( 'seo_twitter_user' ) ) echo '<meta name="twitter:site" content="' . esc_attr( self::o( 'seo_twitter_user' ) ) . '">' . "\n"; } }
	/** Inicio › contenido pilar o páginas superiores › contenido. */
	public static function breadcrumbs_for( $post ) {
		$items = array( array( 'name' => 'Inicio', 'url' => home_url( '/' ) ) );
		$id    = $post->ID;
		$pillar = absint( get_post_meta( $id, '_related_pillar', true ) );
		$parents = $pillar && $pillar !== $id ? array( $pillar ) : array_reverse( get_post_ancestors( $post ) );
		foreach ( $parents as $parent ) if ( 'publish' === get_post_status( $parent ) ) $items[] = array( 'name' => self::crumb_name( $parent ), 'url' => get_permalink( $parent ) );
		$items[] = array( 'name' => self::crumb_name( $post->ID ), 'url' => get_permalink( $post ) );
		return $items;
	}
	/** Título de miga propio (importado o editado) o el título del contenido. */
	private static function crumb_name( $id ) { $custom = trim( (string) get_post_meta( $id, self::P . 'breadcrumb_title', true ) ); return wp_strip_all_tags( '' !== $custom ? $custom : get_the_title( $id ) ); }
	public static function breadcrumbs( $schema = false ) { $items = is_singular() && ! is_front_page() ? self::breadcrumbs_for( get_queried_object() ) : array( array( 'name' => 'Inicio', 'url' => home_url( '/' ) ) ); if ( $schema ) { $out = array(); foreach ( $items as $i => $item ) $out[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $item['name'], 'item' => $item['url'] ); return $out; } return $items; }
	public static function breadcrumb_shortcode() { if ( ! self::o( 'seo_breadcrumbs' ) ) return ''; $html = '<nav class="digitalisimo-breadcrumbs" aria-label="Breadcrumb">'; foreach ( self::breadcrumbs() as $i => $item ) { if ( $i ) $html .= ' <span aria-hidden="true">›</span> '; $html .= '<a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['name'] ) . '</a>'; } return $html . '</nav>'; }
	public static function sitemap_enabled( $enabled ) { return false; }
	/** El índice contiene sólo documentos publicados, no autores ni archivos de términos. */
	public static function sitemap_provider( $provider, $name ) { return in_array( $name, array( 'users', 'taxonomies' ), true ) ? false : $provider; }
	public static function sitemap_posts( $types ) {
		if ( ! isset( $types['page'] ) ) { $page = get_post_type_object( 'page' ); if ( $page && is_post_type_viewable( $page ) ) $types['page'] = $page; }
		$raw = self::sanitize_sitemap_list( Digitalisimo_Integrations_SEO_Resolver::option( 'sitemap_post_types' ) );
		$allowed = array_filter( explode( ',', $raw ) );
		// "post,page" era el valor predeterminado antiguo: recupera productos y otros tipos públicos.
		if ( ! $allowed || 'post,page' === $raw || in_array( 'auto', $allowed, true ) || in_array( 'all', $allowed, true ) ) $allowed = array_keys( $types );
		// La portada estática y las páginas propias de cada sitio siempre tienen proveedor.
		$allowed[] = 'page';
		foreach ( $types as $name => $object ) {
			if ( ! in_array( $name, $allowed, true ) || in_array( $name, array( 'attachment', 'elementor_library', 'wp_template', 'wp_template_part', 'wp_block', 'wp_navigation', 'wp_global_styles' ), true ) || ! is_post_type_viewable( $object ) || empty( $object->public ) || ( 'page' !== $name && ! empty( $object->exclude_from_search ) ) ) unset( $types[ $name ] );
		}
		return $types;
	}
	public static function sitemap_query( $args, $post_type = '' ) {
		$ids = array_merge( (array) ( $args['post__not_in'] ?? array() ), array_map( 'absint', preg_split( '/[\s,;]+/', (string) Digitalisimo_Integrations_SEO_Resolver::option( 'sitemap_exclude_ids' ) ) ), array_map( 'absint', preg_split( '/[\s,;]+/', (string) Digitalisimo_Integrations_SEO_Resolver::option( 'noindex_page_ids' ) ) ) );
		if ( 'page' === $post_type && Digitalisimo_Integrations_SEO_Resolver::option( 'noindex_woo_pages' ) && function_exists( 'wc_get_page_id' ) ) foreach ( array( 'cart', 'checkout', 'myaccount' ) as $kind ) $ids[] = absint( wc_get_page_id( $kind ) );
		$slugs = array_filter( array_map( 'sanitize_title', preg_split( '/[\s,;]+/', (string) Digitalisimo_Integrations_SEO_Resolver::option( 'noindex_page_slugs' ) ) ) );
		if ( $slugs && $post_type ) $ids = array_merge( $ids, get_posts( array( 'post_type' => $post_type, 'post_name__in' => $slugs, 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'suppress_filters' => false ) ) );
		$args['post__not_in'] = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		$not_noindex = array( 'relation' => 'OR', array( 'key' => self::P . 'noindex', 'compare' => 'NOT EXISTS' ), array( 'key' => self::P . 'noindex', 'value' => '1', 'compare' => '!=' ) );
		$not_legacy = array( 'relation' => 'OR', array( 'key' => self::P . 'robots', 'compare' => 'NOT EXISTS' ), array( 'key' => self::P . 'robots', 'value' => 'noindex', 'compare' => 'NOT LIKE' ) );
		$args['meta_query'] = empty( $args['meta_query'] ) ? array( 'relation' => 'AND', $not_noindex, $not_legacy ) : array( 'relation' => 'AND', $args['meta_query'], $not_noindex, $not_legacy );
		return $args;
	}
	public static function attachment_redirect() { if ( ! is_attachment() || Digitalisimo_Integrations_Settings::tools_handles_site_options() || ! self::o( 'seo_redirect_attachments' ) ) return; $parent = wp_get_post_parent_id( get_queried_object_id() ); if ( $parent ) { wp_safe_redirect( get_permalink( $parent ), 301 ); exit; } }
}
