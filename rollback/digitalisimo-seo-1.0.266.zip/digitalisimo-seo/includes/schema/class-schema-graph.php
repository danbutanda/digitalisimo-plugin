<?php
defined( 'ABSPATH' ) || exit;

/**
 * Un único grafo JSON-LD por URL.
 *
 * build() arma Organization (o LocalBusiness/Person) + WebSite + WebPage y,
 * cuando corresponde, BreadcrumbList, la entidad del contenido y su autor, todo
 * relacionado por @id. merge() incorpora lo que publican el tema y otros
 * plugins: descarta tipos que no existen en Schema.org y duplicados de las
 * entidades base, funde los @id repetidos y sólo conserva las preguntas
 * frecuentes que se ven en la página. build(), merge() y unify() son puros;
 * el resto lee los datos del sitio actual.
 */
class Digitalisimo_Integrations_Schema_Graph {
	const CLASS_NAME = 'digitalisimo-schema-graph';
	const RAW_QUERY  = 'digitalisimo_schema_raw';
	const RAW_TOKEN  = 'digitalisimo_schema_raw_token';
	/** Entidades que pueden ser el tema principal de una página. */
	const MAIN_TYPES = array( 'Article', 'Product', 'Service', 'Event', 'Recipe', 'Course', 'JobPosting', 'SoftwareApplication', 'VideoObject', 'Book', 'Movie' );
	/** Nombres de país frecuentes → ISO 3166-1 alfa-2 (Google pide el código). */
	const COUNTRIES = array( 'mexico' => 'MX', 'estados unidos' => 'US', 'estados unidos de america' => 'US', 'usa' => 'US', 'united states' => 'US', 'espana' => 'ES', 'spain' => 'ES', 'colombia' => 'CO', 'argentina' => 'AR', 'chile' => 'CL', 'peru' => 'PE', 'ecuador' => 'EC', 'venezuela' => 'VE', 'guatemala' => 'GT', 'costa rica' => 'CR', 'panama' => 'PA', 'uruguay' => 'UY', 'paraguay' => 'PY', 'bolivia' => 'BO', 'honduras' => 'HN', 'el salvador' => 'SV', 'nicaragua' => 'NI', 'republica dominicana' => 'DO', 'puerto rico' => 'PR', 'cuba' => 'CU', 'canada' => 'CA', 'brasil' => 'BR', 'brazil' => 'BR' );

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'start_buffer' ), 4 );
		add_filter( 'woocommerce_structured_data_product', array( __CLASS__, 'woo_markup' ), 20, 2 );
	}

	/* ------------------------------------------------------------------ *
	 * Construcción (pura)
	 * ------------------------------------------------------------------ */

	public static function country( $value ) {
		$value = trim( (string) $value );
		if ( preg_match( '/^[A-Za-z]{2}$/', $value ) ) return strtoupper( $value );
		$key = Digitalisimo_Integrations_Schema_Rules::normalize( $value );
		return self::COUNTRIES[ $key ] ?? $value;
	}

	/**
	 * Un negocio local sólo se declara con datos reales: nombre, ciudad,
	 * calle o código postal, y teléfono o coordenadas.
	 */
	public static function local_ready( $local ) {
		if ( ! is_array( $local ) ) return false;
		$a = $local['address'] ?? array();
		return '' !== trim( (string) ( $local['name'] ?? '' ) ) && '' !== trim( (string) ( $a['addressLocality'] ?? '' ) ) && ( '' !== trim( (string) ( $a['streetAddress'] ?? '' ) ) || '' !== trim( (string) ( $a['postalCode'] ?? '' ) ) ) && ( '' !== trim( (string) ( $local['telephone'] ?? '' ) ) || ! empty( $local['geo'] ) );
	}

	/** @id estables de las entidades base. */
	public static function ids( $site, $page ) {
		$home = $site['home'];
		$person = 'Person' === ( $site['org_type'] ?? '' );
		return array(
			'identity'   => $home . ( $person ? '#person' : '#organization' ),
			'local'      => $home . '#localbusiness',
			'website'    => $home . '#website',
			'webpage'    => $page['url'] . '#webpage',
			'breadcrumb' => $page['url'] . '#breadcrumb',
			'image'      => $page['url'] . '#primaryimage',
		);
	}

	/**
	 * $site: home, name, org_name, org_type (Organization|LocalBusiness|Person),
	 * org_url, logo, image, same_as, email, language, local (array|null).
	 * $page: kind (home|singular|archive|term|search), url, title, description,
	 * published, modified, image, breadcrumbs, entity (array|null), about_identity,
	 * spatial.
	 */
	public static function build( $site, $page ) {
		$ids   = self::ids( $site, $page );
		$graph = array();
		$local = self::local_ready( $site['local'] ?? null ) ? $site['local'] : null;
		$type  = $site['org_type'] ?? 'Organization';
		if ( ! in_array( $type, array( 'Organization', 'LocalBusiness', 'Person' ), true ) ) $type = 'Organization';
		$is_person = 'Person' === $type;
		// LocalBusiness sin datos reales se publica como Organization.
		if ( 'LocalBusiness' === $type ) $type = 'Organization';

		$identity = array( '@type' => $is_person ? 'Person' : ( $local ? $local['type'] : $type ), '@id' => $ids['identity'], 'name' => $site['org_name'], 'url' => $site['org_url'] ?: $site['home'] );
		if ( ! $is_person && ! empty( $site['name'] ) && $site['name'] !== $site['org_name'] ) $identity['alternateName'] = $site['name'];
		if ( $site['logo'] ) $identity[ $is_person ? 'image' : 'logo' ] = array( '@type' => 'ImageObject', 'url' => $site['logo'] );
		if ( ! $is_person && ! empty( $site['image'] ) && $site['image'] !== $site['logo'] ) $identity['image'] = $site['image'];
		if ( ! empty( $site['same_as'] ) ) $identity['sameAs'] = array_values( $site['same_as'] );
		if ( ! empty( $site['email'] ) ) $identity['email'] = $site['email'];
		if ( ! $is_person && ! empty( $site['local']['telephone'] ) ) $identity['telephone'] = $site['local']['telephone'];
		$business = null;
		if ( $local ) {
			$business = array_filter( array(
				'alternateName'             => ( $local['name'] !== $site['org_name'] ) ? $local['name'] : '',
				'image'                     => $site['logo'] ?: ( $site['image'] ?? '' ),
				'telephone'                 => $local['telephone'] ?? '',
				'priceRange'                => $local['price'] ?? '',
				'address'                   => array( '@type' => 'PostalAddress' ) + array_filter( array_map( 'trim', array_map( 'strval', (array) $local['address'] ) ), 'strlen' ),
				'geo'                       => $local['geo'] ?? array(),
				'openingHoursSpecification' => $local['hours'] ?? array(),
			) );
			if ( isset( $business['address']['addressCountry'] ) ) $business['address']['addressCountry'] = self::country( $business['address']['addressCountry'] );
			if ( isset( $business['geo'] ) ) {
				$lat = self::coordinate( $business['geo']['latitude'] ); $lng = self::coordinate( $business['geo']['longitude'] );
				$business['geo'] = array( '@type' => 'GeoCoordinates', 'latitude' => $lat, 'longitude' => $lng );
				$business['hasMap'] = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $lat . ',' . $lng );
			}
		}
		if ( $business && ! $is_person ) $identity += $business;
		if ( ! $is_person && ! empty( $identity['telephone'] ) && ! empty( $identity['email'] ) ) $identity['contactPoint'] = array( '@type' => 'ContactPoint', 'telephone' => $identity['telephone'], 'email' => $identity['email'] );
		$graph[] = $identity;
		// Una persona con negocio: el negocio es una entidad propia fundada por ella.
		if ( $business && $is_person ) $graph[] = array( '@type' => $local['type'], '@id' => $ids['local'], 'name' => $local['name'], 'url' => $site['home'], 'founder' => array( '@id' => $ids['identity'] ) ) + $business;

		$website = array( '@type' => 'WebSite', '@id' => $ids['website'], 'url' => $site['home'], 'name' => $site['name'], 'publisher' => array( '@id' => $ids['identity'] ) );
		if ( ! empty( $site['language'] ) ) $website['inLanguage'] = $site['language'];
		$graph[] = $website;

		$kind     = $page['kind'];
		$web_type = in_array( $kind, array( 'author', 'profile' ), true ) && ! empty( $page['profile']['name'] ) ? 'ProfilePage' : ( 'search' === $kind ? 'SearchResultsPage' : ( in_array( $kind, array( 'archive', 'term' ), true ) ? 'CollectionPage' : 'WebPage' ) );
		$webpage  = array_filter( array(
			'@type'         => $web_type,
			'@id'           => $ids['webpage'],
			'url'           => $page['url'],
			'name'          => $page['title'],
			'description'   => $page['description'],
			'isPartOf'      => array( '@id' => $ids['website'] ),
			'inLanguage'    => $site['language'] ?? '',
			'datePublished' => $page['published'] ?? '',
			'dateModified'  => $page['modified'] ?? '',
		) );
		if ( ! empty( $page['image'] ) ) $webpage['primaryImageOfPage'] = array( '@type' => 'ImageObject', '@id' => $ids['image'], 'url' => $page['image'] );
		if ( 'home' === $kind || ! empty( $page['about_identity'] ) ) $webpage['about'] = array( '@id' => $ids['identity'] );
		if ( ! empty( $page['spatial'] ) ) $webpage['spatialCoverage'] = $page['spatial'];
		$profile = null;
		if ( 'ProfilePage' === $web_type ) {
			$profile = self::person_node( $site, $page['profile'] );
			$webpage['mainEntity'] = array( '@id' => $profile['@id'] );
		}

		// Breadcrumbs sólo en páginas internas con al menos dos niveles.
		$crumbs = (array) ( $page['breadcrumbs'] ?? array() );
		$breadcrumb = null;
		if ( 'home' !== $kind && count( $crumbs ) >= 2 ) {
			$items = array();
			foreach ( array_values( $crumbs ) as $i => $crumb ) $items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $crumb['name'], 'item' => $crumb['url'] );
			$breadcrumb = array( '@type' => 'BreadcrumbList', '@id' => $ids['breadcrumb'], 'itemListElement' => $items );
			$webpage['breadcrumb'] = array( '@id' => $ids['breadcrumb'] );
		}

		$entity = null;
		$author = null;
		if ( ! empty( $page['entity'] ) ) {
			$e    = $page['entity'];
			$id   = $page['url'] . '#' . strtolower( $e['type'] );
			$base = array( '@type' => $e['type'], '@id' => $id, 'mainEntityOfPage' => array( '@id' => $ids['webpage'] ) );
			if ( Digitalisimo_Integrations_Schema_Vocabulary::is_a( $e['type'], 'Article' ) ) {
				$entity = $base + array_filter( array( 'headline' => self::cut( $page['headline'] ?? $page['title'], 110 ), 'description' => $page['description'], 'datePublished' => $page['published'] ?? '', 'dateModified' => $page['modified'] ?? '', 'inLanguage' => $site['language'] ?? '', 'publisher' => array( '@id' => $ids['identity'] ), 'articleSection' => $e['section'] ?? '', 'keywords' => $e['keywords'] ?? '' ) );
				if ( ! empty( $page['image'] ) ) $entity['image'] = array( '@id' => $ids['image'] );
				if ( ! empty( $page['author']['name'] ) ) {
					$author = self::person_node( $site, $page['author'] );
					$entity['author'] = array( '@id' => $author['@id'] );
				}
			} elseif ( 'Service' === $e['type'] ) {
				$entity = $base + array_filter( array( 'name' => $page['headline'] ?? $page['title'], 'description' => $page['description'], 'url' => $page['url'], 'provider' => array( '@id' => $ids['identity'] ), 'areaServed' => $page['spatial'] ?? array(), 'image' => $page['image'] ?? '' ) );
				if ( isset( $e['offers']['price'], $e['offers']['priceCurrency'] ) && is_numeric( $e['offers']['price'] ) && preg_match( '/^[A-Z]{3}$/', $e['offers']['priceCurrency'] ) ) $entity['offers'] = array( '@type' => 'Offer', 'price' => $e['offers']['price'], 'priceCurrency' => $e['offers']['priceCurrency'], 'url' => $page['url'], 'seller' => array( '@id' => $ids['identity'] ) );
			} elseif ( 'Product' === $e['type'] ) {
				// Identificadores del producto o de la variación elegida en la URL, como los decide WooCommerce (RM8).
				$entity = $base + array_filter( array( 'name' => $page['headline'] ?? $page['title'], 'description' => $page['description'], 'url' => $page['url'], 'image' => $page['image'] ?? '', 'sku' => $e['sku'] ?? '', 'gtin' => self::sanitize_gtin( $e['gtin'] ?? '' ), 'inProductGroupWithID' => (string) ( $e['group'] ?? '' ) ) );
				if ( ! empty( $e['brand'] ) ) $entity['brand'] = array( '@type' => 'Brand', 'name' => $e['brand'] );
				if ( isset( $e['offers']['priceCurrency'], $e['offers']['price'] ) && is_numeric( $e['offers']['price'] ) && preg_match( '/^[A-Z]{3}$/', $e['offers']['priceCurrency'] ) ) {
					$entity['offers'] = array( '@type' => 'Offer', 'price' => $e['offers']['price'], 'priceCurrency' => $e['offers']['priceCurrency'], 'url' => $page['url'], 'seller' => array( '@id' => $ids['identity'] ) );
					if ( ! empty( $e['offers']['availability'] ) ) $entity['offers']['availability'] = $e['offers']['availability'];
				}
				$entity = self::product_extras( $entity, $e );
			} else {
				$entity = $base + array_filter( array( 'name' => $page['headline'] ?? $page['title'], 'description' => $page['description'], 'url' => $page['url'], 'image' => $page['image'] ?? '' ) );
			}
			$webpage['mainEntity'] = array( '@id' => $id );
		}
		$webpage_index = count( $graph );
		$graph[] = $webpage;
		if ( $breadcrumb ) $graph[] = $breadcrumb;
		if ( $entity ) $graph[] = $entity;
		if ( $author ) $graph[] = $author;
		if ( $profile && $profile['@id'] !== $ids['identity'] ) $graph[] = $profile;
		if ( ! empty( $page['video'] ) ) {
			$video = self::video_node( $page );
			if ( $video ) { $graph[] = $video; $graph[ $webpage_index ]['video'] = array( '@id' => $video['@id'] ); }
		}
		return $graph;
	}

	/** La identidad del autor usa el mismo @id en artículos y en su archivo. */
	private static function person_node( $site, $person ) {
		$slug = trim( (string) ( $person['slug'] ?? '' ) );
		$id = $site['home'] . '#/schema/person/' . rawurlencode( $slug );
		return array_filter( array( '@type' => 'Person', '@id' => $id, 'name' => $person['name'], 'url' => $person['url'] ?? '', 'sameAs' => $person['same_as'] ?? array() ) );
	}

	/** Sólo un video con miniatura, fecha propia y URL de reproducción (archivo o reproductor) reales. */
	private static function video_node( $page ) {
		$v = $page['video'];
		if ( empty( $v['name'] ) || empty( $v['thumbnailUrl'] ) || empty( $v['uploadDate'] ) || ( empty( $v['contentUrl'] ) && empty( $v['embedUrl'] ) ) ) return null;
		return array_filter( array( '@type' => 'VideoObject', '@id' => $page['url'] . '#video', 'name' => $v['name'], 'description' => $v['description'] ?? '', 'thumbnailUrl' => $v['thumbnailUrl'], 'uploadDate' => $v['uploadDate'], 'duration' => $v['duration'] ?? '', 'contentUrl' => $v['contentUrl'] ?? '', 'embedUrl' => $v['embedUrl'] ?? '', 'isPartOf' => array( '@id' => $page['url'] . '#webpage' ) ) );
	}

	/**
	 * Coordenada con 7 decimales (precisión de ~1 cm). Se publica como texto:
	 * un float pasa por serialize_precision y algunos servidores lo imprimen
	 * con 50 cifras.
	 */
	public static function coordinate( $value ) {
		return rtrim( rtrim( number_format( (float) $value, 7, '.', '' ), '0' ), '.' );
	}

	private static function cut( $text, $max ) {
		$text = trim( (string) $text );
		if ( strlen( $text ) <= $max ) return $text;
		$cut = substr( $text, 0, $max );
		// No dejar un carácter UTF-8 partido.
		$cut = preg_replace( '/[\x80-\xBF]+$/', '', $cut );
		$cut = preg_replace( '/[\xC0-\xFF]$/', '', $cut );
		return rtrim( $cut );
	}

	/* ------------------------------------------------------------------ *
	 * Unificación (pura)
	 * ------------------------------------------------------------------ */

	private static function index_of( $graph, $id ) {
		foreach ( $graph as $i => $node ) if ( ( $node['@id'] ?? null ) === $id ) return $i;
		return null;
	}

	private static function find( $graph, $family ) {
		foreach ( $graph as $i => $node ) if ( Digitalisimo_Integrations_Schema_Vocabulary::is_a( Digitalisimo_Integrations_Schema_Rules::types( $node ), $family ) ) return $i;
		return null;
	}

	/** Completa $ours con lo que sólo trae $theirs; lo propio nunca se pisa. */
	public static function fill( $ours, $theirs ) {
		foreach ( $theirs as $key => $value ) {
			if ( '@context' === $key || '@id' === $key || '@type' === $key ) continue;
			if ( ! array_key_exists( $key, $ours ) || null === $ours[ $key ] || '' === $ours[ $key ] || array() === $ours[ $key ] ) $ours[ $key ] = $value;
		}
		return $ours;
	}

	private static function add_type( $node, $type ) {
		$types = Digitalisimo_Integrations_Schema_Rules::types( $node );
		if ( ! in_array( $type, $types, true ) ) $types[] = $type;
		$node['@type'] = 1 === count( $types ) ? $types[0] : $types;
		return $node;
	}

	private static function remap( $value, $map ) {
		if ( ! is_array( $value ) ) return $value;
		if ( isset( $value['@id'] ) && 1 === count( $value ) && is_string( $value['@id'] ) && isset( $map[ $value['@id'] ] ) ) return array( '@id' => $map[ $value['@id'] ] );
		foreach ( $value as $key => $child ) if ( '@id' !== $key ) $value[ $key ] = self::remap( $child, $map );
		return $value;
	}

	/**
	 * Incorpora nodos ajenos al grafo propio. $visible es el texto visible de
	 * la página (null si no se conoce: entonces las FAQ no se filtran).
	 * Devuelve array( grafo, registro de cambios ).
	 */
	public static function merge( $graph, $foreign, $page, $visible = null ) {
		$log      = array();
		$map      = array();
		$home     = ! empty( $page['home'] );
		$url      = rtrim( (string) $page['url'], '/' );
		$identity = self::find( $graph, 'Organization' );
		if ( null === $identity ) $identity = self::find( $graph, 'Person' );
		$website  = self::find( $graph, 'WebSite' );
		$webpage  = self::find( $graph, 'WebPage' );
		foreach ( $foreign as $node ) {
			if ( ! is_array( $node ) ) continue;
			unset( $node['@context'] );
			$label = Digitalisimo_Integrations_Schema_Rules::label( $node );
			$types = Digitalisimo_Integrations_Schema_Rules::types( $node );
			$valid = array_values( array_filter( $types, function( $t ) { return 'unknown' !== Digitalisimo_Integrations_Schema_Vocabulary::status( $t ); } ) );
			$id    = is_string( $node['@id'] ?? null ) ? $node['@id'] : '';
			if ( ! $valid ) {
				$log[] = 'Retirado «' . $label . '»: no es un tipo de Schema.org.';
				// Un negocio con tipo inventado es la misma organización del sitio: sus referencias pasan a ella.
				if ( $id && null !== $identity && array_intersect( array( 'address', 'telephone', 'geo', 'openingHoursSpecification', 'areaServed' ), array_keys( $node ) ) ) $map[ $id ] = $graph[ $identity ]['@id'];
				continue;
			}
			if ( count( $valid ) < count( $types ) ) { $node['@type'] = 1 === count( $valid ) ? $valid[0] : $valid; $log[] = 'Se quitaron de «' . $label . '» los tipos que no existen en Schema.org.'; }
			if ( $id && null !== ( $i = self::index_of( $graph, $id ) ) ) {
				if ( Digitalisimo_Integrations_Schema_Vocabulary::is_a( $types, 'Product' ) && ! empty( $node['offers'] ) ) $graph[ $i ]['offers'] = $node['offers'];
				// El estado declarado por el sitio pasa a las ofertas que llegan sin él.
				$graph[ $i ] = self::offers_condition( self::fill( $graph[ $i ], $node ) ); $log[] = 'Fusionado «' . $label . '» con la entidad del mismo @id.'; continue;
			}
			$is = function( $family ) use ( $valid ) { return Digitalisimo_Integrations_Schema_Vocabulary::is_a( $valid, $family ); };
			$node_url = rtrim( (string) ( is_string( $node['url'] ?? null ) ? $node['url'] : '' ), '/' );
			if ( $is( 'WebSite' ) && null !== $website ) { if ( $id ) $map[ $id ] = $graph[ $website ]['@id']; $log[] = 'Retirado «' . $label . '»: el sitio ya está declarado.'; continue; }
			if ( null !== $identity && ( $is( 'Organization' ) || ( $is( 'Person' ) && '' !== $node_url && $node_url === rtrim( (string) ( $graph[ $identity ]['url'] ?? '' ), '/' ) ) ) ) {
				if ( $id ) $map[ $id ] = $graph[ $identity ]['@id'];
				$log[] = 'Retirado «' . $label . '»: duplica la organización del sitio.';
				continue;
			}
			if ( $is( 'BreadcrumbList' ) ) {
				$own = self::find( $graph, 'BreadcrumbList' );
				if ( $home || null !== $own ) { if ( $id && null !== $own ) $map[ $id ] = $graph[ $own ]['@id']; $log[] = 'Retirado «' . $label . '»: ' . ( $home ? 'la portada no lleva BreadcrumbList.' : 'la ruta de navegación ya está declarada.' ); continue; }
				$node['@id'] = $page['url'] . '#breadcrumb';
				if ( null !== $webpage ) $graph[ $webpage ]['breadcrumb'] = array( '@id' => $node['@id'] );
				$graph[] = $node;
				$log[] = 'Integrado «' . $label . '».';
				continue;
			}
			if ( $is( 'FAQPage' ) && null !== $webpage && ! empty( $graph[ $webpage ]['mainEntity'] ) && ( '' === $node_url || $node_url === $url ) ) { $log[] = 'Retirado «' . $label . '»: la página ya tiene una entidad principal distinta de FAQ.'; continue; }
			if ( $is( 'FAQPage' ) && null !== $webpage && empty( $graph[ $webpage ]['mainEntity'] ) && ( '' === $node_url || $node_url === $url ) ) {
				$graph[ $webpage ] = self::add_type( $graph[ $webpage ], 'FAQPage' );
				$graph[ $webpage ]['mainEntity'] = $node['mainEntity'] ?? array();
				if ( $id ) $map[ $id ] = $graph[ $webpage ]['@id'];
				$log[] = 'Las preguntas de «' . $label . '» se integraron en el WebPage de la URL.';
				continue;
			}
			if ( $is( 'WebPage' ) && null !== $webpage && ( '' === $node_url || $node_url === $url ) ) {
				foreach ( $valid as $type ) $graph[ $webpage ] = self::add_type( $graph[ $webpage ], $type );
				$graph[ $webpage ] = self::fill( $graph[ $webpage ], $node );
				if ( $id ) $map[ $id ] = $graph[ $webpage ]['@id'];
				$log[] = 'Fusionado «' . $label . '» con el WebPage de la URL.';
				continue;
			}
			// Contenido: si ya existe una entidad del mismo tipo, se completan entre sí.
			$same = null;
			$main = false;
			foreach ( self::MAIN_TYPES as $type ) if ( $is( $type ) ) $main = true;
			if ( $main ) foreach ( $graph as $i => $own ) if ( array_intersect( $valid, Digitalisimo_Integrations_Schema_Rules::types( $own ) ) ) { $same = $i; break; }
			if ( null !== $same ) {
				// WooCommerce conoce ofertas, variantes e impuestos mejor que el nodo mínimo propio.
				if ( $is( 'Product' ) && ! empty( $node['offers'] ) ) $graph[ $same ]['offers'] = $node['offers'];
				$graph[ $same ] = self::offers_condition( self::fill( $graph[ $same ], $node ) );
				if ( $id ) $map[ $id ] = $graph[ $same ]['@id'];
				$log[] = 'Fusionado «' . $label . '» con la entidad del mismo tipo.';
				continue;
			}
			if ( '' === $id ) $node['@id'] = $page['url'] . '#' . strtolower( $valid[0] );
			if ( $main && null !== $webpage && empty( $graph[ $webpage ]['mainEntity'] ) ) {
				$graph[ $webpage ]['mainEntity'] = array( '@id' => $node['@id'] );
				if ( empty( $node['mainEntityOfPage'] ) ) $node['mainEntityOfPage'] = array( '@id' => $graph[ $webpage ]['@id'] );
			}
			$graph[] = $node;
			$log[] = 'Integrado «' . $label . '».';
		}
		if ( $map ) $graph = self::remap( $graph, $map );
		if ( null !== $visible ) list( $graph, $log ) = self::visible_faq( $graph, $visible, $log );
		return array( array_values( $graph ), $log );
	}

	/** Sólo quedan las preguntas que el visitante puede leer en la página. */
	private static function visible_faq( $graph, $visible, $log ) {
		foreach ( $graph as $i => $node ) {
			if ( ! in_array( 'FAQPage', Digitalisimo_Integrations_Schema_Rules::types( $node ), true ) ) continue;
			$questions = $node['mainEntity'] ?? array();
			$questions = Digitalisimo_Integrations_Schema_Rules::is_list( $questions ) ? $questions : array( $questions );
			$kept = array();
			foreach ( $questions as $q ) if ( is_array( $q ) && Digitalisimo_Integrations_Schema_Rules::visible( $q['name'] ?? '', $visible ) && Digitalisimo_Integrations_Schema_Rules::visible( $q['acceptedAnswer']['text'] ?? '', $visible ) ) $kept[] = $q;
			if ( count( $kept ) === count( $questions ) ) continue;
			$log[] = ( count( $questions ) - count( $kept ) ) . ' pregunta(s) de FAQPage retiradas: la pregunta o su respuesta no aparecen en el contenido visible.';
			if ( $kept ) { $graph[ $i ]['mainEntity'] = $kept; continue; }
			$types = array_values( array_diff( Digitalisimo_Integrations_Schema_Rules::types( $node ), array( 'FAQPage' ) ) );
			if ( ! $types ) { unset( $graph[ $i ] ); continue; }
			$graph[ $i ]['@type'] = 1 === count( $types ) ? $types[0] : $types;
			unset( $graph[ $i ]['mainEntity'] );
		}
		return array( array_values( $graph ), $log );
	}

	/** Un VideoObject sólo sale si el video realmente se renderizó en la página. */
	private static function visible_video( $graph, $html, $log, $page ) {
		$body = preg_match( '#<body\\b[^>]*>(.*)</body>#is', $html, $match ) ? $match[1] : $html;
		$sources = array();
		if ( preg_match_all( '#<(?:video|source)\\b[^>]*\\b(?:src|data-src)\\s*=\\s*(["\\\'])(.*?)\\1#is', $body, $matches ) ) foreach ( $matches[2] as $src ) $sources[] = html_entity_decode( $src, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$removed = array();
		foreach ( $graph as $i => $node ) {
			if ( ! Digitalisimo_Integrations_Schema_Vocabulary::is_a( Digitalisimo_Integrations_Schema_Rules::types( $node ), 'VideoObject' ) || ( $node['@id'] ?? '' ) !== $page['url'] . '#video' ) continue;
			if ( in_array( $node['contentUrl'] ?? '', $sources, true ) ) continue;
			// Un reproductor de Vimeo: el iframe (o los datos del widget que lo crea) nombra su ID.
			if ( empty( $node['contentUrl'] ) && preg_match( '#^https://player\.vimeo\.com/video/(\d+)$#', (string) ( $node['embedUrl'] ?? '' ), $vimeo ) && preg_match( '#vimeo\.com[^"\s<>]{0,40}?\b' . $vimeo[1] . '\b#', $body ) ) continue;
			$removed[] = $node['@id'] ?? '';
			unset( $graph[ $i ] );
			$log[] = 'Retirado VideoObject: el vídeo no aparece en el HTML final.';
		}
		if ( $removed ) foreach ( $graph as &$node ) if ( in_array( $node['video']['@id'] ?? '', $removed, true ) ) unset( $node['video'] );
		return array( array_values( $graph ), $log );
	}

	public static function script( $graph ) {
		return '<script type="application/ld+json" class="' . self::CLASS_NAME . '">' . self::json( array( '@context' => 'https://schema.org', '@graph' => array_values( $graph ) ) ) . '</script>';
	}

	public static function json( $data, $pretty = false ) {
		$json = (string) json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | ( $pretty ? JSON_PRETTY_PRINT : 0 ) );
		// Un "</script>" dentro de un texto cerraría la etiqueta antes de tiempo.
		return str_replace( '</', '<\/', $json );
	}

	/**
	 * Reúne en el grafo propio todos los JSON-LD de la página. Los bloques que
	 * no se pueden leer quedan intactos; sin grafo propio no se toca nada.
	 * Devuelve array( html, registro ).
	 */
	public static function unify( $html, $page ) {
		$blocks = Digitalisimo_Integrations_Schema_Rules::blocks( $html );
		$own    = null;
		foreach ( $blocks as $i => $block ) if ( false !== strpos( $block['attrs'], self::CLASS_NAME ) && is_array( $block['data'] ) ) { $own = $i; break; }
		if ( null === $own ) return array( $html, array() );
		$foreign = array();
		$remove  = array();
		foreach ( $blocks as $i => $block ) {
			if ( $i === $own || ! is_array( $block['data'] ) ) continue;
			foreach ( Digitalisimo_Integrations_Schema_Rules::nodes( array( $block ) ) as $entry ) $foreign[] = $entry['node'];
			$remove[] = $block['tag'];
		}
		$graph = $blocks[ $own ]['data']['@graph'] ?? array();
		list( $graph, $log ) = self::merge( $graph, $foreign, $page, Digitalisimo_Integrations_Schema_Rules::visible_text( $html ) );
		list( $graph, $log ) = self::visible_video( $graph, $html, $log, $page );
		if ( ! $foreign && ! $log ) return array( $html, array() );
		$html = str_replace( $blocks[ $own ]['tag'], self::script( $graph ), $html );
		foreach ( array_unique( $remove ) as $tag ) $html = str_replace( $tag, '', $html );
		return array( $html, $log );
	}

	/** Filtra sólo las FAQ propias cuando la unificación de otros plugins está apagada. */
	public static function sanitize_own_faq( $html, $page ) {
		foreach ( Digitalisimo_Integrations_Schema_Rules::blocks( $html ) as $block ) {
			if ( false === strpos( $block['attrs'], self::CLASS_NAME ) || ! is_array( $block['data'] ) ) continue;
			$graph = $block['data']['@graph'] ?? array();
			list( $clean, $log ) = self::visible_faq( $graph, Digitalisimo_Integrations_Schema_Rules::visible_text( $html ), array() );
			list( $clean, $log ) = self::visible_video( $clean, $html, $log, $page );
			return $log ? str_replace( $block['tag'], self::script( $clean ), $html ) : $html;
		}
		return $html;
	}

	/* ------------------------------------------------------------------ *
	 * Datos del sitio y de la página (WordPress)
	 * ------------------------------------------------------------------ */

	private static function o( $key, $default = '' ) { return Digitalisimo_Integrations_Settings::get( $key, $default ); }

	public static function site() {
		// Nombres sin emoji (auditoría A2: «DIGITALÍSIMO 🥇»); el aviso del escritorio lo dice.
		$name  = Digitalisimo_Integrations_Brand_Check::plain_name( self::o( 'seo_site_name' ) ?: get_bloginfo( 'name' ) );
		$local = null;
		if ( self::o( 'seo_local_enabled' ) ) {
			$lat = trim( (string) self::o( 'seo_local_latitude' ) );
			$lng = trim( (string) self::o( 'seo_local_longitude' ) );
			$local = array(
				'type'      => Digitalisimo_Integrations_Schema_Vocabulary::local_type( self::o( 'seo_local_type' ) ),
				'name'      => Digitalisimo_Integrations_Brand_Check::plain_name( self::o( 'seo_local_name' ) ?: ( self::o( 'seo_organization_name' ) ?: $name ) ),
				'telephone' => Digitalisimo_Integrations_Local_Business::phone(),
				'price'     => self::o( 'seo_local_price_range' ),
				'address'   => array( 'streetAddress' => self::o( 'seo_local_address' ), 'addressLocality' => self::o( 'seo_local_city' ), 'addressRegion' => self::o( 'seo_local_region' ), 'postalCode' => self::o( 'seo_local_postal' ), 'addressCountry' => self::o( 'seo_local_country' ) ),
				'geo'       => is_numeric( $lat ) && is_numeric( $lng ) ? array( 'latitude' => (float) $lat, 'longitude' => (float) $lng ) : array(),
				'hours'     => Digitalisimo_Integrations_Local_Business::schema_hours(),
			);
		}
		return array(
			'home'     => home_url( '/' ),
			'name'     => $name,
			'org_name' => Digitalisimo_Integrations_Brand_Check::plain_name( self::o( 'seo_organization_name' ) ?: $name ),
			'org_type' => self::o( 'seo_organization_type' ) ?: 'Organization',
			'org_url'  => self::o( 'seo_organization_url' ),
			// Comprobadas en segundo plano (Brand_Check): una imagen rota o de demo cae a la de reserva o no se publica.
			'logo'     => Digitalisimo_Integrations_Brand_Check::url( 'logo' ),
			'image'    => Digitalisimo_Integrations_Brand_Check::url( 'image' ),
			'same_as'  => Digitalisimo_Integrations_Social_Profiles::all_urls(),
			'email'    => is_email( self::o( 'seo_organization_email' ) ) ? self::o( 'seo_organization_email' ) : '',
			'language' => get_bloginfo( 'language' ),
			'local'    => $local,
		);
	}

	/** Valores antiguos fueron guardados en minúsculas por sanitize_key(). */
	public static function chosen_type( $post_id ) {
		$raw = strtolower( (string) get_post_meta( $post_id, Digitalisimo_Integrations_SEO_Suite::P . 'schema_type', true ) );
		$types = array( 'article' => 'Article', 'webpage' => 'WebPage', 'faqpage' => 'FAQPage', 'service' => 'Service', 'product' => 'Product', 'localbusiness' => 'LocalBusiness', 'person' => 'Person' );
		return $types[ $raw ] ?? '';
	}

	/** Tipo de entidad del contenido según el editor y el tipo de publicación. */
	public static function entity_type( $post ) {
		$chosen = self::chosen_type( $post->ID );
		$woo    = 'product' === $post->post_type && function_exists( 'wc_get_product' );
		// El tipo real de WooCommerce prevalece sobre una selección antigua del editor.
		if ( 'product' === $post->post_type ) return $woo && self::o( 'seo_schema_unify', 1 ) ? 'Product' : '';
		if ( in_array( $chosen, array( 'Article', 'Service' ), true ) ) return $chosen;
		// Una plantilla con condiciones que coincide manda sobre el tipo por defecto (RM8).
		$template = '' === $chosen ? self::template_for( $post ) : null;
		if ( $template ) return $template['type'];
		// Sin elección en el editor manda el tipo por defecto de su tipo de contenido (RM8); «none» no publica entidad.
		$default = '' === $chosen ? self::type_default( $post->post_type ) : '';
		if ( 'none' === $default ) return '';
		if ( '' !== $default ) return $default;
		if ( '' === $chosen && 'post' === $post->post_type ) return 'BlogPosting';
		if ( '' === $chosen && preg_match( '/^(?:services?|servicios?)$/i', $post->post_type ) ) return 'Service';
		return '';
	}

	/** Entidades que un tipo de contenido puede declarar por defecto. */
	public static function type_default_choices() { return array( '' => 'Automático', 'Article' => 'Artículo', 'BlogPosting' => 'Entrada de blog', 'NewsArticle' => 'Noticia', 'Service' => 'Servicio', 'none' => 'Ninguna (sólo WebPage)' ); }
	public static function sanitize_type_defaults( $value ) {
		$out = array();
		foreach ( is_array( $value ) ? $value : array() as $type => $choice ) {
			$type = sanitize_key( $type );
			if ( '' !== $type && '' !== $choice && array_key_exists( (string) $choice, self::type_default_choices() ) ) $out[ $type ] = (string) $choice;
		}
		return array_slice( $out, 0, 50, true );
	}
	public static function type_default( $post_type ) {
		$defaults = self::o( 'seo_schema_type_defaults', array() );
		$value    = is_array( $defaults ) ? (string) ( $defaults[ $post_type ] ?? '' ) : '';
		return array_key_exists( $value, self::type_default_choices() ) ? $value : '';
	}
	/* ------------------------------------------------------------------ */
	/* Plantillas con condiciones (RM8).                                    */
	/* ------------------------------------------------------------------ */

	/** Entidades que una plantilla puede aportar. Product no: lo describe WooCommerce. */
	public static function template_type_choices() { return array( 'Article' => 'Artículo', 'BlogPosting' => 'Entrada de blog', 'NewsArticle' => 'Noticia', 'Service' => 'Servicio', 'Event' => 'Evento', 'Recipe' => 'Receta', 'Course' => 'Curso', 'JobPosting' => 'Oferta de empleo', 'SoftwareApplication' => 'Aplicación', 'VideoObject' => 'Vídeo', 'Book' => 'Libro', 'Movie' => 'Película' ); }
	const TEMPLATES_MAX = 20;

	/** Lista de IDs positivos y únicos, de texto con comas o de un arreglo. */
	private static function id_list( $value ) {
		$value = is_array( $value ) ? $value : preg_split( '/[\s,]+/', (string) $value );
		return array_slice( array_values( array_unique( array_filter( array_map( 'absint', (array) $value ) ) ) ), 0, 200 );
	}

	/**
	 * Plantillas válidas. Una fila sin tipo válido, sin tipos de contenido o marcada para quitar se descarta;
	 * las propiedades son un objeto JSON sin @context, @id, @type ni @graph (los pone el grafo).
	 */
	public static function sanitize_templates( $value ) {
		$out = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			if ( ! is_array( $row ) || ! empty( $row['remove'] ) ) continue;
			$type = (string) ( $row['type'] ?? '' );
			if ( ! array_key_exists( $type, self::template_type_choices() ) ) continue;
			$types = array_slice( array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) ( $row['post_types'] ?? array() ) ) ) ) ), 0, 20 );
			$terms = is_array( $row['terms'] ?? null ) ? $row['terms'] : explode( ',', (string) ( $row['terms'] ?? '' ) );
			$terms = array_slice( array_values( array_unique( array_filter( array_map( 'sanitize_title', (array) $terms ) ) ) ), 0, 50 );
			$props = is_array( $row['properties'] ?? null ) ? $row['properties'] : json_decode( trim( (string) ( $row['properties'] ?? '' ) ), true );
			$props = is_array( $props ) && ! Digitalisimo_Integrations_Schema_Rules::is_list( $props ) ? array_diff_key( $props, array_flip( array( '@context', '@id', '@type', '@graph' ) ) ) : array();
			$json  = $props ? (string) wp_json_encode( $props, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) : '';
			$out[] = array(
				'name'       => mb_substr( sanitize_text_field( (string) ( $row['name'] ?? '' ) ), 0, 80 ),
				'type'       => $type,
				'post_types' => $types,
				'taxonomy'   => $terms ? sanitize_key( (string) ( $row['taxonomy'] ?? '' ) ) : '',
				'terms'      => $terms,
				'include'    => self::id_list( $row['include'] ?? '' ),
				'exclude'    => self::id_list( $row['exclude'] ?? '' ),
				'properties' => strlen( $json ) <= 20000 ? $json : '',
			);
			if ( count( $out ) >= self::TEMPLATES_MAX ) break;
		}
		return $out;
	}

	/**
	 * ¿La plantilla se aplica? Falla cerrada: sin tipos de contenido no coincide nunca, y con términos
	 * exige que el contenido tenga uno de ellos en su taxonomía.
	 *
	 * @param array $terms Slugs que el contenido tiene en la taxonomía de la plantilla.
	 */
	public static function template_matches( array $template, $post_type, $post_id, array $terms ) {
		if ( empty( $template['post_types'] ) || ! in_array( $post_type, (array) $template['post_types'], true ) ) return false;
		if ( in_array( (int) $post_id, (array) ( $template['exclude'] ?? array() ), true ) ) return false;
		if ( ! empty( $template['include'] ) && ! in_array( (int) $post_id, (array) $template['include'], true ) ) return false;
		if ( ! empty( $template['terms'] ) && ( empty( $template['taxonomy'] ) || ! array_intersect( (array) $template['terms'], $terms ) ) ) return false;
		return true;
	}

	/** @var array Plantilla aplicada por contenido en esta petición. */
	private static $template_cache = array();

	/** Primera plantilla que coincide con el contenido, o null. La elección del editor siempre gana. */
	public static function template_for( $post ) {
		if ( ! $post || 'product' === $post->post_type || '' !== self::chosen_type( $post->ID ) ) return null;
		if ( array_key_exists( $post->ID, self::$template_cache ) ) return self::$template_cache[ $post->ID ];
		$templates = self::o( 'seo_schema_templates', array() );
		$found     = null;
		foreach ( is_array( $templates ) ? $templates : array() as $template ) {
			if ( ! is_array( $template ) || ! array_key_exists( (string) ( $template['type'] ?? '' ), self::template_type_choices() ) ) continue;
			$terms = array();
			if ( ! empty( $template['terms'] ) && ! empty( $template['taxonomy'] ) && taxonomy_exists( $template['taxonomy'] ) ) {
				$assigned = get_the_terms( $post->ID, $template['taxonomy'] );
				$terms    = is_array( $assigned ) ? wp_list_pluck( $assigned, 'slug' ) : array();
			}
			if ( self::template_matches( $template, $post->post_type, $post->ID, $terms ) ) { $found = $template; break; }
		}
		return self::$template_cache[ $post->ID ] = $found;
	}

	/** Las variables de los títulos (%title%, %excerpt%, %customfield(x)%…) en cada texto del nodo. */
	public static function template_values( $value, array $context, $depth = 0 ) {
		if ( is_string( $value ) ) return false === strpos( $value, '%' ) ? $value : Digitalisimo_Integrations_SEO_Variables::replace( $value, $context );
		if ( ! is_array( $value ) || $depth > 8 ) return is_array( $value ) ? array() : $value;
		$out = array();
		foreach ( $value as $key => $item ) {
			$item = self::template_values( $item, $context, $depth + 1 );
			if ( '' !== $item && array() !== $item ) $out[ $key ] = $item;
		}
		return $out;
	}

	/** Nodo de la plantilla del contenido: completa la entidad principal, nunca añade otro bloque. */
	public static function template_nodes( $post ) {
		$template = self::template_for( $post );
		if ( ! $template ) return array();
		$props = json_decode( (string) ( $template['properties'] ?? '' ), true );
		$props = is_array( $props ) ? array_diff_key( $props, array_flip( array( '@context', '@id', '@type', '@graph' ) ) ) : array();
		$node  = array( '@type' => $template['type'] ) + self::template_values( $props, array( 'id' => $post->ID, 'title' => get_the_title( $post ) ) );
		return array_column( Digitalisimo_Integrations_Schema_Rules::nodes( array( array( 'data' => $node ) ) ), 'node' );
	}

	/** Taxonomía de marcas de los productos: la elegida o, si existe, la de WooCommerce. Con marca fija, ninguna. */
	public static function brand_taxonomy() {
		$chosen = sanitize_key( (string) self::o( 'seo_product_brand', '' ) );
		if ( self::BRAND_FIXED === $chosen ) return '';
		if ( '' !== $chosen ) return taxonomy_exists( $chosen ) ? $chosen : '';
		return taxonomy_exists( 'product_brand' ) ? 'product_brand' : '';
	}

	/* ------------------------------------------------------------------ */
	/* Producto: marca, identificadores y estado (RM8).                     */
	/* ------------------------------------------------------------------ */

	/** Valor de `seo_product_brand` que publica la marca escrita en `seo_product_brand_name` en todos los productos. */
	const BRAND_FIXED = '_fixed';
	/** Estados de OfferItemCondition que el sitio puede declarar. */
	const CONDITIONS = array( 'NewCondition' => 'Nuevo', 'UsedCondition' => 'Usado', 'RefurbishedCondition' => 'Reacondicionado', 'DamagedCondition' => 'Dañado' );
	/** Google Merchant Center admite MPN de hasta 70 caracteres. */
	const MPN_MAX = 70;
	/**
	 * Primera versión de WooCommerce cuyo set_data() acepta varios tipos en `@type`. Antes, un arreglo rompe la
	 * página del producto (TypeError de preg_match() en PHP 8) o, en PHP 7, descarta todo su marcado.
	 */
	const WOO_TYPES_SINCE = '11.2.0';

	/** Marca de un producto: la fija del sitio o la primera asignada en la taxonomía elegida. '' si no hay. */
	public static function product_brand( $post_id ) {
		if ( self::BRAND_FIXED === sanitize_key( (string) self::o( 'seo_product_brand', '' ) ) ) return self::sanitize_brand_name( self::o( 'seo_product_brand_name', '' ) );
		$taxonomy = self::brand_taxonomy();
		$brands   = $taxonomy ? get_the_terms( $post_id, $taxonomy ) : array();
		return is_array( $brands ) && $brands ? wp_strip_all_tags( $brands[0]->name ) : '';
	}

	/** Texto de la marca fija: una línea, sin etiquetas, como mucho 100 caracteres. */
	public static function sanitize_brand_name( $value ) {
		// UTF-8 inválido: preg_replace() devuelve null y la marca queda vacía.
		$value = trim( (string) preg_replace( '/\s+/u', ' ', strip_tags( (string) $value ) ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, 100 ) : substr( $value, 0, 100 );
	}

	/** Estado por defecto del sitio: uno de CONDITIONS o '' (no se publica). */
	public static function sanitize_condition( $value ) {
		$value = Digitalisimo_Integrations_Schema_Vocabulary::short( (string) $value );
		return array_key_exists( $value, self::CONDITIONS ) ? $value : '';
	}
	public static function condition_choices() { return array( '' => 'No publicar' ) + self::CONDITIONS; }

	/** GTIN como lo valida WooCommerce: sólo cifras, de 8, 12, 13 o 14. */
	public static function sanitize_gtin( $value ) {
		$value = preg_replace( '/[^0-9]/', '', (string) $value );
		return preg_match( '/^(\d{8}|\d{12,14})$/', $value ) ? $value : '';
	}

	/** MPN: el código del fabricante tal como lo escribe, en una línea y con como mucho 70 caracteres. */
	public static function sanitize_mpn( $value ) {
		// UTF-8 inválido: preg_replace() devuelve null y el MPN no se acepta.
		$value = trim( (string) preg_replace( '/[\s\x00-\x1F\x7F]+/u', ' ', strip_tags( (string) $value ) ) );
		if ( '' === $value ) return '';
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $value ) : strlen( $value );
		return $length <= self::MPN_MAX ? $value : '';
	}

	/**
	 * ISBN-10 o ISBN-13 con su dígito de control; se guarda sin guiones ni espacios. '' si no es válido:
	 * un número equivocado nunca se publica.
	 */
	public static function sanitize_isbn( $value ) {
		$isbn = strtoupper( preg_replace( '/[\s\-]+/', '', (string) $value ) );
		if ( preg_match( '/^\d{9}[\dX]$/', $isbn ) ) {
			$sum = 0;
			for ( $i = 0; $i < 10; $i++ ) $sum += ( 10 - $i ) * ( 'X' === $isbn[ $i ] ? 10 : (int) $isbn[ $i ] );
			return 0 === $sum % 11 ? $isbn : '';
		}
		if ( preg_match( '/^97[89]\d{10}$/', $isbn ) ) {
			$sum = 0;
			for ( $i = 0; $i < 13; $i++ ) $sum += ( $i % 2 ? 3 : 1 ) * (int) $isbn[ $i ];
			return 0 === $sum % 10 ? $isbn : '';
		}
		return '';
	}

	/** Estado de un producto: el suyo, «none» (no publicar) o, si no eligió, el del sitio. */
	public static function product_condition( $product_id ) {
		$own = (string) get_post_meta( $product_id, Digitalisimo_Integrations_SEO_Suite::P . 'condition', true );
		if ( 'none' === $own ) return '';
		$own = self::sanitize_condition( $own );
		return '' !== $own ? $own : self::sanitize_condition( self::o( 'seo_product_condition', '' ) );
	}

	/**
	 * Añade a un nodo Product lo que el sitio declaró: MPN, ISBN (con el tipo Book, que es el que tiene
	 * esa propiedad) y el estado, en el producto y en cada oferta. Nunca pisa lo que el nodo ya trae. Pura.
	 *
	 * @param array $node Nodo Product (propio o de WooCommerce).
	 * @param array $data mpn, isbn y condition ya saneados.
	 */
	public static function product_extras( array $node, array $data ) {
		foreach ( array( 'mpn' => self::sanitize_mpn( $data['mpn'] ?? '' ), 'isbn' => self::sanitize_isbn( $data['isbn'] ?? '' ) ) as $key => $value ) if ( '' !== $value && empty( $node[ $key ] ) ) $node[ $key ] = $value;
		if ( ! empty( $node['isbn'] ) ) $node = self::add_type( $node, 'Book' );
		$condition = self::sanitize_condition( $data['condition'] ?? '' );
		if ( '' !== $condition && empty( $node['itemCondition'] ) ) $node['itemCondition'] = 'https://schema.org/' . $condition;
		return self::offers_condition( $node );
	}

	/** El estado del producto pasa a cada oferta que no declara el suyo. Pura. */
	public static function offers_condition( $node ) {
		if ( empty( $node['itemCondition'] ) || ! is_string( $node['itemCondition'] ) || empty( $node['offers'] ) || ! is_array( $node['offers'] ) ) return $node;
		$list = Digitalisimo_Integrations_Schema_Rules::is_list( $node['offers'] );
		$offers = $list ? $node['offers'] : array( $node['offers'] );
		foreach ( $offers as $i => $offer ) if ( is_array( $offer ) && empty( $offer['itemCondition'] ) ) $offers[ $i ]['itemCondition'] = $node['itemCondition'];
		$node['offers'] = $list ? $offers : $offers[0];
		return $node;
	}

	/**
	 * Variación elegida en la URL con las reglas de WooCommerce: producto con precio, todos sus atributos en la
	 * consulta, una sola variación publicada que coincide y con precio. Null en cualquier otro caso.
	 */
	public static function selected_variation( $product ) {
		if ( ! is_object( $product ) || ! is_callable( array( $product, 'is_type' ) ) || ! $product->is_type( 'variable' ) || ! function_exists( 'wc_variation_attribute_name' ) ) return null;
		// WooCommerce sólo elige variación dentro de la oferta, que no publica sin precio del producto; si aquí se
		// eligiera, el nodo propio describiría la variación y la unificación le añadiría los identificadores del padre.
		if ( '' === (string) $product->get_price() ) return null;
		// Con un WooCommerce que no elige variación, su marcado describe el producto y la unificación mezclaría los dos.
		if ( ! self::woo_selects_variation() ) return null;
		$match = array();
		foreach ( array_keys( (array) $product->get_variation_attributes() ) as $attribute ) {
			$key = wc_variation_attribute_name( $attribute );
			if ( ! isset( $_GET[ $key ] ) || '' === $_GET[ $key ] || ! is_string( $_GET[ $key ] ) ) return null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$match[ $key ] = wc_clean( wp_unslash( $_GET[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
		if ( ! $match ) return null;
		$found = null;
		foreach ( (array) $product->get_children() as $child_id ) {
			$variation = wc_get_product( $child_id );
			if ( ! is_object( $variation ) || ! is_callable( array( $variation, 'get_variation_attributes' ) ) || 'publish' !== $variation->get_status() ) continue;
			foreach ( $variation->get_variation_attributes() as $key => $value ) if ( '' !== $value && ( ! isset( $match[ $key ] ) || $match[ $key ] !== $value ) ) continue 2;
			// Dos variaciones que coinciden: el precio es ambiguo y WooCommerce mantiene la oferta del producto.
			if ( $found ) return null;
			$found = $variation;
		}
		return $found && '' !== $found->get_price() ? $found : null;
	}

	/** Datos del nodo Product: los del producto o, con una variación elegida, los suyos (sin heredar los del padre). */
	public static function product_data( $product, $variation = null ) {
		$source = $variation ? $variation : $product;
		$meta   = function( $key ) use ( $source ) { return (string) get_post_meta( $source->get_id(), Digitalisimo_Integrations_SEO_Suite::P . $key, true ); };
		$data   = array(
			'sku'       => (string) $source->get_sku(),
			'gtin'      => is_callable( array( $source, 'get_global_unique_id' ) ) ? self::sanitize_gtin( $source->get_global_unique_id() ) : '',
			'mpn'       => self::sanitize_mpn( $meta( 'mpn' ) ),
			'isbn'      => self::sanitize_isbn( $meta( 'isbn' ) ),
			'condition' => self::product_condition( $product->get_id() ),
		);
		if ( $variation ) $data['group'] = $product->get_sku() ? (string) $product->get_sku() : (string) $product->get_id();
		return $data;
	}

	/** ¿Este sitio publica su schema? Lo mismo que decide start_buffer(): sin SEO ajeno. */
	public static function publishes() {
		return self::o( 'enable_seo' ) && self::o( 'seo_schema_enabled' ) && '' === Digitalisimo_Integrations_SEO_Resolver::foreign_seo();
	}

	/**
	 * `woocommerce_structured_data_product`: WooCommerce describe el producto (y decide la variación elegida, con
	 * `inProductGroupWithID`); aquí sólo se añade lo que el sitio declaró. Así llega también con la unificación apagada.
	 */
	public static function woo_markup( $markup, $product = null ) {
		if ( ! is_array( $markup ) || ! is_object( $product ) || ! is_callable( array( $product, 'get_id' ) ) || ! self::publishes() ) return $markup;
		$variation = isset( $markup['inProductGroupWithID'] ) ? self::selected_variation( $product ) : null;
		$data      = self::product_data( $product, $variation );
		// WooCommerce eligió una variación que aquí no se reconoce: sin identificadores, nunca los del padre.
		if ( isset( $markup['inProductGroupWithID'] ) && ! $variation ) $data['mpn'] = $data['isbn'] = '';
		// El ISBN exige el tipo Product+Book, que WooCommerce anterior a 11.2.0 no admite: ahí sólo va en el nodo propio.
		if ( ! self::woo_accepts_types() ) $data['isbn'] = '';
		return self::product_extras( $markup, $data );
	}

	/** ¿El WooCommerce cargado describe en su marcado la variación elegida en la URL (y no sólo el producto)? */
	public static function woo_selects_variation() {
		return class_exists( 'WC_Structured_Data' ) && method_exists( 'WC_Structured_Data', 'get_selected_variation' );
	}

	/** ¿El WooCommerce cargado (o la versión dada) acepta varios tipos en `@type`? Sin versión conocida, no. */
	public static function woo_accepts_types( $version = null ) {
		$version = (string) ( null === $version ? ( defined( 'WC_VERSION' ) ? WC_VERSION : '' ) : $version );
		return '' !== $version && version_compare( $version, self::WOO_TYPES_SINCE, '>=' );
	}

	/**
	 * Encuentra un único video relevante: uno de la biblioteca (bloque o widget Elementor) o uno de
	 * Vimeo ya resuelto en cola por Digitalisimo_Integrations_Video. Nunca hace peticiones.
	 */
	public static function video_for_post( $post ) {
		$candidates = array();
		if ( function_exists( 'parse_blocks' ) ) {
			$walk = function( $blocks ) use ( &$walk, &$candidates ) {
				foreach ( (array) $blocks as $block ) {
					if ( 'core/video' === ( $block['blockName'] ?? '' ) ) {
						$a = $block['attrs'] ?? array();
						$candidates[] = array( 'id' => $a['id'] ?? 0, 'url' => $a['src'] ?? '', 'poster' => $a['poster'] ?? '' );
					}
					if ( ! empty( $block['innerBlocks'] ) ) $walk( $block['innerBlocks'] );
				}
			};
			$walk( parse_blocks( $post->post_content ) );
		}
		$elementor = get_post_meta( $post->ID, '_elementor_data', true );
		if ( is_string( $elementor ) ) $elementor = json_decode( $elementor, true );
		if ( is_array( $elementor ) ) {
			$walk = function( $elements ) use ( &$walk, &$candidates ) {
				foreach ( (array) $elements as $element ) {
					if ( ! is_array( $element ) ) continue;
					if ( 'video' === ( $element['widgetType'] ?? '' ) ) {
						$a = $element['settings'] ?? array();
						$hosted = isset( $a['hosted_url'] ) && is_array( $a['hosted_url'] ) ? $a['hosted_url'] : array();
						$overlay = isset( $a['image_overlay'] ) && is_array( $a['image_overlay'] ) ? $a['image_overlay'] : array();
						if ( 'hosted' === ( $a['video_type'] ?? '' ) && 'yes' === ( $a['show_image_overlay'] ?? '' ) ) $candidates[] = array( 'id' => $hosted['id'] ?? 0, 'url' => $hosted['url'] ?? '', 'poster' => $overlay['url'] ?? '' );
					}
					if ( ! empty( $element['elements'] ) ) $walk( $element['elements'] );
				}
			};
			$walk( $elementor );
		}
		$vimeo = class_exists( 'Digitalisimo_Integrations_Video' ) ? Digitalisimo_Integrations_Video::vimeo_ids( $post ) : array();
		foreach ( $vimeo as $vimeo_id ) $candidates[] = array( 'vimeo' => $vimeo_id );
		if ( 1 !== count( $candidates ) ) return null;
		$v = $candidates[0];
		if ( isset( $v['vimeo'] ) ) return Digitalisimo_Integrations_Video::vimeo_video( $post->ID, $v['vimeo'] );
		$id = absint( $v['id'] ?: ( $v['url'] && function_exists( 'attachment_url_to_postid' ) ? attachment_url_to_postid( $v['url'] ) : 0 ) );
		if ( ! $id || 0 !== strpos( (string) get_post_mime_type( $id ), 'video/' ) ) return null;
		$url = wp_get_attachment_url( $id );
		$poster = is_string( $v['poster'] ) ? esc_url_raw( $v['poster'] ) : '';
		$date = get_post_time( DATE_W3C, false, $id );
		$name = trim( wp_strip_all_tags( get_the_title( $id ) ) );
		if ( ! $url || ! $poster || ! $date || ! $name || ! preg_match( '#^https?://#i', $url ) || ! preg_match( '#^https?://#i', $poster ) ) return null;
		// Descripción y duración sólo si las dio quien subió el archivo (leyenda o descripción) o WordPress (metadatos).
		$attachment  = get_post( $id );
		$description = $attachment ? trim( wp_strip_all_tags( $attachment->post_excerpt ?: $attachment->post_content ) ) : '';
		$meta        = wp_get_attachment_metadata( $id );
		$duration    = is_array( $meta ) && ! empty( $meta['length'] ) && class_exists( 'Digitalisimo_Integrations_Video' ) ? Digitalisimo_Integrations_Video::iso_duration( (int) $meta['length'] ) : '';
		return array_filter( array( 'name' => $name, 'description' => $description, 'thumbnailUrl' => $poster, 'uploadDate' => $date, 'duration' => $duration, 'contentUrl' => $url ) );
	}

	/** Contexto de un contenido concreto (vista previa del editor o auditoría). */
	public static function post_page( $post ) {
		$front   = (int) get_option( 'page_on_front' );
		$url     = get_post_meta( $post->ID, Digitalisimo_Integrations_SEO_Suite::P . 'canonical', true ) ?: get_permalink( $post );
		$excerpt = trim( wp_strip_all_tags( $post->post_excerpt ) ) ?: Digitalisimo_Integrations_SEO_Variables::summary( $post );
		$title   = get_post_meta( $post->ID, Digitalisimo_Integrations_SEO_Suite::P . 'title', true ) ?: get_the_title( $post );
		$desc    = get_post_meta( $post->ID, Digitalisimo_Integrations_SEO_Suite::P . 'description', true ) ?: $excerpt;
		return self::singular_page( $post, $front && $front === (int) $post->ID, $url, $title, $desc );
	}

	private static function singular_page( $post, $home, $url, $title, $desc ) {
		$type   = $home ? '' : self::entity_type( $post );
		$author = get_userdata( $post->post_author );
		$image  = get_post_meta( $post->ID, Digitalisimo_Integrations_SEO_Suite::P . 'social_image', true ) ?: get_the_post_thumbnail_url( $post, 'full' );
		$chosen = self::chosen_type( $post->ID );
		$entity = $type ? array( 'type' => $type ) : null;
		if ( 'Service' === $type ) {
			// Una integración puede aportar una oferta real; nunca se infiere del texto.
			$offer = apply_filters( 'digitalisimo_seo_service_offer', array(), $post );
			if ( is_array( $offer ) && isset( $offer['price'], $offer['priceCurrency'] ) ) $entity['offers'] = $offer;
		}
		$profile = ! $home && 'Person' === $chosen && 'product' !== $post->post_type ? array( 'name' => wp_strip_all_tags( get_the_title( $post ) ), 'slug' => $post->post_name ?: (string) $post->ID, 'url' => $url ) : array();
		if ( $type && Digitalisimo_Integrations_Schema_Vocabulary::is_a( $type, 'Article' ) ) {
			// Sólo datos que el sitio ya tiene: su categoría principal y las keywords que eligió el editor.
			$taxonomy = Digitalisimo_Integrations_Breadcrumbs::taxonomy_for( $post->post_type );
			$section  = $taxonomy ? Digitalisimo_Integrations_SEO_Variables::primary_term( $post->ID, $taxonomy ) : null;
			if ( $section ) $entity['section'] = wp_strip_all_tags( $section->name );
			$keywords = implode( ', ', array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, Digitalisimo_Integrations_SEO_Suite::P . 'keywords', true ) ) ) ) );
			if ( '' !== $keywords ) $entity['keywords'] = $keywords;
		}
		if ( 'Product' === $type && function_exists( 'wc_get_product' ) && ( $product = wc_get_product( $post->ID ) ) ) {
			$entity += self::product_data( $product, self::selected_variation( $product ) );
			$brand = self::product_brand( $post->ID );
			if ( '' !== $brand ) $entity['brand'] = $brand;
			$price = function_exists( 'wc_get_price_to_display' ) ? wc_get_price_to_display( $product ) : $product->get_price();
			if ( ! $product->is_type( 'variable' ) && is_numeric( $price ) && function_exists( 'get_woocommerce_currency' ) ) {
				$entity['offers'] = array( 'price' => $price, 'priceCurrency' => get_woocommerce_currency(), 'availability' => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock' );
			}
		}
		return array(
			'kind'           => $home ? 'home' : ( $profile ? 'profile' : 'singular' ),
			'home'           => $home,
			'url'            => $url,
			'title'          => wp_strip_all_tags( (string) $title ),
			'headline'       => wp_strip_all_tags( get_the_title( $post ) ),
			'description'    => wp_strip_all_tags( (string) $desc ),
			'published'      => get_the_date( DATE_W3C, $post ),
			'modified'       => get_the_modified_date( DATE_W3C, $post ),
			'image'          => $image ?: '',
			'breadcrumbs'    => $home || ! self::o( 'seo_breadcrumbs' ) ? array() : Digitalisimo_Integrations_SEO_Suite::breadcrumbs_for( $post ),
			'entity'         => $entity,
			'profile'        => $profile,
			'author'         => $author ? array( 'name' => $author->display_name, 'slug' => $author->user_nicename, 'url' => get_author_posts_url( $author->ID ), 'same_as' => $author->user_url ? array( $author->user_url ) : array() ) : array(),
			'about_identity' => 'LocalBusiness' === $chosen,
			'chosen'         => $chosen,
			'woo_product'    => 'product' === $post->post_type && function_exists( 'wc_get_product' ),
			'video'          => self::video_for_post( $post ),
			'spatial'        => Digitalisimo_Integrations_Editorial::location_schema( $post->ID ),
		);
	}

	/** Contexto de la petición actual. Null cuando la página no lleva schema. */
	public static function current_page() {
		if ( is_404() ) return null;
		$c    = Digitalisimo_Integrations_SEO_Suite::context();
		$url  = ! empty( $c['canonical'] ) && ! is_wp_error( $c['canonical'] ) ? $c['canonical'] : home_url( '/' );
		$home = is_front_page();
		if ( is_singular() && ( $post = get_queried_object() ) instanceof WP_Post ) return self::singular_page( $post, $home, $url, $c['title'] ?? '', $c['description'] ?? '' );
		$author_archive = ! $home && is_author() && ! self::o( 'noindex_authors' );
		$kind = $home ? 'home' : ( $author_archive ? 'author' : ( is_search() ? 'search' : ( is_tax() || is_category() || is_tag() ? 'term' : 'archive' ) ) );
		$profile = array();
		if ( $author_archive && ( $user = get_queried_object() ) instanceof WP_User && $user->display_name ) { $url = get_author_posts_url( $user->ID ); $profile = array( 'name' => $user->display_name, 'slug' => $user->user_nicename, 'url' => $url, 'same_as' => $user->user_url ? array( $user->user_url ) : array() ); }
		$crumbs = array();
		// La misma ruta que las migas visibles: la categoría con sus antecesores.
		if ( 'term' === $kind && self::o( 'seo_breadcrumbs' ) && get_queried_object() ) $crumbs = Digitalisimo_Integrations_Breadcrumbs::trail();
		return array( 'kind' => $kind, 'home' => $home, 'url' => $home ? home_url( '/' ) : $url, 'title' => wp_strip_all_tags( (string) ( $c['title'] ?? '' ) ), 'description' => wp_strip_all_tags( (string) ( $c['description'] ?? '' ) ), 'breadcrumbs' => $crumbs, 'entity' => null, 'profile' => $profile );
	}

	/** Nodos del JSON-LD adicional escrito en el editor, si su tipo es oficial. */
	public static function custom_nodes( $post_id ) {
		$custom = json_decode( (string) get_post_meta( $post_id, Digitalisimo_Integrations_SEO_Suite::P . 'schema_custom', true ), true );
		if ( ! is_array( $custom ) ) return array();
		$block = array( array( 'data' => $custom ) );
		return array_column( Digitalisimo_Integrations_Schema_Rules::nodes( $block ), 'node' );
	}

	/** Grafo propio de una página, con el JSON-LD adicional del editor integrado. */
	public static function graph_for( $site, $page, $post_id = 0, $visible = null ) {
		$graph = self::build( $site, $page );
		$log   = array();
		if ( $post_id ) {
			$template = empty( $page['home'] ) && ! empty( $page['entity'] ) && ( $post = get_post( $post_id ) ) ? self::template_nodes( $post ) : array();
			list( $graph, $log ) = self::merge( $graph, array_merge( $template, self::custom_nodes( $post_id ) ), $page, $visible );
		}
		return array( $graph, $log );
	}

	/** Qué debería tener la URL: lo usa el auditor para señalar faltantes. */
	public static function expected( $site, $page ) {
		$local = self::local_ready( $site['local'] ?? null );
		$type  = 'Person' === ( $site['org_type'] ?? '' ) ? 'Person' : 'Organization';
		$out   = array(
			array( 'type' => $type, 'why' => 'Entidad base del sitio.', 'base' => true ),
			array( 'type' => 'WebSite', 'why' => 'Entidad base del sitio.', 'base' => true ),
			array( 'type' => 'WebPage', 'why' => 'Cada URL se declara como página.', 'base' => true ),
		);
		if ( $local ) $out[] = array( 'type' => 'LocalBusiness', 'why' => 'SEO local está activo con dirección y contacto.' );
		if ( in_array( $page['kind'], array( 'author', 'profile' ), true ) && ! empty( $page['profile']['name'] ) ) {
			$out[] = array( 'type' => 'ProfilePage', 'why' => 'Página pública dedicada a una persona real.' );
			$out[] = array( 'type' => 'Person', 'why' => 'Persona descrita por el perfil.' );
		}
		if ( ! empty( $page['video'] ) ) $out[] = array( 'type' => 'VideoObject', 'why' => 'Video único (de la biblioteca o de Vimeo) con miniatura y fecha reales.' );
		if ( 'home' !== $page['kind'] && count( (array) ( $page['breadcrumbs'] ?? array() ) ) >= 2 ) $out[] = array( 'type' => 'BreadcrumbList', 'why' => 'Página interna con ruta de navegación.' );
		if ( ! empty( $page['entity']['type'] ) ) $out[] = array( 'type' => $page['entity']['type'], 'why' => 'Tipo de contenido de esta URL.' );
		if ( ! empty( $page['woo_product'] ) ) $out[] = array( 'type' => 'Product', 'why' => 'Producto de WooCommerce.' );
		if ( 'FAQPage' === ( $page['chosen'] ?? '' ) ) $out[] = array( 'type' => 'FAQPage', 'why' => 'Elegido en el editor: requiere preguntas visibles en la página.' );
		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * Salida
	 * ------------------------------------------------------------------ */

	/** Imprime el grafo propio en <head>. */
	public static function head() {
		$page = self::current_page();
		if ( ! $page ) return;
		$post_id = is_singular() ? get_queried_object_id() : 0;
		list( $graph ) = self::graph_for( self::site(), $page, $post_id );
		echo self::script( $graph ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON codificado.
	}

	public static function raw_requested() {
		$token = isset( $_GET[ self::RAW_QUERY ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::RAW_QUERY ] ) ) : '';
		return '' !== $token && hash_equals( (string) get_transient( self::RAW_TOKEN ), $token );
	}

	public static function start_buffer() {
		if ( is_admin() || is_feed() || is_robots() || wp_doing_ajax() || 'GET' !== ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) return;
		if ( ! self::o( 'enable_seo' ) || ! self::o( 'seo_schema_enabled' ) || Digitalisimo_Integrations_SEO_Resolver::foreign_seo() ) return;
		if ( self::raw_requested() ) { nocache_headers(); return; }
		$page = self::current_page();
		if ( ! $page ) return;
		$unify = (bool) self::o( 'seo_schema_unify', 1 );
		ob_start( function( $html ) use ( $page, $unify ) {
			if ( false === stripos( $html, 'application/ld+json' ) ) return $html;
			if ( $unify ) list( $html ) = self::unify( $html, $page );
			else $html = self::sanitize_own_faq( $html, $page );
			return $html;
		} );
	}
}
