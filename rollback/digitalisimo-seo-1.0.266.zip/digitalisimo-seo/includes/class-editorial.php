<?php
defined( 'ABSPATH' ) || exit;

/** Herramientas editoriales nativas: ubicaciones, clusters y estado de producción. */
class Digitalisimo_Integrations_Editorial {
	public static function init() {
		add_action( 'init', array( __CLASS__, 'locations_taxonomy' ) ); add_action( 'add_meta_boxes', array( __CLASS__, 'metaboxes' ) ); add_action( 'save_post', array( __CLASS__, 'save' ), 30 ); add_action( 'wp_after_insert_post', array( __CLASS__, 'apply_default_cluster' ), 20, 4 ); add_action( 'admin_post_digitalisimo_create_location', array( __CLASS__, 'create_location' ) ); add_action( 'admin_post_digitalisimo_delete_location', array( __CLASS__, 'delete_location' ) );
		// Variables editoriales dinámicas para plantillas de contenido.
		add_shortcode( 'palabra_clave', array( __CLASS__, 'shortcode_primary_keyword' ) );
		add_shortcode( 'palabras_clave_secundarias', array( __CLASS__, 'shortcode_secondary_keywords' ) );
		add_shortcode( 'contenido_pilar', array( __CLASS__, 'shortcode_pillar' ) );
		add_shortcode( 'contenido_secundario', array( __CLASS__, 'shortcode_secondary' ) );
		add_shortcode( 'descripcion_sitio', array( __CLASS__, 'shortcode_site_description' ) );
		add_shortcode( 'ubicacion_seo', array( __CLASS__, 'shortcode_location' ) ); add_shortcode( 'pais_seo', array( __CLASS__, 'shortcode_country' ) ); add_shortcode( 'estado_seo', array( __CLASS__, 'shortcode_state' ) ); add_shortcode( 'ciudad_seo', array( __CLASS__, 'shortcode_city' ) ); add_shortcode( 'zona_seo', array( __CLASS__, 'shortcode_zone' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) ); add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'manage_post_posts_columns', array( __CLASS__, 'columns' ) ); add_filter( 'manage_page_posts_columns', array( __CLASS__, 'columns' ) ); add_action( 'manage_post_posts_custom_column', array( __CLASS__, 'column_value' ), 10, 2 ); add_action( 'manage_page_posts_custom_column', array( __CLASS__, 'column_value' ), 10, 2 );
		add_filter( 'manage_edit-post_sortable_columns', array( __CLASS__, 'sortable' ) ); add_filter( 'manage_edit-page_sortable_columns', array( __CLASS__, 'sortable' ) ); add_action( 'restrict_manage_posts', array( __CLASS__, 'filters' ) ); add_action( 'pre_get_posts', array( __CLASS__, 'query' ) );
		add_action( 'bulk_edit_custom_box', array( __CLASS__, 'bulk_fields' ), 10, 2 ); add_action( 'admin_action_editpost', array( __CLASS__, 'bulk_save' ) );
	}
	/** Obtiene la entrada principal incluso cuando Elementor cambia el post global para otro widget. */
	private static function current_content_id() {
		global $wp_query, $post;
		$candidates = array( get_queried_object_id(), $wp_query instanceof WP_Query ? $wp_query->get_queried_object_id() : 0, $wp_query instanceof WP_Query && ! empty( $wp_query->post->ID ) ? $wp_query->post->ID : 0, ! empty( $post->ID ) ? $post->ID : 0, get_the_ID() );
		foreach ( $candidates as $candidate ) { $id = absint( $candidate ); if ( $id && in_array( get_post_type( $id ), self::types(), true ) ) return $id; }
		return 0;
	}
	private static function post_keywords( $post_id = 0 ) {
		$post_id = $post_id ?: self::current_content_id();
		return array_values( array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $post_id, 'digitalisimo_seo_keywords', true ) ) ) ) );
	}
	/** Inserta la keyword principal configurada para que una plantilla se actualice al editarla. */
	public static function shortcode_primary_keyword() {
		$keywords = self::post_keywords();
		return esc_html( $keywords[0] ?? '' );
	}
	/** Inserta las keywords secundarias configuradas como una lista semántica. */
	public static function shortcode_secondary_keywords() {
		$keywords = self::post_keywords();
		array_shift( $keywords );
		return $keywords ? '<ul><li>' . implode( '</li><li>', array_map( 'esc_html', $keywords ) ) . '</li></ul>' : '';
	}
	public static function shortcode_pillar() {
		$pillar = get_post( absint( get_post_meta( get_the_ID(), '_related_pillar', true ) ) );
		return $pillar ? '<a href="' . esc_url( get_permalink( $pillar ) ) . '">' . esc_html( $pillar->post_title ) . '</a>' : '';
	}
	public static function shortcode_secondary() {
		$posts = get_posts( array( 'post_type' => self::types(), 'post_status' => 'publish', 'posts_per_page' => -1, 'meta_key' => '_related_pillar', 'meta_value' => get_the_ID() ) );
		if ( ! $posts ) return '';
		$html = '<ul>';
		foreach ( $posts as $post ) $html .= '<li><a href="' . esc_url( get_permalink( $post ) ) . '">' . esc_html( $post->post_title ) . '</a></li>';
		return $html . '</ul>';
	}
	public static function shortcode_site_description() { return esc_html( get_bloginfo( 'description' ) ); }
	public static function assets( $hook ) { if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) return; wp_enqueue_style( 'digitalisimo-keyword-manager', DIGITALISIMO_INTEGRATIONS_URL . 'assets/keyword-manager.css', array(), DIGITALISIMO_INTEGRATIONS_VERSION ); wp_enqueue_script( 'digitalisimo-keyword-manager', DIGITALISIMO_INTEGRATIONS_URL . 'assets/keyword-manager.js', array(), DIGITALISIMO_INTEGRATIONS_VERSION, true ); wp_localize_script( 'digitalisimo-keyword-manager', 'digitalisimoSeoAi', array( 'url' => esc_url_raw( rest_url( 'digitalisimo-seo/v1/editorial-suggestions' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) ); }
	/** Herramientas IA bajo demanda: no cambian el contenido hasta que el editor aplica el resultado. */
	public static function routes() { register_rest_route( 'digitalisimo-seo/v1', '/editorial-suggestions', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'editorial_suggestions' ), 'permission_callback' => function( $request ) { return current_user_can( 'edit_post', absint( $request->get_param( 'post_id' ) ) ); } ) ); }
	public static function editorial_suggestions( $request ) {
		$post_id = absint( $request->get_param( 'post_id' ) ); $post = get_post( $post_id );
		if ( ! $post ) return new WP_Error( 'digitalisimo_post', 'No se encontró el contenido.', array( 'status' => 404 ) );
		if ( ! class_exists( 'Digitalisimo_AI' ) ) return new WP_Error( 'digitalisimo_ai_missing', 'Activa DIGITALÍSIMO IA Tools y configura un proveedor para usar estas sugerencias.', array( 'status' => 400 ) );
		$keyword = sanitize_text_field( $request->get_param( 'keyword' ) );
		if ( ! $keyword ) return new WP_Error( 'digitalisimo_keyword', 'Define primero la keyword principal.', array( 'status' => 400 ) );
		$task = sanitize_key( $request->get_param( 'task' ) );
		if ( ! in_array( $task, array( 'keywords', 'description' ), true ) ) return new WP_Error( 'digitalisimo_task', 'Elige qué contenido deseas generar.', array( 'status' => 400 ) );
		$title = sanitize_text_field( $request->get_param( 'title' ) ) ?: $post->post_title;
		$content = wp_strip_all_tags( (string) $request->get_param( 'content' ) );
		$content = trim( preg_replace( '/\\s+/', ' ', $content ) ); if ( ! $content ) $content = wp_strip_all_tags( $post->post_content );
		$content = function_exists( 'mb_substr' ) ? mb_substr( $content, 0, 12000 ) : substr( $content, 0, 12000 );
		$instruction = 'keywords' === $task ? 'Devuelve exclusivamente JSON válido con esta estructura: {"secondary_keywords":["..."],"seo_suggestions":[{"type":"semantic_term|content_opportunity|faq|new_page","text":"...","reason":"..."}]}. secondary_keywords puede tener de cero a cuatro frases. Incluye allí sólo variaciones o términos con intención de búsqueda muy cercana a la keyword principal, que se puedan responder dentro de esta misma página. No llenes la lista por obligación. Toda idea con intención distinta o que merezca una página independiente va exclusivamente en seo_suggestions. seo_suggestions puede incluir términos semánticos, oportunidades de contenido, preguntas frecuentes u oportunidades para nuevas páginas. No incluyas volumen, CPC, competencia, dificultad ni métricas sin datos reales.' : 'Devuelve exclusivamente JSON válido con la clave description: una sola descripción de 120 a 160 caracteres, clara, útil, sin HTML e incluyendo la keyword principal de forma natural. Esta misma descripción se usará como extracto y meta descripción.';
		$prompt = "Analiza este contenido para SEO. Keyword principal: {$keyword}. Título: {$title}. Contenido: {$content}. {$instruction} No inventes datos, métricas ni hechos que no estén en el contenido.";
		$answer = Digitalisimo_AI::complete( 'seo', $prompt, 'Usa sólo los datos proporcionados. Esta es una propuesta editorial que la persona revisará antes de guardarla.' );
		if ( is_wp_error( $answer ) ) return $answer;
		$data = json_decode( trim( preg_replace( '/^```(?:json)?|```$/m', '', $answer ) ), true );
		if ( ! is_array( $data ) ) return new WP_Error( 'digitalisimo_ai_format', 'La IA no devolvió sugerencias con el formato esperado.', array( 'status' => 502 ) );
		$raw_secondary = (array) ( $data['secondary_keywords'] ?? $data['keywords'] ?? array() );
		$secondary = array(); $seen = array( Digitalisimo_Integrations_Keyword_Match::normalize( $keyword ) );
		foreach ( $raw_secondary as $item ) { $item = sanitize_text_field( $item ); $normalized = Digitalisimo_Integrations_Keyword_Match::normalize( $item ); if ( $item && $normalized && ! in_array( $normalized, $seen, true ) ) { $secondary[] = $item; $seen[] = $normalized; } }
		$suggestions = array();
		foreach ( (array) ( $data['seo_suggestions'] ?? array() ) as $item ) {
			if ( is_string( $item ) ) $item = array( 'type' => 'content_opportunity', 'text' => $item, 'reason' => '' );
			if ( ! is_array( $item ) ) continue;
			$type = sanitize_key( $item['type'] ?? 'content_opportunity' ); if ( ! in_array( $type, array( 'semantic_term', 'content_opportunity', 'faq', 'new_page' ), true ) ) $type = 'content_opportunity';
			$text = sanitize_text_field( $item['text'] ?? '' ); if ( ! $text ) continue;
			$suggestions[] = array( 'type' => $type, 'text' => $text, 'reason' => sanitize_text_field( $item['reason'] ?? '' ) );
		}
		return rest_ensure_response( array( 'keywords' => array_slice( $secondary, 0, 4 ), 'secondary_keywords' => array_slice( $secondary, 0, 4 ), 'seo_suggestions' => array_slice( $suggestions, 0, 8 ), 'description' => sanitize_text_field( $data['description'] ?? '' ) ) );
	}
	/** Catálogo administrativo independiente del contenido editorial. */
	public static function locations_taxonomy() { register_taxonomy( 'digitalisimo_seo_location', array(), array( 'labels' => array( 'name' => 'Ubicaciones SEO', 'singular_name' => 'Ubicación SEO' ), 'public' => false, 'show_ui' => false, 'show_in_rest' => false, 'hierarchical' => true ) ); }
	private static function location_levels() { return array( 'country' => 'País', 'state' => 'Estado', 'city' => 'Ciudad', 'zone' => 'Zona' ); }
	private static function location_level( $id ) { $level = get_term_meta( $id, '_digitalisimo_location_level', true ); return array_key_exists( $level, self::location_levels() ) ? $level : ''; }
	private static function location_parts( $id = 0 ) { $parts = array_fill_keys( array_keys( self::location_levels() ), '' ); while ( $id && ( $location = get_term( $id, 'digitalisimo_seo_location' ) ) && ! is_wp_error( $location ) ) { $level = self::location_level( $id ); if ( $level && ! $parts[ $level ] ) $parts[ $level ] = $location->name; $id = (int) $location->parent; } return $parts; }
	private static function location_label( $id ) { $parts = array_filter( self::location_parts( $id ) ); $term = get_term( $id, 'digitalisimo_seo_location' ); return $parts ? implode( ' · ', $parts ) : ( $term && ! is_wp_error( $term ) ? $term->name : '' ); }
	private static function current_location_parts() { return self::location_parts( self::related_location_id( self::current_content_id() ) ); }
	/** La ubicación editorial empieza en el punto más específico: zona → país. */
	public static function shortcode_location() { return esc_html( implode( ', ', array_filter( array_reverse( self::current_location_parts(), true ) ) ) ); }
	public static function shortcode_country() { $p = self::current_location_parts(); return esc_html( $p['country'] ); }
	public static function shortcode_state() { $p = self::current_location_parts(); return esc_html( $p['state'] ); }
	public static function shortcode_city() { $p = self::current_location_parts(); return esc_html( $p['city'] ); }
	public static function shortcode_zone() { $p = self::current_location_parts(); return esc_html( $p['zone'] ); }
	/** Área administrativa estructurada para el JSON-LD del contenido seleccionado. */
	public static function location_schema( $post_id ) { $id = self::related_location_id( $post_id ); $term = $id ? get_term( $id, 'digitalisimo_seo_location' ) : null; if ( ! $term || is_wp_error( $term ) ) return array(); $types = array( 'country' => 'Country', 'state' => 'AdministrativeArea', 'city' => 'City', 'zone' => 'AdministrativeArea' ); $place = array(); while ( $term && ! is_wp_error( $term ) ) { $level = self::location_level( $term->term_id ); if ( $level ) { $node = array( '@type' => $types[ $level ], 'name' => $term->name ); if ( $place ) $node['containedInPlace'] = $place; $place = $node; } $term = $term->parent ? get_term( $term->parent, 'digitalisimo_seo_location' ) : null; } return $place; }
	/** Tipos realmente públicos: nunca plantillas, bloques internos ni biblioteca de Elementor. */
	public static function content_types() {
		$excluded = array( 'attachment', 'elementor_library', 'elementor-hf', 'wp_template', 'wp_template_part', 'wp_global_styles', 'wp_navigation', 'wp_block' );
		$types = get_post_types( array( 'public' => true, 'show_ui' => true ), 'objects' );
		return array_values( array_keys( array_filter( $types, function( $type, $slug ) use ( $excluded ) { return ! in_array( $slug, $excluded, true ); }, ARRAY_FILTER_USE_BOTH ) ) );
	}
	private static function types() { return self::content_types(); }
	/** El catálogo no usa flujo editorial: muestra cada ubicación guardada sin depender de su estado. */
	public static function locations() { $locations = get_terms( array( 'taxonomy' => 'digitalisimo_seo_location', 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) ); return is_wp_error( $locations ) ? array() : $locations; }
	public static function location_select( $name, $selected = 0 ) { echo '<select name="' . esc_attr( $name ) . '"><option value="0">Sin ubicación predeterminada</option>'; foreach ( self::locations() as $location ) echo '<option value="' . esc_attr( $location->term_id ) . '" ' . selected( absint( $selected ), $location->term_id, false ) . '>' . esc_html( self::location_label( $location->term_id ) ) . '</option>'; echo '</select>'; }
	private static function related_location_id( $post_id ) { $id = absint( get_post_meta( $post_id, '_related_location_id', true ) ); if ( $id && term_exists( $id, 'digitalisimo_seo_location' ) ) return $id; $default = absint( Digitalisimo_Integrations_Settings::get( 'default_content_location', 0 ) ); return $default && term_exists( $default, 'digitalisimo_seo_location' ) ? $default : 0; }
	/** Etiqueta usada en listados: sólo muestra una ubicación válida del catálogo editorial. */
	public static function content_location_label( $post_id ) { $own = absint( get_post_meta( $post_id, '_related_location_id', true ) ); $id = self::related_location_id( $post_id ); if ( ! $id ) return ''; $parts = array_filter( array_reverse( self::location_parts( $id ), true ) ); $label = implode( ' · ', $parts ); return $label . ( ! $own ? ' (predeterminada)' : '' ); }
	/** Pilares para la edición masiva: sólo se pintan ID y título, sin precargar sus metadatos ni sus términos. */
	private static function pillars() { return get_posts( array( 'post_type' => self::types(), 'posts_per_page' => -1, 'meta_key' => 'digitalisimo_seo_pillar', 'meta_value' => 'on', 'no_found_rows' => true, 'update_post_meta_cache' => false, 'update_post_term_cache' => false ) ); }
	/**
	 * Contenido publicado que puede ser pilar, por título. Los selectores sólo usan ID, tipo, título y slug: se leen
	 * esas cuatro columnas, no cada entrada completa con su contenido, metadatos y términos (get_posts con -1, que en
	 * el editor crecía con todo lo publicado del sitio).
	 */
	public static function cluster_candidates() {
		global $wpdb;
		$types = self::types();
		if ( ! $types ) return array();
		$in   = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, post_type, post_name FROM {$wpdb->posts} WHERE post_type IN ($in) AND post_status = 'publish' ORDER BY post_title ASC, ID ASC", $types ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $in sólo son marcadores %s.
		foreach ( (array) $rows as $row ) $row->ID = (int) $row->ID;
		return (array) $rows;
	}
	public static function is_cluster_candidate( $post_id ) { $post = get_post( absint( $post_id ) ); return $post && 'publish' === $post->post_status && in_array( $post->post_type, self::types(), true ); }
	/** Resuelve un ID local o un slug heredado desde la red al pilar de este sitio. */
	public static function cluster_candidate_id( $value ) { $id = absint( $value ); if ( $id && self::is_cluster_candidate( $id ) ) return $id; $slug = sanitize_title( (string) $value ); if ( ! $slug ) return 0; $matches = get_posts( array( 'post_type' => self::types(), 'post_status' => 'publish', 'name' => $slug, 'posts_per_page' => 1, 'orderby' => 'ID', 'order' => 'ASC' ) ); return ! empty( $matches[0] ) ? (int) $matches[0]->ID : 0; }
	/** Selector compartido por el editor, Contenido y la configuración de red. */
	public static function cluster_select( $name, $selected = 0, $id = '' ) { echo '<select class="widefat"' . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . ' name="' . esc_attr( $name ) . '"><option value="0">Sin pilar predeterminado</option>'; foreach ( self::cluster_candidates() as $pillar ) { $type = get_post_type_object( $pillar->post_type ); echo '<option value="' . esc_attr( $pillar->ID ) . '" ' . selected( absint( $selected ), $pillar->ID, false ) . '>' . esc_html( ( $type->labels->singular_name ?? $pillar->post_type ) . ' · ' . $pillar->post_title ) . '</option>'; } echo '</select>'; }
	/** En red se guarda un slug para resolver el pilar equivalente dentro de cada sitio. */
	public static function cluster_slug_select( $name, $selected = '', $id = '' ) { echo '<select class="widefat"' . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . ' name="' . esc_attr( $name ) . '"><option value="">Sin pilar predeterminado</option>'; foreach ( self::cluster_candidates() as $pillar ) { $type = get_post_type_object( $pillar->post_type ); echo '<option value="' . esc_attr( $pillar->post_name ) . '" ' . selected( (string) $selected, $pillar->post_name, false ) . '>' . esc_html( ( $type->labels->singular_name ?? $pillar->post_type ) . ' · ' . $pillar->post_title ) . '</option>'; } echo '</select>'; }
	public static function metaboxes() { foreach ( self::types() as $type ) { remove_meta_box( 'digitalisimo_keywords_editor', $type, 'side' ); remove_meta_box( 'digitalisimo_cluster_method', $type, 'side' ); remove_meta_box( 'digitalisimo_location', $type, 'side' ); remove_meta_box( 'digitalisimo_editorial', $type, 'normal' ); } }
	public static function editor_panels( $post ) { echo '<div class="digitalisimo-editorial-panels"><section><h3>Keywords</h3>'; self::keywords_box( $post ); echo '</section><section><h3>Cluster</h3>'; self::cluster_box( $post ); echo '</section><section><h3>Ubicación</h3>'; self::location_box( $post ); echo '</section></div>'; }
	public static function keywords_box( $post ) { wp_nonce_field( 'digitalisimo_editorial_save', 'digitalisimo_editorial_nonce' ); $keywords = array_slice( array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, 'digitalisimo_seo_keywords', true ) ) ) ), 0, 5 ); $limit = min( 5, max( 1, absint( Digitalisimo_Integrations_Settings::get( 'keyword_max_count', 5 ) ) ) ); echo '<div class="digitalisimo-keyword-manager" data-post-id="' . esc_attr( $post->ID ) . '" data-limit="' . esc_attr( $limit ) . '"><p class="description">La ficha verde es la keyword principal. Puedes usar hasta cuatro secundarias con la misma intención y reordenarlas por arrastre.</p><div class="digitalisimo-keyword-chips"></div><div class="digitalisimo-keyword-add"><input type="text" class="widefat" placeholder="Escribe una keyword secundaria"><button type="button" class="button button-primary">Añadir</button></div><input type="hidden" class="digitalisimo-keyword-value" name="digitalisimo_editorial_keywords" value="' . esc_attr( implode( ', ', $keywords ) ) . '"><div class="digitalisimo-keyword-ai"><div class="digitalisimo-keyword-ai-actions"><button type="button" class="button digitalisimo-keyword-ai-generate" data-ai-task="keywords">Generar sugerencias con IA</button><button type="button" class="button digitalisimo-keyword-ai-generate" data-ai-task="description">Generar descripción del post con IA</button></div><p class="description">Las keywords y la descripción se generan por separado. Las sugerencias SEO adicionales no se agregan a las keywords objetivo.</p><div class="digitalisimo-keyword-ai-result" aria-live="polite"></div></div></div>'; }
	public static function cluster_box( $post ) { wp_nonce_field( 'digitalisimo_editorial_save', 'digitalisimo_editorial_nonce' ); $selected = absint( get_post_meta( $post->ID, '_related_pillar', true ) ); echo '<p><label><input type="checkbox" name="digitalisimo_cluster_pillar" value="1" ' . checked( 'on', get_post_meta( $post->ID, 'digitalisimo_seo_pillar', true ), false ) . '> Marcar como contenido pilar</label></p><p><label><strong>Contenido pilar relacionado</strong><br><select class="widefat" name="digitalisimo_cluster_parent"><option value="">Ninguno</option>'; foreach ( self::cluster_candidates() as $pillar ) if ( $pillar->ID !== $post->ID ) { $type = get_post_type_object( $pillar->post_type ); echo '<option value="' . esc_attr( $pillar->ID ) . '" ' . selected( $selected, $pillar->ID, false ) . '>' . esc_html( ( $type->labels->singular_name ?? $pillar->post_type ) . ' · ' . $pillar->post_title ) . '</option>'; } echo '</select></label></p><p class="description">Sólo muestra contenido público publicado. Al relacionarlo, se marca automáticamente como pilar.</p>'; }
	public static function location_details_box( $post ) { wp_nonce_field( 'digitalisimo_location_save', 'digitalisimo_location_nonce' ); $level = self::location_level( $post->ID ); echo '<p>Construye el catálogo en orden: País → Estado → Ciudad → Zona. Asigna el padre desde Atributos de página.</p><p><label><strong>Tipo de ubicación</strong><br><select name="digitalisimo_location_level"><option value="">Selecciona un tipo</option>'; foreach ( self::location_levels() as $key => $label ) echo '<option value="' . esc_attr( $key ) . '" ' . selected( $level, $key, false ) . '>' . esc_html( $label ) . '</option>'; echo '</select></label></p>'; }
	public static function save_location( $id, $post ) { if ( wp_is_post_revision( $id ) || ! isset( $_POST['digitalisimo_location_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['digitalisimo_location_nonce'] ) ), 'digitalisimo_location_save' ) || ! current_user_can( 'edit_post', $id ) ) return; $level = sanitize_key( $_POST['digitalisimo_location_level'] ?? '' ); if ( array_key_exists( $level, self::location_levels() ) ) update_post_meta( $id, '_digitalisimo_location_level', $level ); else delete_post_meta( $id, '_digitalisimo_location_level' ); }
	public static function location_box( $post ) { wp_nonce_field( 'digitalisimo_editorial_save', 'digitalisimo_editorial_nonce' ); $selected = self::related_location_id( $post->ID ); echo '<select class="widefat" name="digitalisimo_location"><option value="">Usar ubicación predeterminada</option>'; foreach ( self::locations() as $location ) { $level = self::location_level( $location->term_id ); echo '<option value="' . esc_attr( $location->term_id ) . '" ' . selected( $selected, $location->term_id, false ) . '>' . esc_html( self::location_label( $location->term_id ) . ( $level ? ' (' . self::location_levels()[ $level ] . ')' : '' ) ) . '</option>'; } echo '</select><p class="description">Elige una ubicación propia o deja la opción predeterminada del sitio.</p>'; }
	public static function save( $id ) { if ( wp_is_post_revision( $id ) || ! isset( $_POST['digitalisimo_editorial_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['digitalisimo_editorial_nonce'] ) ), 'digitalisimo_editorial_save' ) || ! current_user_can( 'edit_post', $id ) ) return; $keywords = Digitalisimo_Integrations_Keyword_Match::unique( array_filter( array_map( 'trim', explode( ',', sanitize_text_field( wp_unslash( $_POST['digitalisimo_editorial_keywords'] ?? '' ) ) ) ) ) ); $limit = min( 5, max( 1, absint( Digitalisimo_Integrations_Settings::get( 'keyword_max_count', 5 ) ) ) ); update_post_meta( $id, 'digitalisimo_seo_keywords', implode( ', ', array_slice( $keywords, 0, $limit ) ) ); delete_post_meta( $id, 'digitalisimo_seo_search_intent' ); update_post_meta( $id, 'digitalisimo_seo_pillar', isset( $_POST['digitalisimo_cluster_pillar'] ) ? 'on' : '' ); $parent = absint( $_POST['digitalisimo_cluster_parent'] ?? 0 ); if ( $parent && $parent !== $id && in_array( get_post_type( $parent ), self::types(), true ) ) { update_post_meta( $id, '_related_pillar', $parent ); update_post_meta( $parent, 'digitalisimo_seo_pillar', 'on' ); } else delete_post_meta( $id, '_related_pillar' ); $location_id = absint( $_POST['digitalisimo_location'] ?? 0 ); if ( $location_id && term_exists( $location_id, 'digitalisimo_seo_location' ) ) update_post_meta( $id, '_related_location_id', $location_id ); else delete_post_meta( $id, '_related_location_id' ); }
	/** Aplica el pilar global sólo una vez, al crear contenido nuevo, sin tocar los existentes. */
	public static function apply_default_cluster( $post_id, $post, $update, $post_before ) { if ( $update || ! $post || ! in_array( $post->post_type, self::types(), true ) || get_post_meta( $post_id, '_related_pillar', true ) ) return; $pillar = self::cluster_candidate_id( Digitalisimo_Integrations_Settings::get( 'default_cluster_pillar', 0 ) ); if ( $pillar && $pillar !== $post_id ) { update_post_meta( $post_id, '_related_pillar', $pillar ); update_post_meta( $pillar, 'digitalisimo_seo_pillar', 'on' ); } }
	public static function create_location() { if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'digitalisimo_create_location' ) ) wp_die( 'No autorizado.' ); self::locations_taxonomy(); $id = absint( $_POST['digitalisimo_location_id'] ?? 0 ); $name = sanitize_text_field( wp_unslash( $_POST['digitalisimo_location_name'] ?? '' ) ); $level = sanitize_key( $_POST['digitalisimo_location_level'] ?? '' ); $parent = absint( $_POST['digitalisimo_location_parent'] ?? 0 ); $args = array( 'page' => 'digitalisimo-content', 'content_tab' => 'locations' ); if ( ! $name || ! array_key_exists( $level, self::location_levels() ) || ( $id && ! term_exists( $id, 'digitalisimo_seo_location' ) ) ) { $args['location_error'] = 'validation'; wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) ); exit; } if ( $parent && ( $parent === $id || ! term_exists( $parent, 'digitalisimo_seo_location' ) ) ) $parent = 0; $result = $id ? wp_update_term( $id, 'digitalisimo_seo_location', array( 'name' => $name, 'parent' => $parent ) ) : wp_insert_term( $name, 'digitalisimo_seo_location', array( 'parent' => $parent ) ); $saved_id = $id ?: absint( is_array( $result ) ? ( $result['term_id'] ?? 0 ) : 0 ); $saved = ! is_wp_error( $result ) && $saved_id; if ( $saved ) update_term_meta( $saved_id, '_digitalisimo_location_level', $level ); else $args['location_error'] = is_wp_error( $result ) ? sanitize_key( $result->get_error_code() ) : 'database'; $args[ $saved ? ( $id ? 'location_updated' : 'location_created' ) : 'location_error' ] = '1'; wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) ); exit; }
	/** Elimina el catálogo y desvincula con seguridad los contenidos que lo usaban. */
	public static function delete_location() { $id = absint( $_GET['location_id'] ?? 0 ); if ( ! current_user_can( 'manage_options' ) || ! $id || ! check_admin_referer( 'digitalisimo_delete_location_' . $id ) ) wp_die( 'No autorizado.' ); self::locations_taxonomy(); $deleted = wp_delete_term( $id, 'digitalisimo_seo_location' ); if ( $deleted && ! is_wp_error( $deleted ) ) { $posts = get_posts( array( 'post_type' => self::types(), 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_related_location_id', 'meta_value' => $id ) ); foreach ( $posts as $post_id ) delete_post_meta( $post_id, '_related_location_id' ); $state = 'location_deleted'; } else $state = 'location_error'; wp_safe_redirect( add_query_arg( array( 'page' => 'digitalisimo-content', 'content_tab' => 'locations', $state => '1' ), admin_url( 'admin.php' ) ) ); exit; }
	public static function columns( $columns ) { $columns['digitalisimo_cluster'] = 'Cluster'; $columns['digitalisimo_location'] = 'Ubicación'; return $columns; }
	public static function column_value( $column, $id ) {
		// Columna «Cluster»: los pilares de toda la página del listado se cargan juntos en la primera fila (antes, un get_post por fila).
		static $primed = false;
		if ( ! $primed && 'digitalisimo_cluster' === $column ) {
			$primed = true; global $wp_query;
			$pillars = array();
			// Sólo filas con sus metadatos ya en caché (el listado de entradas los precarga). Páginas y otros tipos
			// jerárquicos traen todos los IDs sin metadatos: leerlos aquí sería una consulta por cada página del sitio.
			foreach ( (array) ( $wp_query->posts ?? array() ) as $row ) { $rid = is_object( $row ) ? (int) $row->ID : (int) $row; if ( ! $rid || false === wp_cache_get( $rid, 'post_meta' ) ) continue; $pillar = absint( get_post_meta( $rid, '_related_pillar', true ) ); if ( $pillar ) $pillars[ $pillar ] = $pillar; }
			if ( $pillars && function_exists( '_prime_post_caches' ) ) _prime_post_caches( array_values( $pillars ), false, false );
		}
		if ( 'digitalisimo_location' === $column ) { $label = self::content_location_label( $id ); echo $label ? esc_html( $label ) : '—'; return; } $pid = 'digitalisimo_cluster' === $column ? absint( get_post_meta( $id, '_related_pillar', true ) ) : 0; $item = $pid ? get_post( $pid ) : null; /* get_post( 0 ) devolvería la propia fila. */ if ( $item && ! is_wp_error( $item ) ) echo esc_html( $item->post_title ); }
	public static function sortable( $columns ) { $columns['digitalisimo_cluster'] = 'digitalisimo_cluster'; $columns['digitalisimo_location'] = 'digitalisimo_location'; return $columns; }
	public static function filters() { global $typenow; if ( ! in_array( $typenow, self::types(), true ) ) return; echo '<select name="digitalisimo_filter_location"><option value="">Todas las ubicaciones</option>'; foreach ( self::locations() as $location ) echo '<option value="' . esc_attr( $location->term_id ) . '" ' . selected( absint( $_GET['digitalisimo_filter_location'] ?? 0 ), $location->term_id, false ) . '>' . esc_html( $location->name ) . '</option>'; echo '</select>'; }
	public static function query( $query ) { if ( ! is_admin() || ! $query->is_main_query() ) return; $order = $query->get( 'orderby' ); $map = array( 'digitalisimo_cluster' => '_related_pillar', 'digitalisimo_location' => '_related_location_id' ); if ( isset( $map[ $order ] ) ) { $query->set( 'meta_key', $map[ $order ] ); $query->set( 'orderby', 'meta_value' ); } $meta = (array) $query->get( 'meta_query' ); if ( isset( $_GET['digitalisimo_filter_location'] ) && absint( $_GET['digitalisimo_filter_location'] ) ) $meta[] = array( 'key' => '_related_location_id', 'value' => absint( $_GET['digitalisimo_filter_location'] ) ); if ( $meta ) $query->set( 'meta_query', $meta ); }
	public static function bulk_fields( $column, $type ) { if ( ! in_array( $type, self::types(), true ) || 'digitalisimo_cluster' !== $column ) return; echo '<fieldset><label>Cluster <select name="digitalisimo_bulk_pillar"><option value="">Sin cambios</option><option value="0">Quitar cluster</option>'; foreach ( self::pillars() as $pillar ) echo '<option value="' . esc_attr( $pillar->ID ) . '">' . esc_html( $pillar->post_title ) . '</option>'; echo '</select></label><label> Ubicación <select name="digitalisimo_bulk_location"><option value="">Sin cambios</option><option value="0">Quitar ubicación</option>'; foreach ( self::locations() as $location ) echo '<option value="' . esc_attr( $location->term_id ) . '">' . esc_html( $location->name ) . '</option>'; echo '</select></label></fieldset>'; }
	public static function bulk_save() { if ( empty( $_POST['bulk_edit'] ) || empty( $_POST['post_ids'] ) || ! current_user_can( 'edit_posts' ) ) return; foreach ( array_map( 'absint', (array) $_POST['post_ids'] ) as $id ) { foreach ( array( 'pillar' => '_related_pillar', 'location' => '_related_location_id', ) as $field => $key ) { $value = $_POST[ 'digitalisimo_bulk_' . $field ] ?? ''; if ( '' !== $value && current_user_can( 'edit_post', $id ) ) { if ( '0' === $value && in_array( $field, array( 'pillar', 'location' ), true ) ) delete_post_meta( $id, $key ); else update_post_meta( $id, $key, sanitize_text_field( wp_unslash( $value ) ) ); } } } }
}
