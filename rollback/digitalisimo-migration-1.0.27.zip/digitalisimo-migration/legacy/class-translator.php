<?php
namespace Digitalisimo\Elements\Legacy;

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-demo-media.php';

/**
 * Traduce los ajustes que Element Pack guardó para un widget `bdt-*` a los del widget propio.
 *
 * Elementor no guarda los valores que coinciden con el default del control, así que primero se
 * completan los defaults de Element Pack; después se renombran claves (con sus variantes
 * responsivas y dinámicas), se convierten valores y se traducen los repetidores. Las claves
 * comunes de Elementor (márgenes, fondos, visibilidad, CSS propio…) pasan sin cambios.
 */
final class Translator {
	const MARKER  = '_digitalisimo_legacy';
	const DEVICES = array( '', '_widescreen', '_laptop', '_tablet_extra', '_tablet', '_mobile_extra', '_mobile' );

	/** IDs de Element Pack: todos con prefijo `bdt-` salvo el calendario de FooEvents y Lightbox. */
	const ID_PATTERN = '/^(bdt-[a-z0-9-]+|fooevents-calendar|lightbox)$/';
	/** IDs de Prime Slider (Lite y Pro). Sus mapas viven en `prime-slider/maps/`, fuera de `maps/` (F8-D18). */
	const PS_PATTERN = '/^prime-slider-[a-z0-9-]+$/';

	private static $maps = array();

	/** ¿Es un ID de Element Pack? (Sólo Element Pack: `ids()`, `map()` y los adaptadores siguen siendo suyos.) */
	public static function is_legacy_id( $id ) {
		return 1 === preg_match( self::ID_PATTERN, (string) $id );
	}

	/** ¿Es un ID de Prime Slider? */
	public static function is_prime_slider_id( $id ) {
		return 1 === preg_match( self::PS_PATTERN, (string) $id );
	}

	/** ¿Es un ID que la migración conoce (Element Pack o Prime Slider)? */
	public static function is_known_id( $id ) {
		return self::is_legacy_id( $id ) || self::is_prime_slider_id( $id );
	}

	/** Element Pack conserva sus IDs mientras esté cargado; ni adaptadores ni migración compiten con él. */
	public static function element_pack_active() {
		return defined( 'BDTEP_VER' ) || class_exists( '\\ElementPack\\Element_Pack_Loader', false );
	}

	/** Prime Slider cargado: Lite define BDTPS_CORE_VER y Pro no carga sin Lite. */
	public static function prime_slider_active() {
		return defined( 'BDTPS_CORE_VER' );
	}

	/** @return string[] IDs heredados con mapa disponible. */
	public static function ids() {
		$ids = array();
		foreach ( glob( __DIR__ . '/maps/*.php' ) ?: array() as $file ) {
			if ( false === strpos( basename( $file ), '.styles.' ) && self::is_legacy_id( basename( $file, '.php' ) ) ) {
				$ids[] = basename( $file, '.php' );
			}
		}
		sort( $ids );
		return $ids;
	}

	public static function map( $legacy_id ) {
		if ( ! array_key_exists( $legacy_id, self::$maps ) ) {
			$file                     = __DIR__ . '/maps/' . basename( (string) $legacy_id ) . '.php';
			self::$maps[ $legacy_id ] = self::is_legacy_id( $legacy_id ) && is_file( $file ) ? require $file : null;
		}
		return self::$maps[ $legacy_id ];
	}

	/** Controles de estilo de Element Pack con selectores ya reescritos al marcado propio. */
	public static function styles( $legacy_id ) {
		$file = __DIR__ . '/maps/' . basename( (string) $legacy_id ) . '.styles.php';
		return self::is_legacy_id( $legacy_id ) && is_file( $file ) ? (array) require $file : array();
	}

	public static function target( $legacy_id ) {
		$map = self::map( $legacy_id );
		return is_array( $map ) ? (string) $map['target'] : '';
	}

	/**
	 * Traduce una vez: un documento ya traducido y guardado desde el editor conserva lo editado.
	 */
	public static function translate( $legacy_id, array $settings ) {
		$map = self::map( $legacy_id );
		if ( ! is_array( $map ) ) {
			return $settings;
		}
		return self::translate_map( $map, (string) $legacy_id, $settings );
	}

	/**
	 * Cuerpo de translate() con un mapa dado (los de Prime Slider viven fuera de `maps/`): defaults, renombres,
	 * repetidores, condiciones y filtro del mapa. Un ajuste ya traducido (con el marcador) no se traduce otra vez.
	 */
	public static function translate_map( array $map, string $id, array $settings ): array {
		if ( isset( $settings[ self::MARKER ] ) ) {
			return $settings;
		}
		$legacy_id = $id;
		$out       = self::apply( $settings, $map );
		foreach ( $map['repeaters'] ?? array() as $key => $spec ) {
			$rows = array_key_exists( $key, $settings ) ? $settings[ $key ] : ( $spec['default_rows'] ?? array() );
			unset( $out[ $key ] );
			$items = array();
			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				if ( is_array( $row ) ) {
					$items[] = self::apply( $row, $spec );
				}
			}
			$out[ $spec['target'] ?? $key ] = $items;
		}
		if ( ! empty( $map['conditions'] ) ) {
			$out = self::active( $out, $map['conditions'] );
		}
		if ( isset( $map['filter'] ) && is_callable( $map['filter'] ) ) {
			$out = (array) call_user_func( $map['filter'], $out, $settings );
		}
		$out[ self::MARKER ] = $legacy_id;
		return $out;
	}

	/**
	 * Consulta de entradas de Element Pack (copia del control de PRO Elements con otros nombres) a
	 * los campos `posts_*` del widget `posts`. Element Pack filtra términos por `term_id` y PRO
	 * Elements por `term_taxonomy_id`.
	 */
	public static function posts_query( array $out, bool $tt_ids = false ) {
		$sources = array( 'manual_selection' => 'by_id', '_related_post_type' => 'related' );
		$source  = (string) ( $out['posts_source'] ?? 'post' );
		$out['posts_post_type'] = $sources[ $source ] ?? ( '' !== $source ? $source : 'post' );
		$renames = array(
			'posts_selected_ids'       => 'posts_posts_ids',
			'posts_include_by'         => 'posts_include',
			'posts_include_author_ids' => 'posts_include_authors',
			'posts_exclude_by'         => 'posts_exclude',
			'posts_exclude_author_ids' => 'posts_exclude_authors',
			'query_id'                 => 'posts_query_id',
		);
		foreach ( $renames as $from => $to ) {
			if ( array_key_exists( $from, $out ) ) {
				$out[ $to ] = $out[ $from ];
				unset( $out[ $from ] );
			}
		}
		foreach ( array( 'posts_include_term_ids', 'posts_exclude_term_ids' ) as $key ) {
			// Prime Slider ya guarda `term_taxonomy_id`: no se traduce.
			if ( ! isset( $out[ $key ] ) || $tt_ids ) {
				if ( isset( $out[ $key ] ) ) {
					$out[ $key ] = array_values( array_map( 'strval', (array) $out[ $key ] ) );
				}
				continue;
			}
			$ids = array();
			foreach ( (array) $out[ $key ] as $id ) {
				$term  = function_exists( 'get_term' ) ? get_term( (int) $id ) : null;
				$ids[] = is_object( $term ) && ! empty( $term->term_taxonomy_id ) ? (string) $term->term_taxonomy_id : (string) $id;
			}
			$out[ $key ] = $ids;
		}
		$orderby                = array( 'date' => 'post_date', 'title' => 'post_title', 'modified' => 'modified', 'comment_count' => 'comment_count', 'menu_order' => 'menu_order', 'rand' => 'rand' );
		$out['posts_orderby']   = $orderby[ (string) ( $out['posts_orderby'] ?? 'date' ) ] ?? 'post_date';
		$out['posts_order']     = 'asc' === strtolower( (string) ( $out['posts_order'] ?? 'desc' ) ) ? 'asc' : 'desc';
		unset( $out['posts_source'], $out['posts_only_with_featured_image'], $out['posts_source_description'], $out['posts_divider'] );
		return $out;
	}

	/** Consulta de Element Pack (`posts_*`) en los widgets Loop de PRO Elements (`post_query_*`). */
	public static function loop_query( array $out, bool $tt_ids = false, string $skin = 'post' ) {
		$out = self::posts_query( $out, $tt_ids );
		foreach ( array_keys( $out ) as $key ) {
			if ( 0 === strpos( $key, 'posts_' ) && 'posts_per_page' !== $key ) {
				$out[ 'post_query_' . substr( $key, 6 ) ] = $out[ $key ];
				unset( $out[ $key ] );
			}
		}
		$out['_skin'] = '' !== $skin ? $skin : 'post';
		return $out;
	}

	/**
	 * Consulta y presentación de una rejilla de productos de Element Pack en `woocommerce-products`.
	 * `$spec` nombra los ajustes de cada widget: per_page, columns, title, title_tag, rating, price,
	 * cart, badge, image, excerpt, excerpt_length, excerpt_style, category, readmore, readmore_text,
	 * pagination; cada uno es [clave, valor por
	 * defecto] o un valor fijo. Las partes visibles viajan en `digitalisimo_wc_parts` y el adaptador
	 * las aplica con los hooks del bucle de WooCommerce.
	 */
	public static function wc_products( array $out, array $spec, bool $tt_ids = false ) {
		$get    = static function ( $name, $fallback = '' ) use ( $out, $spec ) {
			if ( ! isset( $spec[ $name ] ) ) {
				return $fallback;
			}
			$rule = $spec[ $name ];
			return is_array( $rule ) ? ( $out[ $rule[0] ] ?? $rule[1] ) : $rule;
		};
		$source = (string) ( $out['posts_source'] ?? 'product' );
		$types  = array( 'onsale' => 'sale', 'featured' => 'featured' );
		$type   = array( 'manual_selection' => 'by_id', 'current_query' => 'current_query', '_related_post_type' => 'related_products' )[ $source ] ?? ( $types[ (string) ( $out['product_show_product_type'] ?? 'all' ) ] ?? 'product' );
		$terms  = static function ( $ids ) use ( $tt_ids ) {
			$out = array();
			foreach ( (array) $ids as $id ) {
				$term  = ! $tt_ids && function_exists( 'get_term' ) ? get_term( (int) $id ) : null;
				$out[] = is_object( $term ) && ! empty( $term->term_taxonomy_id ) ? (string) $term->term_taxonomy_id : (string) $id;
			}
			return $out;
		};
		$set = array(
			'query_post_type' => $type,
			'query_posts_ids' => array_values( array_map( 'strval', (array) ( $out['posts_selected_ids'] ?? array() ) ) ),
			'query_orderby'   => array( 'title' => 'title', 'price' => 'price', 'sales' => 'popularity', 'rand' => 'rand', 'menu_order' => 'menu_order' )[ (string) ( $out['posts_orderby'] ?? 'date' ) ] ?? 'date',
			'query_order'     => 'asc' === strtolower( (string) ( $out['posts_order'] ?? 'desc' ) ) ? 'asc' : 'desc',
		);
		if ( in_array( 'terms', (array) ( $out['posts_include_by'] ?? array() ), true ) ) {
			$set['query_include']          = array( 'terms' );
			$set['query_include_term_ids'] = $terms( $out['posts_include_term_ids'] ?? array() );
		}
		$exclude = array_values( array_intersect( (array) ( $out['posts_exclude_by'] ?? array() ), array( 'current_post', 'manual_selection', 'terms' ) ) );
		if ( $exclude ) {
			$set['query_exclude']          = $exclude;
			$set['query_exclude_ids']      = array_values( array_map( 'strval', (array) ( $out['posts_exclude_ids'] ?? array() ) ) );
			$set['query_exclude_term_ids'] = $terms( $out['posts_exclude_term_ids'] ?? array() );
		}
		$limit   = $get( 'per_page', 8 );
		$limit   = max( 1, (int) ( is_array( $limit ) ? ( $limit['size'] ?? 8 ) : $limit ) );
		$columns = max( 1, (int) $get( 'columns', 4 ) );
		$parts   = array();
		foreach ( array( 'image', 'title', 'excerpt', 'category', 'rating', 'price', 'cart', 'readmore', 'badge' ) as $part ) {
			if ( 'yes' === $get( $part, in_array( $part, array( 'excerpt', 'category', 'readmore' ), true ) ? '' : 'yes' ) ) {
				// «summary»: el extracto manual si existe; si no, el contenido recortado con «…».
				$parts[] = 'excerpt' === $part && 'summary' === $get( 'excerpt_style' ) ? 'summary' : $part;
			}
		}
		$set += array(
			'columns'                         => (string) $columns,
			'rows'                            => (int) ceil( $limit / $columns ),
			'posts_per_page'                  => $limit,
			'paginate'                        => 'yes' === $get( 'pagination' ) ? 'yes' : '',
			'show_onsale_flash'               => 'yes' === $get( 'badge', 'yes' ) ? 'yes' : '',
			'digitalisimo_wc_parts'           => implode( ',', $parts ),
			'digitalisimo_wc_excerpt_length'  => max( 1, (int) $get( 'excerpt_length', 10 ) ),
			'digitalisimo_wc_title_tag'       => (string) $get( 'title_tag', 'h2' ),
			'digitalisimo_wc_readmore_text'   => (string) $get( 'readmore_text', 'Read More' ),
		);
		// Carruseles: todos los productos en una fila del carrusel propio, con las columnas de cada dispositivo.
		if ( 'carousel' === $get( 'layout' ) ) {
			$set['digitalisimo_wc_layout']      = 'carousel';
			$set['digitalisimo_wc_navigation']  = in_array( (string) ( $out['navigation'] ?? 'arrows' ), array( 'none', 'dots' ), true ) ? '' : 'yes';
			$set['digitalisimo_products_limit'] = $limit;
			foreach ( array( '_tablet', '_mobile' ) as $device ) {
				$value = $get( 'columns' . $device );
				if ( '' !== (string) $value ) {
					$set[ 'columns' . $device ] = (string) max( 1, (int) $value );
				}
			}
		}
		foreach ( array_keys( $out ) as $key ) {
			if ( 0 === strpos( $key, 'posts_' ) || 0 === strpos( $key, 'product_' ) || '_skin' === $key ) {
				unset( $out[ $key ] );
			}
		}
		foreach ( $spec as $rule ) {
			if ( is_array( $rule ) ) {
				unset( $out[ $rule[0] ] );
			}
		}
		return $set + $out;
	}

	/**
	 * Presentación de una rejilla de entradas de Element Pack en la piel «classic» de `posts`.
	 * `$spec` nombra los ajustes de cada widget: per_page, columns, title, title_tag, author, date,
	 * comments, category, tags, excerpt, excerpt_length, read_more, read_more_text, image, pagination;
	 * cada uno es [clave, valor por defecto] o un valor fijo.
	 */
	public static function posts_classic( array $out, array $spec, array $content_keys ) {
		$get = static function ( $name, $fallback = '' ) use ( $out, $spec ) {
			if ( ! isset( $spec[ $name ] ) ) {
				return $fallback;
			}
			$rule = $spec[ $name ];
			return is_array( $rule ) ? ( $out[ $rule[0] ] ?? $rule[1] ) : $rule;
		};
		$on    = static function ( $name ) use ( $get ) {
			return 'yes' === $get( $name ) ? 'yes' : '';
		};
		$limit = $get( 'per_page', 6 );
		$set   = array(
			'_skin'                   => 'classic',
			'classic_posts_per_page'  => max( 1, (int) ( is_array( $limit ) ? ( $limit['size'] ?? 6 ) : $limit ) ),
			'classic_columns'         => (string) $get( 'columns', '3' ),
			'classic_thumbnail'       => 'yes' === $get( 'image', 'yes' ) ? 'top' : 'none',
			'classic_masonry'         => '',
			'classic_show_title'      => $on( 'title' ),
			'classic_title_tag'       => (string) $get( 'title_tag', 'h3' ),
			'classic_meta_data'       => array_keys( array_filter( array( 'author' => $on( 'author' ), 'date' => $on( 'date' ), 'comments' => $on( 'comments' ) ) ) ),
			'classic_meta_separator'  => '|',
			'classic_show_excerpt'    => $on( 'excerpt' ),
			'classic_excerpt_length'  => (int) $get( 'excerpt_length', 15 ),
			'classic_show_read_more'  => $on( 'read_more' ),
			'classic_read_more_text'  => (string) $get( 'read_more_text', 'Read More' ),
			'digitalisimo_post_terms' => array_keys( array_filter( array( 'category' => $on( 'category' ), 'post_tag' => $on( 'tags' ) ) ) ),
			'pagination_type'         => 'yes' === $get( 'pagination' ) ? 'numbers' : '',
		);
		foreach ( $content_keys as $key ) {
			unset( $out[ $key ] );
		}
		return $set + self::posts_query( $out );
	}

	/**
	 * `[tag clave="valor"]` como lo armaba Element Pack con los atributos de render de Elementor:
	 * valores escapados, listas separadas por espacios y lógicos como «1» o vacío.
	 */
	public static function shortcode( $tag, array $attributes ) {
		$parts = array();
		foreach ( $attributes as $key => $value ) {
			if ( is_array( $value ) ) {
				$value = implode( ' ', array_map( 'strval', $value ) );
			} elseif ( is_bool( $value ) ) {
				$value = $value ? '1' : '';
			}
			$parts[] = $key . '="' . esc_attr( (string) $value ) . '"';
		}
		return '[' . $tag . ' ' . implode( ' ', $parts ) . ']';
	}

	/** Ajuste opt-in del widget Shortcode (DIGITALÍSIMO Elements): no pinta nada si su etiqueta no está registrada. */
	const SHORTCODE_GUARD = 'digitalisimo_shortcode_if_registered';

	/**
	 * Un widget de Element Pack que sólo imprimía el shortcode de otro plugin pasa al widget
	 * Shortcode de Elementor: se quitan sus ajustes de contenido y se guarda el shortcode armado.
	 *
	 * Element Pack sólo registraba esos widgets con su plugin activo: sin él, la página no mostraba nada. El widget
	 * Shortcode, en cambio, imprime como texto un shortcode que no existe («[contact-form-7 id="21"]»). Por eso el
	 * shortcode armado lleva siempre el ajuste `SHORTCODE_GUARD`: se ve sólo mientras su plugin esté activo en el sitio
	 * (en una red, cada sitio con sus plugins), como con Element Pack. Una versión de Elements sin ese control lo ignora.
	 */
	public static function as_shortcode( array $out, $shortcode, array $content_keys ) {
		foreach ( $content_keys as $key ) {
			unset( $out[ $key ] );
		}
		$out['shortcode'] = (string) $shortcode;
		if ( '' !== trim( (string) $shortcode ) ) {
			$out[ self::SHORTCODE_GUARD ] = 'yes';
		}
		return $out;
	}

	/**
	 * Como `get_settings_for_display()`: un ajuste cuyo control no cumple su condición vale null.
	 * Se evalúa sobre los valores originales, con la comparación estricta de Elementor.
	 */
	public static function active( array $settings, array $conditions ) {
		$out = $settings;
		foreach ( $conditions as $key => $condition ) {
			if ( array_key_exists( $key, $settings ) && ! self::visible( $settings, (array) $condition ) ) {
				$out[ $key ] = null;
			}
		}
		return $out;
	}

	private static function visible( array $values, array $condition ) {
		foreach ( $condition as $condition_key => $condition_value ) {
			preg_match( '/([a-z_\-0-9]+)(?:\[([a-z_]+)])?(!?)$/i', (string) $condition_key, $parts );
			$key = $parts[1] ?? '';
			if ( ! isset( $values[ $key ] ) ) {
				return false;
			}
			$value = $values[ $key ];
			if ( ! empty( $parts[2] ) && is_array( $value ) ) {
				if ( ! isset( $value[ $parts[2] ] ) ) {
					return false;
				}
				$value = $value[ $parts[2] ];
			}
			if ( is_array( $condition_value ) && $condition_value ) {
				$contains = in_array( $value, $condition_value, true );
			} elseif ( is_array( $value ) && $value ) {
				$contains = in_array( $condition_value, $value, true );
			} else {
				$contains = $value === $condition_value;
			}
			if ( ! empty( $parts[3] ) === $contains ) {
				return false;
			}
		}
		return true;
	}

	/** Defaults, renombres, valores y fijos de un nivel (widget o fila de repetidor). */
	private static function apply( array $settings, array $spec ) {
		foreach ( $spec['defaults'] ?? array() as $key => $value ) {
			// Imagen de ejemplo de Element Pack (`{{ep_assets}}…`): la URL de su carpeta instalada, que la conversión copia
			// a la biblioteca de medios (Demo_Media, F8-D17); sin Element Pack instalado, vacía.
			$value = Demo_Media::expand( $value );
			if ( ! array_key_exists( $key, $settings ) ) {
				$settings[ $key ] = $value;
			} elseif ( is_array( $value ) && is_array( $settings[ $key ] ) && $value && array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
				// Como Elementor en los controles de valor múltiple (URL, imagen, icono, medidas):
				// las partes no guardadas toman el default.
				$settings[ $key ] = array_merge( $value, $settings[ $key ] );
			}
		}
		$out = $settings;
		foreach ( $spec['rename'] ?? array() as $from => $to ) {
			foreach ( self::DEVICES as $device ) {
				if ( array_key_exists( $from . $device, $settings ) ) {
					unset( $out[ $from . $device ] );
					$out[ $to . $device ] = $settings[ $from . $device ];
				}
			}
			if ( isset( $settings['__dynamic__'][ $from ] ) ) {
				unset( $out['__dynamic__'][ $from ] );
				$out['__dynamic__'][ $to ] = $settings['__dynamic__'][ $from ];
			}
		}
		foreach ( $spec['groups'] ?? array() as $from => $to ) {
			foreach ( $settings as $key => $value ) {
				if ( 0 === strpos( $key, $from . '_' ) ) {
					unset( $out[ $key ] );
					$out[ $to . substr( $key, strlen( $from ) ) ] = $value;
				}
			}
		}
		foreach ( $spec['values'] ?? array() as $key => $values ) {
			if ( ! array_key_exists( $key, $out ) ) {
				continue;
			}
			if ( is_callable( $values ) ) {
				$out[ $key ] = call_user_func( $values, $out[ $key ], $settings );
			} elseif ( is_scalar( $out[ $key ] ) && array_key_exists( (string) $out[ $key ], $values ) ) {
				$out[ $key ] = $values[ (string) $out[ $key ] ];
			}
		}
		// Textos que Element Pack aceptaba con HTML y el widget propio escapa.
		foreach ( $spec['strip'] ?? array() as $key ) {
			if ( isset( $out[ $key ] ) && is_string( $out[ $key ] ) ) {
				$out[ $key ] = trim( wp_strip_all_tags( $out[ $key ] ) );
			}
		}
		foreach ( $spec['set'] ?? array() as $key => $value ) {
			$out[ $key ] = $value;
		}
		foreach ( $spec['drop'] ?? array() as $key ) {
			unset( $out[ $key ] );
		}
		return $out;
	}
}
