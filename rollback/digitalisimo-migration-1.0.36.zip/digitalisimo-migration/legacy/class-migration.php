<?php
namespace Digitalisimo\Elements\Legacy;

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-translator.php';
require_once __DIR__ . '/class-native.php';
require_once __DIR__ . '/class-context.php';
require_once __DIR__ . '/class-report.php';
// Las pantallas usan la tarea de Migrar, la retirada de plugins y los alias (sin efectos al cargarse).
require_once __DIR__ . '/class-runner.php';
require_once __DIR__ . '/class-retire.php';
require_once __DIR__ . '/class-aliases.php';
require_once __DIR__ . '/class-dropped.php';
require_once __DIR__ . '/class-pro.php';
// La pantalla usa el botón, el estado y el análisis de la tarea completa (\Digitalisimo\Migration\Full).
require_once dirname( __DIR__ ) . '/includes/class-screen.php';

/**
 * Migración de documentos de Element Pack en el sitio actual.
 *
 * Herramientas → Migrar a DIGITALÍSIMO tiene un solo botón, «Migrar», que lanza la tarea completa del
 * sitio (Runner): desactiva los plugins sustituidos, convierte por lotes cada documento al formato propio (`Native`:
 * widgets de DIGITALÍSIMO Elements o de PRO Elements, rasgos propios y CSS personalizado del elemento, sin
 * identificadores de Element Pack), actualiza los widgets fusionados y deja el informe. Antes de tocar un documento
 * guarda su `_elementor_data` original (`wp digitalisimo-migration --revert` lo restaura). Nunca toca otros sitios
 * de la red: en Multisite, Red → Ajustes → Migrar a DIGITALÍSIMO recorre todos los sitios, y lo dice.
 * Esta clase conserva el inventario, la conversión documento a documento y las recuperaciones de versiones antiguas
 * que la tarea encadena.
 */
final class Migration {
	const PAGE   = 'digitalisimo-ep-migration';
	const ACTION = 'digitalisimo_ep_migration';
	const BACKUP = '_digitalisimo_ep_backup';
	/** Copia de los ajustes de la página (`{time, data:<array>}` en JSON, una sola codificación), la primera vez. */
	const BACKUP_PAGE = '_digitalisimo_ep_backup_page';
	/** Copia del estado de 1.0.20 de un documento en modo restringido, antes de la primera escritura de F8 (V.3.4). */
	const BACKUP_F8 = '_digitalisimo_ep_backup_f8';
	/** Marca de F8 tras cada escritura: `{v, time, hash, page_hash, restricted}` (md5 de lo escrito). */
	const F8_MARK = '_digitalisimo_ep_f8';
	const BATCH   = 20;
	/** Análisis previo (V.3.5): acción AJAX, caché sin carga automática y documentos por vuelta. */
	const ANALYZE        = 'digitalisimo_migration_analyze';
	const ANALYSIS       = 'digitalisimo_migration_analysis';
	const ANALYZE_BUDGET = 5;
	const ANALYSIS_BATCH = 500;
	/** Agujas de los documentos con contenido heredado (`_elementor_data`, JSON guardado tal cual). */
	const NEEDLES = array(
		'"widgetType":"bdt-',
		'"widgetType":"fooevents-calendar"',
		'"widgetType":"lightbox"',
		'"widgetType":"prime-slider-',
		'"ep_',
		'"element_pack_',
		'"bdt_',
		'"_mask_shape":"shape-',
		'"shape_divider_top":"ep-',
		'"shape_divider_bottom":"ep-',
		'"image_mask_',
		'"section_sticky_on"',
		'"section_parallax_on"',
		'"section_parallax_elements"',
		'"section_equal_height_on"',
		'"section_particles_on"',
		'"library":"bdt-custom-',
		// Etiqueta dinámica: dentro del JSON guardado lleva la comilla escapada.
		'name=\\"element-pack-',
	);
	/** Agujas de los ajustes de página heredados (`_elementor_page_settings`, PHP serializado: `s:N:"clave"`). */
	const PAGE_NEEDLES = array( '"ep_grid_line_enable"', '"ep_custom_header_script"', '"ep_custom_footer_script"', '"ep_hash_link_enable"', '"ep_content_protector_enable"', '"ep_adblock_detector_enable"', '"element_pack_', '"ep_context_menu_' );

	/** Opción del sitio que recuerda que las reglas perdidas ya se recuperaron una vez. */
	const REPAIRED = 'digitalisimo_ep_conditions_repaired';
	/** Último documento revisado por la recuperación automática (reanudable) y momento de la actualización que la estrenó. */
	const REPAIR_CURSOR = 'digitalisimo_ep_conditions_repair_cursor';
	const REPAIR_CUTOFF = 'digitalisimo_ep_conditions_repair_cutoff';
	/** Resultado acumulado para avisar al terminar. */
	const REPAIR_TOTALS = 'digitalisimo_ep_conditions_repair_totals';
	/** Documentos por petición en la recuperación automática. */
	const REPAIR_BATCH = 25;
	/** Por revisión heredada, si su conversión coincide con el contenido actual de su página (ver overwritten_parents()). */
	const REVISION_CHECK = 'digitalisimo_ep_revision_check';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'network_admin_menu', array( __CLASS__, 'network_menu' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle' ) );
		add_action( 'admin_init', array( __CLASS__, 'repair_once' ) );
		add_action( 'admin_notices', array( __CLASS__, 'repair_notice' ) );
		// Análisis previo por trozos al abrir la herramienta (no es un botón: mismo nonce y capacidad que el paso).
		add_action( 'wp_ajax_' . self::ANALYZE, array( __CLASS__, 'analyze_ajax' ) );
	}

	/**
	 * Hasta 1.0.10 la conversión descartaba las reglas de visibilidad cuando la opción de Element Pack del sitio no
	 * tenía guardada la clave de la extensión (que viene activa por defecto). Se recuperan desde la copia original de
	 * cada documento convertido antes de la actualización, por lotes en cada carga de una pantalla de administración
	 * (nunca en AJAX, REST ni cron, y sólo para quien administra el sitio) hasta terminar; Migrar continúa la misma
	 * pasada si aún no terminó; `wp digitalisimo-migration --repair` la hace entera.
	 */
	public static function repair_once() {
		if ( '1' === (string) get_option( self::REPAIRED, '' ) || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::repair_step( self::REPAIR_BATCH );
	}

	/**
	 * Un lote de la pasada de recuperación, reanudable: el cursor es el mismo para la recuperación automática y para el
	 * botón, así que cada lote continúa donde quedó el anterior. Con $restart, una pasada ya terminada vuelve a empezar
	 * (reparar de nuevo no cambia lo ya reparado).
	 *
	 * @return array{documents:int, elements:int, remaining:int, done:bool} lo reparado en este lote y lo que queda.
	 */
	public static function repair_step( $limit, $restart = false ) {
		if ( $restart && '1' === (string) get_option( self::REPAIRED, '' ) ) {
			delete_option( self::REPAIRED );
			delete_option( self::REPAIR_CURSOR );
			delete_option( self::REPAIR_TOTALS );
		}
		$cutoff = (int) get_option( self::REPAIR_CUTOFF, 0 );
		if ( ! $cutoff ) {
			$cutoff = time();
			update_option( self::REPAIR_CUTOFF, $cutoff, false );
		}
		$cursor    = (int) get_option( self::REPAIR_CURSOR, 0 );
		$totals    = (array) get_option( self::REPAIR_TOTALS, array( 'documents' => 0, 'elements' => 0 ) );
		$step      = array( 'documents' => 0, 'elements' => 0, 'remaining' => 0, 'done' => true );
		$processed = 0;
		foreach ( self::backups() as $post_id ) {
			if ( $post_id <= $cursor ) {
				continue;
			}
			if ( $limit && $processed >= $limit ) {
				$step['done'] = false;
				++$step['remaining'];
				continue;
			}
			$count = self::repair_conditions( $post_id, $cutoff );
			if ( $count ) {
				++$step['documents'];
				$step['elements']   += $count;
				$totals['documents'] = (int) ( $totals['documents'] ?? 0 ) + 1;
				$totals['elements']  = (int) ( $totals['elements'] ?? 0 ) + $count;
			}
			$cursor = $post_id;
			++$processed;
		}
		update_option( self::REPAIR_CURSOR, $cursor, false );
		update_option( self::REPAIR_TOTALS, $totals, false );
		if ( $step['done'] ) {
			update_option( self::REPAIRED, '1', false );
			delete_option( self::REPAIR_CURSOR );
		}
		return $step;
	}

	/** Documentos con copia original que la pasada de recuperación en curso aún no revisó (todos si ya terminó). */
	public static function repair_remaining() {
		$backups = self::backups();
		if ( '1' === (string) get_option( self::REPAIRED, '' ) ) {
			return count( $backups );
		}
		$cursor = (int) get_option( self::REPAIR_CURSOR, 0 );
		$left   = 0;
		foreach ( $backups as $post_id ) {
			$left += $post_id > $cursor ? 1 : 0;
		}
		return $left;
	}

	/** Aviso único al terminar la recuperación automática, si cambió algo. */
	public static function repair_notice() {
		if ( '1' !== (string) get_option( self::REPAIRED, '' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$totals = get_option( self::REPAIR_TOTALS, null );
		if ( ! is_array( $totals ) ) {
			return;
		}
		delete_option( self::REPAIR_TOTALS );
		if ( empty( $totals['documents'] ) ) {
			return;
		}
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( 'DIGITALÍSIMO Migración recuperó reglas de visibilidad perdidas en %d documentos (%d elementos). Vacía la caché de página si la hay.', (int) $totals['documents'], (int) $totals['elements'] ) ) . '</p></div>';
	}

	/**
	 * Recupera en todos los documentos con copia original (WP-CLI); una pasada completa da por terminada la automática.
	 * Con $limit, sólo un lote desde el inicio.
	 *
	 * @return array{documents:int, elements:int}
	 */
	public static function repair_all( $limit = 0 ) {
		$totals = array( 'documents' => 0, 'elements' => 0 );
		$cutoff = (int) get_option( self::REPAIR_CUTOFF, 0 );
		$seen   = 0;
		foreach ( self::backups() as $post_id ) {
			if ( $limit && $seen++ >= $limit ) {
				break;
			}
			$count = self::repair_conditions( $post_id, $cutoff );
			if ( $count ) {
				$totals['documents']++;
				$totals['elements'] += $count;
			}
		}
		if ( ! $limit ) {
			update_option( self::REPAIRED, '1', false );
			delete_option( self::REPAIR_CURSOR );
		}
		return $totals;
	}

	/**
	 * Devuelve a un documento convertido las reglas de visibilidad que su copia original tenía y él ya no. Con $cutoff,
	 * sólo documentos convertidos antes de ese momento (los posteriores ya se convirtieron bien); el texto de la copia
	 * se inspecciona antes de decodificar nada.
	 */
	public static function repair_conditions( $post_id, $cutoff = 0 ) {
		$raw = (string) get_metadata( 'post', $post_id, self::BACKUP, true );
		if ( '' === $raw || false === strpos( $raw, 'ep_display_conditions_enable' ) ) {
			return 0;
		}
		$backup = json_decode( $raw, true );
		if ( ! is_array( $backup ) || ! isset( $backup['data'] ) || ! is_string( $backup['data'] ) ) {
			return 0;
		}
		if ( $cutoff && (int) ( $backup['time'] ?? 0 ) >= $cutoff ) {
			return 0;
		}
		$original = json_decode( $backup['data'], true );
		$current  = self::data( $post_id );
		if ( ! is_array( $original ) || ! $current ) {
			return 0;
		}
		list( $repaired, $count ) = self::repair_conditions_data( $current, $original );
		if ( $count ) {
			update_metadata( 'post', $post_id, '_elementor_data', wp_slash( wp_json_encode( $repaired ) ) );
			self::clear_css( $post_id );
		}
		return $count;
	}

	/**
	 * Reparación pura: cada elemento del original con reglas de Element Pack cuyo homólogo (mismo id) en el documento
	 * actual no tiene ninguna clave `digitalisimo_visibility_*` recibe las reglas convertidas.
	 *
	 * @return array{0:array,1:int} datos reparados y elementos tocados.
	 */
	public static function repair_conditions_data( array $current, array $original ) {
		$with_rules = array();
		self::collect_rules( $original, $with_rules );
		if ( ! $with_rules ) {
			return array( $current, 0 );
		}
		$count = 0;
		return array( self::inject_rules( $current, $with_rules, $count ), $count );
	}

	private static function collect_rules( array $elements, array &$out ) {
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			$settings = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : array();
			$id       = (string) ( $element['id'] ?? '' );
			// También sin filas: con el interruptor encendido y «Mostrar», Element Pack no pintaba el elemento.
			if ( '' !== $id && 'yes' === ( $settings['ep_display_conditions_enable'] ?? '' ) ) {
				$out[ $id ] = Native::visibility_settings( $settings );
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				self::collect_rules( $element['elements'], $out );
			}
		}
	}

	private static function inject_rules( array $elements, array $with_rules, &$count ) {
		foreach ( $elements as $index => $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			$id       = (string) ( $element['id'] ?? '' );
			$settings = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : array();
			if ( '' !== $id && isset( $with_rules[ $id ] ) && ! self::has_own_rules( $settings ) ) {
				$element['settings'] = $with_rules[ $id ] + $settings;
				++$count;
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$element['elements'] = self::inject_rules( $element['elements'], $with_rules, $count );
			}
			$elements[ $index ] = $element;
		}
		return $elements;
	}

	private static function has_own_rules( array $settings ) {
		foreach ( array_keys( $settings ) as $key ) {
			if ( 0 === strpos( (string) $key, 'digitalisimo_visibility_' ) ) {
				return true;
			}
		}
		return false;
	}

	public static function menu() {
		add_management_page( 'Migrar a DIGITALÍSIMO', 'Migrar a DIGITALÍSIMO', 'manage_options', self::PAGE, array( __CLASS__, 'page' ) );
	}

	public static function network_menu() {
		add_submenu_page( 'settings.php', 'Migrar a DIGITALÍSIMO', 'Migrar a DIGITALÍSIMO', 'manage_network_options', self::PAGE, array( __CLASS__, 'network_page' ) );
	}

	/** Motivo y alternativa de un widget de Element Pack sin adaptador (vacío si lo tiene). */
	public static function reason( $type ) {
		static $list = null;
		if ( null === $list ) {
			$file = __DIR__ . '/unsupported.php';
			$list = is_file( $file ) ? (array) require $file : array();
		}
		return (string) ( $list[ $type ] ?? '' );
	}

	/** Estado legible de un widget del inventario. */
	public static function status( $type, $has_map ) {
		if ( $has_map ) {
			return 'Compatible: se muestra con ' . Translator::target( $type );
		}
		$reason = self::reason( $type );
		return 'Sin adaptador: no se mostrará sin Element Pack.' . ( '' !== $reason ? ' ' . $reason : '' );
	}

	/** IDs de documentos del sitio (no revisiones) que contienen widgets o ajustes de Element Pack. */
	public static function documents( $limit = 0 ) {
		return self::query_documents( false, $limit );
	}

	/**
	 * Revisiones y autoguardados con contenido heredado. Sirven para detectar páginas sobrescritas por conversiones
	 * anteriores (overwritten_parents()); después, Migrar los convierte cada uno en su propio registro (convert_document()
	 * escribe con update_metadata(), nunca en el padre como haría update_post_meta() sobre una revisión), salvo los que
	 * delatan una página sobrescrita que no pudo recuperarse.
	 */
	public static function legacy_revisions() {
		return self::query_documents( true );
	}

	/**
	 * Documentos (no revisiones, o sólo revisiones) cuyos ajustes de página tienen claves heredadas de Element Pack. La
	 * etapa de conversión recorre la unión ordenada con documents().
	 *
	 * @return int[]
	 */
	public static function page_documents( $revisions = false ) {
		return self::query_meta( '_elementor_page_settings', self::PAGE_NEEDLES, (bool) $revisions, 0 );
	}

	/** Unión ordenada de documents() y page_documents(): lo que recorre la etapa de conversión. */
	public static function all_documents() {
		$ids = array_values( array_unique( array_merge( self::documents(), self::page_documents() ) ) );
		sort( $ids );
		return $ids;
	}

	/** Documentos (no revisiones) cuyo `_elementor_data` contiene alguna de las agujas indicadas. */
	public static function documents_with( array $needles, $revisions = false ) {
		return $needles ? self::query_meta( '_elementor_data', array_values( array_map( 'strval', $needles ) ), (bool) $revisions, 0 ) : array();
	}

	/** Documentos con copia de sus ajustes de página. */
	public static function page_backups() {
		global $wpdb;
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s ORDER BY post_id", self::BACKUP_PAGE ) ) );
	}

	private static function query_documents( $revisions, $limit = 0 ) {
		return self::query_meta( '_elementor_data', self::NEEDLES, (bool) $revisions, (int) $limit );
	}

	/** IDs con una meta que contiene alguna aguja; revisiones aparte. */
	private static function query_meta( $meta_key, array $needles, $revisions, $limit ) {
		global $wpdb;
		$sql     = "SELECT DISTINCT m.post_id FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '" . ( '_elementor_page_settings' === $meta_key ? '_elementor_page_settings' : '_elementor_data' ) . "' AND p.post_type " . ( $revisions ? '=' : '<>' ) . " 'revision' AND ( " . implode( ' OR ', array_fill( 0, count( $needles ), 'm.meta_value LIKE %s' ) ) . ' ) ORDER BY m.post_id';
		if ( $limit ) {
			$sql .= ' LIMIT ' . absint( $limit );
		}
		$like = array();
		foreach ( $needles as $needle ) {
			$like[] = '%' . $wpdb->esc_like( $needle ) . '%';
		}
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( $sql, $like ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	public static function backups() {
		global $wpdb;
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s ORDER BY post_id", self::BACKUP ) ) );
	}

	/** Recuento por widget: elementos, documentos y si tiene mapa. */
	public static function inventory() {
		$rows = array();
		foreach ( self::documents() as $post_id ) {
			$data = self::data( $post_id );
			$seen = array();
			self::walk( $data, static function ( $element ) use ( &$rows, &$seen, $post_id ) {
				$type   = (string) ( $element['widgetType'] ?? '' );
				$marker = false;
				if ( Native::MARKER_WIDGET === $type ) {
					// Un marcador de K con un widget de Element Pack dentro cuenta como ese widget (V.12, C13).
					$type   = self::marker_type( $element );
					$marker = true;
				}
				if ( ! Translator::is_legacy_id( $type ) ) {
					return $element;
				}
				$rows[ $type ] = $rows[ $type ] ?? array( 'elements' => 0, 'documents' => 0, 'map' => (bool) Translator::map( $type ), 'markers' => 0 );
				$rows[ $type ]['elements']++;
				$rows[ $type ]['markers'] += $marker ? 1 : 0;
				if ( empty( $seen[ $type ] ) ) {
					$rows[ $type ]['documents']++;
					$seen[ $type ] = true;
				}
				return $element;
			} );
		}
		ksort( $rows );
		return $rows;
	}

	/** Tipo del widget que guarda un marcador de K (`bdt-…`, `prime-slider-…`), o ''. */
	public static function marker_type( array $marker ) {
		$preserve = '\\Digitalisimo\\Elements\\Import\\Kits\\Preserve';
		if ( class_exists( $preserve ) ) {
			$info = $preserve::info( $marker );
			$type = is_array( $info ) ? (string) $info['type'] : '';
		} else {
			$type = (string) ( $marker['settings']['digitalisimo_unconverted']['type'] ?? '' );
		}
		return 0 === strpos( $type, 'widget/' ) ? substr( $type, 7 ) : '';
	}

	/** Elementos (de cualquier tipo) con máscaras o separadores de Element Pack, y figuras que ya no tienen archivo. */
	public static function figures() {
		$out = array( 'elements' => 0, 'documents' => 0, 'missing' => array() );
		foreach ( self::documents() as $post_id ) {
			$count = self::count_figures( self::data( $post_id ), $out['missing'] );
			$out['elements'] += $count;
			$out['documents'] += $count ? 1 : 0;
		}
		$out['missing'] = array_values( array_unique( $out['missing'] ) );
		sort( $out['missing'] );
		return $out;
	}

	private static function count_figures( array $elements, array &$missing ) {
		$count = 0;
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			if ( Masks::is_legacy( $element ) ) {
				++$count;
				$missing = array_merge( $missing, Masks::missing( $element ) );
			}
			$count += self::count_figures( (array) ( $element['elements'] ?? array() ), $missing );
		}
		return $count;
	}

	/** Elementos del documento indicado (una revisión lee los suyos, no los del padre). */
	private static function data( $post_id ) {
		return self::decode( get_metadata( 'post', $post_id, '_elementor_data', true ) );
	}

	private static function decode( $raw ) {
		$data = is_string( $raw ) ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : null );
		return is_array( $data ) ? $data : array();
	}

	private static function walk( array $elements, callable $callback ) {
		foreach ( $elements as $index => $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			if ( 'widget' === ( $element['elType'] ?? '' ) ) {
				$element = $callback( $element );
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$element['elements'] = self::walk( $element['elements'], $callback );
			}
			$elements[ $index ] = $element;
		}
		return $elements;
	}

	/**
	 * Conversión en memoria de los elementos de un documento, sin guardar.
	 *
	 * @return array{0:array,1:int} elementos convertidos y número de cambios.
	 */
	public static function convert_data( array $data, $post_id ) {
		// Los widgets (y con ellos los adaptadores) se registran la primera vez que Elementor los pide.
		if ( class_exists( '\\Elementor\\Plugin' ) && isset( \Elementor\Plugin::$instance->widgets_manager ) ) {
			\Elementor\Plugin::$instance->widgets_manager->get_widget_types();
		}
		$changes = 0;
		foreach ( $data as $index => $element ) {
			if ( is_array( $element ) ) {
				list( $data[ $index ], $count ) = Native::element( $element, $post_id, '' );
				$changes += $count;
			}
		}
		// Un fragmento en la raíz (Prime Slider con hermanos) se aplana.
		return array( Native::flatten( array_values( $data ) ), $changes );
	}

	/**
	 * Convierte un documento al formato propio y guarda una copia del original la primera vez. Las escrituras van al id
	 * indicado (update_metadata), nunca al padre de una revisión como haría update_post_meta().
	 *
	 * - Los ajustes de la página se convierten antes que nada (C1-17), con su propia copia (BACKUP_PAGE).
	 * - Un documento migrado por ≤ 1.0.20 (copia sin marca F8) va en modo restringido (V.3.4): conversión de 1.0.20 y
	 *   reparaciones de referencias; antes de escribir, BACKUP_F8 una sola vez.
	 * - Un documento con la marca F8 cuyo contenido no cambió desde entonces no se vuelve a tocar.
	 * - Si el resultado tiene marcadores de K, o el documento tenía la meta, se recuentan (nunca en revisiones).
	 *
	 * @return array{native:int, page:bool} elementos convertidos y si cambió la página.
	 */
	public static function convert_document( $post_id ) {
		$post_id  = (int) $post_id;
		$revision = function_exists( 'wp_is_post_revision' ) && wp_is_post_revision( $post_id );
		Context::begin( $post_id, 'run' );
		$restricted         = self::restricted( $post_id );
		Native::$restricted = $restricted;
		try {
			$page = self::convert_page( $post_id, $restricted );
			$raw  = get_metadata( 'post', $post_id, '_elementor_data', true );
			if ( ! is_string( $raw ) || '' === $raw ) {
				if ( $page ) {
					self::mark( $post_id, $restricted );
				}
				return array( 'native' => 0, 'page' => $page );
			}
			$mark = self::f8_mark( $post_id );
			if ( $mark && md5( $raw ) === (string) ( $mark['hash'] ?? '' ) && false === strpos( $raw, '"widgetType":"' . Native::MARKER_WIDGET . '"' ) ) {
				// Ya convertido por F8 y sin cambios desde entonces: nada heredado nuevo.
				if ( $page ) {
					self::mark( $post_id, $restricted );
				}
				return array( 'native' => 0, 'page' => $page );
			}
			$elements = self::decode( $raw );
			$marked   = 0;
			// Frente I (V.12): los marcadores de K con Element Pack o Prime Slider dentro se convierten antes que el resto,
			// con este documento en `Context` (run); sin `Markers` cargado, como en 1.0.20.
			if ( class_exists( __NAMESPACE__ . '\\Markers', false ) && method_exists( __NAMESPACE__ . '\\Markers', 'expand' ) ) {
				list( $elements, $marked ) = Markers::expand( $elements, $post_id );
			}
			list( $data, $changes ) = self::convert_data( $elements, $post_id );
			$changes               += (int) $marked;
			if ( ! $changes ) {
				if ( $page ) {
					self::mark( $post_id, $restricted );
				}
				return array( 'native' => 0, 'page' => $page );
			}
			$json = (string) wp_json_encode( $data );
			$mark = self::mark_data( $post_id, $restricted, $json );
			if ( '' === (string) get_metadata( 'post', $post_id, self::BACKUP, true ) ) {
				// La primera conversión lleva la marca F8 dentro de su copia: una escritura menos por documento.
				add_metadata( 'post', $post_id, self::BACKUP, wp_slash( wp_json_encode( array( 'time' => time(), 'data' => $raw, 'f8' => $mark ) ) ), true );
				$mark = null;
			} elseif ( $restricted && '' === (string) get_metadata( 'post', $post_id, self::BACKUP_F8, true ) ) {
				add_metadata( 'post', $post_id, self::BACKUP_F8, wp_slash( wp_json_encode( array( 'time' => time(), 'data' => $raw ) ) ), true );
			}
			update_metadata( 'post', $post_id, '_elementor_data', wp_slash( $json ) );
			self::clear_css( $post_id );
			if ( ! $revision ) {
				self::recount_markers( $post_id, $data );
			}
			if ( null !== $mark ) {
				update_metadata( 'post', $post_id, self::F8_MARK, wp_slash( wp_json_encode( $mark ) ) );
			}
			return array( 'native' => $changes, 'page' => $page );
		} finally {
			Native::$restricted = false;
			Context::end();
		}
	}

	/** ¿Documento migrado por ≤ 1.0.20? Copia original sin marca F8 (o con una marca de modo restringido). */
	public static function restricted( $post_id ) {
		if ( '' === (string) get_metadata( 'post', (int) $post_id, self::BACKUP, true ) ) {
			return false;
		}
		$mark = self::f8_mark( $post_id );
		return ! $mark || ! empty( $mark['restricted'] );
	}

	/**
	 * Marca F8 del documento, o null: la meta F8_MARK o, si no la hay, la que lleva la copia original de la primera
	 * conversión (`f8`).
	 */
	public static function f8_mark( $post_id ) {
		$raw  = get_metadata( 'post', (int) $post_id, self::F8_MARK, true );
		$mark = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : null );
		if ( is_array( $mark ) ) {
			return $mark;
		}
		$backup = json_decode( (string) get_metadata( 'post', (int) $post_id, self::BACKUP, true ), true );
		return is_array( $backup ) && isset( $backup['f8'] ) && is_array( $backup['f8'] ) ? $backup['f8'] : null;
	}

	/** Marca F8 con la huella de lo que se escribe (datos y página). */
	private static function mark_data( $post_id, $restricted, $json = null ) {
		$raw  = null === $json ? (string) get_metadata( 'post', $post_id, '_elementor_data', true ) : (string) $json;
		$page = get_metadata( 'post', $post_id, '_elementor_page_settings', true );
		return array(
			'v'          => 1,
			'time'       => time(),
			'hash'       => '' !== $raw ? md5( $raw ) : '',
			'page_hash'  => is_array( $page ) ? md5( serialize( $page ) ) : '', // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- sólo huella.
			'restricted' => $restricted ? 1 : 0,
		);
	}

	/** Deja la marca F8 en su meta. */
	private static function mark( $post_id, $restricted ) {
		update_metadata( 'post', $post_id, self::F8_MARK, wp_slash( wp_json_encode( self::mark_data( $post_id, $restricted ) ) ) );
	}

	/** ¿Tienen los ajustes de la página claves heredadas de Element Pack? */
	public static function page_has_legacy( $settings ) {
		if ( ! is_array( $settings ) ) {
			return false;
		}
		foreach ( array_keys( $settings ) as $key ) {
			if ( 0 === strpos( (string) $key, 'ep_' ) || 0 === strpos( (string) $key, 'element_pack_' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Extensiones de página de Element Pack encendidas en unos ajustes de página (nombre visible de cada una): las de
	 * ámbito `page` de `Effects\Dispatcher::keys()` con su interruptor usado y el menú contextual. Lo demás (los valores
	 * globales de la caja de luz y de la información emergente que guardaban las versiones 9.x en cada página, o las
	 * claves de una extensión apagada) no hacía nada sin Element Pack.
	 *
	 * @return string[]
	 */
	public static function residual_page( $settings ): array {
		if ( ! is_array( $settings ) ) {
			return array();
		}
		$out   = array();
		$pages = array();
		if ( class_exists( __NAMESPACE__ . '\\Effects\\Dispatcher' ) && method_exists( __NAMESPACE__ . '\\Effects\\Dispatcher', 'keys' ) ) {
			foreach ( (array) Effects\Dispatcher::keys() as $slug => $spec ) {
				if ( 'page' === ( $spec['scope'][0] ?? '' ) ) {
					$pages[ (string) ( $spec['label'] ?? $slug ) ] = (array) ( $spec['switch'] ?? array() );
				}
			}
		}
		if ( ! $pages ) {
			// Sin el catálogo de las extensiones (versiones sin el frente C): sus interruptores, por su nombre.
			foreach ( array( 'ep_grid_line_enable', 'ep_custom_header_script', 'ep_custom_footer_script', 'ep_hash_link_enable', 'ep_content_protector_enable', 'ep_adblock_detector_enable' ) as $switch ) {
				$pages[ $switch ] = array( $switch );
			}
		}
		foreach ( $pages as $label => $switches ) {
			foreach ( $switches as $switch ) {
				if ( array_key_exists( $switch, $settings ) && self::used( $settings[ $switch ] ) ) {
					$out[] = (string) $label;
					break;
				}
			}
		}
		if ( array_key_exists( 'ep_context_menu_enable', $settings ) && self::used( $settings['ep_context_menu_enable'] ) ) {
			$out[] = 'Menú contextual';
		}
		return array_values( array_unique( $out ) );
	}

	/** ¿Tiene efecto un valor guardado (interruptor, código)? */
	private static function used( $value ) {
		if ( is_array( $value ) || null === $value || is_bool( $value ) ) {
			return (bool) $value;
		}
		$value = strtolower( trim( (string) $value ) );
		return '' !== $value && 'no' !== $value && 'false' !== $value && '0' !== $value;
	}

	/**
	 * Ajustes de la página: Effects\Page (C) y después Platform\Kit::clean_page (H), con copia la primera vez. En modo
	 * restringido sólo se informan (residual_page()). Sin esas clases no cambia nada (1.0.20).
	 */
	private static function convert_page( $post_id, $restricted ) {
		$settings = get_metadata( 'post', $post_id, '_elementor_page_settings', true );
		if ( ! self::page_has_legacy( $settings ) ) {
			return false;
		}
		if ( $restricted ) {
			// Sin tocarlos: sólo se revisa lo que estaba encendido; el resto (valores globales que guardaban versiones
			// antiguas, extensiones apagadas) no hacía nada sin Element Pack y va a una sola línea del sitio.
			$active = self::residual_page( $settings );
			if ( $active ) {
				Report::add( $post_id, 'core.residual', array( 'element' => 'page', 'name' => implode( ', ', $active ) ) );
			} else {
				Report::site( 'core.residual_inert' );
			}
			return false;
		}
		$new = $settings;
		if ( class_exists( __NAMESPACE__ . '\\Effects\\Page' ) && method_exists( __NAMESPACE__ . '\\Effects\\Page', 'convert' ) ) {
			$new = (array) Effects\Page::convert( $new, $post_id );
		}
		if ( class_exists( __NAMESPACE__ . '\\Platform\\Kit' ) && method_exists( __NAMESPACE__ . '\\Platform\\Kit', 'clean_page' ) ) {
			$new = (array) Platform\Kit::clean_page( $new, $post_id );
		}
		// Iconos o etiquetas dinámicas de Element Pack en los ajustes de la página (raro).
		foreach ( array( 'Icons', 'Dynamic_Tags' ) as $step ) {
			$class = __NAMESPACE__ . '\\Platform\\' . $step;
			if ( class_exists( $class ) && method_exists( $class, 'rewrite_settings' ) ) {
				$new = (array) $class::rewrite_settings( $new );
			}
		}
		if ( $new === $settings ) {
			return false;
		}
		if ( '' === (string) get_metadata( 'post', $post_id, self::BACKUP_PAGE, true ) ) {
			add_metadata( 'post', $post_id, self::BACKUP_PAGE, wp_slash( wp_json_encode( array( 'time' => time(), 'data' => $settings ) ) ), true );
		}
		update_metadata( 'post', $post_id, '_elementor_page_settings', wp_slash( $new ) );
		return true;
	}

	/** Recuento de marcadores de K del documento (V.12), si los tiene o los tuvo. */
	private static function recount_markers( $post_id, array $data ) {
		$preserve = '\\Digitalisimo\\Elements\\Import\\Kits\\Preserve';
		if ( ! class_exists( $preserve ) ) {
			return;
		}
		$had = (int) get_metadata( 'post', $post_id, '_digitalisimo_unconverted', true );
		if ( $had || $preserve::contains_markers( $data ) ) {
			$preserve::recount_document( (int) $post_id, $data );
		}
	}

	/**
	 * Restaura un documento convertido: `_elementor_data` (BACKUP_F8 si existe, si no BACKUP) y los ajustes de la
	 * página (BACKUP_PAGE). Sin copia, false.
	 */
	public static function revert_document( $post_id ) {
		$post_id  = (int) $post_id;
		$restored = false;
		$f8       = json_decode( (string) get_metadata( 'post', $post_id, self::BACKUP_F8, true ), true );
		$backup   = is_array( $f8 ) && isset( $f8['data'] ) && is_string( $f8['data'] ) ? $f8 : json_decode( (string) get_metadata( 'post', $post_id, self::BACKUP, true ), true );
		if ( is_array( $backup ) && isset( $backup['data'] ) && is_string( $backup['data'] ) ) {
			update_metadata( 'post', $post_id, '_elementor_data', wp_slash( $backup['data'] ) );
			if ( is_array( $f8 ) && isset( $f8['data'] ) ) {
				delete_metadata( 'post', $post_id, self::BACKUP_F8 );
			} else {
				delete_metadata( 'post', $post_id, self::BACKUP );
			}
			$restored = true;
		}
		$page = json_decode( (string) get_metadata( 'post', $post_id, self::BACKUP_PAGE, true ), true );
		if ( is_array( $page ) && isset( $page['data'] ) && is_array( $page['data'] ) ) {
			update_metadata( 'post', $post_id, '_elementor_page_settings', wp_slash( $page['data'] ) );
			delete_metadata( 'post', $post_id, self::BACKUP_PAGE );
			$restored = true;
		}
		if ( $restored ) {
			delete_metadata( 'post', $post_id, self::F8_MARK );
			delete_metadata( 'post', $post_id, '_digitalisimo_pro_recovered' ); // Sello de Pro::recover_document().
			self::clear_css( $post_id );
		}
		return $restored;
	}

	/** Cachés de Elementor del documento: su CSS, el HTML de sus elementos y la lista de recursos que encola. */
	public static function clear_css( $post_id ) {
		delete_metadata( 'post', $post_id, '_elementor_css' );
		delete_metadata( 'post', $post_id, '_elementor_element_cache' );
		delete_metadata( 'post', $post_id, '_elementor_page_assets' );
		if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
			\Elementor\Core\Files\CSS\Post::create( $post_id )->delete();
		}
	}

	/**
	 * Páginas cuyo contenido actual es la conversión de una de sus revisiones. Hasta 1.0.13 las revisiones entraban en
	 * los lotes y, como update_post_meta() escribe en el padre cuando recibe una revisión, convertir una revisión antigua
	 * o un autoguardado dejaba ese contenido en la página. La comparación es por valor (la conversión es determinista) y
	 * se recuerda por hash para no reconvertir en cada carga. La última revisión guardada no cuenta: su conversión es
	 * justamente el contenido correcto.
	 *
	 * @return array<int, array{revision:int, date:string, autosave:bool}> por página, la revisión que la sobrescribió.
	 */
	public static function overwritten_parents() {
		$out = array();
		foreach ( self::legacy_revisions() as $revision_id ) {
			$info = self::overwritten_by( $revision_id );
			if ( $info ) {
				$out[ $info['parent'] ] = $info;
			}
		}
		return $out;
	}

	/**
	 * ¿Sobrescribió esta revisión a su página? La comprobación de overwritten_parents() para una sola revisión, con la
	 * caché guardada en cuanto cambia: Migrar la recorre por lotes con plazo y una petición cortada no pierde lo hecho.
	 *
	 * @return array{parent:int, revision:int, date:string, autosave:bool}|null
	 */
	public static function overwritten_by( $revision_id ) {
		$revision  = get_post( $revision_id );
		$parent_id = $revision ? (int) $revision->post_parent : 0;
		if ( ! $parent_id || (int) $revision_id === self::latest_revision( $parent_id ) ) {
			return null;
		}
		$cache        = (array) get_option( self::REVISION_CHECK, array() );
		$raw_parent   = (string) get_metadata( 'post', $parent_id, '_elementor_data', true );
		$raw_revision = (string) get_metadata( 'post', $revision_id, '_elementor_data', true );
		if ( '' === $raw_parent || '' === $raw_revision || ( isset( $cache['ack'][ $parent_id ] ) && $cache['ack'][ $parent_id ] === md5( $raw_parent ) ) ) {
			return null;
		}
		$key = md5( $raw_parent ) . ':' . md5( $raw_revision );
		if ( ! isset( $cache[ $revision_id ]['key'] ) || $cache[ $revision_id ]['key'] !== $key ) {
			list( $converted, $changes ) = self::convert_data( self::decode( $raw_revision ), $revision_id );
			$parent                      = self::decode( $raw_parent );
			// Una página cuyos alias ya pasaron a su widget fusionado sigue reconociéndose: la comparación se hace con los
			// alias convertidos en los dos lados.
			if ( Aliases::map() ) {
				$converted = Aliases::convert_data( $converted )[0];
				$parent    = Aliases::convert_data( $parent )[0];
			}
			$cache[ $revision_id ] = array( 'key' => $key, 'same' => $changes > 0 && self::decode( wp_json_encode( $converted ) ) === self::decode( wp_json_encode( $parent ) ) );
			update_option( self::REVISION_CHECK, $cache, false );
		}
		return empty( $cache[ $revision_id ]['same'] ) ? null : array( 'parent' => $parent_id, 'revision' => (int) $revision_id, 'date' => (string) $revision->post_modified, 'autosave' => (bool) wp_is_post_autosave( $revision_id ) );
	}

	/**
	 * Revisiones heredadas que pueden haber sobrescrito su página: sólo las conversiones de Migración 1.0.13 o anterior
	 * lo hacían, y esas conversiones dejaban la copia original en la página. Las demás no se comprueban.
	 *
	 * @return int[]
	 */
	public static function recover_candidates() {
		$revisions = self::legacy_revisions();
		if ( ! $revisions ) {
			return array();
		}
		$backups = array_flip( self::backups() );
		$out     = array();
		foreach ( $revisions as $revision_id ) {
			$revision = get_post( $revision_id );
			if ( $revision && isset( $backups[ (int) $revision->post_parent ] ) ) {
				$out[] = (int) $revision_id;
			}
		}
		return $out;
	}

	/** Última revisión guardada de una página (no un autoguardado), o 0. */
	public static function latest_revision( $parent_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_parent = %d AND post_type = 'revision' AND post_name NOT LIKE %s ORDER BY ID DESC LIMIT 1", $parent_id, '%' . $wpdb->esc_like( '-autosave-v' ) . '%' ) );
	}

	/**
	 * Devuelve a una página sobrescrita su última versión guardada en el editor, convertida (Elementor crea una revisión
	 * en cada guardado), y esa versión pasa a ser su copia original si era heredada. Sin revisión guardada (las plantillas
	 * de Elementor sólo tienen autoguardados) usa la copia original de la página, que se conserva, salvo que esa copia sea
	 * la de la revisión que la pisó.
	 *
	 * @return string 'revision', 'backup' o '' si no hay de dónde recuperar.
	 */
	public static function recover_from_revision( $parent_id, $revision_id = 0 ) {
		list( $source, $raw ) = self::recovery_source( $parent_id, $revision_id );
		if ( '' === $raw ) {
			return '';
		}
		list( $converted, $changes ) = self::convert_data( self::decode( $raw ), $parent_id );
		update_metadata( 'post', $parent_id, '_elementor_data', wp_slash( wp_json_encode( $converted ) ) );
		if ( 'revision' === $source && $changes ) {
			update_metadata( 'post', $parent_id, self::BACKUP, wp_slash( wp_json_encode( array( 'time' => time(), 'data' => $raw ) ) ) );
		}
		self::clear_css( $parent_id );
		return $source;
	}

	/**
	 * De dónde puede recuperarse una página sobrescrita: su última revisión guardada o, si no la hay, su copia original
	 * cuando no es la de la revisión que la pisó.
	 *
	 * @return array{0:string,1:string} origen ('revision', 'backup' o '') y datos en bruto.
	 */
	public static function recovery_source( $parent_id, $revision_id = 0 ) {
		$latest = self::latest_revision( $parent_id );
		$raw    = $latest ? (string) get_metadata( 'post', $latest, '_elementor_data', true ) : '';
		if ( '' !== $raw ) {
			return array( 'revision', $raw );
		}
		$backup = json_decode( (string) get_metadata( 'post', $parent_id, self::BACKUP, true ), true );
		$raw    = is_array( $backup ) && isset( $backup['data'] ) && is_string( $backup['data'] ) ? $backup['data'] : '';
		if ( '' !== $raw && $revision_id && self::decode( $raw ) === self::decode( get_metadata( 'post', $revision_id, '_elementor_data', true ) ) ) {
			$raw = '';
		}
		return array( '' !== $raw ? 'backup' : '', $raw );
	}

	/** Da por revisada una página sobrescrita con su contenido actual: deja de listarse mientras ese contenido no cambie. */
	public static function acknowledge( $parent_id ) {
		$cache                          = (array) get_option( self::REVISION_CHECK, array() );
		$cache['ack'][ (int) $parent_id ] = md5( (string) get_metadata( 'post', $parent_id, '_elementor_data', true ) );
		update_option( self::REVISION_CHECK, $cache, false );
	}

	/**
	 * Clasifica los documentos con contenido heredado: «convertible» si la conversión aún cambiaría algo y «blocked» si
	 * sólo conserva widgets sin adaptador, que se quedan tal cual (sin Element Pack no se muestran) y por eso los lotes
	 * los saltan en vez de repetirlos.
	 *
	 * @return array{convertible:int[], blocked:int[]}
	 */
	public static function classify() {
		$groups = array( 'convertible' => array(), 'blocked' => array() );
		foreach ( self::documents() as $post_id ) {
			$legacy      = false;
			$convertible = false;
			foreach ( self::data( $post_id ) as $element ) {
				if ( ! is_array( $element ) ) {
					continue;
				}
				if ( Native::is_convertible( $element ) ) {
					$convertible = true;
					break;
				}
				$legacy = $legacy || Native::is_legacy( $element );
			}
			if ( $convertible ) {
				$groups['convertible'][] = $post_id;
			} elseif ( $legacy ) {
				$groups['blocked'][] = $post_id;
			}
		}
		return $groups;
	}

	/** Documentos que la conversión aún cambiaría: los que toman los lotes. */
	public static function convertible() {
		return self::classify()['convertible'];
	}

	/** Documentos que aún contienen widgets o ajustes heredados, convertibles o no. */
	public static function pending() {
		$groups  = self::classify();
		$pending = array_merge( $groups['convertible'], $groups['blocked'] );
		sort( $pending );
		return $pending;
	}

	/** Dar por revisada una página sobrescrita sin origen del que recuperarla (enlaces de versiones anteriores). */
	public static function handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No autorizado.', 403 );
		}
		check_admin_referer( self::ACTION . '_' . get_current_blog_id() );
		$task = sanitize_key( wp_unslash( $_POST['task'] ?? '' ) );
		$args = array( 'page' => self::PAGE, 'done' => $task, 'count' => 0 );
		if ( 'acknowledge' === $task ) {
			$post_id = absint( $_POST['post_id'] ?? 0 );
			if ( $post_id ) {
				self::acknowledge( $post_id );
				$args['count'] = 1;
			}
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'tools.php' ) ) );
		exit;
	}

	private static function assets() {
		if ( function_exists( 'wp_enqueue_script' ) && defined( 'DIGITALISIMO_MIGRATION_FILE' ) ) {
			wp_enqueue_script( 'digitalisimo-migration-migrate', plugins_url( 'assets/js/migrate.js', DIGITALISIMO_MIGRATION_FILE ), array(), DIGITALISIMO_MIGRATION_VERSION, true );
		}
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		Runner::load();
		$state   = Runner::state();
		$running = $state && empty( $state['done'] );
		echo '<div class="wrap digi-migrate-wrap"><h1>Migrar a DIGITALÍSIMO</h1>';
		echo '<p>' . esc_html( \Digitalisimo\Migration\Screen::intro( false ) ) . '</p>';
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- sólo muestra el resultado de la acción.
		if ( isset( $_GET['done'] ) && 'acknowledge' === sanitize_key( wp_unslash( $_GET['done'] ) ) ) {
			echo '<div class="notice notice-success"><p>' . esc_html( absint( $_GET['count'] ?? 0 ) ? 'Página dada por revisada: deja de listarse mientras su contenido no cambie.' : 'No se indicó ninguna página.' ) . '</p></div>';
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		if ( is_multisite() ) {
			// En un sitio de una red, el botón de siempre: la tarea de contenido de este sitio.
			$report   = Runner::report();
			$finished = ! $running && is_array( $report ) && ! empty( $report['done'] );
			self::assets();
			echo '<div id="digi-migrate" class="digi-migrate" data-ajax="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '" data-nonce="' . esc_attr( wp_create_nonce( Runner::AJAX . '_' . get_current_blog_id() ) ) . '" data-network="0" data-running="' . ( $running ? '1' : '0' ) . '">';
			echo '<p><button type="button" class="button button-primary button-hero digi-migrate__button"' . ( $running ? ' disabled' : '' ) . '>Migrar</button></p>';
			echo '<div class="digi-migrate__status">' . Runner::render( $running ? $state : Runner::report() ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML ya escapado por Runner.
			echo '</div>';
		} else {
			// Un sitio individual: la tarea completa (respaldo, instalación, contenido, importación, tema y limpieza).
			list( $status, $full_running ) = \Digitalisimo\Migration\Screen::full_status( false );
			$finished                      = \Digitalisimo\Migration\Screen::finished( false );
			echo \Digitalisimo\Migration\Screen::control( false, $status, $full_running ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Screen y Full.
		}
		// Con la migración terminada, el análisis (lo que hará Migrar, lo que hay en el sitio) se pliega bajo el informe.
		echo \Digitalisimo\Migration\Screen::analysis_open( $finished ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Screen.
		if ( ! is_multisite() ) {
			echo \Digitalisimo\Migration\Screen::plan_html( false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Screen.
		}
		echo '<h2>Qué hay en este sitio</h2>';
		self::site_summary();
		echo self::retire_plan(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado arriba.
		// Contraseñas de aplicación de la IA de Element Pack (sólo informe; nombres sólo para quien puede verlos, V.7).
		if ( class_exists( __NAMESPACE__ . '\\Platform\\Inventory' ) && method_exists( __NAMESPACE__ . '\\Platform\\Inventory', 'app_passwords_html' ) ) {
			echo Platform\Inventory::app_passwords_html( (array) Platform\Inventory::app_passwords() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Inventory.
		}
		// El análisis de F8 se completa por trozos con la acción AJAX de la herramienta (no hay botón).
		$cached = get_option( self::ANALYSIS, null );
		// Completo si lo está el de Element Pack y el inventario de PRO sigue al día (si no, la pantalla lo rehace).
		$done = is_array( $cached ) && ! empty( $cached['done'] ) && Pro::current( $cached['pro'] ?? null );
		$html = $done ? self::analysis_html( self::analysis_result( $cached ) ) : self::analysis_html( array( 'done' => false, 'processed' => 0, 'total' => 0 ) );
		echo '<div class="digi-migrate__analysis" data-action="' . esc_attr( self::ANALYZE ) . '" data-done="' . ( $done ? '1' : '0' ) . '">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Report y Pro.
		echo \Digitalisimo\Migration\Screen::analysis_close() . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- marcado fijo.
	}

	/* ---------------------------------------------------------------- Análisis previo por trozos (V.3.5, §3.G) */

	/** Paso AJAX del análisis previo: mismo nonce y capacidad que el paso de Migrar. */
	public static function analyze_ajax() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No autorizado.', 403 );
		}
		check_ajax_referer( Runner::AJAX . '_' . get_current_blog_id() );
		Runner::load();
		$result = self::analyze_step( (float) apply_filters( 'digitalisimo_migration_analyze_seconds', self::ANALYZE_BUDGET ) );
		wp_send_json_success( $result + array( 'html' => self::analysis_html( $result ) ) );
	}

	/**
	 * Huella de lo que el análisis mira: número y fecha de modificación más reciente de los documentos con agujas.
	 * Mientras no cambie, el análisis guardado vale.
	 */
	public static function analysis_fingerprint( array $ids ) {
		global $wpdb;
		$modified = '';
		if ( $ids ) {
			$modified = (string) $wpdb->get_var( 'SELECT MAX(post_modified_gmt) FROM ' . $wpdb->posts . ' WHERE ID IN (' . implode( ',', array_map( 'intval', $ids ) ) . ')' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- enteros.
		}
		return md5( count( $ids ) . '|' . $modified . '|' . md5( implode( ',', $ids ) ) );
	}

	/**
	 * Una vuelta del análisis previo: describe documentos desde el cursor hasta agotar el plazo, sin escribir nada salvo
	 * su caché (`digitalisimo_migration_analysis`, sin carga automática). Con $budget 0, entero (WP-CLI).
	 *
	 * @return array{done:bool, processed:int, total:int, report:array}
	 */
	public static function analyze_step( $budget = 0 ) {
		$deadline = $budget > 0 ? microtime( true ) + (float) $budget : 0;
		$ids      = self::all_documents();
		$print    = self::analysis_fingerprint( $ids );
		$cache    = get_option( self::ANALYSIS, null );
		if ( ! is_array( $cache ) || ( $cache['fingerprint'] ?? '' ) !== $print ) {
			$cache = array( 'v' => 1, 'fingerprint' => $print, 'cursor' => 0, 'processed' => 0, 'total' => count( $ids ), 'done' => false, 'report' => Report::none() );
			// Lo que no depende de cada documento, una vez: pasos de plataforma (sólo lectura).
			Report::begin( 'analysis' );
			Context::begin( 0, 'analysis' );
			try {
				foreach ( array_values( array_unique( array_merge( Runner::PREPARE_STEPS, Runner::PLATFORM_STEPS ) ) ) as $step ) {
					$class = __NAMESPACE__ . '\\Platform\\' . $step;
					if ( class_exists( $class ) && method_exists( $class, 'analyze' ) ) {
						foreach ( (array) $class::analyze() as $code ) {
							if ( ! is_array( $code ) || ! isset( $code[0] ) ) {
								continue;
							}
							// Un tercer elemento es el documento al que se refiere (shortcodes del inventario).
							if ( ! empty( $code[2] ) ) {
								Report::add( (int) $code[2], (string) $code[0], (array) ( $code[1] ?? array() ) );
							} else {
								Report::site( (string) $code[0], (array) ( $code[1] ?? array() ) );
							}
						}
					}
				}
			} finally {
				Context::end();
			}
			$cache['report'] = Report::take();
		}
		if ( empty( $cache['done'] ) ) {
			Report::begin( 'analysis' );
			$moved = self::moved_to_addon();
			$batch = 0;
			foreach ( $ids as $post_id ) {
				if ( $post_id <= (int) $cache['cursor'] ) {
					continue;
				}
				self::analyze_document( (int) $post_id, $moved );
				$cache['cursor'] = (int) $post_id;
				++$cache['processed'];
				++$batch;
				// Por plazo y, en una máquina rápida, también por recuento: los trozos no dependen del reloj.
				if ( ( $deadline && microtime( true ) >= $deadline ) || $batch >= self::ANALYSIS_BATCH ) {
					break;
				}
			}
			$cache['report'] = Report::merge( (array) $cache['report'], Report::take() );
			$cache['done']   = (int) $cache['processed'] >= count( $ids );
			update_option( self::ANALYSIS, $cache, false );
		}
		// Después, el inventario de los widgets de PRO (Pro), con su propio cursor y su propia huella: al menos un lote
		// por vuelta, como el de Element Pack, aunque el plazo se haya agotado.
		if ( ! empty( $cache['done'] ) ) {
			$before       = $cache['pro'] ?? null;
			$cache['pro'] = Pro::step( is_array( $before ) ? $before : null, (float) $deadline, $budget > 0 ? Pro::ANALYSIS_MAX : 0 );
			if ( $cache['pro'] !== $before ) {
				update_option( self::ANALYSIS, $cache, false );
			}
		}
		return self::analysis_result( $cache );
	}

	/**
	 * Resultado del análisis para la pantalla y WP-CLI: el de Element Pack y, cuando termina, el inventario de PRO, con
	 * el informe previsto de los dos.
	 *
	 * @return array{done:bool, processed:int, total:int, report:array, pro:array|null}
	 */
	public static function analysis_result( array $cache ) {
		$pro    = isset( $cache['pro'] ) && is_array( $cache['pro'] ) ? $cache['pro'] : null;
		$ep     = ! empty( $cache['done'] );
		$report = (array) ( $cache['report'] ?? Report::none() );
		if ( $pro && ! empty( $pro['report'] ) ) {
			$report = Report::merge( $report, (array) $pro['report'] );
		}
		return array(
			'done'      => $ep && $pro && ! empty( $pro['done'] ),
			'processed' => (int) ( $cache['processed'] ?? 0 ),
			'total'     => (int) ( $cache['total'] ?? 0 ),
			'report'    => $report,
			'pro'       => $pro,
			'pro_stage' => $ep,
		);
	}

	/**
	 * Descripción estática de un documento, sin escribir: efectos y Prime Slider (Runner::describe), marcadores
	 * (Markers::classify) y widgets que Element Pack 10 pasó al Addon cuando el Addon no está.
	 */
	private static function analyze_document( $post_id, array $moved ) {
		$data = self::data( $post_id );
		if ( ! $data ) {
			return;
		}
		Context::begin( $post_id, 'analysis' );
		try {
			foreach ( Runner::describe( $data ) as $code => $count ) {
				Report::add( $post_id, (string) $code, array( 'count' => (int) $count ) );
			}
			// Ajustes de página (C) y descartes del documento (Dropped de C), sin escribir nada.
			$page = get_metadata( 'post', $post_id, '_elementor_page_settings', true );
			if ( is_array( $page ) && class_exists( __NAMESPACE__ . '\\Effects\\Page' ) && method_exists( __NAMESPACE__ . '\\Effects\\Page', 'describe' ) ) {
				foreach ( (array) Effects\Page::describe( $page, $post_id ) as $code => $count ) {
					Report::add( $post_id, (string) $code, array( 'count' => (int) $count ) );
				}
			}
			if ( method_exists( __NAMESPACE__ . '\\Dropped', 'report_items' ) ) {
				foreach ( (array) Dropped::report_items( $post_id ) as $item ) {
					if ( is_array( $item ) && isset( $item[0] ) ) {
						Report::add( $post_id, (string) $item[0], (array) ( $item[1] ?? array() ) );
					}
				}
			}
			$markers = array();
			$addon   = array();
			self::walk( $data, static function ( $element ) use ( &$markers, &$addon, $moved ) {
				$type = (string) ( $element['widgetType'] ?? '' );
				if ( Native::MARKER_WIDGET === $type ) {
					$markers[] = $element;
				} elseif ( $moved && in_array( $type, $moved, true ) ) {
					$addon[ $type ] = ( $addon[ $type ] ?? 0 ) + 1;
				}
				return $element;
			} );
			foreach ( $addon as $type => $count ) {
				Report::add( $post_id, 'core.addon_missing', array( 'widget' => $type, 'count' => $count ) );
			}
			if ( $markers && class_exists( __NAMESPACE__ . '\\Markers' ) && method_exists( __NAMESPACE__ . '\\Markers', 'classify' ) ) {
				$groups = (array) Markers::classify( $markers );
				foreach ( array( 'convertible' => 'mk.convertible', 'blocked' => 'mk.blocked', 'declared' => 'mk.declared' ) as $group => $code ) {
					foreach ( array_count_values( array_map( 'strval', (array) ( $groups[ $group ] ?? array() ) ) ) as $type => $count ) {
						Report::add( $post_id, $code, array( 'type' => $type, 'count' => $count ) );
					}
				}
			}
		} finally {
			Context::end();
		}
	}

	/**
	 * IDs que Element Pack 10 pasó al Addon, sólo si Element Pack ≥ 10 está instalado sin el Addon (si no, esos
	 * widgets se siguen viendo y no hay nada que decir).
	 *
	 * @return string[]
	 */
	public static function moved_to_addon() {
		$ep    = false;
		$addon = false;
		foreach ( Retire::installed() as $file => $info ) {
			if ( 'element-pack' !== $info['group'] ) {
				continue;
			}
			if ( '' !== $info['requires'] ) {
				$addon = true;
			} elseif ( '' !== $info['version'] && version_compare( $info['version'], '10', '>=' ) ) {
				$ep = true;
			}
		}
		$file = __DIR__ . '/moved-to-addon.php';
		return $ep && ! $addon && is_file( $file ) ? array_values( array_map( 'strval', (array) require $file ) ) : array();
	}

	/** HTML del análisis: avance mientras dura y, al terminar, el informe previsto (escapado por Report). */
	public static function analysis_html( array $result ) {
		if ( empty( $result['done'] ) ) {
			if ( ! empty( $result['pro_stage'] ) ) {
				return Pro::progress_html( isset( $result['pro'] ) && is_array( $result['pro'] ) ? $result['pro'] : null );
			}
			return '<p class="digi-migrate__analyzing">' . esc_html( sprintf( 'Analizando… (%d de %d)', (int) $result['processed'], (int) $result['total'] ) ) . '</p>';
		}
		// Como el informe final: lo pendiente arriba, lo demás agregado y, plegado, por documento. Su encabezado no repite
		// el de «Lo que hará Migrar» del plan, que va antes.
		$report  = (array) ( $result['report'] ?? array() );
		$digest  = Report::digest( $report );
		$pending = Report::attention( $report, 'site', $digest );
		$html    = ( $pending ? '<h4>' . esc_html( 'Pendiente de revisar' ) . '</h4><ul class="digi-migrate__attention" style="list-style:disc;margin-left:20px"><li>' . implode( '</li><li>', $pending ) . '</li></ul>' : '' ) . Report::render_detail( $report, 'site', 4, $digest );
		$html    = '' !== $html ? '<h3>' . esc_html( 'Lo que hará Migrar en el contenido' ) . '</h3>' . $html : '<p>' . esc_html( 'Nada más que convertir en plantillas, efectos, Prime Slider, contenido conservado ni widgets de PRO.' ) . '</p>';
		if ( isset( $result['pro'] ) && is_array( $result['pro'] ) ) {
			$html .= Pro::table_html( Pro::describe( $result['pro'] ) );
		}
		return $html;
	}

	/**
	 * Columna «Sin equivalente» de la red: lo descartado y lo pendiente según el último informe de F8 del sitio o, si no
	 * lo hay, su análisis previo guardado. Nunca relee documentos.
	 */
	public static function without_summary( $report ) {
		$summary = is_array( $report ) && isset( $report['report']['f8'] ) ? (array) $report['report']['f8'] : array();
		if ( ! $summary ) {
			$cached  = get_option( self::ANALYSIS, null );
			$summary = is_array( $cached ) && ! empty( $cached['done'] ) ? Report::summary( (array) $cached['report'] ) : array();
		}
		$parts = array();
		if ( ! empty( $summary['dropped'] ) ) {
			$parts[] = sprintf( 'sin equivalente: %d', (int) $summary['dropped'] );
		}
		if ( ! empty( $summary['review'] ) ) {
			$parts[] = sprintf( 'pendiente de revisar: %d', (int) $summary['review'] );
		}
		return implode( '; ', $parts );
	}

	/** Plugins que se retiran, con su grupo y su momento (al inicio o al final). */
	private static function retire_plan() {
		$groups = array( 'element-pack' => 'Element Pack', 'pro' => 'Elementor Pro / PRO Elements', 'core' => 'Elementor', 'prime-slider' => 'Prime Slider' );
		$rows   = array();
		foreach ( Retire::status() as $info ) {
			if ( ! $info['site'] && ! $info['network'] ) {
				continue;
			}
			$rows[] = sprintf( '%s (%s; %s)', $info['label'], $groups[ $info['group'] ] ?? $info['group'], $info['late'] ? 'al final, cuando sus widgets estén convertidos' : 'al empezar, en una sola escritura con su grupo' );
		}
		return $rows ? '<p>' . esc_html( 'Se desactivarán: ' . implode( '; ', $rows ) . '.' . ( is_multisite() ? ' Aquí no se borran.' : ' Cuáles se borran al final lo dice «Lo que hará Migrar».' ) ) . '</p>' : '';
	}

	/**
	 * Estado del sitio antes de migrar: plugins sustituidos, inventario de Element Pack, figuras, recuentos, cada
	 * extensión heredada sin equivalente por documento y los plugins de la familia que la migración no desactiva.
	 */
	private static function site_summary() {
		$status = Retire::status();
		$parts  = array();
		foreach ( $status as $info ) {
			$parts[] = $info['label'] . ' (' . ( $info['network'] ? 'activo en toda la red' : ( $info['site'] ? 'activo en este sitio' : 'desactivado' ) ) . ')';
		}
		echo '<p>' . esc_html( 'Plugins que DIGITALÍSIMO Elements sustituye: ' . ( $parts ? implode( ', ', $parts ) . '.' : 'ninguno instalado.' ) ) . '</p>';
		if ( Translator::element_pack_active() ) {
			echo '<div class="notice notice-warning inline"><p>Element Pack está activo: Migrar lo desactiva (sin borrarlo) antes de convertir, porque sus controles ocupan los mismos nombres. Mientras esté activo, sus widgets se muestran con su propio código.</p></div>';
		}
		$inventory = self::inventory();
		echo '<table class="widefat striped" style="max-width:860px"><thead><tr><th>Widget de Element Pack</th><th>Elementos</th><th>Documentos</th><th>Estado</th></tr></thead><tbody>';
		if ( ! $inventory ) {
			echo '<tr><td colspan="4">Este sitio no usa widgets de Element Pack.</td></tr>';
		}
		foreach ( $inventory as $type => $row ) {
			echo '<tr><td><code>' . esc_html( $type ) . '</code></td><td>' . absint( $row['elements'] ) . '</td><td>' . absint( $row['documents'] ) . '</td><td>' . esc_html( self::status( $type, $row['map'] ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
		$figures = self::figures();
		if ( $figures['elements'] ) {
			echo '<p>' . esc_html( sprintf( 'Máscaras y separadores con figuras de Element Pack: %d elementos en %d documentos. Al convertir pasan a copias propias guardadas en los archivos de este sitio.', $figures['elements'], $figures['documents'] ) ) . '</p>';
		}
		if ( $figures['missing'] ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html( sprintf( 'No se encontró el archivo de: %s. Mantén Element Pack instalado (desactivado) hasta migrar; sin archivo, la conversión retira esa máscara o separador para que la imagen siga visible.', implode( ', ', $figures['missing'] ) ) ) . '</p></div>';
		}
		$groups    = self::classify();
		$revisions = count( self::legacy_revisions() );
		$aliases   = Aliases::map() ? count( Aliases::documents() ) : count( Aliases::documents_with( Aliases::KNOWN ) );
		echo '<p>' . esc_html( sprintf( 'Documentos con contenido de Element Pack: %d por convertir y %d que sólo conservan widgets sin equivalente. Revisiones y autoguardados con contenido de Element Pack: %d. Documentos con widgets fusionados por actualizar: %d. Documentos con copia original: %d.', count( $groups['convertible'] ), count( $groups['blocked'] ), $revisions, $aliases, count( self::backups() ) ) ) . '</p>';
		if ( $groups['blocked'] ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html( sprintf( '%d documentos no cambian al migrar porque sólo les quedan widgets sin equivalente (en la tabla, «Sin adaptador»): sin Element Pack esos widgets no se muestran. Sustitúyelos en el editor por la alternativa que indica la tabla, o acepta que desaparezcan.', count( $groups['blocked'] ) ) ) . '</p></div>';
		}
		// Lo que Migrar no convierte (efectos sin equivalente, Prime Slider, marcadores…) lo dice el análisis previo de
		// F8, por trozos y con el mismo formato que el informe final (V.3.5, §3.G).
		$active = array_filter( $status, static function ( $info ) {
			return $info['site'] || $info['network'];
		} );
		if ( ! $inventory && ! $groups['convertible'] && ! $revisions && ! $aliases && ! $active ) {
			echo '<div class="notice notice-success inline"><p>Este sitio ya no tiene contenido heredado ni plugins sustituidos activos. Cuando lo hayas comprobado, puedes desinstalar Element Pack, Elementor, Elementor Pro y DIGITALÍSIMO Migración.</p></div>';
		}
	}

	/** Pantalla de red: un botón que migra todos los sitios (y lo dice) y el estado de cada uno. */
	public static function network_page() {
		if ( ! current_user_can( 'manage_network_options' ) ) {
			return;
		}
		Runner::load();
		$sites   = get_sites( array( 'number' => 500, 'fields' => 'ids' ) );
		echo '<div class="wrap digi-migrate-wrap"><h1>Migrar a DIGITALÍSIMO en la red</h1>';
		echo '<p>' . esc_html( \Digitalisimo\Migration\Screen::intro( true ) ) . '</p>';
		list( $status, $full_running ) = \Digitalisimo\Migration\Screen::full_status( true );
		echo \Digitalisimo\Migration\Screen::control( true, $status, $full_running ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Screen y Full.
		echo \Digitalisimo\Migration\Screen::analysis_open( \Digitalisimo\Migration\Screen::finished( true ), true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Screen.
		echo \Digitalisimo\Migration\Screen::plan_html( true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Screen.
		echo '<h2>Estado de cada sitio</h2>';
		echo '<table class="widefat striped"><thead><tr><th>Sitio</th><th>Elementos compatibles</th><th>Sin adaptador</th><th>Documentos pendientes de convertir</th><th>Widgets fusionados</th><th>Widgets de PRO</th><th>Plugins sustituidos activos en el sitio</th><th>Sin equivalente</th><th>Última migración</th><th></th></tr></thead><tbody>';
		$total_missing = 0;
		foreach ( $sites as $site_id ) {
			switch_to_blog( (int) $site_id );
			$compatible = 0;
			$missing    = array();
			foreach ( self::inventory() as $type => $row ) {
				if ( $row['map'] ) {
					$compatible += $row['elements'];
				} else {
					$missing[] = $type . ' (' . $row['elements'] . ')';
				}
			}
			$groups  = self::classify();
			$pending = count( $groups['convertible'] ) . ( $groups['blocked'] ? ' (+' . count( $groups['blocked'] ) . ' sólo con widgets sin adaptador)' : '' );
			$aliases = Aliases::map() ? count( Aliases::documents() ) : count( Aliases::documents_with( Aliases::KNOWN ) );
			// Widgets de PRO: documentos por convertir y, del análisis guardado del sitio, los que usa (sin releer nada).
			$pro     = Pro::network_cell( get_option( self::ANALYSIS, null ) );
			$plugins = array();
			foreach ( Retire::status() as $info ) {
				if ( $info['site'] ) {
					$plugins[] = $info['label'];
				}
			}
			// Lo que no tiene equivalente, del último informe o del análisis guardado (sin releer documentos aquí).
			$report  = Runner::report();
			$without = self::without_summary( $report );
			$state   = Runner::state();
			$last    = $state && empty( $state['done'] ) ? 'En marcha' : ( $report && ! empty( $report['finished'] ) ? wp_date( 'd/m/Y H:i', (int) $report['finished'] ) : 'Nunca' );
			$name    = get_bloginfo( 'name' );
			$url     = home_url( '/' );
			$tool    = admin_url( 'tools.php?page=' . self::PAGE );
			restore_current_blog();
			$total_missing += count( $missing );
			echo '<tr><td><strong>' . esc_html( $name ) . '</strong><br><code>' . esc_html( $url ) . '</code></td><td>' . absint( $compatible ) . '</td><td>' . ( $missing ? esc_html( implode( ', ', $missing ) ) : '—' ) . '</td><td>' . esc_html( $pending ) . '</td><td>' . absint( $aliases ) . '</td><td>' . esc_html( $pro ) . '</td><td>' . esc_html( $plugins ? implode( ', ', $plugins ) : '—' ) . '</td><td>' . esc_html( '' !== $without ? $without : '—' ) . '</td><td>' . esc_html( $last ) . '</td><td><a href="' . esc_url( $tool ) . '">Abrir la herramienta del sitio</a></td></tr>';
		}
		echo '</tbody></table>';
		$network_active = array();
		foreach ( Retire::status() as $info ) {
			if ( $info['network'] ) {
				$network_active[] = $info['label'];
			}
		}
		echo '<p>' . esc_html( ( $network_active ? 'Activos en toda la red: ' . implode( ', ', $network_active ) . '. ' : '' ) . ( $total_missing ? 'Hay widgets sin adaptador: la herramienta de cada sitio explica el motivo y la alternativa de cada uno.' : 'Ningún sitio usa widgets de Element Pack sin adaptador.' ) ) . '</p>';
		// Contraseñas de aplicación, una vez por usuario de la red (sólo un superadministrador ve los nombres).
		if ( class_exists( __NAMESPACE__ . '\\Platform\\Inventory' ) && method_exists( __NAMESPACE__ . '\\Platform\\Inventory', 'network_app_passwords' ) ) {
			echo Platform\Inventory::app_passwords_html( (array) Platform\Inventory::network_app_passwords(), 'network' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapado por Inventory.
		}
		echo \Digitalisimo\Migration\Screen::analysis_close() . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- marcado fijo.
	}
}
