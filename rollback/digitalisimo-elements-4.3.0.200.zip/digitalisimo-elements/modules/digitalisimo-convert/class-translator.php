<?php
namespace Digitalisimo\Elements\Convert;

defined( 'ABSPATH' ) || exit;

/**
 * Traduce los ajustes guardados de un widget de PRO a los de su widget propio con un mapa declarativo
 * (`maps/<widget de PRO>.php`). Mismas reglas que los traductores de DIGITALÍSIMO Migración, más los
 * colores y tipografías globales del kit (`__globals__`) y la cobertura obligatoria: **cada clave que el sitio guardó
 * se traduce, se conserva, se aproxima o se descarta con su motivo**; una clave que el mapa no declara se informa en
 * «Pendiente de revisar» (`pro.unmapped`) y no pasa al widget propio.
 *
 * Formato del mapa (todas las claves salvo `source` y `target` son opcionales):
 * - `source`, `target`: widget de PRO y widget propio.
 * - `status`: `ready` (validado: lo usan Migración y los kits) o `draft` (sólo las pruebas).
 * - `panel`: `hide` oculta del panel el widget de PRO cuando el mapa está `ready`.
 * - `defaults`: valores por defecto de los controles de PRO. Elementor no guarda lo que coincide con el default, así
 *   que se completan antes de traducir (en un control de valor múltiple, sólo las partes que faltan).
 * - `keep`: claves con el mismo nombre en el widget propio. `rename`: `de => a`. Las dos alcanzan las variantes por
 *   dispositivo (`_tablet`, `_mobile`…) y las de `__dynamic__` y `__globals__`.
 * - `keep_match`: expresión regular; toda clave (sin su dispositivo) que la cumpla pasa con el mismo nombre, como `keep`.
 *   Para los controles que PRO arma con datos del sitio (`<tipo>_taxonomy`), que pueden no existir al convertir.
 * - `groups`: prefijo de un control de grupo (tipografía, borde, sombra, fondo) `de => a`; con todas sus subclaves.
 * - `values`: `clave de destino => [antes => después]` o `callable( $valor, array $origen )`, también por dispositivo.
 * - `set`: valores fijos en el destino. `filter`: `callable( array $destino, array $origen, callable $informe ): array`,
 *   al final; `$informe( código, clave, motivo, sección )` deja un código en el informe (p. ej. `pro.dropped` en
 *   `dropped` para lo que sólo se descarta con el estado del sitio que convierte).
 * - `drop`: `clave => motivo`, pérdida declarada; se informa en «Descartado» si el sitio la cambió del default. Con el
 *   sufijo de un dispositivo (`align_tablet`), descarta sólo ese dispositivo aunque `keep` o `rename` conserven la clave.
 * - `approx`: `clave => motivo`, traducción aproximada (la hacen `rename`, `values` o `filter`); se informa en
 *   «Aproximado» si el sitio la cambió del default.
 * - `inert`: `clave => motivo`, clave guardada que el widget de PRO no lee (la dejó otro plugin o una versión antigua)
 *   y el widget propio tampoco: pasa tal cual, sin pérdida, y se informa en «Convertido» (`pro.inert`). Las de todo
 *   widget están en INERT.
 * - `repeaters`: `clave => submapa` con `target`, `defaults`, `default_rows`, `keep`, `rename`, `values`, `drop`,
 *   `approx` e `inert`; el `_id` de cada fila se conserva.
 * - `classes`: `.clase de PRO => .clase propia`, para el CSS personalizado del propio elemento. `class_patterns`:
 *   `expresión regular => reemplazo`, para las clases que PRO arma con un dato (`.elementor-sitemap-item-<tipo>`); se
 *   aplican antes que `classes` y cuentan para el mismo código `pro.css`.
 * - `img_classes`: `.clase propia => sufijo` de las clases que en PRO eran un fondo CSS y en el widget propio son (sufijo
 *   '') o contienen (p. ej. ` img`) un `<img>`: `background-size` y `background-position` del CSS personalizado pasan a
 *   `object-fit` y `object-position` del `<img>` (`background_to_object()`).
 *
 * `rewrite_external_css()` lleva esas clases al CSS que nombra el widget desde fuera (un contenedor, la página, el kit,
 * el Personalizador): no lo cambia, añade tras cada regla que las nombra su copia con las clases propias.
 *
 * Los ajustes comunes de Elementor y de DIGITALÍSIMO (pestaña Avanzado, visibilidad, movimiento, fijado, atributos,
 * condiciones de visualización de PRO `e_display_conditions`, CSS personalizado, rasgos `digitalisimo_*`) pasan sin
 * cambios.
 *
 * Condiciones de visualización de otros plugins (CONDITION_FAMILIES, o cualquier clave no declarada cuyo nombre hable de
 * condiciones o de visibilidad) y ajustes de otros plugins con un interruptor del mismo prefijo (`foreign()`): nunca se
 * pierden en silencio. Apagados (sin su interruptor encendido, o vacíos) no hacían nada y pasan tal cual (`pro.inert`);
 * encendidos, el widget propio no sabe aplicarlos, así que el elemento no se convierte (`pro.condition_kept`, con
 * `keep`): sigue siendo el widget de PRO, que se ve y se oculta igual. Los códigos de una condición llevan `condition`.
 */
final class Translator {
	const DEVICES = array( '', '_widescreen', '_laptop', '_tablet_extra', '_tablet', '_mobile_extra', '_mobile' );

	/** Claves comunes a todo elemento: pasan tal cual. */
	const COMMON = array( 'custom_css', 'animation_duration', 'e_display_conditions', 'sticky', 'sticky_on', 'sticky_offset', 'sticky_effects_offset', 'sticky_anchor_link_offset', 'sticky_parent' );

	/**
	 * Claves que ningún widget lee, en cualquier widget cuyo mapa no las declare: `clave => motivo`. Pasan tal cual (sin
	 * pérdida) salvo la clave sin nombre, que se quita. Se informan en «Convertido» (`pro.inert`).
	 */
	const INERT = array(
		'content_width' => 'Ancho de contenido de un contenedor guardado en el widget (copiado o pegado desde un contenedor): ni el widget de PRO ni el propio lo leen. Pasa tal cual; no cambia nada de lo que se ve.',
		''              => 'Ajuste sin nombre (dato dañado al guardar): ningún control lo lee. Se quita; no cambia nada de lo que se ve.',
	);

	/**
	 * Condiciones de visualización de otros plugins de complementos: prefijo de sus claves => su interruptor. Sin el
	 * interruptor encendido (Elementor no guarda el apagado) sus reglas no ocultaban nada, aunque Elementor guarde el
	 * repetidor con su fila por defecto. Nombres tomados de los sitios y de la revisión, sin una copia de esos plugins en
	 * el repositorio para comprobarlos: lo que no case aquí lo resuelve la regla del interruptor del mismo prefijo.
	 */
	const CONDITION_FAMILIES = array(
		'display_condition_'     => 'display_condition_enable',
		'pa_display_conditions_' => 'pa_display_conditions_switcher',
		'pa_condition_'          => 'pa_display_conditions_switcher',
		'pp_display_condition'   => 'pp_display_conditions_enable',
		'jedv_'                  => 'jedv_enabled',
	);

	/** Nombres de interruptor (sin dispositivo): `…_enable`, `…_enabled`, `…_switch`, `…_switcher`, `…_show`, `…_active`, `…_on`. */
	const SWITCH_PATTERN = '/_(enable|enabled|switch|switcher|show|active|on)$/';

	/** Nombres de clave que hablan de condiciones o de visibilidad (sin declarar: se tratan como condiciones). */
	const CONDITION_PATTERN = '/condition|visibilit/i';

	/** Código que deja el elemento sin convertir (con `keep`). */
	const KEEP = 'pro.condition_kept';

	/** Prefijos de claves comunes. `_` cubre la pestaña Avanzado y el `_id` de las filas. */
	const COMMON_PREFIXES = array( '_', 'motion_fx_', 'hide_', 'digitalisimo_', 'sticky_' );

	/** Marca del widget de origen en los ajustes traducidos: un ajuste ya traducido no se traduce otra vez. */
	const MARKER = '_digitalisimo_pro';

	/**
	 * Traduce los ajustes de un widget con su mapa.
	 *
	 * @return array{0: array, 1: array<int, array{code:string, key:string, reason:string, section:string}>} Ajustes y
	 *         códigos del informe.
	 */
	public static function translate( array $settings, array $map ): array {
		if ( isset( $settings[ self::MARKER ] ) ) {
			return array( $settings, array() );
		}
		$codes = array();
		$out   = self::level( $settings, $map, $codes, '' );
		foreach ( (array) ( $map['repeaters'] ?? array() ) as $key => $spec ) {
			$rows = array_key_exists( $key, $settings ) ? $settings[ $key ] : ( $spec['default_rows'] ?? array() );
			$items = array();
			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				if ( is_array( $row ) ) {
					$items[] = self::level( $row, (array) $spec, $codes, $key . '.' );
				}
			}
			$out[ (string) ( $spec['target'] ?? $key ) ] = $items;
		}
		if ( ( ! empty( $map['classes'] ) || ! empty( $map['class_patterns'] ) ) && isset( $out['custom_css'] ) && is_string( $out['custom_css'] ) && '' !== $out['custom_css'] ) {
			$css = self::rewrite_classes( $out['custom_css'], (array) ( $map['classes'] ?? array() ), (array) ( $map['class_patterns'] ?? array() ) );
			if ( $css !== $out['custom_css'] ) {
				$out['custom_css'] = $css;
				$codes[]           = self::code( 'pro.css', 'custom_css', 'Clases del widget de PRO en el CSS personalizado del elemento, pasadas a las del widget propio.', 'converted' );
			}
		}
		if ( ! empty( $map['img_classes'] ) && isset( $out['custom_css'] ) && is_string( $out['custom_css'] ) && '' !== $out['custom_css'] ) {
			$lost = false;
			$css  = self::background_to_object( $out['custom_css'], (array) $map['img_classes'], $lost );
			if ( $css !== $out['custom_css'] ) {
				$out['custom_css'] = $css;
				$reason            = 'El fondo de la imagen de PRO (`background-size`, `background-position`) pasa al `<img>` del widget propio (`object-fit`, `object-position`).';
				$found             = false;
				foreach ( $codes as $i => $code ) {
					if ( 'pro.css' === $code['code'] && 'custom_css' === $code['key'] ) {
						$codes[ $i ]['reason'] .= ' ' . $reason;
						$found                  = true;
					}
				}
				if ( ! $found ) {
					$codes[] = self::code( 'pro.css', 'custom_css', $reason, 'converted' );
				}
			}
			if ( $lost ) {
				$codes[] = self::code( 'pro.approx', 'custom_css', 'Un tamaño de fondo con medidas (`background-size` con longitudes o porcentajes), `background-position-x`/`-y`, varios fondos o el atajo `background` no tienen equivalente en el `<img>` del widget propio: quedan sobre su envoltorio, sin efecto.', 'approx' );
			}
		}
		if ( isset( $map['filter'] ) && is_callable( $map['filter'] ) ) {
			$report = static function ( string $code, string $key, string $reason, string $section ) use ( &$codes ): void {
				$codes[] = self::code( $code, $key, $reason, $section );
			};
			$out = (array) call_user_func( $map['filter'], $out, $settings, $report );
		}
		$out[ self::MARKER ] = (string) ( $map['source'] ?? '' );
		return array( $out, $codes );
	}

	/**
	 * Un nivel (el widget o una fila de repetidor): defaults, claves declaradas, comunes y no declaradas.
	 *
	 * @param array  $codes  Recibe los códigos del informe.
	 * @param string $prefix Prefijo de las claves en los códigos (`repetidor.` en una fila).
	 */
	private static function level( array $settings, array $spec, array &$codes, string $prefix ): array {
		$defaults = (array) ( $spec['defaults'] ?? array() );
		$changed  = static function ( $key ) use ( $settings, $defaults ) {
			return array_key_exists( $key, $settings ) && ( ! array_key_exists( $key, $defaults ) || $settings[ $key ] !== $defaults[ $key ] );
		};
		foreach ( $defaults as $key => $value ) {
			if ( ! array_key_exists( $key, $settings ) ) {
				$settings[ $key ] = $value;
			} elseif ( is_array( $value ) && is_array( $settings[ $key ] ) && $value && array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
				// Como Elementor en los controles de valor múltiple (URL, imagen, icono, medidas): lo que falta, del default.
				$settings[ $key ] = array_merge( $value, $settings[ $key ] );
			}
		}
		$rename = (array) ( $spec['rename'] ?? array() );
		foreach ( (array) ( $spec['keep'] ?? array() ) as $key ) {
			$rename[ $key ] = $key;
		}
		$groups  = (array) ( $spec['groups'] ?? array() );
		$match   = isset( $spec['keep_match'] ) && is_string( $spec['keep_match'] ) && '' !== $spec['keep_match'] ? $spec['keep_match'] : '';
		if ( '' !== $match ) {
			foreach ( array_keys( $settings ) as $key ) {
				$base = self::base( (string) $key );
				if ( ! isset( $rename[ $base ] ) && 1 === preg_match( $match, $base ) ) {
					$rename[ $base ] = $base;
				}
			}
			foreach ( array( '__dynamic__', '__globals__' ) as $bag ) {
				foreach ( is_array( $settings[ $bag ] ?? null ) ? array_keys( $settings[ $bag ] ) : array() as $key ) {
					$base = self::base( (string) $key );
					if ( ! isset( $rename[ $base ] ) && 1 === preg_match( $match, $base ) ) {
						$rename[ $base ] = $base;
					}
				}
			}
		}
		$drop    = (array) ( $spec['drop'] ?? array() );
		$approx  = (array) ( $spec['approx'] ?? array() );
		$nested  = array_keys( (array) ( $spec['repeaters'] ?? array() ) );
		$out     = array();
		$handled = array();
		foreach ( $rename as $from => $to ) {
			foreach ( self::DEVICES as $device ) {
				if ( '' !== $device && isset( $drop[ $from . $device ] ) ) {
					continue; // Descartada sólo en este dispositivo: se informa abajo.
				}
				if ( array_key_exists( $from . $device, $settings ) ) {
					$out[ $to . $device ]          = $settings[ $from . $device ];
					$handled[ $from . $device ] = true;
				}
			}
		}
		foreach ( $groups as $from => $to ) {
			foreach ( $settings as $key => $value ) {
				if ( 0 === strpos( (string) $key, $from . '_' ) ) {
					$out[ $to . substr( (string) $key, strlen( $from ) ) ] = $value;
					$handled[ $key ] = true;
				}
			}
		}
		// Claves que el mapa no declara (las que mira la regla del interruptor del mismo prefijo de foreign()).
		$undeclared = array();
		foreach ( array_keys( $settings ) as $key ) {
			$key  = (string) $key;
			$base = self::base( $key );
			if ( ! isset( $handled[ $key ] ) && ! in_array( $key, $nested, true ) && self::MARKER !== $key && '__dynamic__' !== $key && '__globals__' !== $key && ! isset( $drop[ $base ] ) && ! isset( $drop[ $key ] ) && ! isset( $approx[ $base ] ) && ! self::common( $key ) ) {
				$undeclared[] = $key;
			}
		}
		$code_of = static function ( array $foreign, string $key ) use ( $prefix ): array {
			$code = 'keep' === $foreign['state']
				? self::code( self::KEEP, $prefix . $key, (string) $foreign['reason'], 'review' ) + array( 'keep' => true )
				: self::code( 'pro.inert', $prefix . $key, (string) $foreign['reason'], 'converted' );
			return $code + ( ! empty( $foreign['condition'] ) ? array( 'condition' => true ) : array() );
		};
		foreach ( array( '__dynamic__', '__globals__' ) as $bag ) {
			if ( empty( $settings[ $bag ] ) || ! is_array( $settings[ $bag ] ) ) {
				continue;
			}
			$moved = array();
			foreach ( $settings[ $bag ] as $key => $value ) {
				// Una clave descartada sólo en su dispositivo (`drop` con sufijo) no sigue a la conservada.
				$only   = ! isset( $drop[ self::base( (string) $key ) ] ) && isset( $drop[ (string) $key ] ) && self::base( (string) $key ) !== (string) $key;
				$target = $only ? null : self::target_key( (string) $key, $rename, $groups );
				if ( $only ) {
					$codes[] = self::code( 'pro.dropped', $prefix . $key, (string) $drop[ (string) $key ], 'dropped' );
				} elseif ( null !== $target ) {
					$moved[ $target ] = $value;
				} elseif ( self::common( (string) $key ) ) {
					$moved[ $key ] = $value;
				} elseif ( isset( $drop[ self::base( (string) $key ) ] ) ) {
					$codes[] = self::code( 'pro.dropped', $prefix . self::base( (string) $key ), (string) $drop[ self::base( (string) $key ) ], 'dropped' );
				} elseif ( null !== ( $foreign = self::foreign( (string) $key, $settings, $spec, $undeclared ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition
					// Ajuste inerte o condición de otro plugin: su valor dinámico o global la acompaña (el código sale abajo).
					if ( '' !== (string) $key ) {
						$moved[ $key ] = $value;
					}
					if ( ! array_key_exists( $key, $settings ) ) {
						$codes[] = $code_of( $foreign, (string) $key );
					}
				} else {
					$codes[] = self::code( 'pro.unmapped', $prefix . $key, 'Valor dinámico o global de un ajuste que el widget de PRO no declara (lo dejó otro plugin o una versión antigua): no pasa al widget propio. Si ese plugin lo usaba en este elemento, su efecto se pierde.', 'review' );
				}
			}
			if ( $moved ) {
				$out[ $bag ] = $moved;
			}
			$handled[ $bag ] = true;
		}
		foreach ( $settings as $key => $value ) {
			$key = (string) $key;
			if ( isset( $handled[ $key ] ) || in_array( $key, $nested, true ) || self::MARKER === $key ) {
				continue;
			}
			$base = self::base( $key );
			if ( isset( $drop[ $base ] ) || isset( $drop[ $key ] ) ) {
				if ( $changed( $key ) ) {
					$why     = isset( $drop[ $base ] ) ? $base : $key;
					$codes[] = self::code( 'pro.dropped', $prefix . $why, (string) $drop[ $why ], 'dropped' );
				}
				continue;
			}
			if ( self::common( $key ) ) {
				$out[ $key ] = $value;
				continue;
			}
			if ( isset( $approx[ $base ] ) ) {
				continue; // La traduce `filter` con el origen; su código sale abajo si cambió.
			}
			$foreign = self::foreign( $key, $settings, $spec, $undeclared );
			if ( null !== $foreign ) {
				// Inerte (pasa tal cual, salvo la clave sin nombre) u otro plugin (pasa; encendido, `keep`).
				if ( '' !== $key ) {
					$out[ $key ] = $value;
				}
				$codes[] = $code_of( $foreign, $key );
				continue;
			}
			$codes[] = self::code( 'pro.unmapped', $prefix . $key, 'Ajuste guardado que el widget de PRO no declara (lo dejó otro plugin o una versión antigua): no pasa al widget propio. Si ese plugin lo usaba en este elemento, su efecto se pierde.', 'review' );
		}
		foreach ( $approx as $key => $reason ) {
			foreach ( self::DEVICES as $device ) {
				if ( $changed( $key . $device ) ) {
					$codes[] = self::code( 'pro.approx', $prefix . $key, (string) $reason, 'approx' );
					break;
				}
			}
		}
		foreach ( (array) ( $spec['values'] ?? array() ) as $key => $values ) {
			foreach ( self::DEVICES as $device ) {
				if ( ! array_key_exists( $key . $device, $out ) ) {
					continue;
				}
				if ( is_callable( $values ) ) {
					$out[ $key . $device ] = call_user_func( $values, $out[ $key . $device ], $settings );
				} elseif ( is_array( $values ) && is_scalar( $out[ $key . $device ] ) && array_key_exists( (string) $out[ $key . $device ], $values ) ) {
					$out[ $key . $device ] = $values[ (string) $out[ $key . $device ] ];
				}
			}
		}
		foreach ( (array) ( $spec['set'] ?? array() ) as $key => $value ) {
			$out[ $key ] = $value;
		}
		return $out;
	}

	/** Clave de destino de una clave de origen (con su dispositivo) por `rename`/`keep` o `groups`, o null. */
	private static function target_key( string $key, array $rename, array $groups ): ?string {
		foreach ( self::DEVICES as $device ) {
			if ( '' !== $device && substr( $key, -strlen( $device ) ) !== $device ) {
				continue;
			}
			$base = '' === $device ? $key : substr( $key, 0, -strlen( $device ) );
			if ( isset( $rename[ $base ] ) ) {
				return $rename[ $base ] . $device;
			}
		}
		foreach ( $groups as $from => $to ) {
			if ( 0 === strpos( $key, $from . '_' ) ) {
				return $to . substr( $key, strlen( $from ) );
			}
		}
		return null;
	}

	/** La clave sin el sufijo de dispositivo. */
	public static function base( string $key ): string {
		foreach ( self::DEVICES as $device ) {
			if ( '' !== $device && strlen( $key ) > strlen( $device ) && substr( $key, -strlen( $device ) ) === $device ) {
				return substr( $key, 0, -strlen( $device ) );
			}
		}
		return $key;
	}

	/**
	 * Clave no declarada que no es del widget de PRO: inerte (INERT o `inert` del mapa), condición de visualización de
	 * otro plugin, o ajuste de otro plugin con un interruptor del mismo prefijo. `state`: `inert` (no hacía nada; pasa tal
	 * cual) o `keep` (encendido y el widget propio no sabe aplicarlo: el elemento no se convierte). `condition`: si es una
	 * condición o visibilidad.
	 *
	 * Regla del interruptor del mismo prefijo, para lo que no está declarado: si entre las claves no declaradas del
	 * elemento ($undeclared; sin ella, todas las demás) hay un interruptor (SWITCH_PATTERN) con el mismo primer segmento
	 * (`xx_` de `xx_cl_logics`), manda ese interruptor; una clave que es ella misma un interruptor encendido también deja el
	 * elemento como está. Sin interruptor, una condición con valor falla cerrado y otra clave sigue en `pro.unmapped`.
	 *
	 * @param string[]|null $undeclared Claves del elemento que el mapa no declara.
	 * @return array{state:string, reason:string, condition:bool}|null null si no es nada de eso (`pro.unmapped`).
	 */
	public static function foreign( string $key, array $settings, array $spec = array(), ?array $undeclared = null ): ?array {
		$base  = self::base( $key );
		$inert = (array) ( $spec['inert'] ?? array() );
		if ( isset( $inert[ $base ] ) || isset( $inert[ $key ] ) ) {
			return array( 'state' => 'inert', 'reason' => (string) ( $inert[ $base ] ?? $inert[ $key ] ), 'condition' => false );
		}
		if ( array_key_exists( $base, self::INERT ) ) {
			return array( 'state' => 'inert', 'reason' => self::INERT[ $base ], 'condition' => false );
		}
		foreach ( self::CONDITION_FAMILIES as $prefix => $switch ) {
			if ( 0 !== strpos( $base, $prefix ) ) {
				continue;
			}
			if ( self::used( $settings[ $switch ] ?? null ) ) {
				return array( 'state' => 'keep', 'reason' => sprintf( 'Condiciones de visualización de otro plugin encendidas (`%s`): el widget propio no sabe aplicarlas, así que este elemento se queda como widget de PRO, que se sigue viendo (y ocultando) igual.', $switch ), 'condition' => true );
			}
			return array( 'state' => 'inert', 'reason' => sprintf( 'Condiciones de visualización de otro plugin, apagadas (sin `%s` encendido): no ocultaban nada. Pasan tal cual al widget propio.', $switch ), 'condition' => true );
		}
		if ( '' === $base ) {
			return null;
		}
		$condition = 1 === preg_match( self::CONDITION_PATTERN, $base );
		$switch    = self::prefix_switch( $key, $settings, null === $undeclared ? array_map( 'strval', array_keys( $settings ) ) : $undeclared );
		if ( null !== $switch && $condition && 1 !== preg_match( self::CONDITION_PATTERN, self::base( $switch ) ) ) {
			$switch = null; // Una condición sólo la apaga un interruptor de condiciones (no el de otro efecto del plugin).
		}
		if ( null !== $switch ) {
			if ( self::used( $settings[ $switch ] ?? null ) ) {
				return array( 'state' => 'keep', 'reason' => sprintf( 'Ajuste de otro plugin con su interruptor encendido (`%s`) que el widget propio no sabe aplicar: para no perder lo que hacía (y no mostrar algo que estaba oculto), este elemento se queda como widget de PRO, que se sigue viendo igual.', $switch ), 'condition' => $condition );
			}
			return array( 'state' => 'inert', 'reason' => sprintf( 'Ajuste de otro plugin con su interruptor apagado (`%s`): no hacía nada. Pasa tal cual al widget propio.', $switch ), 'condition' => $condition );
		}
		if ( 1 === preg_match( self::SWITCH_PATTERN, $base ) ) {
			return self::used( $settings[ $key ] ?? null )
				? array( 'state' => 'keep', 'reason' => 'Interruptor encendido de otro plugin que el widget propio no sabe aplicar: este elemento se queda como widget de PRO, que se sigue viendo igual.', 'condition' => $condition )
				: array( 'state' => 'inert', 'reason' => 'Interruptor apagado de otro plugin: no hacía nada. Pasa tal cual al widget propio.', 'condition' => $condition );
		}
		if ( $condition ) {
			if ( self::used( $settings[ $key ] ?? null ) ) {
				return array( 'state' => 'keep', 'reason' => 'Ajuste de condiciones o de visibilidad de otro plugin, sin un interruptor que diga si estaba apagado, que el widget propio no sabe aplicar: para no mostrar algo que estaba oculto, este elemento se queda como widget de PRO, que se sigue viendo (y ocultando) igual.', 'condition' => true );
			}
			return array( 'state' => 'inert', 'reason' => 'Ajuste de condiciones o de visibilidad de otro plugin, vacío: no ocultaba nada. Pasa tal cual al widget propio.', 'condition' => true );
		}
		return null;
	}

	/**
	 * Interruptor no declarado del mismo primer segmento que una clave (`xx_enable` para `xx_cl_logics`), o null. Sólo entre
	 * $candidates (claves no declaradas), nunca la propia clave.
	 */
	private static function prefix_switch( string $key, array $settings, array $candidates ): ?string {
		$base = self::base( $key );
		$cut  = strpos( $base, '_' );
		if ( false === $cut || 0 === $cut ) {
			return null;
		}
		$head  = substr( $base, 0, $cut + 1 );
		$found = null;
		foreach ( $candidates as $candidate ) {
			$candidate = (string) $candidate;
			if ( $candidate === $key || self::base( $candidate ) === $base || 0 !== strpos( $candidate, $head ) || ! array_key_exists( $candidate, $settings ) || 1 !== preg_match( self::SWITCH_PATTERN, self::base( $candidate ) ) ) {
				continue;
			}
			// Con varios, manda uno encendido (falla cerrado).
			if ( self::used( $settings[ $candidate ] ) ) {
				return $candidate;
			}
			$found = null === $found ? $candidate : $found;
		}
		return $found;
	}

	/** ¿Tiene efecto un valor guardado? (vacío, `no`, `false` o una lista vacía, no). */
	private static function used( $value ): bool {
		if ( is_array( $value ) ) {
			return (bool) $value;
		}
		if ( null === $value || is_bool( $value ) ) {
			return (bool) $value;
		}
		$value = strtolower( trim( (string) $value ) );
		return '' !== $value && 'no' !== $value && 'false' !== $value && '0' !== $value;
	}

	/** ¿Es una clave común de todo elemento? */
	public static function common( string $key ): bool {
		if ( in_array( $key, self::COMMON, true ) ) {
			return true;
		}
		foreach ( self::COMMON_PREFIXES as $prefix ) {
			if ( 0 === strpos( $key, $prefix ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Clases del widget de PRO en un CSS, por las del widget propio: primero los patrones (`class_patterns`) y después
	 * sólo nombres de clase completos (no `-a` dentro de `.x-ab`), de los más largos a los más cortos.
	 */
	public static function rewrite_classes( string $css, array $classes, array $patterns = array() ): string {
		foreach ( $patterns as $pattern => $replacement ) {
			$result = @preg_replace( (string) $pattern, (string) $replacement, $css ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- un patrón mal escrito en un mapa no rompe la conversión.
			$css    = is_string( $result ) ? $result : $css;
		}
		uksort(
			$classes,
			static function ( $a, $b ) {
				return strlen( (string) $b ) - strlen( (string) $a );
			}
		);
		foreach ( $classes as $from => $to ) {
			$css = (string) preg_replace( '/' . preg_quote( (string) $from, '/' ) . '(?![\w-])/', (string) $to, $css );
		}
		return $css;
	}

	/**
	 * Reglas del CSS (ya con las clases propias) cuyo selector termina en una clase que en PRO era un fondo CSS y en el
	 * widget propio es (o contiene) un `<img>`: tras cada una se añade la misma regla sobre el `<img>` (`$images`: clase =>
	 * sufijo del selector, '' si la clase está en el propio `<img>`) con `background-size` → `object-fit` (`cover`,
	 * `contain`; `auto` → `none`, como «Ajuste de la imagen») y `background-position` → `object-position` (misma
	 * sintaxis). La regla original queda intacta (en el envoltorio no tiene efecto). Lo que no tiene equivalente
	 * (medidas en el tamaño, `background-position-x`/`-y`, varios fondos, el atajo `background`, que en PRO devolvía el
	 * tamaño y la posición a sus valores iniciales) se marca en `$lost` y no se traduce. Los comentarios no pasan a la
	 * regla nueva.
	 *
	 * @param bool $lost Recibe `true` si alguna declaración no tiene equivalente.
	 */
	public static function background_to_object( string $css, array $images, bool &$lost = false ): string {
		$classes = array();
		foreach ( $images as $class => $suffix ) {
			if ( preg_match( '/^\.[A-Za-z_][\w-]*$/', (string) $class ) ) {
				$classes[ (string) $class ] = (string) $suffix;
			}
		}
		if ( ! $classes || false === stripos( $css, 'background' ) ) {
			return $css;
		}
		return (string) preg_replace_callback(
			'/([^{};]*)\{([^{}]*)\}/',
			static function ( array $m ) use ( $classes, &$lost ): string {
				$rule = $m[0];
				if ( false === stripos( $m[2], 'background' ) || '' === trim( $m[1] ) || '@' === ltrim( $m[1] )[0] ) {
					return $rule;
				}
				$targets = array();
				foreach ( self::split_selectors( $m[1] ) as $selector ) {
					// Sin comentarios: los completos y el final de uno abierto antes de la regla (`/* a{b} */ selector …`).
					$selector = trim( (string) preg_replace( array( '#/\*.*?\*/#s', '#^.*\*/#s' ), '', $selector ) );
					// El último compuesto (tras el último combinador): con la clase entera y sin pseudoelemento.
					$last = (string) preg_replace( '/^.*[\s>+~]/s', '', $selector );
					if ( false !== strpos( $last, '::' ) || preg_match( '/:(?:before|after)\b/i', $last ) ) {
						continue;
					}
					foreach ( $classes as $class => $suffix ) {
						if ( preg_match( '/' . preg_quote( $class, '/' ) . '(?![\w-])/', $last ) ) {
							$targets[] = $selector . $suffix;
							break;
						}
					}
				}
				if ( ! $targets ) {
					return $rule;
				}
				$decls = array();
				foreach ( explode( ';', (string) preg_replace( '#/\*.*?\*/#s', '', $m[2] ) ) as $declaration ) {
					if ( preg_match( '/^\s*background\s*:/i', $declaration ) ) {
						$lost = true; // El atajo: en PRO también fijaba el tamaño y la posición (a sus valores iniciales si no los nombra).
						continue;
					}
					if ( ! preg_match( '/^\s*(background-(?:size|position(?:-x|-y)?))\s*:\s*(.+?)\s*$/is', $declaration, $d ) ) {
						continue;
					}
					$important = (bool) preg_match( '/\s*!\s*important$/i', $d[2] );
					$value     = trim( (string) preg_replace( '/\s*!\s*important$/i', '', $d[2] ) );
					$name      = strtolower( $d[1] );
					if ( false !== strpos( $value, ',' ) || 'background-size' !== $name && 'background-position' !== $name ) {
						$lost = true;
						continue;
					}
					if ( 'background-size' === $name ) {
						$fit = array( 'cover' => 'cover', 'contain' => 'contain', 'auto' => 'none', 'auto auto' => 'none' );
						$key = strtolower( (string) preg_replace( '/\s+/', ' ', $value ) );
						if ( ! isset( $fit[ $key ] ) ) {
							$lost = true;
							continue;
						}
						$decls[] = 'object-fit:' . $fit[ $key ] . ( $important ? '!important' : '' );
					} else {
						$decls[] = 'object-position:' . $value . ( $important ? '!important' : '' );
					}
				}
				return $decls ? $rule . "\n" . implode( ',', $targets ) . '{' . implode( ';', $decls ) . '}' : $rule;
			},
			$css
		);
	}

	/** Selectores de una lista separada por comas (sin partir dentro de paréntesis ni corchetes). */
	private static function split_selectors( string $list ): array {
		$out   = array();
		$depth = 0;
		$cur   = '';
		$len   = strlen( $list );
		for ( $i = 0; $i < $len; $i++ ) {
			$ch = $list[ $i ];
			if ( '(' === $ch || '[' === $ch ) {
				$depth++;
			} elseif ( ( ')' === $ch || ']' === $ch ) && $depth > 0 ) {
				$depth--;
			} elseif ( ',' === $ch && 0 === $depth ) {
				$out[] = $cur;
				$cur   = '';
				continue;
			}
			$cur .= $ch;
		}
		$out[] = $cur;
		return $out;
	}

	/**
	 * CSS que nombra las clases de PRO desde fuera del widget (un contenedor, la página, el kit, el Personalizador): tras
	 * cada regla de estilo que las nombra se añade su copia con las clases propias, una por juego de clases que la
	 * cambie (sin repetir copias iguales); también dentro de `@media`, `@supports`, `@container`, `@layer`, `@scope` y
	 * `@-moz-document`. La regla original se queda (sigue valiendo para los widgets de PRO que queden) y el orden de la
	 * cascada no cambia.
	 *
	 * Un juego sólo traduce los selectores de la lista que nombran alguna clase suya que pasa a una clase propia
	 * (`.digi-…`, `.elementor-widget-digitalisimo-…`); los demás se repiten tal cual en la copia. Así un selector que sólo
	 * nombra un estado genérico de PRO (`.elementor-active` → `[aria-expanded=true]`) no se copia sobre todo el sitio,
	 * ni solo ni en una lista. Idempotente: una copia que ya está en el CSS no se vuelve a añadir. Sin cambios devuelve el
	 * CSS tal cual.
	 *
	 * @param string  $css  CSS.
	 * @param array[] $sets Juegos `{ classes, class_patterns }` (los de los mapas: `Converter::class_sets()`).
	 */
	public static function rewrite_external_css( string $css, array $sets ): string {
		if ( '' === trim( $css ) || ! $sets ) {
			return $css;
		}
		// Cada juego con su ancla en una sola expresión; sólo siguen los que podrían aplicarse a este CSS.
		$ready = array();
		foreach ( $sets as $set ) {
			$classes  = (array) ( $set['classes'] ?? array() );
			$patterns = (array) ( $set['class_patterns'] ?? array() );
			$anchors  = array();
			foreach ( $classes as $from => $to ) {
				if ( 1 === preg_match( '/^\.(?:digi-|elementor-widget-digitalisimo-)/', (string) $to ) ) {
					$anchors[] = preg_quote( (string) $from, '/' );
				}
			}
			$anchor = $anchors ? '/(?:' . implode( '|', $anchors ) . ')(?![\w-])/' : '';
			$hit    = '' !== $anchor && 1 === preg_match( $anchor, $css );
			foreach ( $hit ? array() : $patterns as $pattern => $replacement ) {
				$hit = $hit || 1 === @preg_match( (string) $pattern, $css ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- un patrón mal escrito en un mapa no rompe la conversión.
			}
			if ( $hit ) {
				$ready[] = array( 'classes' => $classes, 'class_patterns' => $patterns, 'anchor' => $anchor );
			}
		}
		if ( ! $ready ) {
			return $css;
		}
		$out = self::external_block( $css, $ready, $css );
		return null === $out ? $css : $out;
	}

	/** Un bloque de reglas; null si no cambia nada. */
	private static function external_block( string $css, array $sets, string $whole ): ?string {
		$out     = '';
		$changed = false;
		$len     = strlen( $css );
		$pos     = 0;
		while ( $pos < $len ) {
			$open = self::css_find( $css, $pos, '{' );
			if ( null === $open ) {
				$out .= substr( $css, $pos );
				break;
			}
			$close = self::css_close( $css, $open );
			if ( null === $close ) {
				$out .= substr( $css, $pos );
				break;
			}
			// Sentencias sin bloque (`@import …;`, `@charset …;`) antes del preludio: pasan tal cual.
			$prelude_start = $pos;
			$semi          = self::css_find( $css, $pos, ';', $open );
			while ( null !== $semi ) {
				$prelude_start = $semi + 1;
				$semi          = self::css_find( $css, $prelude_start, ';', $open );
			}
			$out    .= substr( $css, $pos, $prelude_start - $pos );
			$prelude = substr( $css, $prelude_start, $open - $prelude_start );
			$body    = substr( $css, $open + 1, $close - $open - 1 );
			$rule    = substr( $css, $prelude_start, $close + 1 - $prelude_start );
			$name    = strtolower( (string) ( preg_match( '/^\s*(?:\/\*.*?\*\/\s*)*@([a-z-]+)/s', $prelude, $m ) ? $m[1] : '' ) );
			if ( in_array( $name, array( 'media', 'supports', 'container', 'layer', 'scope', 'document', '-moz-document' ), true ) ) {
				$inner = self::external_block( $body, $sets, $whole );
				if ( null !== $inner ) {
					$rule    = $prelude . '{' . $inner . '}';
					$changed = true;
				}
				$out .= $rule;
			} elseif ( '' === $name ) {
				$out .= $rule;
				foreach ( self::external_copies( $prelude, $body, $sets ) as $copy ) {
					if ( false === strpos( $whole, $copy ) ) {
						$out    .= $copy;
						$changed = true;
					}
				}
			} else {
				$out .= $rule; // `@keyframes`, `@font-face`, `@page`…: no nombran elementos.
			}
			$pos = $close + 1;
		}
		return $changed ? $out : null;
	}

	/**
	 * Copias traducidas de una regla de estilo (sin repetir), con los juegos que se le aplican. Una copia que todavía nombra
	 * clases de otro juego (una lista de selectores con el menú y el buscador de PRO) gana a su vez su copia, en la misma
	 * pasada: así la segunda pasada no añade nada (idempotente).
	 *
	 * El ancla se mira en cada selector de la lista: sólo se traducen los que nombran una clase del juego que pasa a una
	 * clase propia, y los demás se repiten tal cual. Así un estado suelto en la misma lista (`.elementor-nav-menu a,
	 * .elementor-active`) no pasa a un atributo que alcanzaría a todo el sitio (`[aria-expanded=true]`).
	 */
	private static function external_copies( string $prelude, string $body, array $sets ): array {
		$rule   = $prelude . '{' . $body . '}';
		$copies = array();
		$queue  = array( array( $prelude, $body ) );
		for ( $i = 0; $i < count( $queue ) && $i < 32; $i++ ) {
			list( $head, $decl ) = $queue[ $i ];
			$text  = $head . '{' . $decl . '}';
			$parts = self::selector_parts( $head );
			foreach ( $sets as $set ) {
				$classes  = $set['classes'];
				$patterns = $set['class_patterns'];
				$anchored = false;
				$new      = array();
				foreach ( $parts as $part ) {
					if ( self::anchored( $part[1], $set ) ) {
						$anchored = true;
						$new[]    = self::rewrite_classes( $part[0], $classes, $patterns );
					} else {
						$new[] = $part[0];
					}
				}
				if ( ! $anchored ) {
					continue;
				}
				$new_head = implode( ',', $new );
				$new_decl = self::rewrite_classes( $decl, $classes, $patterns );
				$copy     = $new_head . '{' . $new_decl . '}';
				if ( $copy !== $text && $copy !== $rule && ! in_array( $copy, $copies, true ) ) {
					$copies[] = $copy;
					$queue[]  = array( $new_head, $new_decl );
				}
			}
		}
		return $copies;
	}

	/** ¿Nombra el selector (sin comentarios ni cadenas) una clase del juego que pasa a una clase propia, o un patrón suyo? */
	private static function anchored( string $plain, array $set ): bool {
		if ( '' !== $set['anchor'] && 1 === preg_match( $set['anchor'], $plain ) ) {
			return true;
		}
		foreach ( $set['class_patterns'] as $pattern => $replacement ) {
			if ( 1 === @preg_match( (string) $pattern, $plain ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors -- un patrón mal escrito en un mapa no rompe la conversión.
				return true;
			}
		}
		return false;
	}

	/**
	 * Selectores de un preludio, partidos por las comas de primer nivel (fuera de comentarios, cadenas, escapes, paréntesis
	 * y corchetes): cada uno, tal cual y en su versión para buscar anclas, con los comentarios en blanco y el interior de las
	 * cadenas tapado (una clase dentro de `[data-x=".clase"]` no ancla). Unidos con comas, devuelven el preludio exacto.
	 *
	 * @return array<int, array{0: string, 1: string}>
	 */
	private static function selector_parts( string $prelude ): array {
		$mask = $prelude;
		$len  = strlen( $prelude );
		for ( $i = 0; $i < $len; $i++ ) {
			$c = $prelude[ $i ];
			if ( '\\' === $c ) {
				$mask[ $i ] = 'x';
				if ( $i + 1 < $len ) {
					$mask[ ++$i ] = 'x';
				}
			} elseif ( '/' === $c && '*' === ( $prelude[ $i + 1 ] ?? '' ) ) {
				$end = strpos( $prelude, '*/', $i + 2 );
				$end = false === $end ? $len : $end + 2;
				for ( ; $i < $end; $i++ ) {
					$mask[ $i ] = ' ';
				}
				--$i;
			} elseif ( '"' === $c || "'" === $c ) {
				$end = self::css_string_end( $prelude, $i );
				for ( ++$i; $i < $end && $i < $len; $i++ ) {
					$mask[ $i ] = 'x';
				}
			}
		}
		$parts = array();
		$depth = 0;
		$start = 0;
		for ( $i = 0; $i < $len; $i++ ) {
			$c = $mask[ $i ];
			if ( '(' === $c || '[' === $c ) {
				++$depth;
			} elseif ( ( ')' === $c || ']' === $c ) && $depth > 0 ) {
				--$depth;
			} elseif ( ',' === $c && 0 === $depth ) {
				$parts[] = array( substr( $prelude, $start, $i - $start ), substr( $mask, $start, $i - $start ) );
				$start   = $i + 1;
			}
		}
		$parts[] = array( substr( $prelude, $start ), substr( $mask, $start ) );
		return $parts;
	}

	/** Posición del siguiente `$char` fuera de comentarios y cadenas, desde `$from` y antes de `$until`, o null. */
	private static function css_find( string $css, int $from, string $char, ?int $until = null ): ?int {
		$len = null === $until ? strlen( $css ) : $until;
		for ( $i = $from; $i < $len; $i++ ) {
			$c = $css[ $i ];
			if ( '/' === $c && '*' === ( $css[ $i + 1 ] ?? '' ) ) {
				$end = strpos( $css, '*/', $i + 2 );
				if ( false === $end ) {
					return null;
				}
				$i = $end + 1;
			} elseif ( '"' === $c || "'" === $c ) {
				$i = self::css_string_end( $css, $i );
			} elseif ( $char === $c ) {
				return $i;
			}
		}
		return null;
	}

	/** Posición de la `}` que cierra la `{` de `$open`, o null si el CSS no la cierra. */
	private static function css_close( string $css, int $open ): ?int {
		$depth = 0;
		$len   = strlen( $css );
		for ( $i = $open; $i < $len; $i++ ) {
			$c = $css[ $i ];
			if ( '/' === $c && '*' === ( $css[ $i + 1 ] ?? '' ) ) {
				$end = strpos( $css, '*/', $i + 2 );
				if ( false === $end ) {
					return null;
				}
				$i = $end + 1;
			} elseif ( '"' === $c || "'" === $c ) {
				$i = self::css_string_end( $css, $i );
			} elseif ( '{' === $c ) {
				++$depth;
			} elseif ( '}' === $c && 0 === --$depth ) {
				return $i;
			}
		}
		return null;
	}

	/** Fin de la cadena que empieza en `$start` (con sus escapes). */
	private static function css_string_end( string $css, int $start ): int {
		$quote = $css[ $start ];
		$len   = strlen( $css );
		for ( $i = $start + 1; $i < $len; $i++ ) {
			if ( '\\' === $css[ $i ] ) {
				++$i;
			} elseif ( $quote === $css[ $i ] ) {
				return $i;
			}
		}
		return $len;
	}

	private static function code( string $code, string $key, string $reason, string $section ): array {
		return array( 'code' => $code, 'key' => $key, 'reason' => $reason, 'section' => $section );
	}
}
