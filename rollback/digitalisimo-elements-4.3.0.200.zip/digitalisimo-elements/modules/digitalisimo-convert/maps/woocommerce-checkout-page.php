<?php
/**
 * Checkout de PRO → Finalizar compra (`digitalisimo-woo-checkout`, modules/digitalisimo-woo/store/class-checkout.php).
 *
 * El widget propio repite todos los controles del de PRO (también los que sólo existen con el recordatorio de acceso, el
 * envío, los cupones o el alta desde el pago activos, y los campos de los tres repetidores) con el mismo nombre, valores
 * por defecto, opciones y condiciones, así que el mapa es `keep`, `groups` y `repeaters`. Los textos por defecto que PRO
 * pintaba sin guardarlos (títulos de sección, términos, cupón, acceso, alta y las filas de los repetidores) se completan
 * con los de PRO, para que lo convertido diga lo mismo. Formato: cabecera de `class-translator.php`.
 */
defined( 'ABSPATH' ) || exit;

$digi_co_t = static function ( $text ) {
	return function_exists( 'esc_html__' ) ? esc_html__( $text, 'elementor-pro' ) : $text; // phpcs:ignore WordPress.WP.I18n -- mismo texto que PRO.
};
$digi_co_row = static function ( $key, $label, $state ) use ( $digi_co_t ) {
	$label = $digi_co_t( $label );
	return array( 'field_key' => $key, 'field_label' => $label, 'label' => $label, 'placeholder' => $label, 'repeater_state' => $state );
};
$digi_co_billing_title = function_exists( 'wc_ship_to_billing_address_only' ) && wc_ship_to_billing_address_only() ? 'Billing and Shipping Details' : 'Billing Details';
$digi_co_address = array(
	'first_name' => array( 'First Name', '' ),
	'last_name'  => array( 'Last Name', '' ),
	'company'    => array( 'Company Name', '' ),
	'country'    => array( 'Country / Region', 'locale' ),
	'address_1'  => array( 'Street Address', 'locale' ),
	'postcode'   => array( 'Post Code', 'locale' ),
	'city'       => array( 'Town / City', 'locale' ),
	'state'      => array( 'State', 'locale' ),
);
$digi_co_billing  = array();
$digi_co_shipping = array();
foreach ( $digi_co_address as $digi_co_key => $digi_co_field ) {
	$digi_co_billing[]  = $digi_co_row( 'billing_' . $digi_co_key, $digi_co_field[0], $digi_co_field[1] );
	$digi_co_shipping[] = $digi_co_row( 'shipping_' . $digi_co_key, $digi_co_field[0], $digi_co_field[1] );
}
$digi_co_billing[] = $digi_co_row( 'billing_phone', 'Phone', '' );
$digi_co_billing[] = $digi_co_row( 'billing_email', 'Email Address', '' );
// Textos por defecto de PRO, sólo de los controles que existen en este sitio (los mismos interruptores de WooCommerce que
// deciden qué controles registran los dos widgets).
$digi_co_option     = static function ( $name ) {
	return function_exists( 'get_option' ) ? get_option( $name ) : false;
};
$digi_co_billing_only = function_exists( 'wc_ship_to_billing_address_only' ) && wc_ship_to_billing_address_only();
$digi_co_defaults   = array(
	'billing_details_section_title' => $digi_co_t( $digi_co_billing_title ),
	'order_summary_section_title'   => $digi_co_t( 'Your Order' ),
	'terms_conditions_message_text' => $digi_co_t( 'I have read and agree to the website' ),
	'terms_conditions_link_text'    => $digi_co_t( 'terms and conditions' ),
);
if ( $digi_co_billing_only ) {
	$digi_co_defaults['additional_information_section_title'] = $digi_co_t( 'Additional Information' );
} elseif ( class_exists( 'WC_Shipping_Zones' ) && count( \WC_Shipping_Zones::get_zones() ) > 0 ) {
	$digi_co_defaults['shipping_details_section_title'] = $digi_co_t( 'Ship to a different address?' );
}
if ( 'yes' === $digi_co_option( 'woocommerce_enable_checkout_login_reminder' ) ) {
	$digi_co_defaults['returning_customer_section_title'] = $digi_co_t( 'Returning customer?' );
	$digi_co_defaults['returning_customer_link_text']     = $digi_co_t( 'Click here to login' );
}
if ( 'yes' === $digi_co_option( 'woocommerce_enable_signup_and_login_from_checkout' ) ) {
	$digi_co_defaults['create_account_text'] = $digi_co_t( 'Create an account?' );
}
if ( function_exists( 'wc_coupons_enabled' ) && wc_coupons_enabled() ) {
	$digi_co_defaults['coupon_section_title_text']      = $digi_co_t( 'Have a coupon?' );
	$digi_co_defaults['coupon_section_title_link_text'] = $digi_co_t( 'Click here to enter your coupon code' );
}
$digi_co_fields    = array(
	'keep' => array( 'field_key', 'field_label', 'label', 'placeholder', 'default', 'repeater_state' ),
	'ui'   => array( 'locale_notice', 'from_billing_notice', 'label_placeholder_notification' ),
);

return array(
	'source'    => 'woocommerce-checkout-page',
	'target'    => 'digitalisimo-woo-checkout',
	'status'    => 'ready',
	'panel'     => 'hide',
	'defaults'  => $digi_co_defaults,
	'keep'      => array(
		'additional_information_active',
		'additional_information_alignment',
		'additional_information_border_color',
		'additional_information_border_radius',
		'additional_information_border_type',
		'additional_information_border_width',
		'additional_information_margin',
		'additional_information_padding',
		'additional_information_section_title',
		'additional_information_titles_color',
		'billing_details_alignment',
		'billing_details_border_color',
		'billing_details_border_radius',
		'billing_details_border_type',
		'billing_details_border_width',
		'billing_details_checkboxes_color',
		'billing_details_margin',
		'billing_details_padding',
		'billing_details_section_title',
		'billing_details_titles_color',
		'checkout_layout',
		'coupon_alignment',
		'coupon_border_color',
		'coupon_border_radius',
		'coupon_border_type',
		'coupon_border_width',
		'coupon_button_alignment',
		'coupon_hover_links_color',
		'coupon_margin',
		'coupon_normal_links_color',
		'coupon_padding',
		'coupon_secondary_title_color',
		'coupon_section_display',
		'coupon_section_title_link_text',
		'coupon_section_title_text',
		'create_account_text',
		'customize_additional_information_background_color',
		'customize_billing_details_background_color',
		'customize_coupon_background_color',
		'customize_order_summary_background_color',
		'customize_payment_background_color',
		'customize_returning_customer_background_color',
		'customize_shipping_address_background_color',
		'forms_buttons_border_color',
		'forms_buttons_border_radius',
		'forms_buttons_border_type',
		'forms_buttons_border_width',
		'forms_buttons_hover_animation',
		'forms_buttons_hover_border_color',
		'forms_buttons_hover_text_color',
		'forms_buttons_hover_transition_duration',
		'forms_buttons_normal_text_color',
		'forms_buttons_padding',
		'forms_columns_gap',
		'forms_fields_border_radius',
		'forms_fields_focus_border_color',
		'forms_fields_focus_color',
		'forms_fields_focus_transition_duration',
		'forms_fields_normal_color',
		'forms_fields_padding',
		'forms_label_color',
		'forms_label_spacing',
		'forms_rows_gap',
		'links_hover_color',
		'links_normal_color',
		'login_button_alignment',
		'order_summary_alignment',
		'order_summary_border_color',
		'order_summary_border_radius',
		'order_summary_border_type',
		'order_summary_border_width',
		'order_summary_descriptions_color',
		'order_summary_items_color',
		'order_summary_items_divider_color',
		'order_summary_items_divider_weight',
		'order_summary_margin',
		'order_summary_padding',
		'order_summary_radios_color',
		'order_summary_rows_gap',
		'order_summary_section_title',
		'order_summary_titles_color',
		'order_summary_totals_color',
		'order_summary_totals_divider_color',
		'order_summary_totals_divider_weight',
		'order_summary_variations_color',
		'payment_border_color',
		'payment_border_radius',
		'payment_border_type',
		'payment_border_width',
		'payment_checkboxes_color',
		'payment_description_color',
		'payment_hover_color',
		'payment_margin',
		'payment_messages_color',
		'payment_normal_color',
		'payment_padding',
		'payment_radio_color',
		'purchase_button_alignment',
		'purchase_button_border_radius',
		'purchase_button_hover_animation',
		'purchase_button_hover_border_color',
		'purchase_button_hover_text_color',
		'purchase_button_hover_transition_duration',
		'purchase_button_normal_text_color',
		'purchase_button_padding',
		'returning_customer_link_text',
		'returning_customer_section_title',
		'returning_customer_title_alignment',
		'returning_customers_border_color',
		'returning_customers_border_radius',
		'returning_customers_border_type',
		'returning_customers_border_width',
		'returning_customers_checkboxes_color',
		'returning_customers_description_color',
		'returning_customers_hover_links_color',
		'returning_customers_margin',
		'returning_customers_normal_links_color',
		'returning_customers_padding',
		'returning_customers_secondary_title_color',
		'section_checkout_show_customize_elements',
		'sections_background_color',
		'sections_border_color',
		'sections_border_radius',
		'sections_border_type',
		'sections_border_width',
		'sections_checkboxes_color',
		'sections_descriptions_color',
		'sections_descriptions_spacing',
		'sections_margin',
		'sections_messages_color',
		'sections_padding',
		'sections_radio_buttons_color',
		'sections_secondary_title_color',
		'sections_secondary_title_spacing',
		'sections_title_color',
		'sections_title_spacing',
		'shipping_address_border_color',
		'shipping_address_border_radius',
		'shipping_address_border_type',
		'shipping_address_border_width',
		'shipping_address_checkboxes_color',
		'shipping_address_margin',
		'shipping_address_padding',
		'shipping_details_section_title',
		'sticky_right_column',
		'sticky_right_column_offset',
		'terms_conditions_link_text',
		'terms_conditions_message_text',
	),
	'groups'    => array(
		'additional_information_section_normal_box_shadow' => 'additional_information_section_normal_box_shadow',
		'additional_information_titles_text_shadow' => 'additional_information_titles_text_shadow',
		'additional_information_titles_typography' => 'additional_information_titles_typography',
		'billing_details_checkboxes_typography' => 'billing_details_checkboxes_typography',
		'billing_details_section_normal_box_shadow' => 'billing_details_section_normal_box_shadow',
		'billing_details_titles_text_shadow' => 'billing_details_titles_text_shadow',
		'billing_details_titles_typography' => 'billing_details_titles_typography',
		'coupon_content_typography' => 'coupon_content_typography',
		'coupon_section_normal_box_shadow' => 'coupon_section_normal_box_shadow',
		'forms_button_text_shadow' => 'forms_button_text_shadow',
		'forms_button_typography' => 'forms_button_typography',
		'forms_buttons_focus_box_shadow' => 'forms_buttons_focus_box_shadow',
		'forms_buttons_hover_background' => 'forms_buttons_hover_background',
		'forms_buttons_normal_background' => 'forms_buttons_normal_background',
		'forms_buttons_normal_box_shadow' => 'forms_buttons_normal_box_shadow',
		'forms_field_typography' => 'forms_field_typography',
		'forms_fields_border' => 'forms_fields_border',
		'forms_fields_focus_background' => 'forms_fields_focus_background',
		'forms_fields_focus_box_shadow' => 'forms_fields_focus_box_shadow',
		'forms_fields_normal_background' => 'forms_fields_normal_background',
		'forms_fields_normal_box_shadow' => 'forms_fields_normal_box_shadow',
		'forms_label_typography' => 'forms_label_typography',
		'order_summary_descriptions_typography' => 'order_summary_descriptions_typography',
		'order_summary_items_typography' => 'order_summary_items_typography',
		'order_summary_radio_typography' => 'order_summary_radio_typography',
		'order_summary_section_normal_box_shadow' => 'order_summary_section_normal_box_shadow',
		'order_summary_titles_text_shadow' => 'order_summary_titles_text_shadow',
		'order_summary_titles_typography' => 'order_summary_titles_typography',
		'order_summary_totals_typography' => 'order_summary_totals_typography',
		'order_summary_variations_typography' => 'order_summary_variations_typography',
		'payment_checkboxes_typography' => 'payment_checkboxes_typography',
		'payment_description_typography' => 'payment_description_typography',
		'payment_info_box_title_background' => 'payment_info_box_title_background',
		'payment_messages_typography' => 'payment_messages_typography',
		'payment_radio_typography' => 'payment_radio_typography',
		'payment_section_normal_box_shadow' => 'payment_section_normal_box_shadow',
		'purchase_button_border' => 'purchase_button_border',
		'purchase_button_hover_background' => 'purchase_button_hover_background',
		'purchase_button_hover_box_shadow' => 'purchase_button_hover_box_shadow',
		'purchase_button_normal_background' => 'purchase_button_normal_background',
		'purchase_button_normal_box_shadow' => 'purchase_button_normal_box_shadow',
		'purchase_button_text_shadow' => 'purchase_button_text_shadow',
		'purchase_button_typography' => 'purchase_button_typography',
		'returning_customers_checkboxes_typography' => 'returning_customers_checkboxes_typography',
		'returning_customers_content_typography' => 'returning_customers_content_typography',
		'returning_customers_description_typography' => 'returning_customers_description_typography',
		'returning_customers_section_normal_box_shadow' => 'returning_customers_section_normal_box_shadow',
		'section_normal_box_shadow' => 'section_normal_box_shadow',
		'sections_checkboxes_typography' => 'sections_checkboxes_typography',
		'sections_descriptions_typography' => 'sections_descriptions_typography',
		'sections_messages_typography' => 'sections_messages_typography',
		'sections_radio_buttons_typography' => 'sections_radio_buttons_typography',
		'sections_secondary_titles_typography' => 'sections_secondary_titles_typography',
		'sections_titles_text_shadow' => 'sections_titles_text_shadow',
		'sections_titles_typography' => 'sections_titles_typography',
		'shipping_address_checkboxes_typography' => 'shipping_address_checkboxes_typography',
		'shipping_address_section_normal_box_shadow' => 'shipping_address_section_normal_box_shadow',
	),
	// Controles sin valor (encabezados y avisos del panel). Los avisos de los repetidores de campos van también aquí:
	// `tests/elements-convert.php` no lee el `ui` de los repetidores.
	'ui'        => array(
		'locale_notice',
		'from_billing_notice',
		'label_placeholder_notification',
		'additional_information_titles_title',
		'billing_details_checkboxes_title',
		'billing_details_titles_title',
		'coupon_button_alignment_note',
		'coupon_button_title',
		'coupon_link_title',
		'coupon_secondary_title',
		'customize_additional_information_section_title',
		'customize_billing_details_section_title',
		'customize_coupon_section_title',
		'customize_order_summary_section_title',
		'customize_payment_section_title',
		'forms_button_title',
		'forms_field_title',
		'forms_label_title',
		'login_button_alignment_note',
		'login_button_title',
		'order_summary_descriptions_title',
		'order_summary_dividers_total_title',
		'order_summary_items_divider_title',
		'order_summary_items_title',
		'order_summary_radios_title',
		'order_summary_titles_title',
		'order_summary_totals_title',
		'order_summary_variations_title',
		'payment_checkboxes_title',
		'payment_description_title',
		'payment_info_box_title',
		'payment_links_title',
		'payment_messages_title',
		'payment_radio_title',
		'purchase_buttom_heading',
		'returning_customers_checkboxes_title',
		'returning_customers_description_title',
		'returning_customers_link_title',
		'returning_customers_secondary_title',
		'returning_customers_section_title',
		'sections_checkboxes_title',
		'sections_descriptions_title',
		'sections_links_title',
		'sections_messages_title',
		'sections_radio_buttons_title',
		'sections_secondary_typography',
		'sections_typography',
		'shipping_address_checkboxes_title',
		'shipping_address_section_title',
		'terms_conditions_heading',
	),
	'approx'    => array(
		'returning_customer_section_title' => 'PRO ofrecía el título de «¿Ya eres cliente?», pero pintaba siempre su texto por defecto: lo convertido pinta ese texto, como PRO. Para usar el texto que tenía guardado, escríbelo otra vez en el control.',
		'returning_customer_link_text'     => 'PRO ofrecía el texto del enlace de acceso, pero pintaba siempre el suyo por defecto: lo convertido pinta ese texto, como PRO. Para usar el texto que tenía guardado, escríbelo otra vez en el control.',
		'coupon_section_title_text'        => 'PRO ofrecía el título de «¿Tienes un cupón?», pero pintaba siempre su texto por defecto: lo convertido pinta ese texto, como PRO. Para usar el texto que tenía guardado, escríbelo otra vez en el control.',
		'coupon_section_title_link_text'   => 'PRO ofrecía el texto del enlace del cupón, pero pintaba siempre el suyo por defecto: lo convertido pinta ese texto, como PRO. Para usar el texto que tenía guardado, escríbelo otra vez en el control.',
	),
	// PRO pintaba estos cuatro textos con su propio dominio y su filtro de textos sólo miraba otros, así que lo guardado
	// (también un valor dinámico) nunca se veía: lo convertido lleva el texto que PRO pintaba. `approx` lo informa.
	'filter'    => static function ( array $out ) use ( $digi_co_t ) {
		$texts = array(
			'returning_customer_section_title' => 'Returning customer?',
			'returning_customer_link_text'     => 'Click here to login',
			'coupon_section_title_text'        => 'Have a coupon?',
			'coupon_section_title_link_text'   => 'Click here to enter your coupon code',
		);
		foreach ( $texts as $key => $text ) {
			if ( array_key_exists( $key, $out ) ) {
				$out[ $key ] = $digi_co_t( $text );
			}
			unset( $out['__dynamic__'][ $key ] );
		}
		if ( isset( $out['__dynamic__'] ) && array() === $out['__dynamic__'] ) {
			unset( $out['__dynamic__'] );
		}
		return $out;
	},
	'repeaters' => array(
		'billing_details_form_fields'        => array( 'target' => 'billing_details_form_fields', 'default_rows' => $digi_co_billing ) + $digi_co_fields,
		'shipping_details_form_fields'       => array( 'target' => 'shipping_details_form_fields', 'default_rows' => $digi_co_shipping ) + $digi_co_fields,
		'additional_information_form_fields' => array(
			'target'       => 'additional_information_form_fields',
			'default_rows' => array(
				array(
					'field_key'   => 'order_comments',
					'field_label' => $digi_co_t( 'Order Notes' ),
					'label'       => $digi_co_t( 'Order Notes' ),
					'placeholder' => $digi_co_t( 'Notes about your order, e.g. special notes for delivery.' ),
				),
			),
		) + $digi_co_fields,
	),
	'classes'   => array(
		'.elementor-widget-woocommerce-checkout-page' => '.elementor-widget-digitalisimo-woo-checkout',
		'.e-checkout__order_review-2'          => '.digi-co__review-2',
		'.e-checkout__order_review'            => '.digi-co__review',
		'.e-checkout__container'               => '.digi-co__container',
		'.e-checkout__column-start'            => '.digi-co__col--start',
		'.e-checkout__column-end'              => '.digi-co__col--end',
		'.e-checkout__column-inner'            => '.digi-co__col-inner',
		'.e-checkout__column'                  => '.digi-co__col',
		'.e-sticky-right-column--active'       => '.digi-co__sticky--active',
		'.e-sticky-right-column'               => '.digi-co__sticky',
		'.e-checkout-layout-one-column'        => '.digi-checkout-layout-one-column',
		'.e-checkout-layout-two-column'        => '.digi-checkout-layout-two-column',
		'.e-checkout-secondary-title'          => '.digi-co__secondary',
		'.e-checkout-message'                  => '.digi-co__message',
		'.e-woocommerce-login-section'         => '.digi-co__login',
		'.e-woocommerce-login-anchor'          => '.digi-co__login-form',
		'.e-woocommerce-login-nudge'           => '.digi-co__login-nudge',
		'.e-woocommerce-coupon-nudge'          => '.digi-co__coupon-nudge',
		'.e-woocommerce-form-login-submit'     => '.digi-co__login-submit',
		'.elementor-woocommerce-login-messages' => '.digi-co__login-messages',
		'.elementor-woocomemrce-login-rememberme' => '.digi-co__remember',
		'.e-login-actions-wrap-start'          => '.digi-co__login-actions-start',
		'.e-login-actions-wrap-end'            => '.digi-co__login-actions-end',
		'.e-login-actions-wrap'                => '.digi-co__login-actions',
		'.e-login-wrap-start'                  => '.digi-co__login-wrap-start',
		'.e-login-wrap-end'                    => '.digi-co__login-wrap-end',
		'.e-login-wrap'                        => '.digi-co__login-wrap',
		'.e-login-label'                       => '.digi-co__login-label',
		'.e-coupon-anchor-description'         => '.digi-co__coupon-desc',
		'.e-coupon-anchor'                     => '.digi-co__coupon-form',
		'.e-coupon-box'                        => '.digi-co__coupon',
		'.e-show-coupon-form'                  => '.digi-co__show-coupon',
		'.e-show-login'                        => '.digi-co__show-login',
		'.e-apply-coupon'                      => '.digi-co__apply',
		'.e-description'                       => '.digi-co__desc',
		'.e-woo-select2-wrapper'               => '.digi-co-select2',
	),
);
