<?php
/**
 * Controles de estilo de Element Pack Pro 9.9.1 `bdt-forminator-forms` con selectores del widget propio.
 * Generado con scripts/legacy-styles.py; no editar a mano.
 */
defined( 'ABSPATH' ) || exit;

return array();
