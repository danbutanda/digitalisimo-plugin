<?php
namespace Digitalisimo\Tools;
defined( 'ABSPATH' ) || exit;

final class Plugin {
	public static function activate( $network_wide = false ) {
		if ( is_multisite() ) add_site_option( 'digitalisimo_tools_settings', array( 'master_blog_id' => get_main_site_id(), 'log_limit' => 200 ) );
	}
	public static function boot() { Updater::init(); Site_Options::init(); Media_WebP::init(); Php_Snippets\Admin::init(); Elementor_Network_Templates\Module::init(); }
}
