<?php
defined( 'ABSPATH' ) || exit;

/**
 * Actualizador compartido de los módulos Digitalisimo.
 *
 * Se declara una sola vez aunque haya varios módulos activos: cada uno se
 * registra con su archivo principal, su versión y el prefijo del ZIP publicado
 * como asset en las Releases del repositorio.
 *
 * Además de anunciar la versión disponible, habilita la actualización
 * automática de WordPress para los módulos registrados, de modo que se
 * instalen solos sin intervención manual, y añade un enlace «Buscar
 * actualizaciones» que invalida la caché para no tener que esperarla.
 */
if ( ! class_exists( 'Digitalisimo_Updater' ) ) {
	final class Digitalisimo_Updater {
		const REPOSITORY = 'danbutanda/digitalisimo-plugin';
		const CACHE_KEY  = 'digitalisimo_releases_index';
		// El índice se vuelve a leer cada diez minutos: es un archivo de la Release, no una consulta a la API.
		const CACHE_TTL  = 10 * MINUTE_IN_SECONDS;
		const ACTION     = 'digitalisimo_check_updates';
		/**
		 * Índice de versiones adjunto a cada Release (el ZIP vigente de los siete plugins). Se descarga como un archivo
		 * de la última Release, no por la API de GitHub, que limita a 60 consultas por hora a cada servidor sin
		 * autenticar y que agotan entre todos los plugins Digitalisimo.
		 */
		const MANIFEST_URL = 'https://github.com/danbutanda/digitalisimo-plugin/releases/latest/download/digitalisimo-plugins.json';
		/** Caché compartida del índice: un solo archivo sirve a todos los plugins que lo lean. */
		const MANIFEST_CACHE = 'digitalisimo_plugins_manifest';
		/** Último índice encontrado: si GitHub no responde, las actualizaciones siguen a la vista en lugar de desaparecer. */
		const LAST_KNOWN = 'digitalisimo_releases_last_known';

		/** Módulos registrados, indexados por su archivo principal relativo. */
		private static $modules = array();
		private static $hooked  = false;
		private static $script_file;

		/**
		 * Registra un módulo para su actualización automática.
		 *
		 * @param string $file    Ruta absoluta del archivo principal del plugin.
		 * @param string $version Versión instalada.
		 * @param string $slug    Identificador del módulo y prefijo del ZIP.
		 */
		public static function register( $file, $version, $slug ) {
			$basename = plugin_basename( $file );
			self::$modules[ $basename ] = array( 'version' => $version, 'slug' => $slug );
			$tools_file = WP_PLUGIN_DIR . '/digitalisimo-tools/digitalisimo-tools.php'; if ( file_exists( $tools_file ) ) { $header = get_file_data( $tools_file, array( 'Version' => 'Version' ) ); if ( ! empty( $header['Version'] ) ) self::$modules['digitalisimo-tools/digitalisimo-tools.php'] = array( 'version' => $header['Version'], 'slug' => 'digitalisimo-tools' ); }
			// El enlace se registra por módulo; el resto de hooks es compartido.
			add_filter( 'plugin_action_links_' . $basename, array( __CLASS__, 'action_link' ) );
			add_filter( 'network_admin_plugin_action_links_' . $basename, array( __CLASS__, 'action_link' ) );
			if ( self::$hooked ) return;
			self::$script_file = $file;
			self::$hooked = true;
			// WordPress Multisite guarda esta información como site transient; WordPress
			// individual puede usar el transient normal. Se cubren lectura y escritura
			// para que una caché creada antes de cargar los módulos no oculte actualizaciones.
			add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
			add_filter( 'pre_set_transient_update_plugins', array( __CLASS__, 'inject' ) );
			add_filter( 'site_transient_update_plugins', array( __CLASS__, 'inject' ) );
			add_filter( 'transient_update_plugins', array( __CLASS__, 'inject' ) );
			add_filter( 'update_plugins_github.com', array( __CLASS__, 'uri_update' ), 10, 4 );
			add_filter( 'auto_update_plugin', array( __CLASS__, 'auto_update' ), 10, 2 );
			add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
			add_action( 'upgrader_process_complete', array( __CLASS__, 'clear' ), 10, 2 );
			add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'force_check' ) );
			// «Buscar actualizaciones de nuevo» de WordPress (update-core.php?force-check=1): vaciar las cachés propias antes de que WordPress vuelva a consultar.
			add_action( 'load-update-core.php', array( __CLASS__, 'native_force_check' ), 1 );
			add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
			add_action( 'network_admin_notices', array( __CLASS__, 'notice' ) );
			add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_inline_update' ) );
		}

		/** Usa la misma actualización AJAX de WordPress sin abandonar Plugins. */
		public static function enqueue_inline_update( $hook ) {
			if ( 'plugins.php' !== $hook || ! self::can_update() ) return;
			wp_enqueue_script( 'digitalisimo-inline-plugin-update', plugins_url( 'assets/js/update-in-place.js', self::$script_file ), array( 'updates' ), self::$modules[ plugin_basename( self::$script_file ) ]['version'], true );
			foreach ( array_keys( self::$modules ) as $file ) {
				wp_add_inline_script( 'digitalisimo-inline-plugin-update', 'window.digitalisimoPluginUpdateFiles=window.digitalisimoPluginUpdateFiles||{};window.digitalisimoPluginUpdateFiles[' . wp_json_encode( $file ) . ']=true;', 'before' );
			}
		}

		/** Enlace «Buscar actualizaciones» en la fila del plugin. */
		public static function action_link( $links ) {
			if ( ! self::can_update() ) return $links;
			$base = admin_url( 'admin-post.php' );
			$url = wp_nonce_url( add_query_arg( array( 'action' => self::ACTION, 'digitalisimo_context' => is_network_admin() ? 'network' : 'site' ), $base ), self::ACTION );
			$links[] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Buscar actualizaciones', 'digitalisimo' ) . '</a>';
			return $links;
		}

		/** En red, la actualización de plugins depende de la capacidad de red. */
		private static function can_update() {
			return is_multisite() ? current_user_can( 'manage_network_plugins' ) : current_user_can( 'update_plugins' );
		}

		/**
		 * Comprobación manual: sin esto habría que esperar a que expire la caché,
		 * porque «Volver a comprobar» de WordPress no la invalida.
		 */
		/** El botón nativo de WordPress consulta de inmediato: se olvidan la versión conocida y el índice compartido. */
		public static function native_force_check() {
			if ( empty( $_GET['force-check'] ) ) return; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- sólo vacía cachés propias.
			delete_site_transient( self::CACHE_KEY );
			delete_transient( self::CACHE_KEY );
			delete_site_transient( self::MANIFEST_CACHE );
		}
		public static function force_check() {
			if ( ! self::can_update() ) wp_die( esc_html__( 'No autorizado.', 'digitalisimo' ) );
			check_admin_referer( self::ACTION );
			delete_site_transient( self::CACHE_KEY );
			delete_transient( self::CACHE_KEY );
			delete_site_transient( self::MANIFEST_CACHE );
			$updates = get_site_transient( 'update_plugins' );
			if ( is_object( $updates ) && isset( $updates->checked ) && is_array( $updates->checked ) ) set_site_transient( 'update_plugins', self::inject( $updates ) );
			else wp_update_plugins();
			$back = wp_get_referer();
			$default = is_multisite() && 'network' === sanitize_key( wp_unslash( $_GET['digitalisimo_context'] ?? '' ) ) ? network_admin_url( 'plugins.php' ) : admin_url( 'plugins.php' );
			wp_safe_redirect( add_query_arg( 'digitalisimo-checked', '1', $back ? $back : $default ) );
			exit;
		}

		/** Resultado de la comprobación manual. */
		public static function notice() {
			if ( empty( $_GET['digitalisimo-checked'] ) || ! self::can_update() ) return;
			$pending = array();
			foreach ( self::$modules as $file => $module ) {
				$release = self::pending( $file );
				if ( $release ) $pending[] = $module['slug'] . ' ' . $release['version'];
			}
			$message = $pending
				? sprintf( __( 'Digitalisimo: actualizaciones disponibles · %s', 'digitalisimo' ), implode( ', ', $pending ) )
				: __( 'Digitalisimo está al día: no hay versiones nuevas publicadas.', 'digitalisimo' );
			echo '<div class="notice notice-' . ( $pending ? 'warning' : 'success' ) . ' is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
		}

		/** Índice de versiones publicadas, por slug de módulo. */
		private static function releases() {
			$cached = get_site_transient( self::CACHE_KEY );
			if ( false !== $cached ) return (array) $cached;
			$index = self::from_manifest();
			// Cada módulo registrado con entrada válida en el índice la usa; sólo si alguno queda sin entrada se completa con la API, de respaldo.
			foreach ( self::$modules as $module ) { if ( empty( $index[ $module['slug'] ] ) ) { $index += self::from_api(); break; } }
			if ( $index ) {
				update_site_option( self::LAST_KNOWN, $index );
				set_site_transient( self::CACHE_KEY, $index, self::CACHE_TTL );
				return $index;
			}
			// GitHub no respondió o limitó las consultas: se conserva el último índice encontrado y se reintenta pronto,
			// para que una actualización ya anunciada no desaparezca de la lista de Plugins.
			$known = get_site_option( self::LAST_KNOWN, array() );
			$known = is_array( $known ) ? $known : array();
			set_site_transient( self::CACHE_KEY, $known, 2 * MINUTE_IN_SECONDS );
			return $known;
		}

		/**
		 * Índice de la última Release: versión y ZIP de cada plugin sin pasar por la API de GitHub. Sólo se acepta una
		 * entrada cuyo ZIP sea del plugin nombrado y de este repositorio; una entrada rechazada o ausente no invalida
		 * las demás, y releases() completa por la API sólo los módulos registrados que queden sin entrada.
		 */
		private static function from_manifest() {
			$manifest = get_site_transient( self::MANIFEST_CACHE );
			if ( ! is_array( $manifest ) ) {
				$response = wp_remote_get( self::MANIFEST_URL, array( 'timeout' => 10, 'redirection' => 5, 'headers' => array( 'Accept' => 'application/json', 'User-Agent' => 'Digitalisimo-WordPress-Updater' ) ) );
				if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) return array();
				$manifest = json_decode( wp_remote_retrieve_body( $response ), true );
				if ( ! is_array( $manifest ) || empty( $manifest['plugins'] ) || ! is_array( $manifest['plugins'] ) ) return array();
				set_site_transient( self::MANIFEST_CACHE, $manifest, 10 * MINUTE_IN_SECONDS );
			}
			$release_url = (string) ( $manifest['release_url'] ?? '' );
			if ( 0 !== strpos( $release_url, 'https://github.com/' . self::REPOSITORY . '/releases' ) ) $release_url = 'https://github.com/' . self::REPOSITORY . '/releases';
			$index = array();
			foreach ( (array) ( $manifest['plugins'] ?? array() ) as $slug => $entry ) {
				$version = is_array( $entry ) ? (string) ( $entry['version'] ?? '' ) : '';
				$package = is_array( $entry ) ? (string) ( $entry['url'] ?? '' ) : '';
				if ( ! preg_match( '/^digitalisimo-[a-z]+(?:-[a-z]+)*$/', (string) $slug ) || ! preg_match( '/^\d+(?:\.\d+)+$/', $version ) ) continue;
				if ( ! preg_match( '#^https://github\.com/' . preg_quote( self::REPOSITORY, '#' ) . '/releases/download/[A-Za-z0-9._-]+/' . $slug . '-' . preg_quote( $version, '#' ) . '\.zip$#', $package ) ) continue;
				$index[ $slug ] = array( 'version' => $version, 'package' => esc_url_raw( $package ), 'url' => esc_url_raw( $release_url ), 'notes' => '' );
			}
			return $index;
		}

		/** Respaldo por la API de GitHub (sujeta a su límite de consultas): el asset más reciente de cada plugin. */
		private static function from_api() {
			$response = wp_remote_get(
				'https://api.github.com/repos/' . self::REPOSITORY . '/releases?per_page=50',
				array( 'timeout' => 10, 'headers' => array( 'Accept' => 'application/vnd.github+json', 'User-Agent' => 'Digitalisimo-WordPress-Updater' ) )
			);
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) return array();
			$index = array();
			foreach ( (array) json_decode( wp_remote_retrieve_body( $response ), true ) as $release ) {
				if ( ! empty( $release['draft'] ) || ! empty( $release['prerelease'] ) ) continue;
				foreach ( (array) ( $release['assets'] ?? array() ) as $asset ) {
					if ( ! preg_match( '/^(digitalisimo-[a-z]+(?:-[a-z]+)*)-([0-9][0-9.]*)\.zip$/', (string) ( $asset['name'] ?? '' ), $match ) ) continue;
					$slug = $match[1];
					if ( isset( $index[ $slug ]['version'] ) && ! version_compare( $match[2], $index[ $slug ]['version'], '>' ) ) continue;
					$index[ $slug ] = array(
						'version'  => $match[2],
						'package'  => esc_url_raw( $asset['browser_download_url'] ?? '' ),
						'url'      => esc_url_raw( $release['html_url'] ?? 'https://github.com/' . self::REPOSITORY . '/releases' ),
						'notes'    => wp_kses_post( $release['body'] ?? '' ),
					);
				}
			}
			return $index;
		}

		/** Versión publicada que supera a la instalada, o array vacío. */
		private static function pending( $file ) {
			$module = self::$modules[ $file ] ?? array();
			if ( ! $module ) return array();
			$release = self::releases()[ $module['slug'] ] ?? array();
			if ( empty( $release['version'] ) || empty( $release['package'] ) ) return array();
			return version_compare( $release['version'], $module['version'], '>' ) ? $release : array();
		}

		public static function uri_update( $update, $plugin_data, $plugin_file, $locales ) {
			if ( ! isset( self::$modules[ $plugin_file ] ) ) return $update;
			$module = self::$modules[ $plugin_file ];
			$release = self::pending( $plugin_file );
			if ( ! $release ) return false;
			return array(
				'slug' => $module['slug'],
				'version' => $release['version'],
				'package' => $release['package'],
				'url' => $release['url'],
				'requires_php' => '7.4',
			);
		}

		public static function inject( $transient ) {
			// WordPress debe construir primero el inventario completo de plugins.
			if ( ! is_object( $transient ) || ! isset( $transient->checked ) || ! is_array( $transient->checked ) ) return $transient;
			if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) $transient->response = array();
			if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) $transient->no_update = array();
			foreach ( self::$modules as $file => $module ) {
				if ( ! isset( $transient->checked[ $file ] ) ) $transient->checked[ $file ] = $module['version'];
				$release = self::pending( $file );
				if ( ! $release ) {
					unset( $transient->response[ $file ] );
					$transient->no_update[ $file ] = self::update_item( $file, $module, array( 'version' => $module['version'] ) );
					continue;
				}
				unset( $transient->no_update[ $file ] );
				$transient->response[ $file ] = self::update_item( $file, $module, $release );
			}
			return $transient;
		}

		/** Forma que WordPress espera tanto en response como en no_update. */
		private static function update_item( $file, $module, $release ) {
			return (object) array(
				'id'           => 'https://github.com/' . self::REPOSITORY,
				'slug'         => $module['slug'],
				'plugin'       => $file,
				'new_version'  => $release['version'],
				'url'          => $release['url'] ?? 'https://github.com/' . self::REPOSITORY . '/releases',
				'package'      => $release['package'] ?? '',
				'tested'       => get_bloginfo( 'version' ),
				'requires'     => '6.0',
				'requires_php' => '7.4',
			);
		}

		/**
		 * Activa la instalación automática de los módulos Digitalisimo.
		 *
		 * Puede desactivarse por sitio con el filtro digitalisimo_auto_update.
		 */
		public static function auto_update( $update, $item ) {
			$file = is_object( $item ) ? ( $item->plugin ?? '' ) : '';
			if ( ! $file || ! isset( self::$modules[ $file ] ) ) return $update;
			return apply_filters( 'digitalisimo_auto_update', true, $file );
		}

		public static function info( $result, $action, $args ) {
			if ( 'plugin_information' !== $action || empty( $args->slug ) ) return $result;
			foreach ( self::$modules as $file => $module ) {
				if ( $module['slug'] !== $args->slug ) continue;
				$release = self::releases()[ $module['slug'] ] ?? array();
				return (object) array(
					'name'          => $module['slug'],
					'slug'          => $module['slug'],
					'version'       => $release['version'] ?? $module['version'],
					'author'        => 'Digitalísimo',
					'homepage'      => 'https://digitalisimo.mx',
					'download_link' => $release['package'] ?? '',
					'requires'      => '6.0',
					'requires_php'  => '7.4',
					'sections'      => array( 'changelog' => self::changelog( $release ) ),
				);
			}
			return $result;
		}

		/**
		 * Notas de la Release sin enlaces: las líneas con una dirección (las que GitHub añade a las notas generadas)
		 * no se muestran. El índice no trae notas, y entonces la ficha sólo indica la versión publicada.
		 */
		private static function changelog( $release ) {
			$lines = preg_split( '/\r\n|\r|\n/', (string) ( $release['notes'] ?? '' ) );
			$notes = trim( implode( "\n", preg_grep( '#https?://|<a\b#i', $lines, PREG_GREP_INVERT ) ) );
			if ( '' !== $notes ) return $notes;
			if ( ! empty( $release['version'] ) ) return '<p>Versión ' . esc_html( $release['version'] ) . ' publicada.</p>';
			return 'Sin notas de versión.';
		}

		/** Limpia sólo la caché de Digitalisimo tras actualizar uno de sus módulos. */
		public static function clear( $upgrader, $options ) {
			if ( 'update' !== ( $options['action'] ?? '' ) || 'plugin' !== ( $options['type'] ?? '' ) || ! array_intersect( (array) ( $options['plugins'] ?? array() ), array_keys( self::$modules ) ) ) return;
			delete_site_transient( self::CACHE_KEY );
			delete_transient( self::CACHE_KEY );
			delete_site_transient( self::MANIFEST_CACHE );
		}
	}
}
