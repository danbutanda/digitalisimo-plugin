<?php
defined( 'ABSPATH' ) || exit;

/**
 * Casos de uso de la subida de un respaldo por fragmentos (B3), compartidos por la pantalla (AJAX), REST y WP-CLI. Las
 * sesiones viven en Digitalisimo_Backups_Uploads; aquí se decide quién sube, cuánto y si el archivo terminado puede
 * entrar en el almacén: sólo después de pasar toda la validación de archivos no confiables de «Seguridad» (la misma de
 * `verify` y de la restauración, sin las condiciones de esta instalación, que se informan en `problems`).
 *
 * Continuar o cerrar una subida es de la cuenta que la empezó (WP-CLI aparte); verla y descartarla, de cualquier
 * cuenta con la capability. En una red se sube desde el sitio principal o la administración de red, porque el almacén
 * es de toda la instalación.
 *
 * Al cerrar, sólo se descarta un archivo que no es un respaldo válido (formato, firma, contenido contra el manifiesto,
 * SQL, SHA-256 declarado). Lo que impide comprobarlo —falta de espacio para descifrarlo, una frase equivocada, un
 * error del servidor— conserva la subida con el motivo, para reintentar o descartarla a mano.
 *
 * Un respaldo de DIGITALÍSIMO que pasa la validación entra en el almacén y en la lista de respaldos, con su fila
 * «Subido» (trait Digitalisimo_Backups_Uploaded_List): se restaura escribiendo RESTAURAR, como uno hecho aquí. Si ese
 * mismo contenido ya está en la lista (mismo SHA-256 y tamaño, con su archivo en el almacén), no se guarda otra copia.
 */
trait Digitalisimo_Backups_Upload_Service {
	/**
	 * Quien anota en la sesión el paso de la comprobación en curso (Digitalisimo_Backups_Uploads::checker()), sólo mientras
	 * service_upload_finish() la comprueba: «Agregar al listado» usa la misma validación sin sesión y no anota nada.
	 */
	private static $upload_checking = null;
	/** El paso de la comprobación de una subida para el panel de avance (un texto general, sin rutas). */
	private static function upload_step( $key, $text ) {
		if ( is_callable( self::$upload_checking ) ) call_user_func( self::$upload_checking, (string) $key, (string) $text );
	}
	/**
	 * Sesión de una subida, o el error que corresponde. Con $owner, sólo la de la cuenta en curso (continuar y cerrar);
	 * sin él, cualquiera (verla y descartarla).
	 */
	private static function upload_session( $id, $owner = true ) {
		$allowed = self::service_scope( false, false );
		if ( is_wp_error( $allowed ) ) return $allowed;
		$id = (string) $id;
		if ( ! Digitalisimo_Backups_Uploads::valid_id( $id ) ) return self::service_error( 'upload_invalid', 'El identificador de la subida no es válido.', 400 );
		try {
			$state = Digitalisimo_Backups_Uploads::read( $id );
		} catch ( Exception $e ) {
			return self::service_error( 'storage', $e->getMessage(), 500 );
		}
		if ( ! $state || time() - (int) ( $state['updated_at'] ?? 0 ) > Digitalisimo_Backups_Uploads::EXPIRES_AFTER ) return self::service_error( 'upload_missing', 'La subida no existe o caducó (24 h sin actividad); vuelve a empezarla.', 404 );
		if ( $owner && ! ( defined( 'WP_CLI' ) && WP_CLI ) && (int) ( $state['user_id'] ?? 0 ) !== (int) get_current_user_id() ) return self::service_error( 'upload_owner', 'Esta subida la empezó otra cuenta: sólo esa cuenta puede continuarla (cualquiera puede descartarla).', 403 );
		return $state;
	}
	/**
	 * Empieza una subida: nombre (.zip o .dgbk), tamaño y, si el cliente lo conoce, su SHA-256. Con el cerrojo corto del
	 * almacén (dos inicios a la vez no superan los límites): tres subidas sin terminar por cuenta y diez en total, y
	 * espacio libre para lo que les falta a todas, más descifrarlas si son `.dgbk`.
	 */
	public static function service_upload_start( array $args ) {
		$allowed = self::service_scope( false, false );
		if ( is_wp_error( $allowed ) ) return $allowed;
		$raw = (string) ( $args['name'] ?? '' );
		// Un .tar.gz de Backuply conserva su nombre (sanitize_file_name() lo cambiaría y, en una red sin `tar` en
		// upload_filetypes, lo rechazaría): lista blanca propia, sin rutas. Esta subida ya pide capability y nonce.
		$name = preg_match( '/\.tar\.gz$/i', $raw ) ? Digitalisimo_Backups_Backuply_Import::upload_name( $raw ) : sanitize_file_name( $raw );
		// Una pieza de UpdraftPlus (…-db.gz, …-db.gz.crypt, …-plugins2.zip) conserva su nombre exacto: sus piezas se agrupan por él.
		if ( self::upload_is_updraft( $raw ) ) $name = $raw;
		if ( '' === $name || strlen( $name ) > 200 || ( ! preg_match( '/\.(?:zip|dgbk|tar\.gz)$/i', $name ) && ! self::upload_is_updraft( $name ) ) ) return self::service_error( 'upload_name', 'Elige un respaldo de DIGITALÍSIMO: un archivo .zip o .dgbk (o el .tar.gz de un respaldo de Backuply, o las piezas de un respaldo de UpdraftPlus, para importarlo).', 400 );
		$size = is_numeric( $args['size'] ?? null ) ? (int) $args['size'] : 0;
		if ( $size <= 0 ) return self::service_error( 'upload_size', 'El tamaño del respaldo no es válido.', 400 );
		if ( $size > Digitalisimo_Backups_Uploads::MAX_SIZE ) return self::service_error( 'upload_size', 'El respaldo supera el tamaño máximo de una subida (64 GB).', 413 );
		$sha256 = strtolower( trim( (string) ( $args['sha256'] ?? '' ) ) );
		if ( '' !== $sha256 && ! preg_match( '/^[0-9a-f]{64}$/', $sha256 ) ) return self::service_error( 'upload_checksum', 'El SHA-256 declarado no es válido: son 64 caracteres hexadecimales.', 400 );
		try {
			$storage = self::local_directory();
			return Digitalisimo_Backups_Job_Store::with_lock( function() use ( $storage, $name, $size, $sha256 ) {
				$open = array_values( array_filter( Digitalisimo_Backups_Uploads::sessions(), array( 'Digitalisimo_Backups_Uploads', 'open' ) ) );
				$user = (int) get_current_user_id();
				$mine = array_filter( $open, function( $state ) use ( $user ) { return (int) ( $state['user_id'] ?? 0 ) === $user; } );
				if ( count( $mine ) >= Digitalisimo_Backups_Uploads::MAX_SESSIONS ) return self::service_error( 'upload_limit', 'Ya tienes ' . count( $mine ) . ' subidas sin terminar: termina o descarta alguna en «Subir un respaldo» antes de empezar otra (sin actividad, caducan a las 24 h).', 409 );
				if ( count( $open ) >= Digitalisimo_Backups_Uploads::MAX_TOTAL ) return self::service_error( 'upload_limit', 'Hay ' . count( $open ) . ' subidas sin terminar en este sitio: descarta alguna en «Subir un respaldo» antes de empezar otra.', 409 );
				$pending = 0;
				foreach ( $open as $state ) $pending += Digitalisimo_Backups_Uploads::reserved( $state );
				$free = Digitalisimo_Backups_Archive_Inspector::free_space( $storage );
				$needed = $size + ( Digitalisimo_Backups_Uploads::encrypted_name( $name ) ? (int) ceil( $size * 1.05 ) : 0 ) + $pending + Digitalisimo_Backups_Security::MARGIN;
				if ( null !== $free && $free < $needed ) return self::service_error( 'upload_space', 'No hay espacio en el almacén privado para este respaldo' . ( Digitalisimo_Backups_Uploads::encrypted_name( $name ) ? ' (un .dgbk necesita además sitio para descifrarlo al comprobarlo)' : '' ) . ': se necesitan ' . Digitalisimo_Backups_Archive_Inspector::megabytes( $needed ) . ' libres y hay ' . Digitalisimo_Backups_Archive_Inspector::megabytes( $free ) . '.', 507 );
				$now = time();
				$state = Digitalisimo_Backups_Uploads::create( array( 'id' => Digitalisimo_Backups_Job_Store::new_id(), 'name' => $name, 'size' => $size, 'sha256' => $sha256, 'chunk_size' => Digitalisimo_Backups_Uploads::chunk_size(), 'user_id' => $user, 'phase' => 'uploading', 'attempts' => 0, 'created_at' => $now, 'updated_at' => $now ) );
				return Digitalisimo_Backups_Uploads::view( $state );
			} );
		} catch ( Exception $e ) {
			return self::service_error( 'storage', $e->getMessage(), 500 );
		}
	}
	/** Estado de una subida (cualquier cuenta con la capability): fase, lo recibido y, si terminó, su resultado. */
	public static function service_upload_status( $id ) {
		$state = self::upload_session( $id, false );
		return is_wp_error( $state ) ? $state : Digitalisimo_Backups_Uploads::view( $state );
	}
	/** Subidas sin terminar y las cerradas de las últimas 24 h, de todas las cuentas (para verlas y descartarlas). */
	public static function service_upload_list() {
		$allowed = self::service_scope( false, false );
		if ( is_wp_error( $allowed ) ) return $allowed;
		try {
			return array_map( array( 'Digitalisimo_Backups_Uploads', 'view' ), Digitalisimo_Backups_Uploads::sessions() );
		} catch ( Exception $e ) {
			return self::service_error( 'storage', $e->getMessage(), 500 );
		}
	}
	/**
	 * Anexa un fragmento en `offset`, que debe ser exactamente lo ya recibido (si no, 409 con lo recibido: el cliente
	 * sigue desde ahí). `$source` es `file` (el temporal de un formulario multipart, sin cargarlo en memoria) o `data`
	 * (el cuerpo de una petición REST). Nunca pasa del tamaño declarado ni del tamaño de fragmento de la sesión, ni
	 * escribe en una subida que ya se está comprobando, cerrada o descartada.
	 */
	public static function service_upload_chunk( $id, $offset, array $source ) {
		$state = self::upload_session( $id );
		if ( is_wp_error( $state ) ) return $state;
		$offset = is_numeric( $offset ) ? (int) $offset : -1;
		$lock = Digitalisimo_Backups_Uploads::lock( $state['id'] );
		if ( ! $lock ) return self::service_error( 'upload_busy', 'Otro fragmento de esta subida se está escribiendo o se está comprobando; espera y vuelve a intentarlo.', 409, array( 'received' => Digitalisimo_Backups_Uploads::received( $state['id'] ) ) );
		$input = null;
		try {
			// Con el cerrojo: si entretanto se cerró o se descartó, no se escribe nada.
			$state = Digitalisimo_Backups_Uploads::read( $state['id'] );
			if ( ! $state || 'uploading' !== Digitalisimo_Backups_Uploads::phase( $state ) ) return self::service_error( 'upload_closed', 'Esta subida ya no admite fragmentos (terminó, se descartó o se está comprobando).', 409, array( 'received' => $state ? Digitalisimo_Backups_Uploads::received( $state['id'] ) : 0 ) );
			$received = Digitalisimo_Backups_Uploads::received( $state['id'] );
			if ( $offset !== $received ) return self::service_error( 'upload_offset', 'La subida va en el byte ' . $received . ': continúa desde ahí.', 409, array( 'received' => $received ) );
			if ( isset( $source['file'] ) && is_string( $source['file'] ) && '' !== $source['file'] ) {
				clearstatcache( true, $source['file'] );
				$length = is_file( $source['file'] ) && ! is_link( $source['file'] ) ? @filesize( $source['file'] ) : false;
				$input = false === $length ? false : @fopen( $source['file'], 'rb' );
			} elseif ( isset( $source['data'] ) && is_string( $source['data'] ) ) {
				$length = strlen( $source['data'] );
				$input = @fopen( 'php://temp', 'w+b' );
				if ( $input ) { fwrite( $input, $source['data'] ); rewind( $input ); }
			} else {
				$length = false;
				$input = false;
			}
			if ( ! $input || ! $length ) return self::service_error( 'upload_chunk', 'No llegó el fragmento del respaldo.', 400 );
			if ( $length > (int) $state['chunk_size'] ) return self::service_error( 'upload_chunk_size', 'El fragmento supera el tamaño de fragmento de esta subida (' . Digitalisimo_Backups_Archive_Inspector::megabytes( (int) $state['chunk_size'] ) . ').', 413 );
			if ( $received + $length > (int) $state['size'] ) return self::service_error( 'upload_overflow', 'El fragmento pasa del tamaño declarado del respaldo.', 400, array( 'received' => $received ) );
			$path = Digitalisimo_Backups_Uploads::data_path( $state['id'] );
			if ( is_link( $path ) || ! is_file( $path ) ) return self::service_error( 'upload_missing', 'El archivo de la subida ya no está en el almacén privado; vuelve a empezarla.', 404 );
			$output = @fopen( $path, 'ab' );
			$written = $output ? stream_copy_to_stream( $input, $output, $length ) : false;
			$flushed = $output && fflush( $output );
			if ( $output ) fclose( $output );
			if ( $written !== $length || ! $flushed ) {
				// Una escritura a medias (disco lleno) no deja bytes de más: el archivo vuelve a lo que tenía.
				$handle = @fopen( $path, 'r+b' );
				if ( $handle ) { ftruncate( $handle, $received ); fclose( $handle ); }
				return self::service_error( 'upload_write', 'No se pudo escribir el fragmento en el almacén privado; revisa el espacio libre y vuelve a intentarlo.', 500, array( 'received' => $received ) );
			}
			$state['updated_at'] = time();
			unset( $state['error'] );
			Digitalisimo_Backups_Uploads::write( $state );
			return Digitalisimo_Backups_Uploads::view( $state );
		} catch ( Exception $e ) {
			return self::service_error( 'storage', $e->getMessage(), 500 );
		} finally {
			if ( is_resource( $input ) ) fclose( $input );
			Digitalisimo_Backups_Uploads::unlock( $lock );
		}
	}
	/**
	 * Cierra la subida: con todos los bytes (y el SHA-256 declarado, si lo hubo) pasa la validación de archivos no
	 * confiables dentro de su sesión y sólo entonces entra en el almacén y en la lista de respaldos («Subido»).
	 *
	 * Idempotente y a prueba de cortes: una subida ya cerrada devuelve su resultado (o su rechazo); mientras otro
	 * proceso la comprueba responde 202 `upload_validating` (el cliente consulta el estado); la comprobación sigue
	 * aunque el proxy corte la petición (ignore_user_abort). Si el proceso muere comprobándola tres veces (el tiempo
	 * límite del servidor), responde 504 y pide cerrarla con WP-CLI, que no tiene límite de tiempo; nunca obliga a subirla
	 * otra vez. Sólo se descarta un archivo que no es un respaldo válido; espacio, frase o un error del servidor la
	 * conservan con el motivo. Un `.dgbk` cifrado con una clave que este sitio no tiene se acepta tras comprobar su
	 * cabecera (se comprueba entero al restaurarlo con su frase, o ya, con `secret`). La frase nunca se guarda.
	 */
	public static function service_upload_finish( $id, array $args = array() ) {
		$state = self::upload_session( $id );
		if ( is_wp_error( $state ) ) return $state;
		$closed = self::upload_closed( $state );
		if ( $closed ) return $closed;
		$lock = Digitalisimo_Backups_Uploads::lock( $state['id'] );
		if ( ! $lock ) return self::upload_validating( $state );
		$discard = false;
		$observer = Digitalisimo_Backups_Jobs::$observer;
		try {
			$state = Digitalisimo_Backups_Uploads::read( $state['id'] );
			if ( ! $state ) return self::service_error( 'upload_missing', 'La subida ya no existe; vuelve a empezarla.', 404 );
			$closed = self::upload_closed( $state );
			if ( $closed ) return $closed;
			// El proceso murió después de mover el archivo al almacén y antes de cerrar la sesión: se termina lo que faltaba.
			$placed = self::upload_resume_placed( $state, $args );
			if ( null !== $placed ) return $placed;
			$received = Digitalisimo_Backups_Uploads::received( $state['id'] );
			if ( $received !== (int) $state['size'] ) return self::service_error( 'upload_incomplete', 'Faltan bytes: llegaron ' . $received . ' de ' . (int) $state['size'] . '.', 409, array( 'received' => $received ) );
			$cli = defined( 'WP_CLI' ) && WP_CLI;
			if ( ! $cli && 'validating' === Digitalisimo_Backups_Uploads::phase( $state ) && (int) ( $state['attempts'] ?? 0 ) >= Digitalisimo_Backups_Uploads::MAX_ATTEMPTS ) {
				return self::service_error( 'upload_timeout', 'La comprobación de esta subida se cortó ' . (int) $state['attempts'] . ' veces (el tiempo límite del servidor o del proxy). Se conserva: termínala con WP-CLI (wp digitalisimo-backups upload finish ' . $state['id'] . '), que no tiene límite de tiempo, o descártala.', 504, array( 'received' => $received ) );
			}
			$state['phase'] = 'validating';
			$state['attempts'] = (int) ( $state['attempts'] ?? 0 ) + 1;
			$state['updated_at'] = time();
			unset( $state['error'], $state['check'] );
			Digitalisimo_Backups_Uploads::write( $state );
			// La comprobación sigue aunque el proxy corte la petición: el cliente consulta el estado y no vuelve a subirla.
			if ( function_exists( 'ignore_user_abort' ) ) ignore_user_abort( true );
			if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 0 );
			// El panel de avance consulta el estado mientras tanto: el paso en curso y, dentro de él, lo que la validación
			// informa al motor («Verificando archivo 120 de 5 000»), anotados en la sesión como mucho cada 2 s.
			$checking = Digitalisimo_Backups_Uploads::checker( $state['id'] );
			self::$upload_checking = $checking;
			Digitalisimo_Backups_Jobs::$observer = function( $percent, $message ) use ( $checking ) { $checking( '', $message ); };
			$path = Digitalisimo_Backups_Uploads::data_path( $state['id'] );
			$report = null;
			if ( '' !== (string) $state['sha256'] ) {
				self::upload_step( 'checksum', 'Calculando el SHA-256 del archivo para compararlo con el declarado…' );
				$checksum = @hash_file( 'sha256', $path );
				if ( false === $checksum ) $report = self::service_error( 'upload_error', 'No se pudo leer el archivo subido para calcular su SHA-256; se conserva para reintentar.', 500 );
				elseif ( ! hash_equals( (string) $state['sha256'], $checksum ) ) $report = self::service_error( 'upload_checksum', 'El archivo recibido no coincide con el SHA-256 declarado y se descartó. Vuelve a subirlo.', 422 );
			}
			// Un respaldo de Backuply (.tar.gz) no se comprueba aquí: la importación lo valida entero, por pasos (I9).
			// Una pieza de UpdraftPlus: sólo su forma (un ZIP o un gzip); la importación del conjunto la valida entera.
			if ( null === $report && self::upload_is_updraft( (string) $state['name'] ) ) {
				self::upload_step( 'gzip', 'Comprobando que es una pieza de UpdraftPlus (la importación del conjunto la comprueba entera después)…' );
				$report = self::upload_updraft_valid( (string) $state['name'], $path ) ? array( 'container' => 'updraft' ) : self::service_error( 'upload_invalid', 'El archivo no es una pieza de UpdraftPlus (un ZIP o un gzip con su nombre) y se descartó.', 422 );
			}
			if ( null === $report && self::upload_is_backuply( (string) $state['name'] ) ) {
				self::upload_step( 'gzip', 'Comprobando que es un .tar.gz de Backuply (la importación lo comprueba entero después)…' );
				$report = "\x1f\x8b" === (string) @file_get_contents( $path, false, null, 0, 2 ) ? array( 'container' => 'backuply' ) : self::service_error( 'upload_invalid', 'El archivo no es un respaldo de Backuply (.tar.gz comprimido con gzip) y se descartó.', 422 );
				// Un respaldo de cuenta de Webuzo también es un .tar.gz: se reconoce por sus primeras entradas (backuply-data/).
				if ( ! is_wp_error( $report ) && self::upload_is_webuzo( $path ) ) $report = array( 'container' => 'webuzo' );
			}
			if ( null === $report ) $report = self::upload_inspect( $path, is_string( $args['secret'] ?? null ) ? $args['secret'] : '' );
			if ( is_wp_error( $report ) ) {
				$code = $report->get_error_code();
				$discard = in_array( $code, array( 'digitalisimo_backups_upload_invalid', 'digitalisimo_backups_upload_checksum' ), true );
				$state['phase'] = $discard ? 'rejected' : 'uploading';
				// Un rechazo por espacio, frase o el servidor no es un corte: no gasta intentos.
				if ( ! $discard ) $state['attempts'] = 0;
				unset( $state['check'] );
				$state['error'] = array( 'code' => $code, 'message' => $report->get_error_message() );
				$state['updated_at'] = time();
				Digitalisimo_Backups_Uploads::write( $state );
				if ( $discard ) @unlink( $path );
				return $report;
			}
			if ( 'backuply' === ( $report['container'] ?? '' ) ) return self::upload_backuply_done( $state, $path );
			if ( 'webuzo' === ( $report['container'] ?? '' ) ) return self::upload_webuzo_done( $state, $path );
			if ( 'updraft' === ( $report['container'] ?? '' ) ) return self::upload_updraft_done( $state, $path );
			return self::upload_place( $state, $path, $report, $args );
		} catch ( Throwable $e ) {
			// El servidor no pudo terminar (almacén, permisos): la subida se conserva para reintentar.
			try {
				if ( is_array( $state ) && Digitalisimo_Backups_Uploads::read( $state['id'] ) ) {
					$state['phase'] = 'uploading';
					$state['attempts'] = 0;
					unset( $state['check'] );
					$state['error'] = array( 'code' => 'digitalisimo_backups_upload_error', 'message' => $e->getMessage() );
					$state['updated_at'] = time();
					Digitalisimo_Backups_Uploads::write( $state );
				}
			} catch ( Throwable $ignored ) {} // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			return self::service_error( 'upload_error', 'No se pudo terminar la subida; se conserva para reintentar o descartarla: ' . $e->getMessage(), 500 );
		} finally {
			self::$upload_checking = null;
			Digitalisimo_Backups_Jobs::$observer = $observer;
			Digitalisimo_Backups_Uploads::unlock( $lock );
		}
	}
	private static function upload_is_backuply( $name ) { return (bool) preg_match( '/\.tar\.gz$/i', (string) $name ); }
	/** El nombre de una pieza de un respaldo de UpdraftPlus (`backup_…_<código>-<entidad>.zip|.gz[.crypt]`). */
	private static function upload_is_updraft( $name ) { return (bool) preg_match( '/^backup_[0-9]{4}-[0-9]{2}-[0-9]{2}-[0-9]{4}_[A-Za-z0-9_.-]{1,64}?_[0-9a-f]{12}-(?:db|plugins|themes|uploads|mu-plugins|others|wpcore|more)[0-9]{0,3}\.(?:zip|gz)(?:\.crypt)?$/D', (string) $name ); }
	/**
	 * El archivo validado entra en el almacén y en la lista. Su SHA-256 se calcula aquí, sobre los mismos bytes que se
	 * validaron (siguen en la sesión, con su cerrojo): es lo que ata la fila al archivo. Nombre, `rename()` y fila van con
	 * el cerrojo corto del almacén (nunca pisa un respaldo ni toma el nombre de una fila); antes de mover nada se anota en
	 * la sesión lo que se va a hacer (`placing`), así que si el proceso muere a mitad, cerrarla otra vez lo termina sin
	 * validar ni subir otra vez (upload_resume_placed()). Si ese contenido ya está en la lista, no se duplica.
	 *
	 * Un `.dgbk` con una clave que este sitio no tiene, cerrado sin su frase, entra en el almacén «sin registro» (M5 de la
	 * revisión): sin descifrarlo no se sabe si es un respaldo completo o un punto incremental, ni su cadena. Se agrega a la
	 * lista con «Agregar al listado» y su frase.
	 *
	 * Si ese mismo contenido (SHA-256 y tamaño) ya está en el almacén como archivo suelto (por ejemplo, ese `.dgbk` subido
	 * antes sin su frase), no se guarda otra copia: se registra ese archivo, con su nombre, que es el que nombran los
	 * puntos de su cadena (N4 de la verificación).
	 */
	private static function upload_place( array $state, $path, array $report, array $args ) {
		self::upload_step( 'register', 'Calculando el SHA-256 de lo comprobado y registrándolo en la lista de respaldos…' );
		$checksum = @hash_file( 'sha256', $path );
		if ( false === $checksum ) throw new Exception( 'No se pudo calcular el SHA-256 del respaldo subido.' );
		$size = (int) $state['size'];
		$storage = trailingslashit( self::local_directory() );
		$name = (string) $state['name'];
		$via = (string) ( $args['via'] ?? ( defined( 'WP_CLI' ) && WP_CLI ? 'cli' : 'rest' ) );
		$info = $report + array( 'via' => $via, 'name' => $name, 'user_id' => (int) ( $state['user_id'] ?? 0 ) );
		$public = self::upload_public_result( $report );
		$loose = ! empty( $report['needs_secret'] );
		$placed = Digitalisimo_Backups_Job_Store::with_lock( function() use ( &$state, $path, $storage, $name, $report, $checksum, $size, $info, $loose ) {
			$same = self::history_same_content( $checksum, $size );
			if ( $same ) return array( 'file' => (string) $same['file'], 'duplicate' => true, 'row' => $same );
			$copy = self::loose_same_content( $checksum, $size );
			if ( '' !== $copy ) {
				$state['placing'] = array( 'file' => $copy, 'sha256' => $checksum, 'info' => self::upload_row_input( $info ), 'loose' => $loose, 'reused' => true );
				$state['updated_at'] = time();
				Digitalisimo_Backups_Uploads::write( $state );
				if ( $loose ) return array( 'file' => $copy, 'duplicate' => false, 'row' => array(), 'loose' => true, 'reused' => true );
				return array( 'file' => $copy, 'duplicate' => false, 'row' => self::remember_uploaded( $storage . $copy, $checksum, $info ), 'reused' => true );
			}
			$file = self::upload_final_name( $name, $report['container'] );
			$state['placing'] = array( 'file' => $file, 'sha256' => $checksum, 'info' => self::upload_row_input( $info ), 'loose' => $loose );
			$state['updated_at'] = time();
			Digitalisimo_Backups_Uploads::write( $state );
			if ( ! @rename( $path, $storage . $file ) ) throw new Exception( 'No se pudo mover el respaldo subido al almacén privado.' );
			self::private_file( $storage . $file );
			if ( $loose ) return array( 'file' => $file, 'duplicate' => false, 'row' => array(), 'loose' => true );
			try {
				$row = self::remember_uploaded( $storage . $file, $checksum, $info );
			} catch ( Throwable $e ) {
				// Sin fila no se queda en el almacén: vuelve a la sesión, que se conserva para reintentar.
				@rename( $storage . $file, $path );
				throw $e;
			}
			return array( 'file' => $file, 'duplicate' => false, 'row' => $row );
		} );
		if ( $placed['duplicate'] || ! empty( $placed['reused'] ) ) @unlink( $path );
		return self::upload_done( $state, $placed, $public, $size );
	}
	/**
	 * Archivo suelto del almacén (un nombre de respaldo sin fila en el historial) con este contenido, o ''. Sólo se lee
	 * entero el que tiene el mismo tamaño.
	 */
	private static function loose_same_content( $sha256, $size ) {
		$storage = trailingslashit( self::local_directory() );
		$known = array_flip( array_map( 'strval', array_column( (array) self::fresh_history(), 'file' ) ) );
		foreach ( (array) @scandir( $storage ) as $file ) {
			$file = (string) $file;
			if ( isset( $known[ $file ] ) || ! self::loose_name( $file ) ) continue;
			$path = $storage . $file;
			if ( is_link( $path ) || ! is_file( $path ) || (int) @filesize( $path ) !== (int) $size ) continue;
			if ( hash_equals( (string) $sha256, (string) @hash_file( 'sha256', $path ) ) ) return $file;
		}
		return '';
	}
	/** Lo de la validación que la fila necesita, guardado en la sesión mientras se coloca (sin el ZIP abierto). */
	private static function upload_row_input( array $info ) {
		return array_intersect_key( $info, array_flip( array( 'container', 'verified', 'needs_secret', 'trust', 'signature', 'key', 'compatible', 'problems', 'scope', 'multisite', 'created_at', 'via', 'name', 'user_id', '_row' ) ) );
	}
	/** El informe de la validación sin lo interno de la fila. */
	private static function upload_public_result( array $report ) {
		unset( $report['_row'] );
		return $report;
	}
	/**
	 * Cierra la sesión con su resultado: el archivo, si está en la lista y qué confirmación pide. Si ese contenido ya
	 * estaba en la lista (`duplicate`), la confianza y la palabra son las de esa fila (B1 de la revisión): un respaldo
	 * hecho aquí con su SHA-256 es «registrado en este sitio» y se restaura con RESTAURAR, no con la frase de sin firma.
	 */
	private static function upload_done( array $state, array $placed, array $public, $size ) {
		$row = (array) $placed['row'];
		$loose = ! empty( $placed['loose'] );
		$trust = (string) ( $public['trust'] ?? 'untrusted' );
		if ( ! empty( $placed['duplicate'] ) && 'untrusted' === $trust && ! empty( $row['sha256'] ) && ! self::is_uploaded_row( $row ) && 'imported' !== (string) ( $row['origin'] ?? 'created' ) ) $trust = 'provenance';
		$vouched = self::is_uploaded_row( $row ) && 'untrusted' === $trust;
		$result = array( 'file' => (string) $placed['file'], 'size' => (int) $size, 'registered' => ! $loose, 'listed' => ! $loose, 'duplicate' => ! empty( $placed['duplicate'] ), 'date' => (string) ( $row['date'] ?? '' ) ) + $public;
		$result['trust'] = $trust;
		$result['confirmation'] = Digitalisimo_Backups_Security::confirmation_word( array( 'trust' => $trust, 'vouched' => $vouched ? 'uploaded' : '' ) );
		$result['vouched'] = $vouched ? 'uploaded' : '';
		$result['origin'] = $loose ? '' : (string) ( $row['origin'] ?? 'created' );
		$result['restorable'] = $loose ? false : self::restorable_item( $row );
		$result['uploaded'] = $loose ? null : self::uploaded_summary( $row );
		if ( $loose ) $result['problems'] = array( 'Está cifrado con la clave ' . (string) ( $public['key'] ?? '' ) . ', que este sitio no tiene: quedó en el almacén «sin registro», con el nombre ' . (string) $placed['file'] . '. Da su frase para agregarlo a la lista: «Agregar al listado» con su frase en Herramientas → «Restaurar un archivo suelto» (también se restaura desde ahí con su frase).' );
		unset( $state['placing'], $state['check'] );
		$state['phase'] = 'done';
		$state['result'] = $result;
		$state['updated_at'] = time();
		Digitalisimo_Backups_Uploads::write( $state );
		return $result;
	}
	/**
	 * Una sesión con `placing` y sin sus bytes: el proceso murió después del `rename()`. Si el archivo está en el almacén
	 * con el SHA-256 anotado, se registra (si aún no tiene fila) y la sesión se cierra con su resultado; null si no aplica.
	 */
	private static function upload_resume_placed( array $state, array $args ) {
		$placing = is_array( $state['placing'] ?? null ) ? $state['placing'] : null;
		if ( ! $placing ) return null;
		$data = Digitalisimo_Backups_Uploads::data_path( $state['id'] );
		if ( is_file( $data ) && Digitalisimo_Backups_Uploads::received( $state['id'] ) === (int) $state['size'] ) {
			// El rename() no llegó a ocurrir: se valida y se coloca de nuevo.
			unset( $state['placing'] );
			Digitalisimo_Backups_Uploads::write( $state );
			return null;
		}
		$file = sanitize_file_name( (string) ( $placing['file'] ?? '' ) );
		$path = '' !== $file ? self::local_path( $file ) : '';
		if ( '' === $path || ! hash_equals( (string) ( $placing['sha256'] ?? '' ), (string) @hash_file( 'sha256', $path ) ) ) {
			$state['phase'] = 'rejected';
			$state['error'] = array( 'code' => 'digitalisimo_backups_upload_missing', 'message' => 'El respaldo subido ya no está en el almacén con el contenido que se comprobó; vuelve a subirlo.' );
			unset( $state['placing'] );
			$state['updated_at'] = time();
			Digitalisimo_Backups_Uploads::write( $state );
			return self::service_error( 'upload_missing', $state['error']['message'], 404 );
		}
		$info = (array) ( $placing['info'] ?? array() );
		if ( ! empty( $placing['loose'] ) ) return self::upload_done( $state, array( 'file' => $file, 'duplicate' => false, 'row' => array(), 'loose' => true ), self::upload_public_result( $info ), (int) $state['size'] );
		$row = Digitalisimo_Backups_Job_Store::with_lock( function() use ( $file, $path, $placing, $info ) {
			$row = self::history_item( $file );
			return $row ? $row : self::remember_uploaded( $path, (string) $placing['sha256'], $info );
		} );
		return self::upload_done( $state, array( 'file' => $file, 'duplicate' => false, 'row' => $row ), self::upload_public_result( $info ), (int) $state['size'] );
	}
	/**
	 * Un `.tar.gz` de Backuply subido entra en `backuply/` del almacén (con un nombre libre) para importarlo: no es un
	 * respaldo de Backups ni aparece en «Restaurar» hasta convertirlo (Respaldos de Backuply, REST o WP-CLI).
	 */
	private static function upload_backuply_done( array $state, $path ) {
		self::upload_step( 'register', 'Guardándolo en el almacén privado para importarlo…' );
		$store = Digitalisimo_Backups_Backuply_Import::store_directory( true );
		$name = Digitalisimo_Backups_Backuply_Import::upload_name( (string) $state['name'] );
		if ( '' === $name ) $name = 'backuply-upload-' . gmdate( 'Ymd-His' ) . '.tar.gz';
		$file = Digitalisimo_Backups_Job_Store::with_lock( function() use ( $path, $store, $name ) {
			$file = $name;
			while ( file_exists( $store . '/' . $file ) || is_link( $store . '/' . $file ) ) $file = substr( $name, 0, -7 ) . '-' . bin2hex( random_bytes( 3 ) ) . '.tar.gz';
			if ( ! @rename( $path, $store . '/' . $file ) ) throw new Exception( 'No se pudo mover el respaldo de Backuply subido al almacén privado.' );
			@chmod( $store . '/' . $file, 0600 );
			return $file;
		} );
		$result = array( 'file' => $file, 'size' => (int) $state['size'], 'registered' => false, 'container' => 'backuply', 'backuply' => array( 'source' => 'store', 'name' => $file ), 'verified' => false, 'trust' => 'untrusted', 'confirmation' => 'RESTAURAR SIN FIRMA', 'needs_secret' => false, 'compatible' => false, 'problems' => array( 'Es un respaldo de Backuply: impórtalo en Herramientas → «Importar de Backuply, UpdraftPlus o Webuzo» (o con wp digitalisimo-backups backuply import ' . $file . ') para convertirlo en un ZIP de Backups y restaurarlo.' ) );
		unset( $state['check'] );
		$state['phase'] = 'done';
		$state['result'] = $result;
		$state['updated_at'] = time();
		Digitalisimo_Backups_Uploads::write( $state );
		return $result;
	}
	/** Una subida ya cerrada responde siempre lo mismo: su resultado o su rechazo. */
	private static function upload_closed( array $state ) {
		$phase = Digitalisimo_Backups_Uploads::phase( $state );
		if ( 'done' === $phase && is_array( $state['result'] ?? null ) ) return $state['result'];
		if ( 'rejected' === $phase ) return self::service_error( 'upload_invalid', (string) ( $state['error']['message'] ?? 'El archivo no era un respaldo válido y se descartó.' ), 422 );
		return null;
	}
	/** Otro proceso la está comprobando: 202 con la vista; el cliente consulta el estado hasta que termine. */
	private static function upload_validating( array $state ) {
		return self::service_error( 'upload_validating', 'La subida se está comprobando; consulta su estado en unos segundos.', 202, array( 'received' => Digitalisimo_Backups_Uploads::received( $state['id'] ), 'upload' => Digitalisimo_Backups_Uploads::view( $state ) ) );
	}
	/** Descarta una subida sin cerrar, de cualquier cuenta con la capability, y borra lo recibido. */
	public static function service_upload_cancel( $id ) {
		$state = self::upload_session( $id, false );
		if ( is_wp_error( $state ) ) return $state;
		$lock = Digitalisimo_Backups_Uploads::lock( $state['id'] );
		if ( ! $lock ) return self::service_error( 'upload_busy', 'La subida se está escribiendo o comprobando; vuelve a intentarlo en unos segundos.', 409 );
		// Con el cerrojo se marca descartada (un fragmento que llegue después no escribe); se suelta antes de borrar.
		try {
			$state['phase'] = 'cancelled';
			$state['updated_at'] = time();
			Digitalisimo_Backups_Uploads::write( $state );
		} catch ( Exception $e ) {} // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
		Digitalisimo_Backups_Uploads::unlock( $lock );
		Digitalisimo_Backups_Uploads::remove( $state['id'] );
		return array( 'id' => (string) $state['id'], 'cancelled' => true );
	}
	/**
	 * Validación de archivo no confiable del respaldo subido, en su sesión: la de `verify` (firma o ninguna confianza,
	 * descifrado completo de un `.dgbk`, entradas, CRC y SHA-256 de cada una contra el manifiesto v3 estricto y el SQL
	 * en seco). Devuelve el informe o el error: `upload_invalid` (no es un respaldo válido: se descarta),
	 * `secret_wrong`, `upload_space` o `upload_error` (no se pudo comprobar: se conserva).
	 */
	private static function upload_inspect( $path, $secret ) {
		// La confirmación de un archivo suelto (lo traído de un destino); la subida y «Agregar al listado» la cambian por la
		// de un respaldo subido (RESTAURAR) al registrarlo (upload_done(), service_register()).
		$summary = array( 'container' => 'zip', 'verified' => false, 'needs_secret' => false, 'trust' => 'untrusted', 'signature' => 'unsigned', 'key' => '', 'confirmation' => 'RESTAURAR SIN FIRMA', 'compatible' => false, 'problems' => array() );
		if ( ! class_exists( 'ZipArchive' ) ) return self::service_error( 'upload_error', 'El servidor necesita la extensión PHP ZipArchive para comprobar el respaldo; la subida se conserva.', 500 );
		if ( Digitalisimo_Backups_Encrypted_File::is_encrypted( $path ) ) {
			self::upload_step( 'header', 'Comprobando la cabecera del respaldo cifrado…' );
			try {
				$parsed = Digitalisimo_Backups_Encrypted_File::read_header( $path );
				$header = $parsed['header'];
			} catch ( Exception $e ) {
				return self::service_error( 'upload_invalid', 'El archivo no es un respaldo cifrado válido y se descartó: ' . $e->getMessage(), 422 );
			}
			$key_id = (string) $header['key']['id'];
			$summary = array_merge( $summary, array( 'container' => 'dgbk', 'trust' => 'signed', 'signature' => 'signed', 'key' => Digitalisimo_Backups_Keys::short( $key_id ), 'confirmation' => 'RESTAURAR' ) );
			if ( ! Digitalisimo_Backups_Keys::can_open( $key_id ) ) {
				// Sin la frase sólo se sabe lo que dice su cabecera pública: fecha, alcance y si es de una red.
				if ( '' === $secret ) return array_merge( $summary, array( 'needs_secret' => true, 'compatible' => true, 'scope' => (string) ( $header['scope'] ?? '' ), 'multisite' => ! empty( $header['multisite'] ), 'created_at' => (string) ( $header['created_at'] ?? '' ), 'plugin_version' => (string) ( $header['plugin_version'] ?? '' ), 'problems' => array( 'Está cifrado con la clave ' . Digitalisimo_Backups_Keys::short( $key_id ) . ', que este sitio no tiene: se comprobará por completo al restaurarlo escribiendo su frase o su clave.' ) ) );
				$root = Digitalisimo_Backups_Sodium::available() ? Digitalisimo_Backups_Keys::resolve_with_secret( $header['key'], $secret ) : false;
				if ( false !== $root ) Digitalisimo_Backups_Sodium::memzero( $root );
				if ( false === $root ) return self::upload_wrong_secret( $key_id );
			}
			// Descifrarlo para comprobarlo necesita sitio además del archivo subido: si no lo hay, se conserva.
			$free = Digitalisimo_Backups_Archive_Inspector::free_space( dirname( $path ) );
			$needed = (int) ceil( (int) $header['inner_size'] * 1.05 ) + Digitalisimo_Backups_Security::MARGIN;
			if ( null !== $free && $free < $needed ) return self::service_error( 'upload_space', 'No hay espacio para descifrar el respaldo y comprobarlo: se necesitan ' . Digitalisimo_Backups_Archive_Inspector::megabytes( $needed ) . ' libres en el almacén y hay ' . Digitalisimo_Backups_Archive_Inspector::megabytes( $free ) . '. La subida se conserva: libera espacio y vuelve a terminarla, o descártala.', 507 );
		} elseif ( "PK\x03\x04" !== (string) @file_get_contents( $path, false, null, 0, 4 ) ) {
			return self::service_error( 'upload_invalid', 'El archivo no es un ZIP ni un respaldo cifrado de DIGITALÍSIMO y se descartó.', 422 );
		} elseif ( '' !== $secret ) {
			// Un ZIP firmado con una clave que este sitio no tiene: una frase equivocada no es un archivo inválido.
			$zip = new ZipArchive();
			if ( true === $zip->open( $path ) ) {
				try {
					$auth = Digitalisimo_Backups_Manifest_Auth::verify( $zip, $secret );
				} catch ( Throwable $e ) {
					$auth = array();
				}
				@$zip->close();
				if ( 'wrong_key' === ( $auth['state'] ?? '' ) ) return self::upload_wrong_secret( (string) ( $auth['key']['id'] ?? '' ) );
			}
		}
		$report = null;
		try {
			self::upload_step( 'open', 'dgbk' === $summary['container'] ? 'Descifrando el respaldo para comprobarlo entero…' : 'Abriendo el ZIP y comprobando la firma de su manifiesto…' );
			$report = Digitalisimo_Backups_Security::open( $path, array(), $secret );
			$source = array();
			self::upload_step( 'contents', 'Comprobando cada archivo contra el manifiesto (CRC y SHA-256) y la base de datos en seco…' );
			$data = self::inspect_package( $report['zip'], 'untrusted' !== $report['trust'], false, $source, true );
			$problems = self::package_installation_problems( $data );
			// El respaldo de una red en un WordPress individual: se restaura un sitio suyo, que se elige al restaurarlo.
			$network = self::network_converts( $data );
			if ( $network ) $problems = array();
			// Un punto incremental: se conserva y se restaura con su cadena (sus archivos se buscan en el almacén por nombre).
			$chain = 'incremental' === ( $data['type'] ?? '' ) ? self::loose_chain_needs( $data ) : null;
			if ( $chain && $chain['missing'] ) $problems[] = 'Es un punto incremental (' . $chain['sequence'] . ' de su cadena): se restaura con su cadena y faltan en el almacén ' . count( $chain['missing'] ) . ' archivos (' . implode( ', ', array_slice( $chain['missing'], 0, 3 ) ) . ( count( $chain['missing'] ) > 3 ? '…' : '' ) . '). Súbelos o tráelos de su destino con ese nombre.';
			// «Origen → este sitio», como `verify`: qué cambiaría al restaurarlo aquí (o por qué no se puede).
			$relocation = null;
			if ( ! $problems && ! $network ) {
				self::upload_step( 'plan', 'Comprobando qué cambiaría al restaurarlo en este sitio («Origen → este sitio»)…' );
				$plan = self::relocation_plan( $data, $source, array( 'addresses' => 'current' ) );
				$problems = $plan->problems();
				$relocation = $plan->summary();
			}
			if ( 'untrusted' === $report['trust'] && Digitalisimo_Backups_Security::settings()['require_signed'] ) $problems[] = 'Este sitio sólo restaura respaldos firmados (Backups → Ajustes → Cifrado y firma) y este archivo no tiene una firma válida de una clave de este sitio.';
			$row = self::uploaded_row_info( $report, $data, $relocation, $problems );
			$sites = $network ? self::network_sites_of( (array) $source ) : array();
			if ( $sites ) $row['sites'] = $sites;
			return array_merge( $summary, array(
				'container' => (string) $report['container'],
				'verified' => true,
				'trust' => (string) $report['trust'],
				'signature' => (string) $report['auth'],
				'key' => isset( $report['key']['id'] ) ? Digitalisimo_Backups_Keys::short( $report['key']['id'] ) : '',
				'confirmation' => 'untrusted' === $report['trust'] ? 'RESTAURAR SIN FIRMA' : 'RESTAURAR',
				'compatible' => ! $problems,
				'problems' => $problems,
				'entries' => (int) $report['zip']->numFiles,
				'format' => (string) ( $data['format'] ?? '' ),
				'scope' => (string) ( $data['scope'] ?? '' ),
				'multisite' => ! empty( $data['multisite'] ),
				'created_at' => (string) ( $data['created_at'] ?? '' ),
				'plugin_version' => (string) ( $data['plugin_version'] ?? '' ),
				'relocation' => $relocation,
				'wp_config' => self::config_report( $report['zip'] ),
				'chain' => $chain,
				'convert' => $network ? array( 'sites' => $sites, 'main' => self::network_main_of( $sites, (array) ( $source['network'] ?? array() ) ), 'text' => 'Es el respaldo de una red y este WordPress es individual: al restaurarlo se elige qué sitio de la red (por defecto, el principal) queda como este WordPress.' ) : null,
				'_row' => $row,
			) );
		} catch ( Exception $e ) {
			return self::upload_failure( $e->getMessage() );
		} catch ( Throwable $e ) {
			return self::service_error( 'upload_error', 'No se pudo comprobar el respaldo por un error del servidor; la subida se conserva para reintentar: ' . $e->getMessage(), 500 );
		} finally {
			Digitalisimo_Backups_Security::close( $report );
		}
	}
	private static function upload_wrong_secret( $key_id ) {
		return self::service_error( 'secret_wrong', 'La frase o clave escrita no corresponde a la clave ' . Digitalisimo_Backups_Keys::short( $key_id ) . ' de este respaldo. La subida se conserva: vuelve a terminarla con la frase correcta o sin frase.', 400 );
	}
	/**
	 * Qué significa un fallo de la comprobación: lo que dice del servidor (espacio, libsodium, la carpeta de trabajo)
	 * conserva la subida; lo demás es que el archivo no es un respaldo válido, y se descarta. Una frase equivocada no
	 * llega aquí: upload_inspect() la reconoce antes por la cabecera del .dgbk o por la firma del manifiesto.
	 */
	private static function upload_failure( $message ) {
		if ( false !== strpos( $message, 'No hay espacio' ) ) return self::service_error( 'upload_space', $message . ' La subida se conserva: libera espacio y vuelve a terminarla, o descártala.', 507 );
		if ( false !== strpos( $message, 'este servidor no tiene' ) || false !== strpos( $message, 'No se pudo crear la carpeta de trabajo' ) || false !== strpos( $message, 'ZipArchive' ) ) return self::service_error( 'upload_error', 'No se pudo comprobar el respaldo en este servidor; la subida se conserva para reintentar: ' . $message, 500 );
		return self::service_error( 'upload_invalid', 'El archivo no supera la validación de archivos no confiables y se descartó: ' . $message, 422 );
	}
	/**
	 * Nombre en el almacén: el original si ya es el de un respaldo de DIGITALÍSIMO (con la extensión de su contenido) y
	 * no lo usa ningún archivo ni ninguna fila del historial; si no, `digitalisimo-upload-<fecha>-<aleatorio>`. Así nunca
	 * toma la fila (ni la confianza) de otro respaldo: su fila es la suya, «Subido», con su propio SHA-256.
	 */
	private static function upload_final_name( $name, $container ) {
		$storage = trailingslashit( self::local_directory() );
		$extension = 'dgbk' === $container ? '.dgbk' : '.zip';
		$stem = (string) preg_replace( '/\.(?:zip|dgbk)$/i', '', sanitize_file_name( (string) $name ) );
		$known = array_flip( array_map( 'strval', array_column( (array) self::fresh_history(), 'file' ) ) );
		$free = function( $candidate ) use ( $storage, $known ) { return ! file_exists( $storage . $candidate ) && ! is_link( $storage . $candidate ) && ! isset( $known[ $candidate ] ); };
		$listed = preg_match( '/^digitalisimo-[A-Za-z0-9._-]+$/', $stem ) || ( '.zip' === $extension && preg_match( '/^safety-before-restore-[A-Za-z0-9._-]+$/', $stem ) );
		if ( $listed && $free( $stem . $extension ) ) return $stem . $extension;
		do {
			$candidate = 'digitalisimo-upload-' . gmdate( 'Ymd-His' ) . '-' . bin2hex( random_bytes( 4 ) ) . $extension;
		} while ( ! $free( $candidate ) );
		return $candidate;
	}
}
