<?php
defined( 'ABSPATH' ) || exit;

/** Consulta independiente de SEO para no depender de la caché horaria del actualizador compartido. */
final class Digitalisimo_SEO_Release_Check {
	const CACHE_KEY = 'digitalisimo_seo_release_check';
	const HOOK = 'digitalisimo_seo_refresh_release';
	const SLUG = 'digitalisimo-seo';
	const REPOSITORY = 'danbutanda/digitalisimo-plugin';
	/**
	 * Índice de versiones adjunto a cada Release (el ZIP vigente de los siete plugins). Se descarga como un archivo
	 * de la última Release, no por la API de GitHub, que limita a 60 consultas por hora a cada servidor sin
	 * autenticar y que agotan entre todos los plugins Digitalisimo.
	 */
	const MANIFEST_URL = 'https://github.com/danbutanda/digitalisimo-plugin/releases/latest/download/digitalisimo-plugins.json';
	/** Caché compartida del índice: un solo archivo sirve a todos los plugins que lo lean. */
	const MANIFEST_CACHE = 'digitalisimo_plugins_manifest';
	/** Un fallo de GitHub (índice o API, por separado) detiene dos minutos las consultas de todos los plugins Digitalisimo y del tema. */
	const MANIFEST_RETRY = 'digitalisimo_plugins_manifest_retry';
	const API_RETRY      = 'digitalisimo_github_api_retry';
	/** Índice recién descargado (cuatro minutos): la consulta periódica de otro plugin lo reutiliza en vez de bajarlo otra vez. */
	const MANIFEST_FRESH = 'digitalisimo_plugins_manifest_fresh';
	/** Acción explícita en esta petición («Buscar actualizaciones»): 10 s y sin la espera. */
	private static $explicit = false;
	/** Última versión encontrada: si GitHub no responde, la actualización sigue a la vista en lugar de desaparecer. */
	const LAST_KNOWN = 'digitalisimo_seo_last_release';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'prime' ), 0 );
		add_filter( 'update_plugins_github.com', array( __CLASS__, 'uri_update' ), 30, 4 );
		// WordPress lee update_plugins en cada pantalla del escritorio (el contador del menú): esa lectura sólo usa lo ya
		// sabido y nunca espera a GitHub. Descargan el cron y las consultas de WordPress (pre_set_…: Plugins,
		// Actualizaciones, wp_update_plugins), que ya son momentos de red.
		add_filter( 'site_transient_update_plugins', array( __CLASS__, 'inject_known' ), 30 );
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ), 30 );
		add_action( self::HOOK, array( __CLASS__, 'refresh' ) );
		add_action( 'admin_post_digitalisimo_check_updates', array( __CLASS__, 'clear_for_manual' ), 1 );
		add_filter( 'cron_schedules', array( __CLASS__, 'schedule' ) );
		// Cada sitio con SEO programa el cron (así renueva aunque el principal no tenga SEO o no reciba visitas), pero la
		// caché y la última versión conocida son de red: en una red, refresh() toma un candado y sólo uno descarga.
		if ( ! wp_next_scheduled( self::HOOK ) ) wp_schedule_event( time() + 300, 'digitalisimo_five_minutes', self::HOOK );
	}

	/** Candado de red de refresh(): con un cron por sitio, una descarga del índice cada cinco minutos en toda la red. */
	const LOCK = 'digitalisimo_seo_release_refresh_lock';

	/**
	 * Las cachés de todos los actualizadores Digitalisimo en una sola consulta, en init: el menú del escritorio
	 * (wp-admin/menu.php, antes de admin_init) lee update_plugins y update_themes en cada pantalla, y cada
	 * actualizador leía entonces la suya con su propia consulta (WordPress nunca carga con autoload un transitorio de red).
	 */
	public static function prime() {
		if ( ! is_admin() || wp_doing_ajax() || wp_using_ext_object_cache() ) return;
		// Sólo quien ve el contador de actualizaciones del menú; nunca en los envíos de formularios ni en las subidas.
		if ( in_array( $GLOBALS['pagenow'] ?? '', array( 'admin-post.php', 'async-upload.php' ), true ) || ! ( current_user_can( 'update_plugins' ) || current_user_can( 'update_themes' ) ) ) return;
		$keys = array();
		foreach ( array( 'digitalisimo_plugins_manifest', 'digitalisimo_releases_index', 'digitalisimo_backups_release', 'digitalisimo_tools_release', 'digitalisimo_elements_release', 'digitalisimo_migration_release', 'digitalisimo_seo_release_check', 'digitalisimo_theme_release', 'digitalisimo_tools_theme_release', 'digitalisimo_tools_bridge_release', 'digitalisimo_plugins_manifest_retry', 'digitalisimo_github_api_retry' ) as $key ) { $keys[] = '_site_transient_' . $key; $keys[] = '_site_transient_timeout_' . $key; }
		if ( is_multisite() ) { if ( function_exists( 'wp_prime_network_option_caches' ) ) wp_prime_network_option_caches( get_current_network_id(), $keys ); }
		elseif ( function_exists( 'wp_prime_option_caches' ) ) wp_prime_option_caches( $keys );
	}

	public static function schedule( $schedules ) {
		$schedules['digitalisimo_five_minutes'] = array( 'interval' => 300, 'display' => 'Digitalisimo: cada cinco minutos' );
		return $schedules;
	}

	public static function clear_for_manual() {
		if ( ! current_user_can( is_multisite() ? 'manage_network_plugins' : 'update_plugins' ) ) return;
		check_admin_referer( 'digitalisimo_check_updates' );
		self::$explicit = true;
		self::clear();
	}

	/** Vacía la caché propia y el índice compartido para que la siguiente consulta descargue el índice de nuevo. */
	private static function clear() {
		delete_site_transient( self::CACHE_KEY );
		delete_site_transient( self::MANIFEST_CACHE );
		delete_site_transient( self::MANIFEST_RETRY );
		delete_site_transient( self::API_RETRY );
	}

	/**
	 * El cron actualiza únicamente el índice de SEO y el aviso; no consulta WordPress.org. Descarga el índice de nuevo y
	 * lo deja en la caché compartida, sin vaciarla antes: si GitHub falla, los demás plugins conservan el índice que ya
	 * tenían y release() conserva la última versión encontrada.
	 */
	public static function refresh() {
		if ( is_multisite() ) {
			if ( get_site_transient( self::LOCK ) ) return;
			set_site_transient( self::LOCK, time(), 4 * MINUTE_IN_SECONDS );
		}
		delete_site_transient( self::CACHE_KEY );
		self::release( true );
		$updates = get_site_transient( 'update_plugins' );
		if ( ! is_object( $updates ) || ! isset( $updates->checked ) || ! is_array( $updates->checked ) ) {
			wp_update_plugins();
			$updates = get_site_transient( 'update_plugins' );
		}
		$updates = self::inject( $updates );
		if ( is_object( $updates ) && isset( $updates->checked ) && is_array( $updates->checked ) ) set_site_transient( 'update_plugins', $updates );
	}

	private static function release( $fresh = false ) {
		$cached = get_site_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) return $cached;
		$latest = self::from_manifest( $fresh );
		if ( ! $latest ) $latest = self::from_api();
		if ( $latest ) {
			update_site_option( self::LAST_KNOWN, $latest );
			set_site_transient( self::CACHE_KEY, $latest, 10 * MINUTE_IN_SECONDS );
			return $latest;
		}
		// GitHub no respondió o limitó las consultas: se conserva lo último encontrado y se reintenta pronto.
		$known = get_site_option( self::LAST_KNOWN, array() );
		$known = is_array( $known ) ? $known : array();
		set_site_transient( self::CACHE_KEY, $known, 2 * MINUTE_IN_SECONDS );
		return $known;
	}

	/** Las consultas en cron pueden esperar; las de una pantalla de administración no deben retrasarla. */
	private static function timeout() { return self::$explicit || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) || ( defined( 'WP_CLI' ) && WP_CLI ) ? 10 : 3; }

	/** Versión de SEO en el índice de la última Release; sólo acepta un ZIP suyo de este repositorio. */
	private static function from_manifest( $fresh = false ) {
		// La descarga forzada del cron reutiliza el índice que otro plugin Digitalisimo bajó en los últimos cuatro minutos.
		$manifest = $fresh && false === get_site_transient( self::MANIFEST_FRESH ) ? false : get_site_transient( self::MANIFEST_CACHE );
		if ( ! is_array( $manifest ) ) {
			// GitHub falló hace menos de dos minutos (para cualquier plugin Digitalisimo): no se vuelve a intentar todavía.
			if ( ! self::$explicit && false !== get_site_transient( self::MANIFEST_RETRY ) ) return array();
			$response = wp_remote_get( self::MANIFEST_URL, array( 'timeout' => self::timeout(), 'redirection' => 5, 'headers' => array( 'Accept' => 'application/json', 'User-Agent' => 'Digitalisimo-SEO-Updater' ) ) );
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) { set_site_transient( self::MANIFEST_RETRY, 1, 2 * MINUTE_IN_SECONDS ); return array(); }
			$manifest = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( ! is_array( $manifest ) || empty( $manifest['plugins'] ) || ! is_array( $manifest['plugins'] ) ) { set_site_transient( self::MANIFEST_RETRY, 1, 2 * MINUTE_IN_SECONDS ); return array(); }
			set_site_transient( self::MANIFEST_CACHE, $manifest, 10 * MINUTE_IN_SECONDS );
			set_site_transient( self::MANIFEST_FRESH, time(), 4 * MINUTE_IN_SECONDS );
		}
		$entry   = $manifest['plugins'][ self::SLUG ] ?? null;
		$version = is_array( $entry ) ? (string) ( $entry['version'] ?? '' ) : '';
		$package = is_array( $entry ) ? (string) ( $entry['url'] ?? '' ) : '';
		if ( ! preg_match( '/^\d+(?:\.\d+)+$/', $version ) || ! preg_match( '#^https://github\.com/' . preg_quote( self::REPOSITORY, '#' ) . '/releases/download/[A-Za-z0-9._-]+/' . self::SLUG . '-' . preg_quote( $version, '#' ) . '\.zip$#', $package ) ) return array();
		$release_url = (string) ( $manifest['release_url'] ?? '' );
		if ( 0 !== strpos( $release_url, 'https://github.com/' . self::REPOSITORY . '/releases' ) ) $release_url = 'https://github.com/' . self::REPOSITORY . '/releases';
		return array( 'version' => $version, 'package' => esc_url_raw( $package ), 'url' => esc_url_raw( $release_url ) );
	}

	/** Respaldo por la API de GitHub (sujeta a su límite de consultas): el asset más reciente de SEO. */
	private static function from_api() {
		if ( ! self::$explicit && false !== get_site_transient( self::API_RETRY ) ) return array();
		$response = wp_remote_get( 'https://api.github.com/repos/' . self::REPOSITORY . '/releases?per_page=50', array(
			'timeout' => self::timeout(),
			'headers' => array( 'Accept' => 'application/vnd.github+json', 'User-Agent' => 'Digitalisimo-SEO-Updater' ),
		) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) { set_site_transient( self::API_RETRY, 1, 2 * MINUTE_IN_SECONDS ); return array(); }
		$latest = array();
		foreach ( (array) json_decode( wp_remote_retrieve_body( $response ), true ) as $release ) {
			if ( ! empty( $release['draft'] ) || ! empty( $release['prerelease'] ) ) continue;
			foreach ( (array) ( $release['assets'] ?? array() ) as $asset ) {
				if ( ! preg_match( '/^digitalisimo-seo-([0-9][0-9.]*)\.zip$/', (string) ( $asset['name'] ?? '' ), $match ) ) continue;
				if ( $latest && ! version_compare( $match[1], $latest['version'], '>' ) ) continue;
				$package = esc_url_raw( $asset['browser_download_url'] ?? '' );
				if ( ! $package ) continue;
				$latest = array( 'version' => $match[1], 'package' => $package, 'url' => esc_url_raw( $release['html_url'] ?? '' ) );
			}
		}
		return $latest;
	}

	private static function pending() {
		$release = self::release();
		return ! empty( $release['version'] ) && version_compare( $release['version'], DIGITALISIMO_INTEGRATIONS_VERSION, '>' ) ? $release : array();
	}

	public static function uri_update( $update, $plugin_data, $plugin_file, $locales ) {
		if ( plugin_basename( DIGITALISIMO_INTEGRATIONS_FILE ) !== $plugin_file ) return $update;
		$release = self::pending();
		if ( ! $release ) return $update;
		return array( 'slug' => 'digitalisimo-seo', 'version' => $release['version'], 'package' => $release['package'], 'url' => $release['url'], 'requires_php' => '7.4' );
	}

	/** Lo ya sabido sin red: la caché propia o, vencida, la última versión encontrada (el cron la renueva). */
	private static function known() {
		$cached = get_site_transient( self::CACHE_KEY );
		if ( ! is_array( $cached ) ) $cached = get_site_option( self::LAST_KNOWN, array() );
		return is_array( $cached ) && ! empty( $cached['version'] ) && version_compare( $cached['version'], DIGITALISIMO_INTEGRATIONS_VERSION, '>' ) ? $cached : array();
	}

	/** Lectura de update_plugins (cada pantalla del escritorio): sólo lo ya sabido, sin peticiones a GitHub. */
	public static function inject_known( $transient ) { return self::apply( $transient, false ); }

	/** Escritura de update_plugins (WordPress está consultando actualizaciones): puede descargar el índice. */
	public static function inject( $transient ) { return self::apply( $transient, true ); }

	private static function apply( $transient, $remote ) {
		if ( ! is_object( $transient ) || ! isset( $transient->checked ) || ! is_array( $transient->checked ) ) return $transient;
		$release = $remote ? self::pending() : self::known();
		if ( ! $release ) return $transient;
		$file = plugin_basename( DIGITALISIMO_INTEGRATIONS_FILE );
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) $transient->response = array();
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) $transient->no_update = array();
		$transient->checked[ $file ] = DIGITALISIMO_INTEGRATIONS_VERSION;
		unset( $transient->no_update[ $file ] );
		$transient->response[ $file ] = (object) array(
			'id' => 'https://github.com/danbutanda/digitalisimo-plugin/digitalisimo-seo',
			'slug' => 'digitalisimo-seo', 'plugin' => $file,
			'new_version' => $release['version'], 'package' => $release['package'], 'url' => $release['url'],
			'requires' => '6.0', 'requires_php' => '7.4',
		);
		return $transient;
	}
}
