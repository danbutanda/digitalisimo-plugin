<?php
namespace Digitalisimo\Elements;

defined( 'ABSPATH' ) || exit;

final class Elementor_Slider_Widget extends \Elementor\Widget_Base {
	public function get_name() { return 'digitalisimo-slider-optimizado'; }
	public function get_title() { return 'Slider Optimizado'; }
	public function get_icon() { return 'eicon-slider-album'; }
	public function get_categories() { return array( 'digitalisimo' ); }
	public function get_keywords() { return array( 'digitalisimo', 'slider', 'logos', 'banner', 'marquee' ); }
	public function get_style_depends() { return array( 'digitalisimo-slider-optimizado' ); }
	public function get_script_depends() { return array( 'digitalisimo-slider-optimizado' ); }

	protected function register_controls() {
		$c = '\\Elementor\\Controls_Manager';
		$this->start_controls_section( 'content', array( 'label' => 'Contenido' ) );
		$this->add_control( 'mode', array( 'label' => 'Modo', 'type' => $c::SELECT, 'default' => 'multiple', 'options' => array( 'multiple' => 'Logos / imágenes múltiples', 'repeat' => 'Imagen repetida / banner' ) ) );
		$this->add_control( 'gallery_images', array( 'label' => 'Seleccionar varias imágenes', 'type' => $c::GALLERY, 'default' => array(), 'description' => 'Elige todas las imágenes de una vez. Se mostrarán primero y usarán el ALT guardado en la Biblioteca de Medios.', 'condition' => array( 'mode' => 'multiple' ) ) );
		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'image', array( 'label' => 'Imagen', 'type' => $c::MEDIA, 'default' => array( 'url' => \Elementor\Utils::get_placeholder_image_src() ) ) );
		$repeater->add_control( 'alt', array( 'label' => 'Texto alternativo', 'type' => $c::TEXT, 'label_block' => true ) );
		$repeater->add_control( 'link', array( 'label' => 'Enlace opcional', 'type' => $c::URL, 'options' => array( 'url', 'is_external', 'nofollow' ), 'label_block' => true ) );
		$this->add_control( 'images', array( 'label' => 'Imágenes individuales con ALT o enlace', 'type' => $c::REPEATER, 'fields' => $repeater->get_controls(), 'title_field' => '{{{ alt || "Imagen" }}}', 'description' => 'Opcional. Estos elementos se agregan después de las imágenes seleccionadas arriba; los sliders existentes se conservan.', 'condition' => array( 'mode' => 'multiple' ) ) );
		$this->add_control( 'repeat_image', array( 'label' => 'Imagen / banner', 'type' => $c::MEDIA, 'condition' => array( 'mode' => 'repeat' ) ) );
		$this->add_control( 'repeat_alt', array( 'label' => 'Texto alternativo', 'type' => $c::TEXT, 'condition' => array( 'mode' => 'repeat' ) ) );
		$this->add_control( 'repeat_count', array( 'label' => 'Repeticiones', 'type' => $c::NUMBER, 'min' => 1, 'max' => 100, 'default' => 10, 'description' => 'En bucle continuo con espejo regula la velocidad equivalente de la onda.', 'condition' => array( 'mode' => 'repeat' ) ) );
		$this->add_control( 'mirror', array( 'label' => 'Reflejar elementos alternados', 'type' => $c::SWITCHER, 'return_value' => 'yes', 'default' => '', 'description' => 'En el bucle de una imagen repetida ocupa el ancho completo y conserva su proporción: no aplica separación, ancho máximo, altura fija ni radio que cortarían la unión.' ) );
		$this->add_control( 'label', array( 'label' => 'Nombre accesible del componente', 'type' => $c::TEXT, 'placeholder' => 'Logotipos de clientes' ) );
		$this->end_controls_section();

		$this->start_controls_section( 'movement', array( 'label' => 'Movimiento' ) );
		$this->add_control( 'animation', array( 'label' => 'Animación', 'type' => $c::SELECT, 'default' => 'continuous', 'options' => array( 'continuous' => 'Continua', 'off' => 'Desactivada' ) ) );
		$this->add_control( 'direction', array( 'label' => 'Dirección', 'type' => $c::SELECT, 'default' => 'left', 'options' => array( 'left' => 'Izquierda', 'right' => 'Derecha' ), 'condition' => array( 'animation' => 'continuous' ) ) );
		$this->add_control( 'speed', array( 'label' => 'Duración de un recorrido (segundos)', 'type' => $c::NUMBER, 'default' => 30, 'min' => 1, 'max' => 600, 'condition' => array( 'animation' => 'continuous' ), 'selectors' => array( '{{WRAPPER}} .digi-slider' => '--digi-duration: {{VALUE}}s;' ) ) );
		$this->add_control( 'infinite', array( 'label' => 'Loop infinito', 'type' => $c::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => array( 'animation' => 'continuous' ) ) );
		$this->add_control( 'pause', array( 'label' => 'Pausar al pasar el mouse', 'type' => $c::SWITCHER, 'return_value' => 'yes', 'default' => '', 'condition' => array( 'animation' => 'continuous' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 'style', array( 'label' => 'Estilo', 'tab' => $c::TAB_STYLE ) );
		$this->add_responsive_control( 'visible', array( 'label' => 'Elementos visibles', 'type' => $c::NUMBER, 'min' => 1, 'max' => 9, 'step' => 1, 'default' => 9, 'tablet_default' => 6, 'mobile_default' => 3, 'description' => 'Elige entre 1 y 9. Usa los iconos de escritorio, tableta y móvil para definir cada vista.', 'render_type' => 'template', 'selectors' => array( '{{WRAPPER}} .digi-slider' => '--digi-visible: {{VALUE}};' ) ) );
		$this->add_responsive_control( 'gap', array( 'label' => 'Separación', 'type' => $c::SLIDER, 'size_units' => array( 'px', 'em', 'rem' ), 'range' => array( 'px' => array( 'min' => 0, 'max' => 100 ) ), 'default' => array( 'size' => 16, 'unit' => 'px' ), 'description' => 'Con imagen repetida y espejo, las mitades se unen sin separación.', 'selectors' => array( '{{WRAPPER}} .digi-slider' => '--digi-gap: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'max_width', array( 'label' => 'Ancho máximo por elemento', 'type' => $c::SLIDER, 'size_units' => array( 'px', 'em', 'rem' ), 'range' => array( 'px' => array( 'min' => 20, 'max' => 1000 ) ), 'selectors' => array( '{{WRAPPER}} .digi-slider' => '--digi-max-width: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'width', array( 'label' => 'Ancho del slider', 'type' => $c::SLIDER, 'size_units' => array( '%', 'px', 'vw' ), 'range' => array( '%' => array( 'min' => 1, 'max' => 100 ), 'px' => array( 'min' => 50, 'max' => 2000 ) ), 'selectors' => array( '{{WRAPPER}} .digi-slider' => 'width: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_responsive_control( 'padding', array( 'label' => 'Relleno', 'type' => $c::DIMENSIONS, 'size_units' => array( 'px', 'em', 'rem' ), 'selectors' => array( '{{WRAPPER}} .digi-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
		$this->add_control( 'height_mode', array( 'label' => 'Altura', 'type' => $c::SELECT, 'default' => 'auto', 'options' => array( 'auto' => 'Automática', 'fixed' => 'Personalizada' ) ) );
		$this->add_responsive_control( 'height', array( 'label' => 'Altura personalizada', 'type' => $c::SLIDER, 'size_units' => array( 'px', 'em', 'rem' ), 'range' => array( 'px' => array( 'min' => 10, 'max' => 1000 ) ), 'condition' => array( 'height_mode' => 'fixed' ), 'selectors' => array( '{{WRAPPER}} .digi-slider' => '--digi-height: {{SIZE}}{{UNIT}};' ) ) );
		$this->add_control( 'object_fit', array( 'label' => 'Ajuste de imagen', 'type' => $c::SELECT, 'default' => 'contain', 'options' => array( 'contain' => 'Contain (logos)', 'cover' => 'Cover (banner)', 'fill' => 'Fill' ), 'selectors' => array( '{{WRAPPER}} .digi-slider img' => 'object-fit: {{VALUE}};' ) ) );
		$this->add_control( 'natural_width', array( 'label' => 'Ancho natural de imagen', 'type' => $c::SWITCHER, 'return_value' => 'yes', 'default' => '', 'condition' => array( 'mode' => 'repeat' ) ) );
		$this->add_control( 'align', array( 'label' => 'Alineación vertical', 'type' => $c::SELECT, 'default' => 'center', 'options' => array( 'start' => 'Arriba', 'center' => 'Centro', 'end' => 'Abajo' ), 'selectors' => array( '{{WRAPPER}} .digi-slider__group' => 'align-items: {{VALUE}};' ) ) );
		$this->add_control( 'radius', array( 'label' => 'Radio de borde', 'type' => $c::SLIDER, 'size_units' => array( 'px', 'em', 'rem' ), 'selectors' => array( '{{WRAPPER}} .digi-slider img' => 'border-radius: {{SIZE}}{{UNIT}};' ) ) );
		$this->end_controls_section();

		$this->start_controls_section( 'images_style', array( 'label' => 'Carga de imágenes', 'tab' => $c::TAB_STYLE ) );
		$this->add_control( 'image_size', array( 'label' => 'Tamaño registrado', 'type' => $c::SELECT, 'default' => 'large', 'options' => $this->image_sizes() ) );
		$this->add_control( 'loading', array( 'label' => 'Carga', 'type' => $c::SELECT, 'default' => 'auto', 'options' => array( 'auto' => 'Automática', 'lazy' => 'Lazy', 'eager' => 'Eager' ), 'description' => 'Las imágenes visibles al iniciar se cargan de inmediato para evitar espacios durante el movimiento.' ) );
		$this->add_control( 'priority', array( 'label' => 'Prioridad', 'type' => $c::SELECT, 'default' => 'auto', 'options' => array( 'auto' => 'Automática', 'high' => 'Alta', 'low' => 'Baja' ) ) );
		$this->end_controls_section();
	}

	private function image_sizes() {
		$sizes = array( 'full' => 'Original' );
		foreach ( get_intermediate_image_sizes() as $name ) $sizes[ $name ] = $name;
		return $sizes;
	}

	/** Evita el espacio provisional de las imágenes lazy cuando falta metadata del adjunto. */
	private function image_dimensions( $id, $size ) {
		static $cache = array();
		$key = ( function_exists( 'get_current_blog_id' ) ? get_current_blog_id() : 0 ) . ':' . $id . ':' . $size;
		if ( isset( $cache[ $key ] ) ) return $cache[ $key ];
		$dimensions = array();
		$source = wp_get_attachment_image_src( $id, $size );
		if ( is_array( $source ) && ! empty( $source[1] ) && ! empty( $source[2] ) ) $dimensions = array( absint( $source[1] ), absint( $source[2] ) );
		if ( ! $dimensions ) {
			$file = get_attached_file( $id );
			if ( $file && is_readable( $file ) ) {
				$actual = wp_getimagesize( $file );
				if ( is_array( $actual ) && ! empty( $actual[0] ) && ! empty( $actual[1] ) ) $dimensions = array( absint( $actual[0] ), absint( $actual[1] ) );
			}
		}
		return $cache[ $key ] = $dimensions;
	}

	private function image( $item, $settings, $decorative, $initial, $primary ) {
		$id = absint( $item['image']['id'] ?? 0 );
		if ( ! $id ) return '';
		$alt = $decorative ? '' : trim( (string) ( $item['alt'] ?? '' ) );
		if ( ! $decorative && '' === $alt ) $alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
		$size = sanitize_key( $settings['image_size'] ?? 'large' );
		if ( ! in_array( $size, get_intermediate_image_sizes(), true ) && 'full' !== $size ) $size = 'large';
		$attrs = array( 'alt' => $alt, 'decoding' => 'async' );
		$dimensions = $this->image_dimensions( $id, $size );
		if ( $dimensions ) { $attrs['width'] = $dimensions[0]; $attrs['height'] = $dimensions[1]; }
		$loading = $settings['loading'] ?? 'auto';
		$priority = $settings['priority'] ?? 'auto';
		if ( $initial ) $loading = 'eager';
		elseif ( 'auto' === $loading ) $loading = 'lazy';
		// Sin dimensiones no se debe crear un placeholder lazy de altura arbitraria.
		if ( ! $dimensions ) $loading = 'eager';
		if ( in_array( $loading, array( 'lazy', 'eager' ), true ) ) $attrs['loading'] = $decorative && ! $initial && $dimensions && 'eager' === $loading ? 'lazy' : $loading;
		if ( 'high' === $priority && $primary ) $attrs['fetchpriority'] = 'high';
		elseif ( 'low' === $priority && ! $decorative ) $attrs['fetchpriority'] = 'low';
		$desktop = max( 1, absint( $settings['visible'] ?? 9 ) );
		$tablet = max( 1, absint( $settings['visible_tablet'] ?? 6 ) );
		$mobile = max( 1, absint( $settings['visible_mobile'] ?? 3 ) );
		$mirror_loop = 'repeat' === ( $settings['mode'] ?? 'multiple' ) && 'yes' === ( $settings['mirror'] ?? '' ) && 'continuous' === ( $settings['animation'] ?? 'continuous' ) && 'yes' === ( $settings['infinite'] ?? 'yes' );
		$attrs['sizes'] = $mirror_loop ? '100vw' : '(max-width: 767px) ' . ceil( 100 / $mobile ) . 'vw, (max-width: 1024px) ' . ceil( 100 / $tablet ) . 'vw, ' . ceil( 100 / $desktop ) . 'vw';
		$html = wp_get_attachment_image( $id, $size, false, $attrs );
		if ( ! $html ) return '';
		$link = $item['link'] ?? array();
		$url = $decorative ? '' : esc_url( $link['url'] ?? '' );
		if ( $url ) {
			$rel = array();
			if ( ! empty( $link['nofollow'] ) ) $rel[] = 'nofollow';
			if ( ! empty( $link['is_external'] ) ) $rel[] = 'noopener';
			$html = '<a href="' . $url . '"' . ( $rel ? ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"' : '' ) . ( ! empty( $link['is_external'] ) ? ' target="_blank"' : '' ) . '>' . $html . '</a>';
		}
		return $html;
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$items = array();
		if ( 'repeat' === ( $s['mode'] ?? 'multiple' ) ) {
			$id = absint( $s['repeat_image']['id'] ?? 0 );
			if ( $id ) {
				$count = min( 100, max( 1, absint( $s['repeat_count'] ?? 10 ) ) );
				$items = array_fill( 0, $count, array( 'image' => $s['repeat_image'], 'alt' => $s['repeat_alt'] ?? '' ) );
			}
		} else {
			foreach ( (array) ( $s['gallery_images'] ?? array() ) as $image ) {
				if ( is_array( $image ) && absint( $image['id'] ?? 0 ) ) $items[] = array( 'image' => $image );
			}
			foreach ( (array) ( $s['images'] ?? array() ) as $item ) if ( absint( $item['image']['id'] ?? 0 ) ) $items[] = $item;
		}
		if ( ! $items ) return;
		$accessible_count = 'repeat' === ( $s['mode'] ?? 'multiple' ) ? 1 : count( $items );
		$animate = 'continuous' === ( $s['animation'] ?? 'continuous' );
		$infinite = $animate && 'yes' === ( $s['infinite'] ?? 'yes' );
		$mirror = 'yes' === ( $s['mirror'] ?? '' );
		$mirror_repeat = $mirror && 'repeat' === ( $s['mode'] ?? 'multiple' );
		$mirror_loop = $mirror_repeat && $infinite;
		$loop_duration = 0;
		$loop_scale    = 0;
		$sources_count = 0;
		// Elementos visibles por dispositivo: un campo vacío usa el valor de la hoja de estilos (9, 6 y 3) y los
		// breakpoints adicionales de Elementor (widescreen, laptop, tablet_extra, mobile_extra) también cuentan.
		$visible_values = array();
		foreach ( $s as $key => $value ) {
			if ( ( 'visible' === $key || 0 === strpos( (string) $key, 'visible_' ) ) && ! is_array( $value ) && '' !== trim( (string) $value ) ) $visible_values[ $key ] = absint( $value );
		}
		$visible_values += array( 'visible' => 9, 'visible_tablet' => 6, 'visible_mobile' => 3 );
		$max_visible = max( 1, max( $visible_values ) );
		$natural     = 'yes' === ( $s['natural_width'] ?? '' ) && 'repeat' === ( $s['mode'] ?? 'multiple' );
		$speed = is_numeric( $s['speed'] ?? null ) ? (float) $s['speed'] : 30.0;
		// Hasta 4.3.0.148 el bucle se rellenaba hasta este largo: la duración configurada se ajustó sobre él y se conserva su velocidad.
		$legacy_minimum = min( 30, max( 10, $max_visible ) );
		// Una serie par conserva la alternancia de espejos en la unión del loop.
		if ( $mirror_loop ) {
			$previous_count = max( $legacy_minimum, count( $items ) );
			if ( $previous_count % 2 ) ++$previous_count;
			$loop_duration = max( 2.0, min( 600.0, $speed ) * 2 / $previous_count );
			// Dos mitades forman el ciclo completo; el segundo grupo repite ese ciclo.
			$items         = array( $items[0], $items[0] );
			$sources_count = 1;
		} elseif ( $infinite ) {
			$source = $items;
			$ids    = array();
			foreach ( $items as $item ) $ids[ absint( $item['image']['id'] ?? 0 ) . '|' . (string) ( $item['alt'] ?? '' ) . '|' . (string) ( $item['link']['url'] ?? '' ) ] = true;
			// Varias copias de la misma imagen son una sola: el bucle la repite cuantas veces haga falta y se anuncia una vez.
			if ( 1 === count( $ids ) ) {
				$source           = array( $items[0] );
				$accessible_count = 1;
			}
			$previous_count = max( $legacy_minimum, count( $items ) );
			if ( $mirror && $previous_count % 2 ) ++$previous_count;
			// Un grupo cubre el viewport más un elemento en el dispositivo más exigente; con espejo, par. Con «Ancho natural»
			// cada copia mide lo que mide la imagen, no una fracción del viewport: se conserva el largo anterior.
			$need = $natural ? $legacy_minimum : $max_visible + 1;
			if ( $mirror && $need % 2 ) ++$need;
			$items = array();
			while ( count( $items ) < $need || count( $items ) < count( $source ) || ( $mirror && count( $items ) % 2 ) ) $items[] = $source[ count( $items ) % count( $source ) ];
			$sources_count = count( $source );
			// La duración es la de un grupo: si el grupo cambió de largo, se escala para que la velocidad lineal sea la misma.
			if ( count( $items ) !== $previous_count ) $loop_scale = max( 1 / max( 1.0, min( 600.0, $speed ) ), count( $items ) / $previous_count );
		}
		$classes = array( 'digi-slider' );
		if ( $animate ) {
			$classes[] = $infinite ? 'digi-slider--infinite' : 'digi-slider--once';
			// El carrusel comienza inmóvil hasta que se decodifiquen las imágenes visibles.
			$classes[] = 'digi-slider--preparing';
		}
		if ( 'right' === ( $s['direction'] ?? 'left' ) ) $classes[] = 'digi-slider--right';
		if ( 'yes' === ( $s['pause'] ?? '' ) ) $classes[] = 'digi-slider--pause';
		if ( 'yes' === ( $s['natural_width'] ?? '' ) && 'repeat' === ( $s['mode'] ?? '' ) ) $classes[] = 'digi-slider--natural';
		if ( $mirror ) $classes[] = 'digi-slider--mirror';
		if ( $mirror_repeat ) $classes[] = 'digi-slider--mirror-repeat';
		if ( $mirror_loop ) $classes[] = 'digi-slider--mirror-loop';
		if ( 'fixed' === ( $s['height_mode'] ?? 'auto' ) ) $classes[] = 'digi-slider--fixed';
		$label = trim( (string) ( $s['label'] ?? '' ) );
		// El ancho de cada grupo se declara (elementos × ancho de elemento): medido por el contenido, Firefox no resuelve las
		// unidades de contenedor y dejaba un hueco al final de cada grupo.
		$style = '--digi-count:' . count( $items ) . ( $loop_duration > 0 ? ';--digi-loop-duration:' . round( $loop_duration, 3 ) . 's' : ( $loop_scale > 0 ? ';--digi-loop-scale:' . round( $loop_scale, 4 ) : '' ) );
		echo '<div class="' . esc_attr( implode( ' ', $classes ) ) . '"' . ' style="' . esc_attr( $style ) . '"' . ( $sources_count ? ' data-digi-sources="' . (int) $sources_count . '"' : '' ) . ( $label ? ' role="group" aria-label="' . esc_attr( $label ) . '"' : '' ) . '><div class="digi-slider__viewport"><div class="digi-slider__track">';
		$this->group( $items, $s, $mirror, false, $accessible_count );
		if ( $infinite ) $this->group( $items, $s, $mirror, true, 0 );
		echo '</div></div></div>';
	}

	private function group( $items, $settings, $mirror, $decorative, $accessible_count ) {
		echo '<div class="digi-slider__group"' . ( $decorative ? ' aria-hidden="true"' : '' ) . '>';
		$count = count( $items );
		$visible = min( $count, max( 1, absint( $settings['visible'] ?? 9 ), absint( $settings['visible_tablet'] ?? 6 ), absint( $settings['visible_mobile'] ?? 3 ) ) );
		$warm = min( $count, $visible + 1 );
		$right = 'right' === ( $settings['direction'] ?? 'left' ) && 'continuous' === ( $settings['animation'] ?? 'continuous' );
		$infinite = $right && 'yes' === ( $settings['infinite'] ?? 'yes' );
		foreach ( $items as $index => $item ) {
			$item_decorative = $decorative || $index >= $accessible_count;
			// Todas las copias de una onda reflejada usan el mismo archivo: cargarlas
			// evita que una mitad aparezca vacía al entrar en el viewport.
			$initial = $mirror && 'repeat' === ( $settings['mode'] ?? 'multiple' )
				? true
				: ( $right ? ( $decorative ? $index < $warm : $index >= $count - $warm ) : ( ! $decorative && $index < $warm ) );
			$primary = $right ? ( $decorative ? 0 === $index : ( ! $infinite && $index === $count - $visible ) ) : ( ! $decorative && 0 === $index );
			$html = $this->image( $item, $settings, $item_decorative, $initial, $primary );
			if ( ! $html ) continue;
			echo '<div class="digi-slider__item' . ( $mirror && $index % 2 ? ' digi-slider__item--mirror' : '' ) . '"' . ( $item_decorative ? ' aria-hidden="true"' : '' ) . '>' . $html . '</div>';
		}
		echo '</div>';
	}
}
