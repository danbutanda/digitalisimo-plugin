<?php
defined( 'ABSPATH' ) || exit;

/** Chat editorial: herramienta de redacción de IA Tools, independiente de SEO. */
class Digitalisimo_AI_Article_Chat {
	const META_KEY = 'digitalisimo_article_chat';

	public static function init() {
		add_shortcode( 'digitalisimo_article_chat', array( __CLASS__, 'shortcode' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'metaboxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 30 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'public_assets' ), 20 );
	}

	private static function types() { return get_post_types( array( 'public' => true, 'show_ui' => true ), 'names' ); }
	private static function current_content_id() { global $wp_query, $post; $candidates = array( get_queried_object_id(), $wp_query instanceof WP_Query ? $wp_query->get_queried_object_id() : 0, $wp_query instanceof WP_Query && ! empty( $wp_query->post->ID ) ? $wp_query->post->ID : 0, ! empty( $post->ID ) ? $post->ID : 0, get_the_ID() ); foreach ( $candidates as $candidate ) { $id = absint( $candidate ); if ( $id && in_array( get_post_type( $id ), self::types(), true ) ) return $id; } return 0; }
	public static function public_assets() { if ( is_singular() ) wp_enqueue_style( 'digitalisimo-ai-article-dialogue', DIGITALISIMO_CHATBOT_URL . 'assets/article-dialogue.css', array(), DIGITALISIMO_CHATBOT_VERSION ); }
	public static function assets( $hook ) { if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) return; wp_enqueue_media(); wp_enqueue_style( 'digitalisimo-ai-article-chat', DIGITALISIMO_CHATBOT_URL . 'assets/article-chat.css', array(), DIGITALISIMO_CHATBOT_VERSION ); wp_enqueue_script( 'digitalisimo-ai-article-chat', DIGITALISIMO_CHATBOT_URL . 'assets/article-chat.js', array(), DIGITALISIMO_CHATBOT_VERSION, true ); }

	public static function metaboxes() { foreach ( self::types() as $type ) add_meta_box( 'digitalisimo-ai-article-chat', 'Digitalisimo IA · Chat del artículo', array( __CLASS__, 'box' ), $type, 'normal', 'default' ); }
	public static function box( $post ) {
		wp_nonce_field( 'digitalisimo_ai_article_chat_save', 'digitalisimo_ai_article_chat_nonce' ); $data = json_decode( (string) get_post_meta( $post->ID, self::META_KEY, true ), true ); $speakers = (array) ( $data['speakers'] ?? array() ); $messages = (array) ( $data['messages'] ?? array() );
		if ( ! $speakers ) $speakers = array( array( 'id' => 'user', 'name' => 'Empresario', 'icon' => '🧑', 'align' => 'end' ), array( 'id' => 'maryia', 'name' => 'MaryIA', 'icon' => '🤖', 'align' => 'center' ), array( 'id' => 'daniel', 'name' => 'Daniel', 'icon' => '👨‍💼', 'align' => 'start' ) );
		if ( ! $messages ) $messages = array( array( 'speaker' => 'user', 'text' => 'Tengo una duda sobre este tema.' ), array( 'speaker' => 'maryia', 'text' => 'Consulta recibida. Revisemos los datos.' ), array( 'speaker' => 'daniel', 'text' => 'Lo aterrizamos a una decisión clara.' ) );
		echo '<div class="digitalisimo-article-chat-editor"><p>Herramienta de redacción de IA Tools. Ordena los mensajes como deben mostrarse de arriba hacia abajo.</p><h4>Personajes</h4><div class="digitalisimo-chat-speakers">';
		foreach ( $speakers as $speaker ) { $key = sanitize_key( $speaker['id'] ?? uniqid( 'speaker_' ) ); echo '<div class="digitalisimo-chat-speaker"><input type="hidden" name="digitalisimo_article_chat_speakers[' . esc_attr( $key ) . '][id]" value="' . esc_attr( $key ) . '"><label class="digitalisimo-chat-field">Nombre <input class="regular-text digitalisimo-chat-name" name="digitalisimo_article_chat_speakers[' . esc_attr( $key ) . '][name]" value="' . esc_attr( $speaker['name'] ?? '' ) . '"></label> <label class="digitalisimo-chat-field">Icono <input class="small-text" name="digitalisimo_article_chat_speakers[' . esc_attr( $key ) . '][icon]" value="' . esc_attr( $speaker['icon'] ?? '💬' ) . '"></label> <label class="digitalisimo-chat-field">Alineación <select name="digitalisimo_article_chat_speakers[' . esc_attr( $key ) . '][align]">'; foreach ( array( 'start' => 'Izquierda', 'center' => 'Centro', 'end' => 'Derecha' ) as $align => $label ) echo '<option value="' . esc_attr( $align ) . '" ' . selected( $speaker['align'] ?? '', $align, false ) . '>' . esc_html( $label ) . '</option>'; echo '</select></label><input type="hidden" class="digitalisimo-chat-image-id" name="digitalisimo_article_chat_speakers[' . esc_attr( $key ) . '][image_id]" value="' . absint( $speaker['image_id'] ?? 0 ) . '"><button type="button" class="button digitalisimo-chat-media">Elegir foto</button> <span class="digitalisimo-chat-image-status">' . ( ! empty( $speaker['image_id'] ) ? 'Foto seleccionada.' : 'Sin foto: se usará el icono.' ) . '</span> <button type="button" class="button-link-delete digitalisimo-chat-remove-speaker">Quitar personaje</button></div>'; }
		echo '</div><p><button type="button" class="button digitalisimo-chat-add-speaker">Añadir personaje</button></p><h4>Conversación</h4><div class="digitalisimo-chat-messages">'; foreach ( $messages as $message ) echo '<div class="digitalisimo-chat-message"><select class="digitalisimo-chat-message-speaker" name="digitalisimo_article_chat_messages[][speaker]" data-selected="' . esc_attr( $message['speaker'] ?? '' ) . '"></select><textarea rows="2" name="digitalisimo_article_chat_messages[][text]">' . esc_textarea( $message['text'] ?? '' ) . '</textarea><button type="button" class="button-link-delete digitalisimo-chat-remove-message">Quitar</button></div>'; echo '</div><p><button type="button" class="button button-secondary digitalisimo-chat-add-message">Añadir mensaje</button></p><p><code>[digitalisimo_article_chat]</code> se puede colocar dentro del contenido o en la plantilla individual de Elementor.</p></div>';
	}
	public static function save( $id ) {
		if ( wp_is_post_revision( $id ) || ! isset( $_POST['digitalisimo_ai_article_chat_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['digitalisimo_ai_article_chat_nonce'] ) ), 'digitalisimo_ai_article_chat_save' ) || ! current_user_can( 'edit_post', $id ) ) return;
		// Guardados de Elementor, imagen destacada, revisiones y Quick Edit pueden
		// conservar el nonce, pero omitir parcial o totalmente los campos del chat.
		// El metadato existente sólo puede cambiar con una conversación completa.
		if ( ! isset( $_POST['digitalisimo_article_chat_speakers'], $_POST['digitalisimo_article_chat_messages'] ) || ! is_array( $_POST['digitalisimo_article_chat_speakers'] ) || ! is_array( $_POST['digitalisimo_article_chat_messages'] ) ) return;
		$speakers = array();
		foreach ( $_POST['digitalisimo_article_chat_speakers'] as $row ) {
			$key = sanitize_key( $row['id'] ?? '' );
			$name = sanitize_text_field( $row['name'] ?? '' );
			if ( $key && $name ) $speakers[] = array( 'id' => $key, 'name' => $name, 'icon' => sanitize_text_field( $row['icon'] ?? '💬' ), 'image_id' => absint( $row['image_id'] ?? 0 ), 'align' => in_array( $row['align'] ?? '', array( 'start', 'center', 'end' ), true ) ? $row['align'] : 'start' );
		}
		$ids = wp_list_pluck( $speakers, 'id' );
		$messages = array();
		foreach ( $_POST['digitalisimo_article_chat_messages'] as $row ) {
			$speaker = sanitize_key( $row['speaker'] ?? '' );
			$text = sanitize_textarea_field( $row['text'] ?? '' );
			if ( $text && in_array( $speaker, $ids, true ) ) $messages[] = array( 'speaker' => $speaker, 'text' => $text );
		}
		if ( ! $speakers || ! $messages ) return;
		update_post_meta( $id, self::META_KEY, wp_json_encode( array( 'speakers' => $speakers, 'messages' => $messages ), JSON_UNESCAPED_UNICODE ) );
	}
	public static function shortcode() { $data = json_decode( (string) get_post_meta( self::current_content_id(), self::META_KEY, true ), true ); if ( empty( $data['speakers'] ) || empty( $data['messages'] ) ) return ''; $speakers = array(); foreach ( (array) $data['speakers'] as $speaker ) if ( ! empty( $speaker['id'] ) && ! empty( $speaker['name'] ) ) $speakers[ sanitize_key( $speaker['id'] ) ] = $speaker; if ( ! $speakers ) return ''; $html = '<div class="digitalisimo-dialogue digitalisimo-article-chat" aria-label="Conversación">'; $rendered = 0; foreach ( (array) $data['messages'] as $message ) { $id = sanitize_key( $message['speaker'] ?? '' ); if ( empty( $speakers[ $id ] ) || empty( $message['text'] ) ) continue; $speaker = $speakers[ $id ]; $align = in_array( $speaker['align'] ?? '', array( 'start', 'center', 'end' ), true ) ? $speaker['align'] : 'start'; $avatar = ! empty( $speaker['image_id'] ) ? wp_get_attachment_image( absint( $speaker['image_id'] ), 'thumbnail', false, array( 'class' => 'digitalisimo-chat-avatar' ) ) : '<span class="digitalisimo-chat-icon" aria-hidden="true">' . esc_html( $speaker['icon'] ?? '💬' ) . '</span>'; $html .= '<p class="digitalisimo-dialogue-' . esc_attr( $align ) . '">' . $avatar . '<strong>' . esc_html( $speaker['name'] ) . '</strong>' . esc_html( $message['text'] ) . '</p>'; $rendered++; } return $rendered ? $html . '</div>' : ''; }
}
