<?php

/**
 * prime192v1
 *
 * PHP version 5 and 7
 *
 * @author    Jim Wigginton <terrafrost@php.net>
 * @copyright 2017 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://pear.php.net/package/Math_BigInteger
 */

namespace DigitalisimoBackups\Vendor\phpseclib3\Crypt\EC\Curves;

final class prime192v1 extends secp192r1
{
}
