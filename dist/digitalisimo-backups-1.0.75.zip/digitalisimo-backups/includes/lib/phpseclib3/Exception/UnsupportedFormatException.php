<?php

/**
 * UnsupportedFormatException
 *
 * PHP version 5
 *
 * @author    Jim Wigginton <terrafrost@php.net>
 * @copyright 2015 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://phpseclib.sourceforge.net
 */

namespace DigitalisimoBackups\Vendor\phpseclib3\Exception;

/**
 * UnsupportedFormatException
 *
 * @author  Jim Wigginton <terrafrost@php.net>
 */
class UnsupportedFormatException extends \RuntimeException
{
}
