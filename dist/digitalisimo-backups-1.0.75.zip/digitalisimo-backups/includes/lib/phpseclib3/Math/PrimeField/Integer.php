<?php

/**
 * Prime Finite Fields
 *
 * PHP version 5 and 7
 *
 * @author    Jim Wigginton <terrafrost@php.net>
 * @copyright 2017 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 */

namespace DigitalisimoBackups\Vendor\phpseclib3\Math\PrimeField;

use DigitalisimoBackups\Vendor\phpseclib3\Common\Functions\Strings;
use DigitalisimoBackups\Vendor\phpseclib3\Math\BigInteger;
use DigitalisimoBackups\Vendor\phpseclib3\Math\Common\FiniteField\Integer as Base;

/**
 * Prime Finite Fields
 *
 * @author  Jim Wigginton <terrafrost@php.net>
 */
class Integer extends Base
{
    /**
     * Holds the PrimeField's value
     *
     * @var BigInteger
     */
    protected $value;

    /**
     * Keeps track of current instance
     *
     * @var int
     */
    protected $instanceID;

    /**
     * Holds the PrimeField's modulo
     *
     * @var array<int, BigInteger>
     */
    protected static $modulo;

    /**
     * Holds a pre-generated function to perform modulo reductions
     *
     * @var array<int, callable(BigInteger):BigInteger>
     */
    protected static $reduce;

    /**
     * Zero
     *
     * @var BigInteger[]
     */
    protected static $zero;

    /**
     * One
     *
     * @var BigInteger[]
     */
    protected static $one;

    /**
     * Two
     *
     * @var BigInteger[]
     */
    protected static $two;

    /**
     * Constant Time Mask
     *
     * @var BigInteger[]
     */
    protected static $mask;

    /**
     * Default constructor
     *
     * @param int $instanceID
     * @param BigInteger $num
     */
    public function __construct($instanceID, $num = null)
    {
        $this->instanceID = $instanceID;
        if (!isset($num)) {
            $this->value = clone static::$zero[$instanceID];
        } else {
            $reduce = static::$reduce[$instanceID];
            $this->value = $reduce($num);
        }
    }

    /**
     * Set the modulo for a given instance
     *
     * @param int $instanceID
     * @return void
     */
    public static function setModulo($instanceID, BigInteger $modulo)
    {
        static::$modulo[$instanceID] = $modulo;
        $one = new BigInteger(1);
        static::$mask[$instanceID] = [
            new BigInteger(0),
            $one->bitwise_leftShift($modulo->getLength())->subtract($one)
        ];
    }

    /**
     * Set the modulo for a given instance
     *
     * @param int $instanceID
     * @return void
     */
    public static function setRecurringModuloFunction($instanceID, callable $function)
    {
        static::$reduce[$instanceID] = $function;
        if (!isset(static::$zero[$instanceID])) {
            static::$zero[$instanceID] = new BigInteger();
        }
    }

    /**
     * Delete the modulo for a given instance
     */
    public static function cleanupCache($instanceID)
    {
        unset(static::$modulo[$instanceID]);
        unset(static::$reduce[$instanceID]);
        unset(static::$zero[$instanceID]);
        unset(static::$one[$instanceID]);
        unset(static::$two[$instanceID]);
        unset(static::$mask[$instanceID]);
    }

    /**
     * Returns the modulo
     *
     * @param int $instanceID
     * @return BigInteger
     */
    public static function getModulo($instanceID)
    {
        return static::$modulo[$instanceID];
    }

    /**
     * Tests a parameter to see if it's of the right instance
     *
     * Throws an exception if the incorrect class is being utilized
     *
     * @return void
     */
    public static function checkInstance(self $x, self $y)
    {
        if ($x->instanceID != $y->instanceID) {
            throw new \UnexpectedValueException('The instances of the two PrimeField\Integer objects do not match');
        }
    }

    /**
     * Tests the equality of two numbers.
     *
     * @return bool
     */
    public function equals(self $x)
    {
        static::checkInstance($this, $x);

        return $this->value->equals($x->value);
    }

    /**
     * Compares two numbers.
     *
     * @return int
     */
    public function compare(self $x)
    {
        static::checkInstance($this, $x);

        return $this->value->compare($x->value);
    }

    /**
     * Conditionally add the modulus, without branching on the value.
     *
     * $diff must be in (-modulo, modulo). Returns $diff + modulo when $diff is
     * negative, $diff otherwise.
     *
     * @return static
     */
    private function conditionalAddModulo(BigInteger $diff)
    {
        $mask = static::$mask[$this->instanceID][(int) $diff->isNegative()];

        $temp = new static($this->instanceID);
        $temp->value = $diff->add(
            static::$modulo[$this->instanceID]->bitwise_and($mask)
        );
        return $temp;
    }

    /**
     * Adds two PrimeFieldIntegers.
     *
     * @return static
     */
    public function add(self $x)
    {
        static::checkInstance($this, $x);

        // $this->value + $x->value is in [0, 2m), so subtracting once lands in [-m, m)
        return $this->conditionalAddModulo(
            $this->value->add($x->value)->subtract(static::$modulo[$this->instanceID])
        );
    }

    /**
     * Subtracts two PrimeFieldIntegers.
     *
     * @return static
     */
    public function subtract(self $x)
    {
        static::checkInstance($this, $x);

        // already in (-m, m)
        return $this->conditionalAddModulo($this->value->subtract($x->value));
    }

    /**
     * Multiplies two PrimeFieldIntegers.
     *
     * @return static
     */
    public function multiply(self $x)
    {
        static::checkInstance($this, $x);

        return new static($this->instanceID, $this->value->multiply($x->value));
    }

    /**
     * Divides two PrimeFieldIntegers.
     *
     * @return static
     */
    public function divide(self $x)
    {
        static::checkInstance($this, $x);

        $denominator = $x->value->modInverse(static::$modulo[$this->instanceID]);
        return new static($this->instanceID, $this->value->multiply($denominator));
    }

    /**
     * Performs power operation on a PrimeFieldInteger.
     *
     * @return static
     */
    public function pow(BigInteger $x)
    {
        $temp = new static($this->instanceID);
        $temp->value = $this->value->powMod($x, static::$modulo[$this->instanceID]);

        return $temp;
    }

    /**
     * Calculates the square root
     *
     * @link https://en.wikipedia.org/wiki/Tonelli%E2%80%93Shanks_algorithm
     * @return static|false
     */
    public function squareRoot()
    {
        if (!isset(static::$one[$this->instanceID])) {
            static::$one[$this->instanceID] = new BigInteger(1);
            static::$two[$this->instanceID] = new BigInteger(2);
        }
        $one = &static::$one[$this->instanceID];
        $two = &static::$two[$this->instanceID];
        $modulo = &static::$modulo[$this->instanceID];
        $reduce = &static::$reduce[$this->instanceID];

        $p_1 = $modulo->subtract($one);
        $q = clone $p_1;
        $s = BigInteger::scan1divide($q);
        list($pow) = $p_1->divide($two);
        for ($z = $one; !$z->equals($modulo); $z = $z->add($one)) {
            $temp = $z->powMod($pow, $modulo);
            if ($temp->equals($p_1)) {
                break;
            }
        }

        $m = new BigInteger($s);
        $c = $z->powMod($q, $modulo);
        $t = $this->value->powMod($q, $modulo);
        list($temp) = $q->add($one)->divide($two);
        $r = $this->value->powMod($temp, $modulo);

        while (!$t->equals($one)) {
            for ($i = clone $one; $i->compare($m) < 0; $i = $i->add($one)) {
                if ($t->powMod($two->pow($i), $modulo)->equals($one)) {
                    break;
                }
            }

            if ($i->compare($m) == 0) {
                return false;
            }
            $b = $c->powMod($two->pow($m->subtract($i)->subtract($one)), $modulo);
            $m = $i;
            $c = $reduce($b->multiply($b));
            $t = $reduce($t->multiply($c));
            $r = $reduce($r->multiply($b));
        }

        return new static($this->instanceID, $r);
    }

    /**
     * Is Odd?
     *
     * @return bool
     */
    public function isOdd()
    {
        return $this->value->isOdd();
    }

    /**
     * Negate
     *
     * A negative number can be written as 0-12. With modulos, 0 is the same thing as the modulo
     * so 0-12 is the same thing as modulo-12
     *
     * @return static
     */
    public function negate()
    {
        return new static($this->instanceID, static::$modulo[$this->instanceID]->subtract($this->value));
    }

    /**
     * Converts an Integer to a byte string (eg. base-256).
     *
     * @return string
     */
    public function toBytes()
    {
        if (isset(static::$modulo[$this->instanceID])) {
            $length = static::$modulo[$this->instanceID]->getLengthInBytes();
            return str_pad($this->value->toBytes(), $length, "\0", STR_PAD_LEFT);
        }
        return $this->value->toBytes();
    }

    /**
     * Converts an Integer to a hex string (eg. base-16).
     *
     * @return string
     */
    public function toHex()
    {
        return Strings::bin2hex($this->toBytes());
    }

    /**
     * Converts an Integer to a bit string (eg. base-2).
     *
     * @return string
     */
    public function toBits()
    {
        // return $this->value->toBits();
        static $length;
        if (!isset($length)) {
            $length = static::$modulo[$this->instanceID]->getLength();
        }

        return str_pad($this->value->toBits(), $length, '0', STR_PAD_LEFT);
    }

    /**
     * Returns the w-ary non-adjacent form (wNAF)
     *
     * @param int $w optional
     * @return array<int, int>
     */
    public function getNAF($w = 1)
    {
        $w++;

        $zero = &static::$zero[$this->instanceID];

        $mask = new BigInteger((1 << $w) - 1);
        $sub = new BigInteger(1 << $w);
        //$sub = new BigInteger(1 << ($w - 1));
        $d = $this->toBigInteger();
        $d_i = [];

        $i = 0;
        while ($d->compare($zero) > 0) {
            if ($d->isOdd()) {
                // start mods

                $bigInteger = $d->testBit($w - 1) ?
                    $d->bitwise_and($mask)->subtract($sub) :
                    //$sub->subtract($d->bitwise_and($mask)) :
                    $d->bitwise_and($mask);
                // end mods
                $d = $d->subtract($bigInteger);
                $d_i[$i] = (int) $bigInteger->toString();
            } else {
                $d_i[$i] = 0;
            }
            $shift = !$d->equals($zero) && $d->bitwise_and($mask)->equals($zero) ? $w : 1; // $w or $w + 1?
            $d = $d->bitwise_rightShift($shift);
            while (--$shift > 0) {
                $d_i[++$i] = 0;
            }
            $i++;
        }

        return $d_i;
    }

    /**
     * Converts an Integer to a BigInteger
     *
     * @return BigInteger
     */
    public function toBigInteger()
    {
        return clone $this->value;
    }

    /**
     *  __toString() magic method
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->value;
    }

    /**
     *  __debugInfo() magic method
     *
     * @return array
     */
    public function __debugInfo()
    {
        return ['value' => $this->toHex()];
    }
}
