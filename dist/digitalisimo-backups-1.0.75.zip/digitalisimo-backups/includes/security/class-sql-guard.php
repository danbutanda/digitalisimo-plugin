<?php
defined( 'ABSPATH' ) || exit;

/**
 * Divide el SQL de un respaldo en sentencias, leyendo por fragmentos. Es el único divisor: el análisis previo y la
 * importación ven exactamente las mismas sentencias. Conserva la semántica que tuvo siempre la importación: comillas
 * ' " ` con escape por barra invertida, «;» fuera de comillas termina la sentencia y una sentencia que empieza por
 * «--» no se ejecuta.
 */
final class Digitalisimo_Backups_Sql_Reader {
	private $current = '';
	private $quote = '';
	private $escaped = false;
	/** Bytes ya leídos y, de cada sentencia que devolvió el último feed(), la posición justo después de su «;». */
	private $fed = 0;
	private $ends = array();

	public function feed( $chunk ) {
		$out = array();
		$this->ends = array();
		$length = strlen( $chunk );
		$i = 0;
		while ( $i < $length ) {
			if ( $this->escaped ) { $this->current .= $chunk[ $i++ ]; $this->escaped = false; continue; }
			if ( '' !== $this->quote ) {
				$run = strcspn( $chunk, '\\' . $this->quote, $i );
				$this->current .= substr( $chunk, $i, $run );
				$i += $run;
				if ( $i >= $length ) break;
				$char = $chunk[ $i++ ];
				$this->current .= $char;
				if ( '\\' === $char ) $this->escaped = true; else $this->quote = '';
				continue;
			}
			$run = strcspn( $chunk, "'\"`;", $i );
			$this->current .= substr( $chunk, $i, $run );
			$i += $run;
			if ( $i >= $length ) break;
			$char = $chunk[ $i++ ];
			if ( ';' === $char ) {
				$statement = trim( $this->current );
				if ( '' !== $statement && 0 !== strpos( $statement, '--' ) ) { $out[] = $statement; $this->ends[] = $this->fed + $i; }
				$this->current = '';
				continue;
			}
			$this->quote = $char;
			$this->current .= $char;
		}
		$this->fed += $length;
		return $out;
	}
	/**
	 * Posiciones (desde el primer byte leído) justo después del «;» de cada sentencia del último feed(). Una
	 * restauración por tramos sigue desde una de ellas con un lector nuevo: tras un «;» fuera de comillas no queda estado.
	 */
	public function ends() { return $this->ends; }
	public function finish() {
		if ( '' !== $this->quote ) throw new Exception( 'La base de datos del ZIP termina con una cadena SQL incompleta.' );
		$statement = trim( $this->current );
		$this->current = '';
		return '' !== $statement && 0 !== strpos( $statement, '--' ) ? array( $statement ) : array();
	}
}

/**
 * Lista blanca de sentencias. Dialecto «exporter»: lo que escribió cualquier versión de DIGITALÍSIMO Backups (SET NAMES,
 * SET foreign_key_checks, DROP TABLE IF EXISTS, CREATE TABLE e INSERT INTO con cadenas o NULL) sobre tablas del
 * manifiesto. Dialecto «mysqldump»: además lo que escriben UpdraftPlus y mysqldump, siempre como no confiable. En un
 * archivo no confiable CREATE TABLE no puede usar DATA/INDEX DIRECTORY, CONNECTION, UNION, motores remotos ni las
 * formas LIKE o SELECT. Se ejecuta dos veces: en seco antes de la copia previa y por sentencia al importar.
 */
final class Digitalisimo_Backups_Sql_Guard {
	const EXPORTER = 'exporter';
	const MYSQLDUMP = 'mysqldump';
	const SESSION_VARIABLES = array( 'FOREIGN_KEY_CHECKS', 'UNIQUE_CHECKS', 'SQL_MODE', 'SQL_NOTES', 'TIME_ZONE', 'CHARACTER_SET_CLIENT', 'CHARACTER_SET_RESULTS', 'COLLATION_CONNECTION', 'AUTOCOMMIT', 'SQL_QUOTE_SHOW_CREATE' );
	const SAFE_CHARSETS = array( 'UTF8MB4', 'UTF8', 'UTF8MB3', 'BINARY', 'LATIN1', 'ASCII' );
	const SENSITIVE = array( 'SQL_MODE', 'CHARACTER_SET_CLIENT', 'CHARACTER_SET_RESULTS', 'COLLATION_CONNECTION' );
	const REMOTE_ENGINES = array( 'FEDERATED', 'CONNECT', 'SPIDER', 'MERGE', 'MRG_MYISAM' );
	const CREATE_DENIED = array( 'DIRECTORY', 'CONNECTION', 'UNION', 'SELECT', 'LOAD_FILE', 'INTO', 'OUTFILE', 'DUMPFILE' );
	private $dialect;
	private $trusted;
	private $tables;
	private $prefix;
	private $count = 0;
	private $safe_vars = array();
	private $s = '';
	private $i = 0;
	private $n = 0;
	private $kind = '';
	private $excerpt_end = 0;
	/** Tablas que cambian de nombre al importar (nombre del respaldo => nombre nuevo) y tramos que cambian en la sentencia. */
	private $renames = array();
	private $spans = array();
	private $nested = false;
	/** Gancho que recibe cada INSERT comprobado (tabla, columnas y posición de cada literal) y devuelve tramos que cambian. */
	private $insert_hook = null;
	private $insert = null;
	/** Tablas que se comprueban pero no se ejecutan, y si la sentencia en curso no se ejecuta. */
	private $skips = array();
	private $skip_current = false;
	/** Con el renombrado en seco (verify y la pasada previa a la restauración), lo que no se puede renombrar se anota. */
	private $rename_strict = true;
	private $rename_problems = array();

	/** $tables: lista del manifiesto v3; sin ella, $prefix (si no es vacío) acota las tablas. */
	public function __construct( $dialect, $trusted, $tables = null, $prefix = '' ) {
		$this->dialect = self::MYSQLDUMP === $dialect ? self::MYSQLDUMP : self::EXPORTER;
		$this->trusted = (bool) $trusted && self::EXPORTER === $this->dialect;
		$this->tables = is_array( $tables ) ? array_fill_keys( array_map( 'strval', $tables ), true ) : null;
		$this->prefix = (string) $prefix;
	}
	/** Reglas de un respaldo propio según su manifiesto y su nivel de confianza. */
	public static function for_backup( $manifest, $trusted ) {
		$v3 = is_array( $manifest ) && 'digitalisimo-backup/v3' === ( $manifest['format'] ?? '' ) && is_array( $manifest['database_tables'] ?? null );
		return new self( self::EXPORTER, $trusted, $v3 ? $manifest['database_tables'] : null, $v3 || $trusted ? '' : (string) ( $GLOBALS['wpdb']->base_prefix ?? '' ) );
	}

	/**
	 * Al importar, las tablas de $map (nombre en el respaldo => nombre nuevo) se crean, vacían y llenan con su nombre
	 * nuevo, también en `REFERENCES` de una clave foránea. Se cambia el identificador exacto que leyó el análisis, nunca
	 * por búsqueda de texto. Una vista u otro objeto que no es una tabla, o una tabla dentro de un comentario
	 * ejecutable, se rechazan: no se puede asegurar su nombre nuevo.
	 */
	public function rename_tables( array $map, $strict = true ) {
		foreach ( $map as $from => $to ) if ( (string) $from !== (string) $to ) $this->renames[ (string) $from ] = (string) $to;
		$this->rename_strict = (bool) $strict;
		return $this;
	}
	/** Sin $strict (pasada en seco): lo que no se puede renombrar, en el orden en que apareció. */
	public function rename_problems() { return array_values( array_unique( $this->rename_problems ) ); }
	/** Estas tablas se comprueban como las demás, pero sus sentencias no se ejecutan (ni DROP, ni CREATE, ni INSERT). */
	public function skip_tables( array $tables ) {
		foreach ( $tables as $table ) $this->skips[ (string) $table ] = true;
		return $this;
	}
	/** La última sentencia comprobada no se ejecuta (tabla omitida o fila que el gancho descartó). */
	public function skipped() { return $this->skip_current; }
	private function cannot_rename( $why ) {
		if ( $this->rename_strict ) $this->reject( $why );
		$this->rename_problems[] = $why;
	}
	/**
	 * $hook( array $insert, string $sql ) recibe cada INSERT permitido: `table` (nombre en el respaldo), `columns` (o null
	 * sin lista de columnas) y `rows`, una lista por fila con, por valor, array( type => 'str', quote, start, end ) (el
	 * contenido entre comillas, tal como está en $sql), null para NULL o array( type => 'raw'|'other' ). Devuelve tramos
	 * array( inicio, fin, texto ) que reemplazan el contenido de esos literales en la sentencia que se ejecuta, o false
	 * para no ejecutarla.
	 */
	public function on_insert( callable $hook ) {
		$this->insert_hook = $hook;
		return $this;
	}
	/** La última sentencia comprobada, con los nombres de tabla y los literales cambiados ('' si no se ejecuta). */
	public function rewritten() {
		if ( $this->skip_current ) return '';
		if ( ! $this->spans ) return $this->s;
		$spans = $this->spans;
		usort( $spans, function( $a, $b ) { return $a[0] - $b[0]; } );
		// Una sola pasada: los tramos se copian en orden, sin rehacer la sentencia entera por cada uno.
		$parts = array();
		$at = 0;
		foreach ( $spans as $span ) {
			if ( $span[0] < $at || $span[0] > $span[1] ) throw new Exception( 'Cambios superpuestos en una sentencia del respaldo.' );
			$parts[] = substr( $this->s, $at, $span[0] - $at );
			$parts[] = $span[2];
			$at = $span[1];
		}
		$parts[] = substr( $this->s, $at );
		return implode( '', $parts );
	}

	/** Recorre el SQL completo del ZIP sin ejecutar nada. */
	public function scan_zip( $zip ) {
		$stream = $zip->getStream( 'database.sql' );
		if ( ! $stream ) throw new Exception( 'No se pudo leer la base de datos del ZIP.' );
		try {
			return $this->scan( function() use ( $stream ) {
				if ( feof( $stream ) ) return null;
				$chunk = fread( $stream, 65536 );
				if ( false === $chunk || ( '' === $chunk && ! feof( $stream ) ) ) throw new Exception( 'La base de datos del ZIP está truncada.' );
				return $chunk;
			} );
		} finally {
			fclose( $stream );
		}
	}
	/** $read devuelve un fragmento, o null al terminar. $run recibe cada sentencia permitida. */
	public function scan( $read, $run = null ) {
		$reader = new Digitalisimo_Backups_Sql_Reader();
		$executed = 0;
		while ( null !== ( $chunk = call_user_func( $read ) ) ) {
			foreach ( $reader->feed( $chunk ) as $statement ) if ( $this->check( $statement ) ) { if ( $run && ! $this->skip_current ) call_user_func( $run, $this->rewritten() ); $executed++; }
		}
		foreach ( $reader->finish() as $statement ) if ( $this->check( $statement ) ) { if ( $run && ! $this->skip_current ) call_user_func( $run, $this->rewritten() ); $executed++; }
		if ( ! $executed ) throw new Exception( 'La base de datos del respaldo está vacía.' );
		return $executed;
	}

	/** Una restauración por tramos sigue contando desde la sentencia en la que se quedó (para los mensajes de error). */
	public function start_at( $count ) {
		$this->count = max( 0, (int) $count );
		return $this;
	}
	public function count() { return $this->count; }
	/** true si la sentencia se ejecuta, false si sólo trae comentarios; excepción si no está permitida. */
	public function check( $sql ) {
		$this->count++;
		$this->s = (string) $sql;
		$this->i = 0;
		$this->n = strlen( $this->s );
		$this->kind = '';
		$this->excerpt_end = 80;
		$this->spans = array();
		$this->insert = null;
		$this->nested = false;
		$this->skip_current = false;
		try {
			$allowed = $this->statement();
			if ( $allowed && ! $this->skip_current && $this->insert_hook && null !== $this->insert ) {
				$spans = call_user_func( $this->insert_hook, $this->insert, $this->s );
				if ( false === $spans ) $this->skip_current = true;
				else foreach ( (array) $spans as $span ) $this->spans[] = $span;
			}
			return $allowed;
		} catch ( UnexpectedValueException $e ) {
			$excerpt = preg_replace( '/[\x00-\x1F\x7F]+/', ' ', substr( $this->s, 0, min( 80, $this->excerpt_end ) ) );
			throw new Exception( 'La base de datos del respaldo trae una sentencia no permitida (sentencia ' . $this->count . ( $this->kind ? ', ' . $this->kind : '' ) . '): ' . $e->getMessage() . ' «' . $excerpt . ( $this->n > min( 80, $this->excerpt_end ) ? '…' : '' ) . '».' );
		}
	}
	private function reject( $why ) { throw new UnexpectedValueException( $why ); }

	private function statement() {
		$token = $this->next();
		if ( 'end' === $token[0] ) return false;
		if ( 'exec' === $token[0] ) {
			if ( self::MYSQLDUMP !== $this->dialect ) $this->reject( 'comentario ejecutable fuera de lo que escribe el exportador' );
			if ( self::unreachable( $token ) ) return $this->statement(); // Versión inalcanzable: es un comentario.
			$this->sub( $token[1], 'executable' );
			$this->end();
			return true;
		}
		if ( 'word' !== $token[0] ) $this->reject( 'no empieza por una instrucción' );
		$this->kind = $token[1];
		switch ( $token[1] ) {
			case 'SET': $this->set(); break;
			case 'DROP': $this->words( array( 'TABLE' ) ); $this->kind = 'DROP TABLE'; $this->words( array( 'IF', 'EXISTS' ) ); $this->table(); $this->end(); break;
			case 'CREATE': $this->create(); break;
			case 'INSERT': $this->insert(); break;
			default:
				if ( self::MYSQLDUMP === $this->dialect && $this->dump_statement( $token[1] ) ) break;
				$this->reject( 'tipo de sentencia no permitido en un respaldo' );
		}
		return true;
	}
	/**
	 * Un comentario ejecutable que ningún servidor ejecuta. /*M! sólo lo lee MariaDB, que entiende seis dígitos: desde
	 * 900000 es inalcanzable. /*! también lo lee MySQL, que puede tomar sólo los cinco primeros dígitos (900000 sería
	 * 9.0.0 seguido de «0 …»): sólo es inalcanzable si también lo son esos cinco (999990 a 999999).
	 */
	private static function unreachable( $token ) { return ! empty( $token[3] ) ? $token[2] >= 900000 : $token[2] >= 999990; }
	/** Contenido de un /*!NNNNN … *\/ del volcado: sólo SET o ALTER TABLE … KEYS. */
	private function sub( $content, $mode ) {
		$saved = array( $this->s, $this->i, $this->n );
		$this->s = $content;
		$this->i = 0;
		$this->n = strlen( $content );
		$this->nested = true;
		$token = $this->next();
		if ( 'word' === $token[0] && 'SET' === $token[1] ) { $this->kind = 'SET'; $this->set(); }
		elseif ( 'word' === $token[0] && 'ALTER' === $token[1] ) { $this->kind = 'ALTER TABLE'; $this->alter_keys(); }
		else $this->reject( 'comentario ejecutable no permitido' );
		$this->nested = false;
		list( $this->s, $this->i, $this->n ) = $saved;
	}
	private function dump_statement( $word ) {
		switch ( $word ) {
			case 'LOCK':
				$this->words( array( 'TABLES' ) );
				do {
					$this->table();
					$mode = $this->next();
					if ( 'word' !== $mode[0] || ! in_array( $mode[1], array( 'READ', 'WRITE' ), true ) ) $this->reject( 'bloqueo no reconocido' );
					if ( 'READ' === $mode[1] && $this->peek_word( 'LOCAL' ) ) $this->next();
				} while ( $this->accept_punct( ',' ) );
				$this->end();
				return true;
			case 'UNLOCK': $this->words( array( 'TABLES' ) ); $this->end(); return true;
			case 'ALTER': $this->kind = 'ALTER TABLE'; $this->alter_keys(); return true;
			case 'START': $this->words( array( 'TRANSACTION' ) ); $this->end(); return true;
			case 'COMMIT': $this->end(); return true;
		}
		return false;
	}
	private function alter_keys() {
		$this->words( array( 'TABLE' ) );
		$this->table();
		$action = $this->next();
		if ( 'word' !== $action[0] || ! in_array( $action[1], array( 'DISABLE', 'ENABLE' ), true ) ) $this->reject( 'ALTER TABLE sólo puede activar o desactivar índices' );
		$this->words( array( 'KEYS' ) );
		$this->end();
	}
	private function set() {
		$safe = self::EXPORTER === $this->dialect ? array( 'UTF8MB4', 'UTF8' ) : self::SAFE_CHARSETS;
		if ( $this->peek_word( 'NAMES' ) ) {
			$this->next();
			$charset = $this->next();
			if ( 'word' !== $charset[0] || ! in_array( $charset[1], $safe, true ) ) $this->reject( 'juego de caracteres no permitido' );
			if ( $this->peek_word( 'COLLATE' ) ) { $this->next(); $collation = $this->next(); if ( 'word' !== $collation[0] || ! $this->safe_charset_prefix( $collation[1] ) ) $this->reject( 'intercalación no permitida' ); }
			$this->end();
			return;
		}
		do {
			$target = $this->next();
			if ( self::MYSQLDUMP === $this->dialect && 'word' === $target[0] && in_array( $target[1], array( 'SESSION', 'LOCAL' ), true ) ) $target = $this->next();
			$user = '';
			if ( 'var' === $target[0] && 0 !== strpos( $target[1], '@@' ) ) {
				if ( self::MYSQLDUMP !== $this->dialect ) $this->reject( 'variable no permitida' );
				$user = $target[1];
				$name = '';
			} else {
				$name = 'var' === $target[0] ? preg_replace( '/^@@(?:SESSION\.|LOCAL\.)?/', '', $target[1] ) : ( 'word' === $target[0] ? $target[1] : '' );
				$allowed = self::EXPORTER === $this->dialect ? ( 'word' === $target[0] ? array( 'FOREIGN_KEY_CHECKS' ) : array() ) : self::SESSION_VARIABLES;
				if ( '' === $name || false !== strpos( $name, '.' ) || ! in_array( $name, $allowed, true ) ) $this->reject( 'variable no permitida' );
			}
			$this->expect_punct( '=' );
			$value = $this->next();
			if ( self::EXPORTER === $this->dialect ) {
				if ( 'num' !== $value[0] || ! in_array( $value[1], array( '0', '1' ), true ) ) $this->reject( 'valor no permitido' );
				continue;
			}
			if ( ! in_array( $value[0], array( 'str', 'num', 'word', 'var' ), true ) ) $this->reject( 'valor no permitido' );
			if ( 'var' === $value[0] && 0 === strpos( $value[1], '@@' ) && ! preg_match( '/^@@(?:SESSION\.|LOCAL\.|GLOBAL\.)?[A-Z0-9_]+$/D', $value[1] ) ) $this->reject( 'valor no permitido' );
			if ( '' !== $user ) { $this->safe_vars[ $user ] = 'var' === $value[0] && 0 === strpos( $value[1], '@@' ); continue; }
			// Lo que cambia cómo MySQL lee comillas y barras invertidas desincronizaría este análisis.
			if ( 'var' === $value[0] && 0 !== strpos( $value[1], '@@' ) ) { if ( in_array( $name, self::SENSITIVE, true ) && empty( $this->safe_vars[ $value[1] ] ) ) $this->reject( 'valor no permitido para ' . $name ); continue; }
			if ( 'SQL_MODE' === $name && ( 'str' !== $value[0] || preg_match( '/NO_BACKSLASH_ESCAPES|ANSI/i', substr( $this->s, $value[2], $value[3] - $value[2] ) ) ) ) $this->reject( 'modo SQL no permitido' );
			if ( in_array( $name, array( 'CHARACTER_SET_CLIENT', 'CHARACTER_SET_RESULTS' ), true ) && ( 'word' !== $value[0] || ! in_array( $value[1], $safe, true ) ) ) $this->reject( 'juego de caracteres no permitido' );
			if ( 'COLLATION_CONNECTION' === $name && ( 'word' !== $value[0] || ! $this->safe_charset_prefix( $value[1] ) ) ) $this->reject( 'intercalación no permitida' );
		} while ( self::MYSQLDUMP === $this->dialect && $this->accept_punct( ',' ) );
		$this->end();
	}
	private function safe_charset_prefix( $collation ) {
		foreach ( self::SAFE_CHARSETS as $charset ) if ( $collation === $charset || 0 === strpos( $collation, $charset . '_' ) ) return true;
		return false;
	}
	private function create() {
		$what = $this->next();
		if ( 'word' !== $what[0] || 'TABLE' !== $what[1] ) {
			// Lo escribió SHOW CREATE TABLE de este servidor (por ejemplo, una vista). Con otro prefijo no se puede asegurar
			// a qué tablas apunta.
			if ( $this->trusted && $this->renames ) {
				$name = $this->peek_name();
				$this->cannot_rename( 'no se puede cambiar el prefijo de una vista u otro objeto que no es una tabla' . ( null === $name ? '' : ' («' . $name . '»)' ) );
			}
			if ( $this->trusted ) return;
			$this->reject( 'sólo se admite CREATE TABLE' );
		}
		$this->kind = 'CREATE TABLE';
		$this->table();
		if ( $this->renames ) $this->references();
		if ( $this->trusted ) return;
		$open = $this->next();
		if ( 'punct' !== $open[0] || '(' !== $open[1] || $this->peek_word( 'LIKE' ) ) $this->reject( 'las formas LIKE o SELECT de CREATE TABLE no se admiten' );
		$this->create_body( false );
	}
	/** Recorre la definición sin interpretarla y rechaza las opciones que salen de la base de datos. */
	private function create_body( $inside_comment ) {
		$previous = '';
		while ( true ) {
			$token = $this->next();
			if ( 'end' === $token[0] ) return;
			if ( 'exec' === $token[0] ) {
				if ( $inside_comment ) $this->reject( 'comentario ejecutable anidado' );
				if ( self::unreachable( $token ) ) continue;
				if ( ! preg_match( '/^\s*(?:PARTITION\s+BY\b|INVISIBLE\s*$|DEFAULT\s+ENCRYPTION\b)/i', $token[1] ) ) $this->reject( 'comentario ejecutable no permitido en CREATE TABLE' );
				$saved = array( $this->s, $this->i, $this->n );
				$this->s = $token[1];
				$this->i = 0;
				$this->n = strlen( $token[1] );
				$this->create_body( true );
				list( $this->s, $this->i, $this->n ) = $saved;
				continue;
			}
			if ( 'var' === $token[0] ) $this->reject( 'variables en CREATE TABLE' );
			// Una clave foránea hacia otra base de datos (`REFERENCES otra.tabla`, con la base entre comillas invertidas o sin
			// ellas). Sólo tras REFERENCES: MariaDB escribe `DEFAULT nextval(\`base\`.\`secuencia\`)` con la base delante, y eso
			// no lee nada de otra base (las formas TABLE/VALUES/SELECT, que sí, se rechazan aparte).
			if ( 'REFERENCES' === $previous && in_array( $token[0], array( 'ident', 'word' ), true ) && $this->accept_punct( '.' ) ) $this->reject( 'otra base de datos dentro de CREATE TABLE no permitida en un archivo sin firma' );
			// MySQL 8.0.19+: `CREATE TABLE t (…) TABLE otra` y `… VALUES ROW(…)` llenan la tabla como CREATE … SELECT.
			// VALUES sólo vale en una partición (VALUES LESS THAN, VALUES IN).
			if ( 'word' === $token[0] && 'TABLE' === $token[1] ) $this->reject( 'la forma TABLE de CREATE TABLE no se admite en un archivo sin firma' );
			if ( 'word' === $token[0] && 'VALUES' === $token[1] && ! $this->peek_word( 'LESS' ) && ! $this->peek_word( 'IN' ) ) $this->reject( 'la forma VALUES de CREATE TABLE no se admite en un archivo sin firma' );
			// ENGINE admite un nombre o un texto: ENGINE='CONNECT' y ENGINE=`SPIDER` también eligen el motor.
			if ( in_array( $previous, array( 'ENGINE', 'TYPE' ), true ) && in_array( $token[0], array( 'str', 'ident' ), true ) ) {
				$engine = strtoupper( 'ident' === $token[0] ? $token[1] : substr( $this->s, $token[2], $token[3] - $token[2] ) );
				if ( ! preg_match( '/^[A-Z0-9_]+$/D', $engine ) || in_array( $engine, self::REMOTE_ENGINES, true ) ) $this->reject( 'motor ' . ( preg_match( '/^[A-Z0-9_]+$/D', $engine ) ? $engine : 'no reconocido' ) . ' no permitido en un archivo sin firma' );
			}
			if ( 'word' !== $token[0] ) { if ( 'punct' !== $token[0] || '=' !== $token[1] ) $previous = ''; continue; }
			if ( in_array( $token[1], self::CREATE_DENIED, true ) ) $this->reject( 'opción ' . $token[1] . ' no permitida en un archivo sin firma' );
			if ( in_array( $previous, array( 'ENGINE', 'TYPE' ), true ) && in_array( $token[1], self::REMOTE_ENGINES, true ) ) $this->reject( 'motor ' . $token[1] . ' no permitido en un archivo sin firma' );
			$previous = $token[1];
		}
	}
	/** Nombre de una vista u otro objeto (el identificador tras VIEW, TRIGGER…), sin mover la lectura; null si no lo hay. */
	private function peek_name() {
		$at = $this->i;
		$name = null;
		try {
			while ( true ) {
				$token = $this->next();
				if ( 'end' === $token[0] ) break;
				if ( 'word' === $token[0] && in_array( $token[1], array( 'VIEW', 'TRIGGER', 'FUNCTION', 'PROCEDURE', 'EVENT' ), true ) ) {
					$token = $this->next();
					if ( 'ident' === $token[0] ) $name = $token[1];
					break;
				}
			}
		} catch ( UnexpectedValueException $e ) {
			$name = null;
		}
		$this->i = $at;
		return $name;
	}
	/** Claves foráneas de un CREATE TABLE: `REFERENCES` a una tabla que cambia de nombre la apunta a su nombre nuevo. */
	private function references() {
		$at = $this->i;
		$expect = false;
		while ( true ) {
			$token = $this->next();
			if ( 'end' === $token[0] ) break;
			if ( 'exec' === $token[0] ) {
				if ( false !== stripos( $token[1], 'REFERENCES' ) ) $this->cannot_rename( 'clave foránea dentro de un comentario ejecutable' );
				continue;
			}
			if ( $expect && 'ident' === $token[0] && isset( $this->renames[ $token[1] ] ) ) $this->spans[] = array( $token[2], $token[3], '`' . str_replace( '`', '``', $this->renames[ $token[1] ] ) . '`' );
			$expect = 'word' === $token[0] && 'REFERENCES' === $token[1];
		}
		$this->i = $at;
	}
	private function insert() {
		if ( self::MYSQLDUMP === $this->dialect && $this->peek_word( 'IGNORE' ) ) $this->next();
		$this->words( array( 'INTO' ) );
		$this->excerpt_end = $this->i;
		$table = $this->table();
		$this->excerpt_end = $this->i;
		$record = null !== $this->insert_hook;
		$columns = null;
		$rows = array();
		$token = $this->next();
		if ( 'punct' === $token[0] && '(' === $token[1] ) {
			$columns = array();
			do {
				$column = $this->next();
				if ( 'ident' !== $column[0] ) $this->reject( 'columna no reconocida' );
				$columns[] = $column[1];
			} while ( $this->accept_punct( ',' ) );
			$this->expect_punct( ')' );
			$token = $this->next();
		} elseif ( self::EXPORTER === $this->dialect ) {
			$this->reject( 'falta la lista de columnas' );
		}
		if ( 'word' !== $token[0] || ! in_array( $token[1], array( 'VALUES', 'VALUE' ), true ) ) $this->reject( 'INSERT sólo admite VALUES con valores literales' );
		do {
			$this->expect_punct( '(' );
			$row = array();
			do { $value = $this->literal(); if ( $record ) $row[] = $value; } while ( $this->accept_punct( ',' ) );
			$this->expect_punct( ')' );
			if ( $record ) $rows[] = $row;
		} while ( $this->accept_punct( ',' ) );
		$this->end();
		if ( $record ) $this->insert = array( 'table' => $table, 'columns' => $columns, 'rows' => $rows );
	}
	/** Comprueba un literal y lo describe para el gancho de INSERT (ver on_insert()). */
	private function literal() {
		$token = $this->next();
		if ( 'str' === $token[0] && "'" === $token[1] ) return array( 'type' => 'str', 'quote' => "'", 'start' => $token[2], 'end' => $token[3] );
		if ( 'word' === $token[0] && 'NULL' === $token[1] ) return null;
		if ( self::MYSQLDUMP === $this->dialect ) {
			if ( 'punct' === $token[0] && in_array( $token[1], array( '-', '+' ), true ) ) $token = $this->next();
			if ( 'num' === $token[0] ) return array( 'type' => 'raw', 'raw' => $token[1] );
			if ( in_array( $token[0], array( 'hex', 'bit' ), true ) ) return array( 'type' => 'other' );
			if ( 'word' === $token[0] && 0 === strpos( $token[1], '_' ) && preg_match( '/^_(?:BINARY|UTF8MB4|UTF8MB3|UTF8|LATIN1)$/D', $token[1] ) ) { $value = $this->next(); if ( ( 'str' === $value[0] && "'" === $value[1] ) || 'hex' === $value[0] ) return array( 'type' => 'other' ); }
		}
		$this->reject( 'INSERT sólo admite valores literales' );
	}
	private function table() {
		$token = $this->next();
		if ( 'ident' !== $token[0] ) $this->reject( 'la tabla debe ir entre comillas invertidas' );
		if ( $this->accept_punct( '.' ) ) $this->reject( 'no se admite otra base de datos' );
		$name = $token[1];
		if ( null !== $this->tables ) { if ( ! isset( $this->tables[ $name ] ) ) $this->reject( 'la tabla no figura en el manifiesto' ); }
		elseif ( '' !== $this->prefix && 0 !== strpos( $name, $this->prefix ) ) $this->reject( 'la tabla no usa el prefijo de este sitio' );
		if ( isset( $this->renames[ $name ] ) ) {
			if ( $this->nested ) $this->cannot_rename( 'no se puede cambiar el prefijo de una tabla dentro de un comentario ejecutable («' . $name . '»)' );
			else $this->spans[] = array( $token[2], $token[3], '`' . str_replace( '`', '``', $this->renames[ $name ] ) . '`' );
		}
		if ( isset( $this->skips[ $name ] ) ) $this->skip_current = true;
		return $name;
	}
	private function words( $words ) {
		foreach ( $words as $word ) { $token = $this->next(); if ( 'word' !== $token[0] || $word !== $token[1] ) $this->reject( 'se esperaba ' . $word ); }
	}
	private function end() { $token = $this->next(); if ( 'end' !== $token[0] ) $this->reject( 'texto de más al final' ); }
	private function peek_word( $word ) { $at = $this->i; $token = $this->next(); $this->i = $at; return 'word' === $token[0] && $word === $token[1]; }
	private function accept_punct( $char ) { $at = $this->i; $token = $this->next(); if ( 'punct' === $token[0] && $char === $token[1] ) return true; $this->i = $at; return false; }
	private function expect_punct( $char ) { if ( ! $this->accept_punct( $char ) ) $this->reject( 'se esperaba «' . $char . '»' ); }

	/** Siguiente token: array( tipo, valor [, versión] ). Los comentarios que MySQL ignora cuentan como espacio. */
	private function next() {
		$s = $this->s;
		$n = $this->n;
		while ( true ) {
			$this->i += strspn( $s, " \t\r\n\f\v", $this->i );
			if ( $this->i >= $n ) return array( 'end', '' );
			$c = $s[ $this->i ];
			if ( '#' === $c || ( '-' === $c && '-' === ( $s[ $this->i + 1 ] ?? '' ) && ( $this->i + 2 >= $n || ord( $s[ $this->i + 2 ] ) <= 32 || 127 === ord( $s[ $this->i + 2 ] ) ) ) ) {
				$end = strpos( $s, "\n", $this->i );
				$this->i = false === $end ? $n : $end + 1;
				continue;
			}
			if ( '/' === $c && '*' === ( $s[ $this->i + 1 ] ?? '' ) ) {
				$end = strpos( $s, '*/', $this->i + 2 );
				if ( false === $end ) $this->reject( 'comentario sin cerrar' );
				$body = substr( $s, $this->i + 2, $end - $this->i - 2 );
				$this->i = $end + 2;
				if ( preg_match( '/^(M?)!([0-9]{5,6})?/', $body, $match ) ) return array( 'exec', substr( $body, strlen( $match[0] ) ), isset( $match[2] ) ? (int) $match[2] : 0, 'M' === $match[1] );
				if ( '' !== $body && '+' === $body[0] ) $this->reject( 'indicaciones del optimizador no permitidas' );
				continue;
			}
			break;
		}
		$start = $this->i;
		if ( "'" === $c || '"' === $c ) {
			$this->i++;
			while ( true ) {
				$this->i += strcspn( $s, '\\' . $c, $this->i );
				if ( $this->i >= $n ) $this->reject( 'cadena sin cerrar' );
				if ( '\\' === $s[ $this->i ] ) { $this->i += 2; continue; }
				if ( $c === ( $s[ $this->i + 1 ] ?? '' ) ) { $this->i += 2; continue; }
				$this->i++;
				return array( 'str', $c, $start + 1, $this->i - 1 );
			}
		}
		if ( '`' === $c ) {
			$name = '';
			$this->i++;
			while ( true ) {
				$run = strcspn( $s, '`\\', $this->i );
				$name .= substr( $s, $this->i, $run );
				$this->i += $run;
				if ( $this->i >= $n ) $this->reject( 'identificador sin cerrar' );
				if ( '\\' === $s[ $this->i ] ) $this->reject( 'barra invertida en un identificador' );
				if ( '`' === ( $s[ $this->i + 1 ] ?? '' ) ) { $name .= '`'; $this->i += 2; continue; }
				$this->i++;
				if ( strlen( $name ) > 192 ) $this->reject( 'identificador demasiado largo' );
				return array( 'ident', $name, $start, $this->i );
			}
		}
		if ( preg_match( '/\G(?:0x[0-9A-Fa-f]+|[Xx]\'[0-9A-Fa-f]*\')/', $s, $match, 0, $start ) ) { $this->i += strlen( $match[0] ); return array( 'hex', '' ); }
		if ( preg_match( '/\G(?:0b[01]+|[Bb]\'[01]*\')/', $s, $match, 0, $start ) ) { $this->i += strlen( $match[0] ); return array( 'bit', '' ); }
		if ( preg_match( '/\G(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?(?![A-Za-z_$])/', $s, $match, 0, $start ) ) { $this->i += strlen( $match[0] ); return array( 'num', $match[0] ); }
		if ( preg_match( '/\G[A-Za-z_$][A-Za-z0-9_$]*/', $s, $match, 0, $start ) ) { $this->i += strlen( $match[0] ); return array( 'word', strtoupper( $match[0] ) ); }
		if ( '@' === $c && preg_match( '/\G@@?(?:`[^`]{1,64}`|[A-Za-z0-9_$]+(?:\.[A-Za-z0-9_$]+)?)/', $s, $match, 0, $start ) ) { $this->i += strlen( $match[0] ); return array( 'var', strtoupper( $match[0] ) ); }
		$this->i++;
		return array( 'punct', $c );
	}
}
