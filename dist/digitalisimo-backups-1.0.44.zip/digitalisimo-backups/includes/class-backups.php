<?php
defined( 'ABSPATH' ) || exit;

/** Respaldo manual completo: base de datos, archivos y copia opcional remota. */
final class Digitalisimo_Backups {
	const OPTION = 'digitalisimo_backups_settings';
	const STORAGE = 'digitalisimo_backups_private_storage';
	const HISTORY = 'digitalisimo_backups_history';
	const POLICIES = 'digitalisimo_backups_policies';
	const SERVERS = 'digitalisimo_backups_servers';
	const ACTION_SAVE = 'digitalisimo_backups_save';
	const ACTION_RUN = 'digitalisimo_backups_run';
	const ACTION_OAUTH = 'digitalisimo_backups_oauth';
	const ACTION_LOCK = 'digitalisimo_backups_lock';
	const ACTION_DOWNLOAD = 'digitalisimo_backups_download';
	const ACTION_DELETE = 'digitalisimo_backups_delete';
	const ACTION_SAVE_POLICIES = 'digitalisimo_backups_save_policies';
	const ACTION_RUN_POLICY = 'digitalisimo_backups_run_policy';
	const ACTION_RESTORE = 'digitalisimo_backups_restore';
	const ACTION_CREATE_AUTOMATION = 'digitalisimo_backups_create_automation';
	const ACTION_UPDATE_AUTOMATION = 'digitalisimo_backups_update_automation';
	const ACTION_DELETE_AUTOMATION = 'digitalisimo_backups_delete_automation';
	public static function init() { self::activate_default_policies(); add_action( 'admin_post_' . self::ACTION_SAVE, array( __CLASS__, 'save' ) ); add_action( 'admin_post_' . self::ACTION_RUN, array( __CLASS__, 'run' ) ); add_action( 'admin_post_' . self::ACTION_OAUTH, array( __CLASS__, 'oauth_callback' ) ); add_action( 'admin_post_' . self::ACTION_LOCK, array( __CLASS__, 'toggle_lock' ) ); add_action( 'admin_post_' . self::ACTION_DOWNLOAD, array( __CLASS__, 'download' ) ); add_action( 'admin_post_' . self::ACTION_DELETE, array( __CLASS__, 'delete_backup' ) ); add_action( 'admin_post_' . self::ACTION_SAVE_POLICIES, array( __CLASS__, 'save_policies' ) ); add_action( 'admin_post_' . self::ACTION_RUN_POLICY, array( __CLASS__, 'run_policy_request' ) ); add_action( 'admin_post_' . self::ACTION_CREATE_AUTOMATION, array( __CLASS__, 'create_automation' ) ); add_action( 'admin_post_' . self::ACTION_UPDATE_AUTOMATION, array( __CLASS__, 'update_automation' ) ); add_action( 'admin_post_' . self::ACTION_DELETE_AUTOMATION, array( __CLASS__, 'delete_automation' ) ); add_action( 'admin_post_' . self::ACTION_RESTORE, array( __CLASS__, 'restore_request' ) ); add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) ); add_action( 'digitalisimo_backups_full', array( __CLASS__, 'scheduled_backup' ), 10, 1 ); add_action( 'digitalisimo_backups_db', array( __CLASS__, 'scheduled_backup' ), 10, 1 ); add_action( 'digitalisimo_backups_policy', array( __CLASS__, 'scheduled_policy' ), 10, 2 ); }
	private static function defaults() { return array( 'destination' => 'local', 'sftp_name' => 'SFTP', 'google_name' => 'Google Drive', 'onedrive_name' => 'OneDrive', 'sftp_host' => '', 'sftp_port' => '22', 'sftp_user' => '', 'sftp_path' => '/', 'sftp_password' => '', 'sftp_fingerprint' => '', 'google_client_id' => '', 'google_client_secret' => '', 'google_refresh_token' => '', 'google_folder_id' => '', 'onedrive_client_id' => '', 'onedrive_client_secret' => '', 'onedrive_refresh_token' => '', 'onedrive_folder' => 'Digitalisimo Backups', 'retention' => '5', 'full_schedule' => 'disabled', 'database_schedule' => 'disabled' ); }
	/** Los ZIP no deben quedar bajo una ruta servida por Apache, Nginx o el CDN. */
	private static function local_directory() {
		static $directory = null;
		if ( null !== $directory ) return $directory;
		$wp_root = realpath( ABSPATH );
		if ( false === $wp_root ) throw new Exception( 'No se pudo resolver la raíz de WordPress para ubicar los respaldos.' );
		$document_root = ! empty( $_SERVER['DOCUMENT_ROOT'] ) ? realpath( (string) $_SERVER['DOCUMENT_ROOT'] ) : false;
		$explicit = defined( 'DIGITALISIMO_BACKUPS_STORAGE_DIR' );
		$saved = is_multisite() ? get_site_option( self::STORAGE, array() ) : get_option( self::STORAGE, array() );
		if ( $explicit ) {
			$path = (string) DIGITALISIMO_BACKUPS_STORAGE_DIR;
		} elseif ( is_array( $saved ) && wp_normalize_path( $wp_root ) === ( $saved['wordpress_root'] ?? '' ) && ! empty( $saved['directory'] ) ) {
			$path = (string) $saved['directory'];
		} else {
			if ( false === $document_root ) throw new Exception( 'No se conoce la raíz pública del servidor. Define DIGITALISIMO_BACKUPS_STORAGE_DIR en wp-config.php con una carpeta privada fuera del sitio.' );
			$path = dirname( $document_root ) . '/.digitalisimo-backups-' . substr( hash( 'sha256', wp_normalize_path( $wp_root ) ), 0, 16 );
		}
		if ( ! preg_match( '#^(?:/|[a-zA-Z]:[/\\\\])#', $path ) || is_link( $path ) ) throw new Exception( 'La carpeta de respaldos debe ser una ruta absoluta y no un enlace simbólico.' );
		if ( ! wp_mkdir_p( $path ) ) throw new Exception( 'No se pudo crear la carpeta privada de respaldos. Define DIGITALISIMO_BACKUPS_STORAGE_DIR con una ruta escribible fuera de la raíz pública.' );
		$real = realpath( $path );
		if ( false === $real ) throw new Exception( 'No se pudo resolver la carpeta privada de respaldos.' );
		foreach ( array_filter( array( $wp_root, realpath( WP_CONTENT_DIR ), realpath( WP_PLUGIN_DIR ), $document_root ) ) as $public_root ) {
			if ( self::path_within( $real, $public_root ) ) throw new Exception( 'La carpeta de respaldos está dentro de una ruta pública. Elige una ruta privada fuera del sitio.' );
		}
		if ( ! is_writable( $real ) ) throw new Exception( 'La carpeta privada de respaldos no permite escritura.' );
		if ( DIRECTORY_SEPARATOR === '/' ) {
			@chmod( $real, 0700 );
			clearstatcache( true, $real );
			$permissions = @fileperms( $real );
			if ( false === $permissions || ( $permissions & 0077 ) !== 0 ) throw new Exception( 'La carpeta privada de respaldos permite acceso a otros usuarios del servidor.' );
		}
		if ( ! $explicit && ( ! is_array( $saved ) || ( $saved['directory'] ?? '' ) !== $real || ( $saved['wordpress_root'] ?? '' ) !== wp_normalize_path( $wp_root ) ) ) {
			$record = array( 'wordpress_root' => wp_normalize_path( $wp_root ), 'directory' => $real );
			if ( is_multisite() ) update_site_option( self::STORAGE, $record );
			else update_option( self::STORAGE, $record, false );
		}
		self::migrate_legacy_storage( $real );
		$directory = $real;
		return $directory;
	}
	private static function path_within( $path, $root ) {
		$path = wp_normalize_path( $path );
		$root = rtrim( wp_normalize_path( $root ), '/' );
		return $path === $root || 0 === strpos( $path, $root . '/' );
	}
	/** Traslada los respaldos anteriores; nunca deja un ZIP parcialmente copiado como válido. */
	private static function migrate_legacy_storage( $private ) {
		$legacy = WP_PLUGIN_DIR . '/digitalisimo-backups-storage';
		if ( ! file_exists( $legacy ) ) return;
		if ( is_link( $legacy ) || ! is_dir( $legacy ) ) throw new Exception( 'La carpeta de respaldos anterior no es una carpeta segura.' );
		$lock = @fopen( $private . '/.migration.lock', 'c' );
		if ( ! $lock || ! flock( $lock, LOCK_EX ) ) { if ( $lock ) fclose( $lock ); throw new Exception( 'No se pudo bloquear la migración de respaldos anteriores.' ); }
		try {
			$names = @scandir( $legacy );
			if ( false === $names ) throw new Exception( 'No se pudo leer la carpeta anterior de respaldos.' );
			foreach ( $names as $name ) {
				if ( in_array( $name, array( '.', '..', 'index.php', '.htaccess' ), true ) ) continue;
				$source = $legacy . '/' . $name;
				if ( is_link( $source ) || ! is_file( $source ) ) throw new Exception( 'Hay un elemento no migrable en la carpeta anterior de respaldos: ' . $name );
				$target = $private . '/' . $name;
				$source_hash = @hash_file( 'sha256', $source );
				if ( false === $source_hash ) throw new Exception( 'No se pudo verificar el respaldo anterior ' . $name . '.' );
				if ( file_exists( $target ) ) {
					$target_hash = is_file( $target ) && ! is_link( $target ) ? @hash_file( 'sha256', $target ) : false;
					if ( false === $target_hash || ! hash_equals( $source_hash, $target_hash ) ) throw new Exception( 'Dos respaldos con el mismo nombre tienen distinto contenido: ' . $name );
				} elseif ( ! @rename( $source, $target ) ) {
					$temp = $target . '.migrating';
					$input = @fopen( $source, 'rb' );
					$output = @fopen( $temp, 'wb' );
					if ( ! $input || ! $output ) { if ( $input ) fclose( $input ); if ( $output ) fclose( $output ); @unlink( $temp ); throw new Exception( 'No se pudo copiar el respaldo anterior ' . $name . ' a la carpeta privada.' ); }
					$copied = stream_copy_to_stream( $input, $output );
					$flushed = fflush( $output );
					fclose( $input );
					fclose( $output );
					$temp_hash = @hash_file( 'sha256', $temp );
					if ( false === $copied || ! $flushed || $copied !== @filesize( $source ) || false === $temp_hash || ! hash_equals( $source_hash, $temp_hash ) || ! @rename( $temp, $target ) ) { @unlink( $temp ); throw new Exception( 'La copia del respaldo anterior ' . $name . ' no superó la verificación.' ); }
				}
				if ( file_exists( $source ) && ! @unlink( $source ) ) throw new Exception( 'Se copió ' . $name . ' a la carpeta privada, pero no se pudo retirar de la carpeta pública.' );
			}
		} finally {
			flock( $lock, LOCK_UN );
			fclose( $lock );
		}
	}
	/** Políticas independientes: cada una conserva su propia cadena y retención. */
	public static function default_policies() { return array( array( 'id' => 'monthly-full', 'label' => 'Completo mensual', 'type' => 'full', 'schedule' => 'monthly', 'retain' => 4, 'destination' => 'local', 'enabled' => true ) ); }
	public static function policies() { $saved = (array) get_option( self::POLICIES, self::default_policies() ); $defaults = array(); foreach ( self::default_policies() as $policy ) $defaults[ $policy['id'] ] = $policy; foreach ( $saved as &$policy ) { $base = $defaults[ $policy['id'] ?? '' ] ?? array( 'enabled' => true ); $policy = wp_parse_args( (array) $policy, $base ); if ( 'full' !== ( $policy['type'] ?? '' ) ) { $policy['enabled'] = false; $policy['schedule'] = 'disabled'; } } unset( $policy ); return $saved; }
	public static function activate_default_policies() {
		$saved = get_option( self::POLICIES, false );
		if ( false === $saved ) { add_option( self::POLICIES, self::default_policies(), '', false ); return; }
		$saved = (array) $saved;
		$changed = false;
		foreach ( $saved as &$policy ) {
			if ( 'full' === ( $policy['type'] ?? '' ) ) continue;
			$was_active = ! empty( $policy['enabled'] ) || 'disabled' !== ( $policy['schedule'] ?? '' );
			if ( $was_active ) $changed = true;
			$policy['enabled'] = false;
			$policy['schedule'] = 'disabled';
			if ( $was_active && ! empty( $policy['id'] ) ) wp_clear_scheduled_hook( 'digitalisimo_backups_policy', array( $policy['id'], get_current_blog_id() ) );
		}
		unset( $policy );
		if ( $changed ) update_option( self::POLICIES, $saved, false );
	}
	public static function policy( $id ) { foreach ( self::policies() as $policy ) if ( ( $policy['id'] ?? '' ) === $id ) return $policy; return array(); }
	public static function run_policy( $id, $site_id = 0 ) {
		$policy = self::policy( $id );
		if ( ! $policy || empty( $policy['enabled'] ) ) return new WP_Error( 'digitalisimo_backup_policy', 'La política no existe o está desactivada.' );
		if ( 'full' !== ( $policy['type'] ?? '' ) ) return new WP_Error( 'digitalisimo_backup_partial', 'Una exportación parcial no puede ejecutarse como respaldo completo.' );
		$site_id = $site_id ?: get_current_blog_id();
		if ( is_multisite() && ( (int) $site_id !== (int) get_main_site_id() || (int) get_current_blog_id() !== (int) get_main_site_id() ) ) return new WP_Error( 'digitalisimo_backup_scope', 'La política completa de Multisite debe ejecutarse desde el sitio principal de la red.' );
		try {
			$file = self::create_network();
			$settings = self::settings();
			$settings['destination'] = $policy['destination'];
			$remote = 'local' === $policy['destination'] ? array() : self::transfer( $file, $settings );
			self::remember( $file, $policy['destination'], is_multisite() ? 'network' : 'installation', $policy, $remote, $site_id );
			self::prune_policy( $policy );
			return $file;
		} catch ( Exception $e ) {
			return new WP_Error( 'digitalisimo_backup_policy_failed', $e->getMessage() );
		}
	}

	/** El manifiesto enlaza incrementales con su completo base para restaurarlos en orden. */
	public static function incremental_manifest( $policy_id, $base_file, $changes ) { return array( 'format' => 'digitalisimo-backup/v2', 'policy' => sanitize_key( $policy_id ), 'type' => 'incremental', 'base' => sanitize_file_name( $base_file ), 'created_at' => gmdate( 'c' ), 'changes' => array_values( (array) $changes ), 'checksum' => hash( 'sha256', wp_json_encode( (array) $changes ) ) ); }
	/** Detecta y agrupa los archivos estándar de UpdraftPlus sin asumir que un ZIP aislado es restaurable. */
	public static function detect_updraft_sets( $directory = '' ) { $directory = $directory ?: WP_CONTENT_DIR . '/updraft'; $sets = array(); foreach ( glob( trailingslashit( $directory ) . 'backup_*' ) ?: array() as $path ) { $name = wp_basename( $path ); if ( ! preg_match( '/^(backup_[0-9-]{15}_.+?_[0-9a-f]{12})-(db|plugins|themes|uploads|others)([0-9]+)?\.(zip|gz)(?:\.crypt)?$/i', $name, $m ) ) continue; $key = $m[1]; if ( ! isset( $sets[ $key ] ) ) $sets[ $key ] = array( 'id' => $key, 'files' => array(), 'complete' => false ); $sets[ $key ]['files'][ strtolower( $m[2] ) ][] = array( 'path' => $path, 'part' => absint( $m[3] ), 'encrypted' => false !== strpos( $name, '.crypt' ) ); } foreach ( $sets as &$set ) { foreach ( $set['files'] as &$parts ) usort( $parts, function( $a, $b ) { return $a['part'] <=> $b['part']; } ); $set['complete'] = ! empty( $set['files']['db'] ) && ! array_filter( $set['files'], function( $parts ) { return array_filter( $parts, function( $part ) { return $part['encrypted']; } ); } ); } return $sets; }
	/** Rechaza piezas ausentes, cifradas o ilegibles antes de extraer cualquier archivo. */
	public static function validate_backup_set( $set ) { if ( empty( $set['complete'] ) || empty( $set['files']['db'] ) ) return new WP_Error( 'digitalisimo_backup_incomplete', 'El conjunto no incluye una base de datos legible o tiene piezas cifradas.' ); foreach ( $set['files'] as $parts ) foreach ( $parts as $part ) if ( ! is_readable( $part['path'] ) ) return new WP_Error( 'digitalisimo_backup_unreadable', 'Una pieza del respaldo no se puede leer.' ); return true; }
	private static function settings() { return wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() ); }
	/** Catálogo persistente de conexiones; conserva la configuración previa como primer servidor. */
	private static function servers() { self::migrate_servers(); return (array) get_option( self::SERVERS, array() ); }
	private static function migrate_servers() { if ( false !== get_option( self::SERVERS, false ) ) return; $s = self::settings(); $servers = array(); if ( $s['sftp_host'] && $s['sftp_user'] ) $servers[] = array( 'id' => 'legacy-ftp', 'type' => 'sftp', 'name' => $s['sftp_name'] ?: 'SFTP', 'host' => $s['sftp_host'], 'port' => $s['sftp_port'], 'user' => $s['sftp_user'], 'path' => $s['sftp_path'], 'verified' => false ); add_option( self::SERVERS, $servers, '', false ); }
	private static function server_list() { $servers = self::servers(); echo '<section class="digitalisimo-backups-card"><h2>Servidores creados</h2>'; if ( ! $servers ) { echo '<p>Aún no hay servidores verificados.</p></section>'; return; } echo '<table class="widefat striped"><thead><tr><th>Nombre</th><th>Tipo</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>'; foreach ( $servers as $server ) echo '<tr><td>' . esc_html( $server['name'] ?? '' ) . '</td><td>' . esc_html( self::destination_label( $server['type'] ?? '' ) ) . '</td><td>' . ( empty( $server['verified'] ) ? 'Pendiente de verificación' : 'Verificado' ) . '</td><td><button class="button" disabled>Editar</button> <button class="button" disabled>Eliminar</button></td></tr>'; echo '</tbody></table><p class="description">Editar y eliminar se habilitarán al terminar la verificación de conexión de cada servidor.</p></section>'; }
	public static function cron_schedules( $schedules ) { $schedules['digitalisimo_every_6_hours'] = array( 'interval' => 6 * HOUR_IN_SECONDS, 'display' => 'Cada 6 horas' ); $schedules['digitalisimo_every_12_hours'] = array( 'interval' => 12 * HOUR_IN_SECONDS, 'display' => 'Cada 12 horas' ); $schedules['monthly'] = array( 'interval' => 30 * DAY_IN_SECONDS, 'display' => 'Mensual' ); return $schedules; }
	private static function schedule_options() { return array( 'disabled' => 'Desactivado', 'hourly' => 'Cada hora', 'digitalisimo_every_6_hours' => 'Cada 6 horas', 'digitalisimo_every_12_hours' => 'Cada 12 horas', 'daily' => 'Diario', 'weekly' => 'Semanal', 'monthly' => 'Mensual' ); }
	private static function sync_schedules( $settings ) { foreach ( array( 'full' => 'full_schedule', 'db' => 'database_schedule' ) as $type => $key ) { $hook = 'digitalisimo_backups_' . $type; wp_clear_scheduled_hook( $hook ); if ( 'full' === $type && 'disabled' !== $settings[ $key ] ) wp_schedule_event( time() + MINUTE_IN_SECONDS, $settings[ $key ], $hook, array( get_current_blog_id() ) ); } }
	private static function sync_policy_schedules() { foreach ( self::policies() as $policy ) { $args = array( $policy['id'], get_current_blog_id() ); wp_clear_scheduled_hook( 'digitalisimo_backups_policy', $args ); if ( ! empty( $policy['enabled'] ) && 'disabled' !== $policy['schedule'] ) wp_schedule_event( time() + MINUTE_IN_SECONDS, $policy['schedule'], 'digitalisimo_backups_policy', $args ); } }
	public static function scheduled_policy( $policy_id, $site_id ) { $result = self::run_policy( $policy_id, $site_id ); if ( is_wp_error( $result ) ) error_log( 'Digitalisimo Backups: ' . $result->get_error_message() ); }
	public static function scheduled_backup( $site_id ) {
		if ( current_filter() === 'digitalisimo_backups_db' ) {
			error_log( 'Digitalisimo Backups: se omitió la exportación parcial de base de datos; requiere una política de respaldo completo.' );
			return;
		}
		if ( is_multisite() && ( (int) $site_id !== (int) get_main_site_id() || (int) get_current_blog_id() !== (int) get_main_site_id() ) ) {
			error_log( 'Digitalisimo Backups: se omitió una tarea heredada de subsitio que no cubre la red completa.' );
			return;
		}
		try {
			$file = self::create_network();
			$settings = self::settings();
			$remote = 'local' === $settings['destination'] ? array() : self::transfer( $file, $settings );
			self::remember( $file, $settings['destination'], is_multisite() ? 'network' : 'installation', array( 'id' => 'legacy-full', 'type' => 'full' ), $remote );
			self::prune( dirname( $file ), (int) $settings['retention'] );
		} catch ( Exception $e ) {
			error_log( 'Digitalisimo Backups: ' . $e->getMessage() );
		}
	}

	private static function can_manage() { return is_multisite() ? current_user_can( 'manage_network_options' ) : current_user_can( 'manage_options' ); }
	private static function network_context() { if ( ! is_multisite() ) return false; if ( is_network_admin() || ! empty( $_REQUEST['digitalisimo_backups_network'] ) ) return true; $referer = wp_get_referer(); return $referer && false !== strpos( $referer, '/wp-admin/network/' ); }
	private static function admin_url() { return self::network_context() ? network_admin_url( 'admin.php?page=digitalisimo-network-backups' ) : admin_url( 'admin.php?page=digitalisimo-backups' ); }
	private static function context_args() { return self::network_context() ? array( 'digitalisimo_backups_network' => '1' ) : array(); }
	public static function page() { if ( ! self::can_manage() ) { echo '<div class="wrap"><h1>Backups · Digitalisimo</h1><p>El respaldo completo de esta red requiere permisos de administración de red.</p></div>'; return; } self::render( false ); }
	public static function network_page() { if ( ! self::can_manage() ) return; self::render( true ); }
	private static function secret_fields() { return array( 'sftp_password', 'google_client_secret', 'google_refresh_token', 'onedrive_client_secret', 'onedrive_refresh_token' ); }
	/** Sólo ofrece destinos remotos que ya cuentan con una conexión válida. */
	private static function manual_destinations( $settings ) { $destinations = array( 'local' => self::destination_label( 'local' ) ); if ( ! empty( $settings['sftp_host'] ) && ! empty( $settings['sftp_user'] ) && ! empty( $settings['sftp_password'] ) && ! empty( $settings['sftp_fingerprint'] ) ) $destinations['sftp'] = $settings['sftp_name'] ?: self::destination_label( 'sftp' ); if ( ! empty( $settings['google_refresh_token'] ) ) $destinations['google'] = $settings['google_name'] ?: self::destination_label( 'google' ); if ( ! empty( $settings['onedrive_refresh_token'] ) ) $destinations['onedrive'] = $settings['onedrive_name'] ?: self::destination_label( 'onedrive' ); return $destinations; }
	private static function manual_destination_select( $settings ) { $html = '<label>Destino<br><select name="digitalisimo_backup_destination">'; foreach ( self::manual_destinations( $settings ) as $value => $label ) $html .= '<option value="' . esc_attr( $value ) . '"' . selected( $settings['destination'], $value, false ) . '>' . esc_html( $label ) . '</option>'; return $html . '</select></label>'; }
	private static function render( $network ) {
		try { self::local_directory(); }
		catch ( Throwable $e ) { echo '<div class="wrap digitalisimo-backups"><h1>Backups · Digitalisimo</h1><div class="notice notice-error"><p>' . esc_html( $e->getMessage() ) . '</p></div></div>'; return; }
		$s = self::settings(); $history = array_slice( (array) get_option( self::HISTORY, array() ), 0, 10 );
		echo '<div class="wrap digitalisimo-backups"><h1>Backups · Digitalisimo</h1><p>Genera un ZIP integral: archivos de WordPress, plugins, temas, medios y base de datos. El respaldo se crea primero en el hosting y después se copia al destino elegido.</p>';
		if ( isset( $_GET['backup'] ) ) echo '<div class="notice notice-' . ( 'ok' === $_GET['backup'] ? 'success' : 'error' ) . '"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['message'] ?? '' ) ) ) . '</p></div>';
		$tab = sanitize_key( $_GET['tab'] ?? 'backups' ); $base = self::admin_url(); echo '<nav class="digitalisimo-backups-tabs"><a class="' . ( 'backups' === $tab ? 'is-active' : '' ) . '" href="' . esc_url( add_query_arg( 'tab', 'backups', $base ) ) . '">Backups</a><a class="' . ( 'servers' === $tab ? 'is-active' : '' ) . '" href="' . esc_url( add_query_arg( 'tab', 'servers', $base ) ) . '">Servidores</a></nav>';
		if ( 'servers' === $tab ) { self::servers_panel( $s ); self::server_list(); echo '</div>'; return; }
		echo '<div class="digitalisimo-backups-grid"><section class="digitalisimo-backups-card"><h2>Crear respaldo completo</h2><p>Incluye todos los sitios de la red cuando WordPress usa Multisite, o el sitio completo en una instalación individual.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::ACTION_RUN );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_RUN ) . '"><input type="hidden" name="digitalisimo_backup_scope" value="installation">';
		if ( $network ) echo '<input type="hidden" name="digitalisimo_backups_network" value="1">';
		echo '<p>' . self::manual_destination_select( $s ) . '</p><button class="button button-primary button-hero">Crear respaldo completo ' . ( is_multisite() ? 'de la red' : 'de WordPress' ) . '</button></form>';

			echo '<p class="description">Destino actual: <strong>' . esc_html( self::destination_label( $s['destination'] ) ) . '</strong></p></section><section class="digitalisimo-backups-card"><h2>Últimos respaldos</h2>';
				if ( ! $history ) echo '<p>Aún no hay respaldos creados.</p>'; else { echo '<table class="widefat striped"><thead><tr><th>Fecha</th><th>Archivo</th><th>Tipo</th><th>Tamaño</th><th>Destino</th><th>Protección</th><th>Acciones</th></tr></thead><tbody>'; foreach ( $history as $item ) { $file = $item['file'] ?? ''; echo '<tr><td>' . esc_html( $item['date'] ?? '' ) . '</td><td>' . esc_html( $file ) . '</td><td>' . esc_html( ( $item['scope'] ?? 'site' ) === 'network' ? 'Red completa' : ( ( $item['scope'] ?? 'site' ) === 'installation' ? 'Instalación completa' : 'Exportación anterior de sitio' ) ) . '</td><td>' . esc_html( size_format( (int) ( $item['size'] ?? 0 ) ) ) . '</td><td>' . esc_html( self::destination_label( $item['destination'] ?? 'local' ) ) . '</td><td><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( self::ACTION_LOCK ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_LOCK ) . '"><input type="hidden" name="file" value="' . esc_attr( $file ) . '"><input type="hidden" name="locked" value="' . ( empty( $item['locked'] ) ? '1' : '0' ) . '"><button class="button button-small">' . ( empty( $item['locked'] ) ? 'Bloquear' : 'Bloqueado ✓' ) . '</button></form></td><td>'; if ( 'local' === ( $item['destination'] ?? 'local' ) || ! empty( $item['remote'] ) ) { echo '<a class="button button-small" href="' . esc_url( self::download_url( $file ) ) . '">Descargar</a> <form style="display:inline" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'¿Eliminar este respaldo?\')">'; wp_nonce_field( self::ACTION_DELETE ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_DELETE ) . '"><input type="hidden" name="file" value="' . esc_attr( $file ) . '"><button class="button button-small">Eliminar</button></form>'; } else echo 'Respaldo remoto anterior: sin identificador'; echo '</td></tr>'; } echo '</tbody></table>'; } echo '</section></div>';
			self::updraft_panel(); self::restore_panel( $history ); self::automation_fields(); echo '</div>';
		}
		private static function servers_panel( $s ) { echo '<section class="digitalisimo-backups-card"><h2>Servidores y nubes</h2><p>Configura las conexiones disponibles para respaldos. En Backups sólo aparecerán Local y las conexiones que ya estén listas.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( self::ACTION_SAVE ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_SAVE ) . '"><table class="form-table"><tr><th><label for="destination">Destino predeterminado</label></th><td><select name="digitalisimo_backups[destination]" id="destination"><option value="local" ' . selected( $s['destination'], 'local', false ) . '>Hosting / almacenamiento local</option><option value="sftp" ' . selected( $s['destination'], 'sftp', false ) . '>SFTP</option><option value="google" ' . selected( $s['destination'], 'google', false ) . '>Google Drive</option><option value="onedrive" ' . selected( $s['destination'], 'onedrive', false ) . '>Microsoft OneDrive</option></select></td></tr><tr data-server="sftp"><th>Nombre SFTP</th><td><input name="digitalisimo_backups[sftp_name]" value="' . esc_attr( $s['sftp_name'] ) . '"></td></tr><tr data-server="google"><th>Nombre Google Drive</th><td><input name="digitalisimo_backups[google_name]" value="' . esc_attr( $s['google_name'] ) . '"></td></tr><tr data-server="onedrive"><th>Nombre OneDrive</th><td><input name="digitalisimo_backups[onedrive_name]" value="' . esc_attr( $s['onedrive_name'] ) . '"></td></tr></table>'; self::connection_fields( $s ); submit_button( 'Guardar conexiones' ); echo '</form></section>'; }
		private static function policy_types() { return array( 'full' => 'Respaldo completo' ); }
		private static function policy_label( $policy ) { $types = self::policy_types(); $schedules = self::schedule_options(); return ( $types[ $policy['type'] ] ?? 'Respaldo' ) . ' · ' . ( $schedules[ $policy['schedule'] ] ?? 'Sin programación' ); }
		/** Cada automatización tiene un formulario propio: no existe una configuración global compartida. */
		private static function automation_fields() {
			$types = self::policy_types(); $schedules = self::schedule_options(); $destinations = array( 'local', 'sftp', 'google', 'onedrive' );
			echo '<section class="digitalisimo-backups-automations"><h2>Automatizaciones de respaldo</h2><p>Crea una automatización para cada estrategia de respaldo. Sus opciones se guardan de manera independiente y puedes crear, modificar, ejecutar o eliminar cada una sin afectar las demás.</p>';
			echo '<div class="digitalisimo-backups-card"><h3>Crear automatización</h3><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( self::ACTION_CREATE_AUTOMATION ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_CREATE_AUTOMATION ) . '"><p><label>Tipo<br><select name="digitalisimo_backup_automation[type]">'; foreach ( $types as $value => $label ) echo '<option value="' . esc_attr( $value ) . '">' . esc_html( $label ) . '</option>'; echo '</select></label> <label>Frecuencia<br><select name="digitalisimo_backup_automation[schedule]">'; foreach ( $schedules as $value => $label ) if ( 'disabled' !== $value ) echo '<option value="' . esc_attr( $value ) . '"' . selected( $value, 'weekly', false ) . '>' . esc_html( $label ) . '</option>'; echo '</select></label> <label>Destino<br><select name="digitalisimo_backup_automation[destination]">'; foreach ( $destinations as $destination ) echo '<option value="' . esc_attr( $destination ) . '">' . esc_html( self::destination_label( $destination ) ) . '</option>'; echo '</select></label> <label>Conservar<br><input type="number" min="1" max="100" name="digitalisimo_backup_automation[retain]" value="4"></label></p><p><button class="button button-primary">Crear automatización</button></p></form></div>';
			echo '<h3>Automatizaciones creadas</h3><div class="digitalisimo-backups-grid">';
			foreach ( self::policies() as $policy ) { $id = esc_attr( $policy['id'] ); if ( 'full' !== ( $policy['type'] ?? '' ) ) { echo '<section class="digitalisimo-backups-card"><h3>' . esc_html( $policy['label'] ?? $id ) . '</h3><p>Esta automatización parcial anterior está desactivada. Sus respaldos históricos se conservan; crea una automatización completa para proteger la instalación.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'¿Eliminar esta automatización anterior?\')">'; wp_nonce_field( self::ACTION_DELETE_AUTOMATION ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_DELETE_AUTOMATION ) . '"><input type="hidden" name="policy_id" value="' . $id . '"><button class="button button-link-delete">Eliminar automatización</button></form></section>'; continue; } echo '<section class="digitalisimo-backups-card"><h3>' . esc_html( self::policy_label( $policy ) ) . '</h3><p class="description">Tipo fijo: Respaldo completo.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( self::ACTION_UPDATE_AUTOMATION ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_UPDATE_AUTOMATION ) . '"><input type="hidden" name="policy_id" value="' . $id . '"><p><label><input type="checkbox" name="digitalisimo_backup_automation[enabled]" value="1" ' . checked( ! empty( $policy['enabled'] ), true, false ) . '> Activa</label></p><p><label>Frecuencia<br><select name="digitalisimo_backup_automation[schedule]">'; foreach ( $schedules as $value => $label ) echo '<option value="' . esc_attr( $value ) . '" ' . selected( $policy['schedule'], $value, false ) . '>' . esc_html( $label ) . '</option>'; echo '</select></label> <label>Destino<br><select name="digitalisimo_backup_automation[destination]">'; foreach ( $destinations as $destination ) echo '<option value="' . esc_attr( $destination ) . '" ' . selected( $policy['destination'], $destination, false ) . '>' . esc_html( self::destination_label( $destination ) ) . '</option>'; echo '</select></label> <label>Conservar<br><input type="number" min="1" max="100" name="digitalisimo_backup_automation[retain]" value="' . esc_attr( $policy['retain'] ) . '"></label></p><p><button class="button button-primary">Guardar esta automatización</button></p></form><div class="digitalisimo-backups-actions"><form style="display:inline" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( self::ACTION_RUN_POLICY ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_RUN_POLICY ) . '"><input type="hidden" name="digitalisimo_backup_policy" value="' . $id . '"><button class="button">Ejecutar ahora</button></form> <form style="display:inline" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'¿Eliminar esta automatización? Sus respaldos ya creados se conservan.\')">'; wp_nonce_field( self::ACTION_DELETE_AUTOMATION ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_DELETE_AUTOMATION ) . '"><input type="hidden" name="policy_id" value="' . $id . '"><button class="button button-link-delete">Eliminar</button></form></div></section>'; }
			echo '</div></section>';
		}
		private static function updraft_panel() { $sets = self::detect_updraft_sets(); echo '<h2>Respaldos detectados de UpdraftPlus</h2><p>Se analizan los archivos estándar dentro de <code>wp-content/updraft</code>. Sólo los conjuntos completos y sin cifrado se pueden restaurar.</p>'; if ( ! $sets ) { echo '<p>No se detectaron respaldos de UpdraftPlus en el almacenamiento local.</p>'; return; } echo '<table class="widefat striped"><thead><tr><th>Conjunto</th><th>Componentes</th><th>Estado</th></tr></thead><tbody>'; foreach ( $sets as $set ) { $components = array_map( function( $name, $parts ) { return $name . ( count( $parts ) > 1 ? ' × ' . count( $parts ) : '' ); }, array_keys( $set['files'] ), $set['files'] ); echo '<tr><td>' . esc_html( $set['id'] ) . '</td><td>' . esc_html( implode( ', ', $components ) ) . '</td><td>' . ( $set['complete'] ? 'Listo para restaurar abajo' : 'Incompleto o cifrado' ) . '</td></tr>'; } echo '</tbody></table><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( self::ACTION_RESTORE ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_RESTORE ) . '"><input type="hidden" name="updraft" value="1"><p><select name="updraft_set"><option value="">Elige un conjunto UpdraftPlus</option>'; foreach ( $sets as $set ) if ( $set['complete'] ) echo '<option value="' . esc_attr( $set['id'] ) . '">' . esc_html( $set['id'] ) . '</option>'; echo '</select> <input type="text" name="confirmation" placeholder="RESTAURAR" autocomplete="off"> <button class="button">Restaurar conjunto</button></p></form>'; }
		private static function schedule_fields( $s ) { echo '<h2>Políticas automáticas</h2><p>Cada política tiene su propia frecuencia, destino y retención. Un incremental guarda la base de datos y sólo los archivos modificados desde su último punto base; al restaurar se aplica después de su respaldo completo base.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( self::ACTION_SAVE_POLICIES ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_SAVE_POLICIES ) . '"><table class="widefat striped"><thead><tr><th>Activa</th><th>Nombre</th><th>Tipo</th><th>Frecuencia</th><th>Destino</th><th>Conservar</th><th>Ejecutar</th></tr></thead><tbody>'; foreach ( self::policies() as $policy ) { $id = esc_attr( $policy['id'] ); echo '<tr><td><input type="checkbox" name="digitalisimo_backups_policies[' . $id . '][enabled]" value="1" ' . checked( ! empty( $policy['enabled'] ), true, false ) . '></td><td><input type="hidden" name="digitalisimo_backups_policies[' . $id . '][id]" value="' . $id . '"><input type="text" name="digitalisimo_backups_policies[' . $id . '][label]" value="' . esc_attr( $policy['label'] ) . '"></td><td><strong>' . esc_html( array( 'full' => 'Completo', 'incremental' => 'Incremental', 'database' => 'Base de datos' )[ $policy['type'] ] ) . '</strong><input type="hidden" name="digitalisimo_backups_policies[' . $id . '][type]" value="' . esc_attr( $policy['type'] ) . '"></td><td><select name="digitalisimo_backups_policies[' . $id . '][schedule]">'; foreach ( self::schedule_options() as $value => $label ) echo '<option value="' . esc_attr( $value ) . '" ' . selected( $policy['schedule'], $value, false ) . '>' . esc_html( $label ) . '</option>'; echo '</select></td><td><select name="digitalisimo_backups_policies[' . $id . '][destination]">'; foreach ( array( 'local', 'sftp', 'google', 'onedrive' ) as $destination ) echo '<option value="' . esc_attr( $destination ) . '" ' . selected( $policy['destination'], $destination, false ) . '>' . esc_html( self::destination_label( $destination ) ) . '</option>'; echo '</select></td><td><input type="number" min="1" max="100" name="digitalisimo_backups_policies[' . $id . '][retain]" value="' . esc_attr( $policy['retain'] ) . '"></td><td><button class="button" name="action" value="' . esc_attr( self::ACTION_RUN_POLICY ) . '" formaction="' . esc_url( admin_url( 'admin-post.php' ) ) . '" formmethod="post">Ejecutar ahora<input type="hidden" name="digitalisimo_backup_policy" value="' . $id . '"></button></td></tr>'; } echo '</tbody></table><p><button class="button button-primary">Guardar políticas automáticas</button></p></form>'; }
	private static function connection_fields( $s ) {
		echo '<h2>Conexiones externas</h2><p>Elige un tipo para ver únicamente sus campos. Los secretos ya guardados no se muestran; deja el campo vacío para conservarlos.</p><p><label for="digitalisimo-server-type"><strong>Tipo de servidor</strong><br><select id="digitalisimo-server-type"><option value="sftp">SFTP</option><option value="google">Google Drive</option><option value="onedrive">OneDrive</option></select></label></p><table class="form-table"><tr data-server="sftp"><th colspan="2"><h3>SFTP</h3></th></tr>';
		self::field( 'sftp_host', 'Host o IP', $s ); self::field( 'sftp_port', 'Puerto', $s, 'number' ); self::field( 'sftp_user', 'Usuario', $s ); self::field( 'sftp_password', 'Contraseña', $s, 'password' ); self::field( 'sftp_path', 'Carpeta remota', $s ); self::field( 'sftp_fingerprint', 'Huella SHA-1 de la clave SSH del servidor', $s ); echo '<tr data-server="sftp"><th></th><td><p class="description">Confírmala con el administrador del servidor por un canal independiente. Se acepta una huella hexadecimal de 40 caracteres, con o sin dos puntos. Sin ella no se enviarán respaldos por SFTP.</p></td></tr>';
		echo '<tr data-server="google"><th colspan="2"><h3>Google Drive</h3></th></tr>'; self::field( 'google_client_id', 'Client ID', $s ); self::field( 'google_client_secret', 'Client secret', $s, 'password' ); self::field( 'google_refresh_token', 'Refresh token', $s, 'password' ); self::field( 'google_folder_id', 'ID de carpeta', $s ); echo '<tr data-server="google"><th>Cómo obtener Google Drive</th><td><ol><li>Abre <a href="https://console.cloud.google.com/" target="_blank" rel="noopener">Google Cloud Console</a> y crea o elige un proyecto.</li><li>Activa <strong>Google Drive API</strong> en APIs y servicios.</li><li>En Credenciales crea un cliente OAuth de tipo <strong>Aplicación web</strong>.</li><li>Agrega como URI de redirección autorizada: <code>' . esc_html( self::oauth_callback_url() ) . '</code></li><li>Copia Client ID y Client secret aquí, guarda y usa «Conectar Google Drive con mi sesión».</li></ol></td></tr>';
		echo '<tr data-server="onedrive"><th colspan="2"><h3>Microsoft OneDrive</h3></th></tr>'; self::field( 'onedrive_client_id', 'Client ID', $s ); self::field( 'onedrive_client_secret', 'Client secret', $s, 'password' ); self::field( 'onedrive_refresh_token', 'Refresh token', $s, 'password' ); self::field( 'onedrive_folder', 'Carpeta remota', $s ); echo '<tr data-server="onedrive"><th>Cómo obtener OneDrive</th><td><ol><li>Abre <a href="https://entra.microsoft.com/" target="_blank" rel="noopener">Microsoft Entra</a> → App registrations → New registration.</li><li>En Authentication agrega esta URL: <code>' . esc_html( self::oauth_callback_url() ) . '</code></li><li>Copia Client ID y Client secret, guarda y conecta la sesión.</li></ol></td></tr></table><p data-server="google"><a class="button button-secondary" href="' . esc_url( self::oauth_url( 'google' ) ) . '">Conectar Google Drive</a></p><p data-server="onedrive"><a class="button button-secondary" href="' . esc_url( self::oauth_url( 'onedrive' ) ) . '">Conectar OneDrive</a></p><script>document.addEventListener("DOMContentLoaded",function(){var s=document.getElementById("digitalisimo-server-type");if(!s)return;function f(){document.querySelectorAll("[data-server]").forEach(function(e){e.style.display=e.dataset.server===s.value?"":"none"})}s.addEventListener("change",f);f()})</script>';
		}
	private static function field( $key, $label, $s, $type = 'text' ) { $secret = in_array( $key, self::secret_fields(), true ); $server = 0 === strpos( $key, 'sftp_' ) ? 'sftp' : ( 0 === strpos( $key, 'google_' ) ? 'google' : 'onedrive' ); echo '<tr data-server="' . esc_attr( $server ) . '"><th><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><input class="regular-text" type="' . esc_attr( $type ) . '" id="' . esc_attr( $key ) . '" name="digitalisimo_backups[' . esc_attr( $key ) . ']" value="' . esc_attr( $secret ? '' : $s[ $key ] ) . '"' . ( $secret && $s[ $key ] ? ' placeholder="Guardado · escribe sólo para reemplazar"' : '' ) . '></td></tr>'; }
	private static function oauth_callback_url() { return add_query_arg( self::context_args(), admin_url( 'admin-post.php?action=' . self::ACTION_OAUTH ) ); }
	private static function oauth_url( $provider ) { return wp_nonce_url( add_query_arg( array_merge( array( 'action' => self::ACTION_OAUTH, 'provider' => $provider ), self::context_args() ), admin_url( 'admin-post.php' ) ), self::ACTION_OAUTH ); }
	private static function download_url( $file ) { return wp_nonce_url( add_query_arg( array_merge( array( 'action' => self::ACTION_DOWNLOAD, 'file' => rawurlencode( $file ) ), self::context_args() ), admin_url( 'admin-post.php' ) ), self::ACTION_DOWNLOAD ); }
	public static function download() { if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); check_admin_referer( self::ACTION_DOWNLOAD ); $file = sanitize_file_name( wp_unslash( $_GET['file'] ?? '' ) ); $item = self::history_item( $file ); if ( ! $item ) wp_die( 'Respaldo no disponible.' ); if ( 'local' !== ( $item['destination'] ?? 'local' ) ) { self::download_remote( $item ); exit; } $path = self::local_path( $file ); if ( ! $path ) wp_die( 'Respaldo no disponible.' ); nocache_headers(); header( 'Content-Type: application/zip' ); header( 'Content-Disposition: attachment; filename="' . $file . '"' ); header( 'Content-Length: ' . filesize( $path ) ); readfile( $path ); exit; }
	public static function delete_backup() { if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); check_admin_referer( self::ACTION_DELETE ); $file = sanitize_file_name( wp_unslash( $_POST['file'] ?? '' ) ); $item = self::history_item( $file ); if ( ! $item ) self::redirect( false, 'El respaldo no está registrado.' ); try { if ( 'local' === ( $item['destination'] ?? 'local' ) ) { $path = self::local_path( $file ); if ( ! $path ) { self::remove_history( $file ); self::redirect( true, 'El archivo local ya no existía; se eliminó su registro del listado.' ); } if ( ! is_writable( dirname( $path ) ) ) throw new Exception( 'El hosting no permite escribir en la carpeta de respaldos: ' . dirname( $path ) ); if ( ! @wp_delete_file( $path ) && file_exists( $path ) ) throw new Exception( 'El hosting rechazó eliminar el archivo local. Revisa permisos de la carpeta de respaldos.' ); } else self::delete_remote( $item ); self::remove_history( $file ); self::redirect( true, 'Respaldo eliminado.' ); } catch ( Exception $e ) { self::redirect( false, $e->getMessage() ); } }
	public static function oauth_callback() { if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); $provider = sanitize_key( $_REQUEST['provider'] ?? '' ); if ( ! in_array( $provider, array( 'google', 'onedrive' ), true ) ) self::redirect( false, 'Proveedor no válido.' ); $settings = self::settings(); if ( empty( $_GET['code'] ) ) { check_admin_referer( self::ACTION_OAUTH ); if ( empty( $settings[ $provider . '_client_id' ] ) || empty( $settings[ $provider . '_client_secret' ] ) ) self::redirect( false, 'Guarda antes el Client ID y Client secret del proveedor.' ); $state = wp_generate_password( 32, false, false ); set_transient( 'digitalisimo_backup_oauth_' . get_current_user_id(), array( 'state' => $state, 'provider' => $provider ), 15 * MINUTE_IN_SECONDS ); $redirect = self::oauth_callback_url(); if ( 'google' === $provider ) $url = add_query_arg( array( 'client_id' => $settings['google_client_id'], 'redirect_uri' => $redirect, 'response_type' => 'code', 'access_type' => 'offline', 'prompt' => 'consent', 'scope' => 'https://www.googleapis.com/auth/drive.file', 'state' => $state ), 'https://accounts.google.com/o/oauth2/v2/auth' ); else $url = add_query_arg( array( 'client_id' => $settings['onedrive_client_id'], 'redirect_uri' => $redirect, 'response_type' => 'code', 'response_mode' => 'query', 'scope' => 'offline_access Files.ReadWrite', 'state' => $state ), 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize' ); wp_redirect( $url ); exit; } $saved = get_transient( 'digitalisimo_backup_oauth_' . get_current_user_id() ); if ( empty( $saved['state'] ) || ! hash_equals( $saved['state'], (string) $_GET['state'] ) || $provider !== $saved['provider'] ) self::redirect( false, 'La autorización expiró o no coincide. Inténtalo nuevamente.' ); delete_transient( 'digitalisimo_backup_oauth_' . get_current_user_id() ); $endpoint = 'google' === $provider ? 'https://oauth2.googleapis.com/token' : 'https://login.microsoftonline.com/common/oauth2/v2.0/token'; $response = wp_remote_post( $endpoint, array( 'timeout' => 30, 'body' => array( 'client_id' => $settings[ $provider . '_client_id' ], 'client_secret' => $settings[ $provider . '_client_secret' ], 'code' => sanitize_text_field( wp_unslash( $_GET['code'] ) ), 'redirect_uri' => self::oauth_callback_url(), 'grant_type' => 'authorization_code' ) ) ); $data = json_decode( wp_remote_retrieve_body( $response ), true ); if ( is_wp_error( $response ) || empty( $data['refresh_token'] ) ) self::redirect( false, 'El proveedor no devolvió un refresh token. Revisa la URL de redirección registrada en su aplicación.' ); $settings[ $provider . '_refresh_token' ] = sanitize_text_field( $data['refresh_token'] ); update_option( self::OPTION, $settings, false ); self::redirect( true, ( 'google' === $provider ? 'Google Drive' : 'OneDrive' ) . ' conectado correctamente.' ); }
	public static function save() {
		if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); check_admin_referer( self::ACTION_SAVE ); $old = self::settings(); $input = (array) ( $_POST['digitalisimo_backups'] ?? array() ); $out = self::defaults();
			$out['destination'] = in_array( $input['destination'] ?? '', array( 'local', 'sftp', 'google', 'onedrive' ), true ) ? $input['destination'] : 'local'; $out['retention'] = min( 100, max( 1, absint( $input['retention'] ?? 5 ) ) );
		foreach ( array( 'sftp_name', 'google_name', 'onedrive_name', 'sftp_host', 'sftp_user', 'sftp_path', 'google_client_id', 'google_folder_id', 'onedrive_client_id', 'onedrive_folder' ) as $key ) $out[ $key ] = sanitize_text_field( $input[ $key ] ?? '' ); $out['sftp_port'] = min( 65535, max( 1, absint( $input['sftp_port'] ?? 22 ) ) );
		$fingerprint = trim( (string) ( $input['sftp_fingerprint'] ?? '' ) );
		if ( '' !== $fingerprint && ! preg_match( '/^(?:[a-f0-9]{40}|(?:[a-f0-9]{2}:){19}[a-f0-9]{2})$/i', $fingerprint ) ) self::redirect( false, 'La huella SFTP debe contener 40 caracteres hexadecimales SHA-1, con o sin dos puntos.' );
		$out['sftp_fingerprint'] = strtoupper( str_replace( ':', '', $fingerprint ) );
			foreach ( self::secret_fields() as $key ) $out[ $key ] = '' !== trim( (string) ( $input[ $key ] ?? '' ) ) ? sanitize_text_field( $input[ $key ] ) : $old[ $key ]; $out['full_schedule'] = array_key_exists( $input['full_schedule'] ?? '', self::schedule_options() ) ? $input['full_schedule'] : 'disabled'; $out['database_schedule'] = 'disabled'; update_option( self::OPTION, $out, false ); self::sync_schedules( $out ); wp_safe_redirect( add_query_arg( array( 'backup' => 'ok', 'message' => rawurlencode( 'Destino y automatizaciones guardados.' ) ), self::admin_url() ) ); exit;
	}
	public static function save_policies() {
		if ( ! self::can_manage() ) wp_die( 'No autorizado.' );
		check_admin_referer( self::ACTION_SAVE_POLICIES );
		$allowed_types = array( 'full' ); $allowed_destinations = array( 'local', 'sftp', 'google', 'onedrive' ); $out = array();
		foreach ( (array) ( $_POST['digitalisimo_backups_policies'] ?? array() ) as $id => $policy ) {
			$id = sanitize_key( $id ); $type = sanitize_key( $policy['type'] ?? '' );
			if ( ! $id || ! in_array( $type, $allowed_types, true ) ) continue;
			$schedule = sanitize_key( $policy['schedule'] ?? 'disabled' );
			$out[] = array( 'id' => $id, 'label' => sanitize_text_field( $policy['label'] ?? $id ), 'type' => $type, 'schedule' => array_key_exists( $schedule, self::schedule_options() ) ? $schedule : 'disabled', 'destination' => in_array( $policy['destination'] ?? '', $allowed_destinations, true ) ? $policy['destination'] : 'local', 'retain' => min( 100, max( 1, absint( $policy['retain'] ?? 4 ) ) ), 'enabled' => ! empty( $policy['enabled'] ) );
		}
		if ( ! $out ) self::redirect( false, 'No se recibió una política válida.' );
		update_option( self::POLICIES, $out, false ); self::sync_policy_schedules(); self::redirect( true, 'Políticas automáticas guardadas.' );
	}
	private static function automation_input( $input, $id = '', $type = '' ) {
		$types = self::policy_types(); $schedules = self::schedule_options(); $destinations = array( 'local', 'sftp', 'google', 'onedrive' );
		$type = $type ?: sanitize_key( $input['type'] ?? '' );
		if ( ! isset( $types[ $type ] ) ) return new WP_Error( 'digitalisimo_backup_type', 'El tipo de respaldo no es válido.' );
		$schedule = sanitize_key( $input['schedule'] ?? 'daily' );
		if ( ! isset( $schedules[ $schedule ] ) ) $schedule = 'daily';
		$destination = in_array( $input['destination'] ?? '', $destinations, true ) ? $input['destination'] : 'local';
		if ( 'incremental' === $type && ! in_array( $destination, array( 'local', 'sftp' ), true ) ) return new WP_Error( 'digitalisimo_backup_incremental_destination', 'Los respaldos incrementales sólo se admiten en Local o SFTP. Google Drive y OneDrive siempre generan respaldos completos.' );
		return array( 'id' => $id ?: 'automation-' . wp_generate_uuid4(), 'label' => '', 'type' => $type, 'schedule' => $schedule, 'destination' => $destination, 'retain' => min( 100, max( 1, absint( $input['retain'] ?? 4 ) ) ), 'enabled' => ! empty( $input['enabled'] ) );
	}
	public static function create_automation() {
		if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); check_admin_referer( self::ACTION_CREATE_AUTOMATION );
		$input = (array) ( $_POST['digitalisimo_backup_automation'] ?? array() ); $input['enabled'] = 1;
		$automation = self::automation_input( $input ); if ( is_wp_error( $automation ) ) self::redirect( false, $automation->get_error_message() );
		$policies = self::policies(); $policies[] = $automation; update_option( self::POLICIES, $policies, false ); self::sync_policy_schedules(); self::redirect( true, 'Automatización creada.' );
	}
	public static function update_automation() {
		if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); check_admin_referer( self::ACTION_UPDATE_AUTOMATION );
		$id = sanitize_key( $_POST['policy_id'] ?? '' ); $policies = self::policies(); $found = false;
		foreach ( $policies as $index => $policy ) if ( $id === ( $policy['id'] ?? '' ) ) { $automation = self::automation_input( (array) ( $_POST['digitalisimo_backup_automation'] ?? array() ), $id, $policy['type'] ); if ( is_wp_error( $automation ) ) self::redirect( false, $automation->get_error_message() ); $policies[ $index ] = $automation; $found = true; break; }
		if ( ! $found ) self::redirect( false, 'La automatización ya no existe.' ); update_option( self::POLICIES, $policies, false ); self::sync_policy_schedules(); self::redirect( true, 'Automatización guardada.' );
	}
	public static function delete_automation() {
		if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); check_admin_referer( self::ACTION_DELETE_AUTOMATION );
		$id = sanitize_key( $_POST['policy_id'] ?? '' ); $policies = self::policies(); $remaining = array(); $found = false;
		foreach ( $policies as $policy ) { if ( $id === ( $policy['id'] ?? '' ) ) { $found = true; continue; } $remaining[] = $policy; }
		if ( ! $found ) self::redirect( false, 'La automatización ya no existe.' ); wp_clear_scheduled_hook( 'digitalisimo_backups_policy', array( $id, get_current_blog_id() ) ); update_option( self::POLICIES, $remaining, false ); self::sync_policy_schedules(); self::redirect( true, 'Automatización eliminada. Los respaldos existentes se conservan.' );
	}
	public static function run_policy_request() {
		if ( ! self::can_manage() ) wp_die( 'No autorizado.' );
		check_admin_referer( self::ACTION_RUN_POLICY );
		$id = sanitize_key( $_POST['digitalisimo_backup_policy'] ?? '' ); $result = self::run_policy( $id );
		if ( is_wp_error( $result ) ) self::redirect( false, $result->get_error_message() );
		self::redirect( true, 'Política ejecutada: ' . wp_basename( $result ) );
	}
	public static function run() {
		if ( ! self::can_manage() ) wp_die( 'No autorizado.' );
		check_admin_referer( self::ACTION_RUN );
		@set_time_limit( 0 );
		ignore_user_abort( true );
		$context = self::network_context();
		$scope = sanitize_key( wp_unslash( $_POST['digitalisimo_backup_scope'] ?? 'installation' ) );
		if ( ! in_array( $scope, array( 'installation', 'network' ), true ) ) self::redirect( false, 'La exportación de un subsitio no constituye un respaldo completo de WordPress.', $context );
		$settings = self::settings();
		$available = self::manual_destinations( $settings );
		$destination = sanitize_key( wp_unslash( $_POST['digitalisimo_backup_destination'] ?? $settings['destination'] ) );
		if ( ! isset( $available[ $destination ] ) ) self::redirect( false, 'El destino seleccionado no está conectado o no es válido.', $context );
		$settings['destination'] = $destination;
		try {
			$file = self::create_network();
			$remote = 'local' === $destination ? array() : self::transfer( $file, $settings );
			self::remember( $file, $destination, is_multisite() ? 'network' : 'installation', array( 'id' => 'manual', 'type' => 'full' ), $remote );
			self::prune( dirname( $file ), (int) $settings['retention'] );
			self::redirect( true, 'Respaldo completo creado: ' . wp_basename( $file ) . ' en ' . self::destination_label( $destination ) . '.', $context );
		} catch ( Exception $e ) {
			self::redirect( false, $e->getMessage(), $context );
		}
	}

	private static function create_network() {
		if ( ! class_exists( 'ZipArchive' ) ) throw new Exception( 'El servidor necesita la extensión PHP ZipArchive para crear el respaldo.' );
		$dir = self::local_directory();
		if ( ! wp_mkdir_p( $dir ) || ! is_writable( $dir ) ) throw new Exception( 'No se puede escribir en la carpeta protegida de Digitalisimo Backups.' );
		self::protect( $dir );
		$name = 'digitalisimo-backup-' . sanitize_title( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '-' . gmdate( 'Ymd-His' ) . '-' . substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 8 ) . '.zip';
		$file = trailingslashit( $dir ) . $name;
		$zip = new ZipArchive();
		if ( true !== $zip->open( $file, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) throw new Exception( 'No se pudo crear el archivo ZIP.' );
		$sql_file = '';
		try {
			global $wpdb;
			$created_at = gmdate( 'c' );
			$tables = $wpdb->get_col( 'SHOW TABLES' );
			$sql_file = tempnam( sys_get_temp_dir(), 'digitalisimo-sql-' );
			if ( false === $sql_file ) throw new Exception( 'No se pudo preparar un archivo temporal para la base de datos.' );
			$snapshot_mode = self::database_sql_to_file( $tables, $sql_file );
			self::zip_add_file( $zip, $sql_file, 'database.sql' );
			$sql_size = @filesize( $sql_file );
			$sql_hash = @hash_file( 'sha256', $sql_file );
			if ( false === $sql_size || false === $sql_hash ) throw new Exception( 'No se pudo verificar el SQL temporal.' );
			$entries = array( 'database.sql' => array( 'size' => $sql_size, 'sha256' => $sql_hash ) );
			self::add_full_files( $zip, $dir, $entries );
			$manifest = array(
				'format' => 'digitalisimo-backup/v3',
				'backup_format_version' => 3,
				'backup_id' => wp_generate_uuid4(),
				'scope' => 'installation',
				'type' => 'full',
				'created_at' => $created_at,
				'completed_at' => gmdate( 'c' ),
				'home_url' => home_url(),
				'site_url' => site_url(),
				'wordpress_version' => get_bloginfo( 'version' ),
				'php_version' => PHP_VERSION,
				'database_version' => method_exists( $wpdb, 'db_version' ) ? $wpdb->db_version() : '',
				'database_name' => DB_NAME,
				'database_size' => $entries['database.sql']['size'],
				'database_consistency' => $snapshot_mode,
				'table_prefix' => $wpdb->base_prefix,
				'database_tables' => $tables,
				'multisite' => is_multisite(),
				'file_count' => count( $entries ) - 1,
				'uncompressed_size' => array_sum( array_column( $entries, 'size' ) ),
				'checksum_algorithm' => 'sha256',
				'plugin_version' => DIGITALISIMO_BACKUPS_VERSION,
				'entries' => $entries,
			);
			self::zip_add_string( $zip, 'manifest.json', wp_json_encode( $manifest, JSON_PRETTY_PRINT ) );
			self::finish_zip( $zip, $file );
			return $file;
		} catch ( Throwable $e ) {
			@$zip->close();
			@unlink( $file );
			throw $e;
		} finally {
			if ( $sql_file ) @unlink( $sql_file );
		}
	}
	/** Inventario estricto de la instalación, sin omitir archivos sin avisar. */
	private static function add_full_files( $zip, $backup_dir, &$entries ) {
		$root = realpath( ABSPATH );
		$content = realpath( WP_CONTENT_DIR );
		if ( false === $root || false === $content ) throw new Exception( 'No se pudo resolver la ruta de WordPress o wp-content.' );
		$root = trailingslashit( wp_normalize_path( $root ) );
		$content = wp_normalize_path( $content );
		if ( 0 !== strpos( trailingslashit( $content ), $root ) ) throw new Exception( 'wp-content está fuera de ABSPATH; se necesita incluirlo explícitamente antes de crear un respaldo completo.' );
		if ( ! is_file( $root . 'wp-config.php' ) ) throw new Exception( 'wp-config.php está fuera de ABSPATH o no se puede leer; no se creará un respaldo incompleto.' );
		$backup_dir = trailingslashit( wp_normalize_path( realpath( $backup_dir ) ) );
		$iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::LEAVES_ONLY );
		foreach ( $iterator as $entry ) {
			$path = wp_normalize_path( $entry->getPathname() );
			if ( 0 === strpos( $path, $backup_dir ) ) continue;
			if ( $entry->isLink() ) throw new Exception( 'El respaldo completo no puede omitir el enlace simbólico ' . $path . '.' );
			if ( ! $entry->isFile() ) continue;
			$relative = substr( $path, strlen( $root ) );
			$name = 'wordpress/' . $relative;
			$size = @filesize( $path );
			$hash = @hash_file( 'sha256', $path );
			if ( false === $size || false === $hash ) throw new Exception( 'No se pudo inventariar el archivo ' . $relative . '.' );
			self::zip_add_file( $zip, $path, $name );
			$entries[ $name ] = array( 'size' => $size, 'sha256' => $hash );
		}
		foreach ( array( 'wordpress/wp-config.php', 'wordpress/wp-load.php', 'wordpress/wp-settings.php', 'wordpress/wp-admin/index.php', 'wordpress/wp-includes/version.php' ) as $required ) {
			if ( ! isset( $entries[ $required ] ) ) throw new Exception( 'Falta el archivo obligatorio ' . $required . ' en el respaldo.' );
		}
	}

	private static function create_site( $site_id, $type = 'full' ) {
		if ( ! class_exists( 'ZipArchive' ) ) throw new Exception( 'El servidor necesita la extensión PHP ZipArchive para crear el respaldo.' );
		$dir = self::local_directory();
		if ( ! wp_mkdir_p( $dir ) || ! is_writable( $dir ) ) throw new Exception( 'No se puede escribir en la carpeta protegida de Digitalisimo Backups.' );
		self::protect( $dir );
		$site = get_site( $site_id );
		if ( ! $site ) throw new Exception( 'El sitio elegido ya no existe.' );
		$name = 'digitalisimo-site-' . $site_id . '-' . sanitize_title( $site->domain ) . '-' . ( 'database' === $type ? 'db-' : 'full-' ) . gmdate( 'Ymd-His' ) . '.zip';
		$file = trailingslashit( $dir ) . $name;
		$zip = new ZipArchive();
		if ( true !== $zip->open( $file, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) throw new Exception( 'No se pudo crear el archivo ZIP.' );
		try {
			switch_to_blog( $site_id );
			try {
				global $wpdb;
				$prefix = $wpdb->prefix;
				$upload = wp_upload_dir();
				$source_url = home_url();
				self::zip_add_string( $zip, 'database.sql', self::database_sql( self::site_tables( $prefix ), $prefix, 'wp_' ) );
				self::zip_add_string( $zip, 'migration.json', wp_json_encode( array( 'scope' => 'site', 'type' => $type, 'source_url' => $source_url, 'target_table_prefix' => 'wp_', 'upload_directory' => $upload['basedir'], 'created_at' => gmdate( 'c' ) ), JSON_PRETTY_PRINT ) );
				if ( 'full' === $type ) {
					$instructions = "1. Instala WordPress limpio.\n2. Copia wordpress/ sobre la instalación, excepto wp-config.php.\n3. Importa database.sql en la base de datos destino (usa prefijo wp_).\n4. Sustituye " . $source_url . " por la URL nueva en la base de datos con WP-CLI search-replace o una herramienta que preserve datos serializados.\n5. Revisa Ajustes > Enlaces permanentes y guarda una vez.\n";
					self::zip_add_string( $zip, 'MIGRAR-A-WORDPRESS-UNICO.txt', $instructions );
					self::add_directory( $zip, ABSPATH, $dir, true );
					self::add_upload_directory( $zip, $upload['basedir'] );
				}
			} finally {
				restore_current_blog();
			}
			self::finish_zip( $zip, $file );
			return $file;
		} catch ( Throwable $e ) {
			@$zip->close();
			@unlink( $file );
			throw $e;
		}
	}

		private static function add_directory( $zip, $root, $backup_dir, $exclude_uploads = false ) { $iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::LEAVES_ONLY ); $backup_dir = trailingslashit( wp_normalize_path( $backup_dir ) ); foreach ( $iterator as $file ) { if ( ! $file->isFile() || $file->isLink() ) continue; $path = wp_normalize_path( $file->getPathname() ); if ( 0 === strpos( $path, $backup_dir ) || false !== strpos( $path, '/.git/' ) || false !== strpos( $path, '/node_modules/' ) || false !== strpos( $path, '/cache/' ) || ( $exclude_uploads && 0 === strpos( $path, trailingslashit( wp_normalize_path( WP_CONTENT_DIR . '/uploads' ) ) ) ) ) continue; $relative = ltrim( substr( $path, strlen( wp_normalize_path( ABSPATH ) ) ), '/' ); if ( $exclude_uploads && 'wp-config.php' === $relative ) continue; self::zip_add_file( $zip, $path, 'wordpress/' . $relative ); } }
		private static function add_upload_directory( $zip, $directory ) { if ( ! is_dir( $directory ) ) return; $iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $directory, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::LEAVES_ONLY ); foreach ( $iterator as $file ) if ( $file->isFile() && ! $file->isLink() ) { $path = wp_normalize_path( $file->getPathname() ); $relative = ltrim( substr( $path, strlen( wp_normalize_path( $directory ) ) ), '/' ); self::zip_add_file( $zip, $path, 'wordpress/wp-content/uploads/' . $relative ); } }
	private static function zip_add_string( $zip, $name, $content ) {
		if ( ! is_string( $content ) || '' === $content || ! $zip->addFromString( $name, $content ) ) throw new Exception( 'No se pudo agregar ' . $name . ' al respaldo.' );
	}
	private static function zip_add_file( $zip, $path, $name ) {
		if ( ! is_file( $path ) || ! is_readable( $path ) || ! $zip->addFile( $path, $name ) ) throw new Exception( 'No se pudo agregar el archivo ' . $name . ' al respaldo.' );
	}
	/** Reabre y lee cada entrada antes de aceptar el ZIP como candidato a respaldo. */
	private static function finish_zip( $zip, $file ) {
		if ( ! $zip->close() || ! is_file( $file ) || ! filesize( $file ) ) {
			@unlink( $file );
			throw new Exception( 'El ZIP no se pudo cerrar correctamente.' );
		}
		$check = new ZipArchive();
		if ( true !== $check->open( $file, ZipArchive::CHECKCONS ) ) {
			@unlink( $file );
			throw new Exception( 'El ZIP generado no supera la comprobación estructural.' );
		}
		try {
			self::verify_zip_contents( $check );
		} catch ( Exception $e ) {
			$check->close();
			@unlink( $file );
			throw $e;
		}
		$check->close();
	}
	/** Comprueba presencia, lectura completa y CRC de todos los miembros del archivo. */
	private static function verify_zip_contents( $zip ) {
		$names = array();
		$observed = array();
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$stat = $zip->statIndex( $i );
			if ( ! $stat || ! isset( $stat['name'], $stat['size'], $stat['crc'] ) ) throw new Exception( 'Una entrada ZIP no tiene metadatos completos.' );
			$name = $stat['name'];
			if ( isset( $names[ $name ] ) ) throw new Exception( 'El ZIP contiene nombres de archivo duplicados.' );
			$names[ $name ] = true;
			if ( '/' === substr( $name, -1 ) ) continue;
			$stream = $zip->getStream( $name );
			if ( ! $stream ) throw new Exception( 'No se pudo leer ' . $name . ' del ZIP.' );
			$bytes = 0;
			$crc = hash_init( 'crc32b' );
			$sha = hash_init( 'sha256' );
			while ( ! feof( $stream ) ) {
				$chunk = fread( $stream, 1048576 );
				if ( false === $chunk || ( '' === $chunk && ! feof( $stream ) ) ) { fclose( $stream ); throw new Exception( 'La entrada ' . $name . ' está truncada.' ); }
				$bytes += strlen( $chunk );
				hash_update( $crc, $chunk );
				hash_update( $sha, $chunk );
			}
			fclose( $stream );
			if ( $bytes !== (int) $stat['size'] || hash_final( $crc ) !== sprintf( '%08x', $stat['crc'] ) ) throw new Exception( 'Falló la integridad de ' . $name . ' dentro del ZIP.' );
			if ( 'manifest.json' !== $name ) $observed[ $name ] = array( 'size' => $bytes, 'sha256' => hash_final( $sha ) );
		}
		if ( ! isset( $names['database.sql'] ) || ( ! isset( $names['manifest.json'] ) && ! isset( $names['migration.json'] ) ) ) throw new Exception( 'Falta SQL o metadata obligatoria en el ZIP.' );
		if ( isset( $names['manifest.json'] ) ) {
			$raw_manifest = $zip->getFromName( 'manifest.json' );
			$manifest = false === $raw_manifest ? null : json_decode( $raw_manifest, true );
			if ( ! is_array( $manifest ) || JSON_ERROR_NONE !== json_last_error() ) throw new Exception( 'El manifiesto del ZIP no es JSON válido.' );
			if ( ! in_array( $manifest['format'] ?? '', array( '', 'digitalisimo-backup/v2', 'digitalisimo-backup/v3' ), true ) ) throw new Exception( 'El formato del manifiesto no es compatible.' );
			if ( 'digitalisimo-backup/v3' === ( $manifest['format'] ?? '' ) ) {
				if ( 3 !== ( $manifest['backup_format_version'] ?? null ) || 'installation' !== ( $manifest['scope'] ?? '' ) || 'full' !== ( $manifest['type'] ?? '' ) || ! is_array( $manifest['entries'] ?? null ) || count( $manifest['entries'] ) !== count( $observed ) ) throw new Exception( 'El manifiesto completo no coincide con el ZIP.' );
				foreach ( array( 'database.sql', 'wordpress/wp-config.php', 'wordpress/wp-load.php', 'wordpress/wp-settings.php', 'wordpress/wp-admin/index.php', 'wordpress/wp-includes/version.php' ) as $required ) if ( ! isset( $observed[ $required ] ) ) throw new Exception( 'Falta el archivo obligatorio ' . $required . ' en el respaldo completo.' );
				if ( (int) ( $manifest['file_count'] ?? -1 ) !== count( $observed ) - 1 || (int) ( $manifest['uncompressed_size'] ?? -1 ) !== array_sum( array_column( $observed, 'size' ) ) ) throw new Exception( 'El tamaño o el número de archivos no coincide con el manifiesto.' );
				foreach ( $observed as $name => $actual ) {
					$expected = $manifest['entries'][ $name ] ?? null;
					if ( ! is_array( $expected ) || (int) ( $expected['size'] ?? -1 ) !== $actual['size'] || ! is_string( $expected['sha256'] ?? null ) || ! hash_equals( $expected['sha256'], $actual['sha256'] ) ) throw new Exception( 'Falló el SHA-256 de ' . $name . ' en el manifiesto.' );
				}
			}
		}
	}

	private static function site_tables( $prefix ) { global $wpdb; $like = $wpdb->esc_like( $prefix ) . '%'; $tables = (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) ); foreach ( array( $wpdb->base_prefix . 'users', $wpdb->base_prefix . 'usermeta' ) as $table ) if ( ! in_array( $table, $tables, true ) ) $tables[] = $table; return $tables; }
	private static function database_sql( $tables = null, $source_prefix = '', $target_prefix = '' ) {
		global $wpdb;
		if ( null === $tables ) $tables = $wpdb->get_col( 'SHOW TABLES' );
		if ( ! is_array( $tables ) || ! $tables ) throw new Exception( 'No se pudo obtener la lista de tablas de la base de datos.' );
		$sql = "-- Digitalisimo WordPress backup\n-- " . gmdate( 'c' ) . "\nSET NAMES utf8mb4;\nSET foreign_key_checks = 0;\n\n";
		foreach ( $tables as $table ) {
			$output = $target_prefix && 0 === strpos( $table, $source_prefix ) ? $target_prefix . substr( $table, strlen( $source_prefix ) ) : $table;
			$escaped = str_replace( '`', '``', $table );
			$create = $wpdb->get_row( "SHOW CREATE TABLE `" . $escaped . "`", ARRAY_N );
			if ( ! is_array( $create ) || empty( $create[1] ) ) throw new Exception( 'No se pudo exportar la definición de la tabla ' . $table . '.' );
			$definition = str_replace( '`' . $table . '`', '`' . $output . '`', $create[1] );
			$sql .= "DROP TABLE IF EXISTS `" . str_replace( '`', '``', $output ) . "`;\n" . $definition . ";\n";
			$rows = $wpdb->get_results( "SELECT * FROM `" . $escaped . "`", ARRAY_A );
			if ( ! is_array( $rows ) || ! empty( $wpdb->last_error ) ) throw new Exception( 'No se pudieron exportar los datos de la tabla ' . $table . '.' );
			foreach ( $rows as $row ) {
				$columns = array_map( function( $column ) { return '`' . str_replace( '`', '``', $column ) . '`'; }, array_keys( $row ) );
				$values = array_map( array( __CLASS__, 'sql_value' ), array_values( $row ) );
				$sql .= 'INSERT INTO `' . str_replace( '`', '``', $output ) . '` (' . implode( ',', $columns ) . ') VALUES (' . implode( ',', $values ) . ");\n";
			}
			$sql .= "\n";
		}
		return $sql . "SET foreign_key_checks = 1;\n";
	}
	/** Exporta el SQL por filas sin construir toda la base de datos en memoria. */
	private static function database_sql_to_file( $tables, $path ) {
		global $wpdb;
		if ( ! is_array( $tables ) || ! $tables ) throw new Exception( 'No se pudo obtener la lista de tablas de la base de datos.' );
		$output = @fopen( $path, 'wb' );
		if ( ! $output ) throw new Exception( 'No se pudo abrir el archivo SQL temporal.' );
		$snapshot = '';
		$complete = false;
		try {
			$snapshot = self::begin_database_snapshot( $tables );
			self::write_sql( $output, "SET NAMES utf8mb4;\nSET foreign_key_checks = 0;\n\n" );
			foreach ( $tables as $table ) {
				$escaped = str_replace( '`', '``', $table );
				$create = $wpdb->get_row( "SHOW CREATE TABLE `" . $escaped . "`", ARRAY_N );
				if ( ! is_array( $create ) || empty( $create[1] ) || ! empty( $wpdb->last_error ) ) throw new Exception( 'No se pudo exportar la definición de la tabla ' . $table . '.' );
				self::write_sql( $output, "DROP TABLE IF EXISTS `" . $escaped . "`;\n" . $create[1] . ";\n" );
				$query = "SELECT * FROM `" . $escaped . "`";
				if ( class_exists( 'mysqli' ) && isset( $wpdb->dbh ) && $wpdb->dbh instanceof mysqli ) {
					$result = @mysqli_query( $wpdb->dbh, $query, MYSQLI_USE_RESULT );
					if ( false === $result ) throw new Exception( 'No se pudo leer la tabla ' . $table . ' en modo streaming.' );
					try {
						while ( $row = mysqli_fetch_assoc( $result ) ) self::write_sql_row( $output, $table, $row );
						if ( mysqli_errno( $wpdb->dbh ) ) throw new Exception( 'Se interrumpió la lectura de la tabla ' . $table . '.' );
					} finally {
						mysqli_free_result( $result );
					}
				} else {
					$order = self::unique_order_columns( $table );
					if ( ! $order ) {
						$rows = $wpdb->get_results( $query, ARRAY_A );
						if ( ! is_array( $rows ) || ! empty( $wpdb->last_error ) ) throw new Exception( 'No se pudieron exportar los datos de la tabla ' . $table . '.' );
						foreach ( $rows as $row ) self::write_sql_row( $output, $table, $row );
						self::write_sql( $output, "\n" );
						continue;
					}
					$offset = 0;
					$batch = 500;
					do {
						$rows = $wpdb->get_results( $query . ' ORDER BY ' . implode( ', ', $order ) . ' LIMIT ' . $offset . ', ' . $batch, ARRAY_A );
						if ( ! is_array( $rows ) || ! empty( $wpdb->last_error ) ) throw new Exception( 'No se pudieron exportar los datos de la tabla ' . $table . '.' );
						foreach ( $rows as $row ) self::write_sql_row( $output, $table, $row );
						$offset += count( $rows );
					} while ( count( $rows ) === $batch );
				}
				self::write_sql( $output, "\n" );
			}
			self::write_sql( $output, "SET foreign_key_checks = 1;\n" );
			if ( ! fflush( $output ) ) throw new Exception( 'No se pudo completar el SQL temporal.' );
			$complete = true;
			return $snapshot;
		} finally {
			try {
				if ( $snapshot ) self::end_database_snapshot( $snapshot, $complete );
			} finally {
				fclose( $output );
			}
		}
	}
	/** InnoDB usa snapshot; tablas no transaccionales requieren bloqueo de lectura. */
	private static function begin_database_snapshot( $tables ) {
		global $wpdb;
		$transactional = true;
		foreach ( $tables as $table ) {
			$status = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
			if ( ! is_array( $status ) || empty( $status['Engine'] ) || ! empty( $wpdb->last_error ) ) throw new Exception( 'No se pudo determinar el motor de la tabla ' . $table . '; no se creará un respaldo sin consistencia.' );
			if ( 'innodb' !== strtolower( $status['Engine'] ) ) $transactional = false;
		}
		if ( $transactional ) {
			if ( false === $wpdb->query( 'SET TRANSACTION ISOLATION LEVEL REPEATABLE READ' ) || false === $wpdb->query( 'START TRANSACTION WITH CONSISTENT SNAPSHOT' ) ) throw new Exception( 'No se pudo iniciar una instantánea consistente de la base de datos.' );
			return 'transaction';
		}
		$locks = array_map( function( $table ) { return '`' . str_replace( '`', '``', $table ) . '` READ'; }, $tables );
		if ( false === $wpdb->query( 'LOCK TABLES ' . implode( ', ', $locks ) ) ) throw new Exception( 'No se pudieron bloquear las tablas no transaccionales durante el respaldo.' );
		return 'lock';
	}
	private static function end_database_snapshot( $mode, $complete ) {
		global $wpdb;
		$command = 'lock' === $mode ? 'UNLOCK TABLES' : ( $complete ? 'COMMIT' : 'ROLLBACK' );
		if ( false === $wpdb->query( $command ) ) throw new Exception( 'No se pudo cerrar la instantánea consistente de la base de datos.' );
	}
	/** Orden estable para paginar en un DB drop-in que no expone mysqli. */
	private static function unique_order_columns( $table ) {
		global $wpdb;
		$escaped = str_replace( '`', '``', $table );
		$indexes = $wpdb->get_results( 'SHOW INDEX FROM `' . $escaped . '`', ARRAY_A );
		if ( ! is_array( $indexes ) || ! empty( $wpdb->last_error ) ) throw new Exception( 'No se pudieron analizar los índices de la tabla ' . $table . '.' );
		$primary = array();
		foreach ( $indexes as $index ) if ( 'PRIMARY' === ( $index['Key_name'] ?? '' ) && isset( $index['Column_name'] ) ) $primary[ (int) ( $index['Seq_in_index'] ?? 1 ) ] = '`' . str_replace( '`', '``', $index['Column_name'] ) . '`';
		if ( ! $primary ) return array();
		ksort( $primary );
		return array_values( $primary );
	}
	private static function write_sql_row( $handle, $table, $row ) {
		$columns = array_map( function( $column ) { return '`' . str_replace( '`', '``', $column ) . '`'; }, array_keys( $row ) );
		$values = array_map( array( __CLASS__, 'sql_value' ), array_values( $row ) );
		self::write_sql( $handle, 'INSERT INTO `' . str_replace( '`', '``', $table ) . '` (' . implode( ',', $columns ) . ') VALUES (' . implode( ',', $values ) . ");\n" );
	}
	private static function write_sql( $handle, $sql ) {
		$length = strlen( $sql );
		$offset = 0;
		while ( $offset < $length ) {
			$written = fwrite( $handle, substr( $sql, $offset ) );
			if ( false === $written || 0 === $written ) throw new Exception( 'No se pudo escribir el SQL temporal completo.' );
			$offset += $written;
		}
	}

	private static function sql_value( $value ) { if ( null === $value ) return 'NULL'; return "'" . str_replace( array( '\\', "\0", "\n", "\r", "\x1a", "'" ), array( '\\\\', '\\0', '\\n', '\\r', '\\Z', "\\'" ), (string) $value ) . "'"; }
	private static function protect( $dir ) { if ( ! file_exists( trailingslashit( $dir ) . 'index.php' ) ) file_put_contents( trailingslashit( $dir ) . 'index.php', "<?php // Silence is golden.\n" ); if ( ! file_exists( trailingslashit( $dir ) . '.htaccess' ) ) file_put_contents( trailingslashit( $dir ) . '.htaccess', "Deny from all\n" ); }
	private static function transfer( $file, $s ) { if ( 'sftp' === $s['destination'] ) return self::sftp( $file, $s ); if ( 'google' === $s['destination'] ) return self::google( $file, $s ); if ( 'onedrive' === $s['destination'] ) return self::onedrive( $file, $s ); }
	private static function sftp( $file, $s ) {
		$connection = self::sftp_connection( $s );
		$sftp = @ssh2_sftp( $connection );
		if ( ! $sftp ) throw new Exception( 'No se pudo iniciar SFTP en el servidor remoto.' );
		$directory = rtrim( (string) $s['sftp_path'], '/' );
		if ( '' === $directory ) $directory = '/';
		if ( '/' !== substr( $directory, 0, 1 ) ) throw new Exception( 'La carpeta SFTP debe ser una ruta absoluta.' );
		$remote = rtrim( $directory, '/' ) . '/' . wp_basename( $file );
		$temporary = $remote . '.part-' . bin2hex( random_bytes( 6 ) );
		$source_size = @filesize( $file );
		$source_hash = @hash_file( 'sha256', $file );
		if ( false === $source_size || false === $source_hash ) throw new Exception( 'No se puede verificar el ZIP local antes de subirlo.' );
		$source = @fopen( $file, 'rb' );
		$target_url = 'ssh2.sftp://' . intval( $sftp ) . $temporary;
		$target = @fopen( $target_url, 'wb' );
		if ( ! $source || ! $target ) {
			if ( $source ) fclose( $source );
			if ( $target ) fclose( $target );
			throw new Exception( 'No se pudo abrir el archivo local o el destino SFTP.' );
		}
		try {
			$copied = @stream_copy_to_stream( $source, $target );
			$flushed = @fflush( $target );
		} finally {
			fclose( $source );
			fclose( $target );
		}
		if ( false === $copied || $copied !== $source_size || ! $flushed ) {
			@ssh2_sftp_unlink( $sftp, $temporary );
			throw new Exception( 'La transferencia SFTP quedó incompleta.' );
		}
		$remote_hash = @hash_file( 'sha256', $target_url );
		if ( false === $remote_hash || ! hash_equals( $source_hash, $remote_hash ) ) {
			@ssh2_sftp_unlink( $sftp, $temporary );
			throw new Exception( 'La copia SFTP no coincide con el ZIP local.' );
		}
		if ( ! @ssh2_sftp_rename( $sftp, $temporary, $remote ) ) {
			@ssh2_sftp_unlink( $sftp, $temporary );
			throw new Exception( 'No se pudo publicar el respaldo verificado en SFTP.' );
		}
		return array( 'provider' => 'sftp', 'path' => $remote, 'sha256' => $source_hash );
	}
	private static function token( $url, $s, $prefix ) { if ( ! $s[ $prefix . '_client_id' ] || ! $s[ $prefix . '_client_secret' ] || ! $s[ $prefix . '_refresh_token' ] ) throw new Exception( 'Completa Client ID, Client secret y Refresh token del destino.' ); $response = wp_remote_post( $url, array( 'timeout' => 30, 'body' => array( 'client_id' => $s[ $prefix . '_client_id' ], 'client_secret' => $s[ $prefix . '_client_secret' ], 'refresh_token' => $s[ $prefix . '_refresh_token' ], 'grant_type' => 'refresh_token' ) ) ); $data = json_decode( wp_remote_retrieve_body( $response ), true ); if ( is_wp_error( $response ) || empty( $data['access_token'] ) ) throw new Exception( 'No se pudo renovar el acceso al almacenamiento remoto.' ); return $data['access_token']; }
	private static function google( $file, $s ) { $token = self::token( 'https://oauth2.googleapis.com/token', $s, 'google' ); $metadata = array( 'name' => wp_basename( $file ) ); if ( $s['google_folder_id'] ) $metadata['parents'] = array( $s['google_folder_id'] ); $response = wp_remote_post( 'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable', array( 'timeout' => 30, 'headers' => array( 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json; charset=UTF-8', 'X-Upload-Content-Type' => 'application/zip', 'X-Upload-Content-Length' => filesize( $file ) ), 'body' => wp_json_encode( $metadata ) ) ); $session = wp_remote_retrieve_header( $response, 'location' ); if ( is_wp_error( $response ) || ! $session ) throw new Exception( 'Google Drive no pudo iniciar la carga.' ); $result = json_decode( wp_remote_retrieve_body( self::resumable_upload( $session, $file, array( 'Content-Type' => 'application/zip' ) ) ), true ); if ( empty( $result['id'] ) ) throw new Exception( 'Google Drive no confirmó el archivo cargado.' ); return array( 'provider' => 'google', 'id' => sanitize_text_field( $result['id'] ) ); }
	private static function onedrive( $file, $s ) { $token = self::token( 'https://login.microsoftonline.com/common/oauth2/v2.0/token', $s, 'onedrive' ); $folder = trim( $s['onedrive_folder'], '/' ); $path = implode( '/', array_map( 'rawurlencode', array_filter( explode( '/', $folder ) ) ) ); $url = 'https://graph.microsoft.com/v1.0/me/drive/root:/' . $path . '/' . rawurlencode( wp_basename( $file ) ) . ':/createUploadSession'; $response = wp_remote_post( $url, array( 'timeout' => 30, 'headers' => array( 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'item' => array( '@microsoft.graph.conflictBehavior' => 'rename' ) ) ) ) ); $data = json_decode( wp_remote_retrieve_body( $response ), true ); if ( is_wp_error( $response ) || empty( $data['uploadUrl'] ) ) throw new Exception( 'OneDrive no pudo iniciar la carga. Verifica que exista la carpeta remota.' ); $result = json_decode( wp_remote_retrieve_body( self::resumable_upload( $data['uploadUrl'], $file, array(), 3276800 ) ), true ); if ( empty( $result['id'] ) ) throw new Exception( 'OneDrive no confirmó el archivo cargado.' ); return array( 'provider' => 'onedrive', 'id' => sanitize_text_field( $result['id'] ) ); }
	/** Sube en fragmentos para que archivos grandes no agoten la memoria del hosting. */
	private static function resumable_upload( $url, $file, $headers = array(), $chunk_size = 8388608 ) { $size = filesize( $file ); $handle = @fopen( $file, 'rb' ); if ( ! $handle ) throw new Exception( 'No se pudo leer el ZIP para transferirlo.' ); $offset = 0; $response = array(); while ( ! feof( $handle ) ) { $chunk = fread( $handle, $chunk_size ); if ( false === $chunk || '' === $chunk ) break; $end = $offset + strlen( $chunk ) - 1; $response = wp_remote_request( $url, array( 'method' => 'PUT', 'timeout' => 120, 'headers' => array_merge( $headers, array( 'Content-Length' => strlen( $chunk ), 'Content-Range' => 'bytes ' . $offset . '-' . $end . '/' . $size ) ), 'body' => $chunk ) ); $code = wp_remote_retrieve_response_code( $response ); if ( is_wp_error( $response ) || ! in_array( $code, array( 200, 201, 202, 308 ), true ) ) { fclose( $handle ); throw new Exception( 'El almacenamiento remoto interrumpió la transferencia.' ); } $offset = $end + 1; } fclose( $handle ); if ( $offset !== $size ) throw new Exception( 'La transferencia remota quedó incompleta.' ); return $response; }
	private static function remember( $file, $destination, $scope = 'site', $policy = array(), $remote = array(), $site_id = 0, $locked = false ) { $history = (array) get_option( self::HISTORY, array() ); $history = array_values( array_filter( $history, function( $entry ) use ( $file ) { return ( $entry['file'] ?? '' ) !== wp_basename( $file ); } ) ); $checksum = hash_file( 'sha256', $file ); if ( false === $checksum ) throw new Exception( 'No se pudo calcular el SHA-256 del respaldo terminado.' ); array_unshift( $history, array( 'date' => current_time( 'mysql' ), 'file' => wp_basename( $file ), 'size' => filesize( $file ), 'sha256' => $checksum, 'destination' => $destination, 'scope' => $scope, 'site_id' => $site_id ?: get_current_blog_id(), 'policy' => $policy['id'] ?? 'manual', 'backup_type' => $policy['type'] ?? ( false !== strpos( wp_basename( $file ), '-db-' ) ? 'database' : 'full' ), 'remote' => (array) $remote, 'locked' => $locked ) ); update_option( self::HISTORY, array_merge( array_slice( $history, 0, 100 ), array_values( array_filter( array_slice( $history, 100 ), function( $entry ) { return ! empty( $entry['locked'] ); } ) ) ), false ); }
	public static function toggle_lock() { if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); check_admin_referer( self::ACTION_LOCK ); $file = sanitize_file_name( wp_unslash( $_POST['file'] ?? '' ) ); $history = (array) get_option( self::HISTORY, array() ); foreach ( $history as &$item ) if ( hash_equals( (string) ( $item['file'] ?? '' ), $file ) ) $item['locked'] = ! empty( $_POST['locked'] ); unset( $item ); update_option( self::HISTORY, $history, false ); self::redirect( true, ! empty( $_POST['locked'] ) ? 'Respaldo bloqueado: no se eliminará durante la rotación.' : 'Respaldo desbloqueado.' ); }
	private static function prune( $dir, $keep ) { $history = (array) get_option( self::HISTORY, array() ); $locked = array_filter( array_column( array_filter( $history, function( $item ) { return ! empty( $item['locked'] ); } ), 'file' ) ); $files = glob( trailingslashit( $dir ) . 'digitalisimo-*.zip' ) ?: array(); usort( $files, function( $a, $b ) { return filemtime( $b ) <=> filemtime( $a ); } ); $rotating = array_values( array_filter( $files, function( $file ) use ( $locked ) { return ! in_array( wp_basename( $file ), $locked, true ); } ) ); foreach ( array_slice( $rotating, $keep ) as $file ) @unlink( $file ); }
	private static function prune_policy( $policy ) { $history = (array) get_option( self::HISTORY, array() ); $matching = array_values( array_filter( $history, function( $item ) use ( $policy ) { return ( $item['policy'] ?? '' ) === $policy['id'] && empty( $item['locked'] ); } ) ); foreach ( array_slice( $matching, (int) $policy['retain'] ) as $item ) { $path = trailingslashit( self::local_directory() ) . sanitize_file_name( $item['file'] ?? '' ); if ( is_file( $path ) ) @unlink( $path ); } }
		private static function redirect( $ok, $message, $network = null ) { $network = null === $network ? self::network_context() : $network; $url = $network ? network_admin_url( 'admin.php?page=digitalisimo-network-backups' ) : admin_url( 'admin.php?page=digitalisimo-backups' ); wp_safe_redirect( add_query_arg( array( 'backup' => $ok ? 'ok' : 'error', 'message' => rawurlencode( $message ) ), $url ) ); exit; }
	private static function create_for_policy( $policy, $site_id ) { if ( 'incremental' === $policy['type'] && ! self::latest_full_backup( $site_id ) ) return self::create_site( $site_id, 'full' ); return 'incremental' === $policy['type'] ? self::create_incremental_site( $site_id, $policy ) : self::create_site( $site_id, 'database' === $policy['type'] ? 'database' : 'full' ); }
	private static function latest_full_backup( $site_id ) { foreach ( (array) get_option( self::HISTORY, array() ) as $item ) if ( (int) ( $item['site_id'] ?? 0 ) === (int) $site_id && 'full' === ( $item['backup_type'] ?? '' ) && file_exists( trailingslashit( self::local_directory() ) . ( $item['file'] ?? '' ) ) ) return $item; return array(); }
	/** Delta restaurable: base de datos completa y sólo archivos modificados desde el último completo. */
	private static function create_incremental_site( $site_id, $policy ) {
		if ( ! class_exists( 'ZipArchive' ) ) throw new Exception( 'El servidor necesita la extensión PHP ZipArchive para crear el respaldo.' );
		$site = get_site( $site_id );
		if ( ! $site ) throw new Exception( 'El sitio de la política ya no existe.' );
		$dir = self::local_directory();
		if ( ! wp_mkdir_p( $dir ) || ! is_writable( $dir ) ) throw new Exception( 'No se puede escribir en la carpeta protegida de Digitalisimo Backups.' );
		self::protect( $dir );
		$base = self::latest_full_backup( $site_id );
		$since = $base ? (int) @filemtime( trailingslashit( $dir ) . $base['file'] ) : 0;
		$file = trailingslashit( $dir ) . 'digitalisimo-site-' . $site_id . '-' . sanitize_title( $site->domain ) . '-incremental-' . gmdate( 'Ymd-His' ) . '.zip';
		$zip = new ZipArchive();
		if ( true !== $zip->open( $file, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) throw new Exception( 'No se pudo crear el ZIP incremental.' );
		try {
			switch_to_blog( $site_id );
			try {
				global $wpdb;
				$prefix = $wpdb->prefix;
				$upload = wp_upload_dir();
				self::zip_add_string( $zip, 'database.sql', self::database_sql( self::site_tables( $prefix ), $prefix, 'wp_' ) );
				self::add_changed_directory( $zip, ABSPATH, $dir, $since, true );
				self::add_changed_directory( $zip, $upload['basedir'], $dir, $since, false, 'wordpress/wp-content/uploads/' );
				self::zip_add_string( $zip, 'manifest.json', wp_json_encode( array( 'format' => 'digitalisimo-backup/v2', 'scope' => 'site', 'type' => 'incremental', 'policy' => $policy['id'], 'base' => $base['file'] ?? '', 'requires_full_backup' => empty( $base ), 'since' => $since, 'created_at' => gmdate( 'c' ) ), JSON_PRETTY_PRINT ) );
			} finally {
				restore_current_blog();
			}
			self::finish_zip( $zip, $file );
			return $file;
		} catch ( Throwable $e ) {
			@$zip->close();
			@unlink( $file );
			throw $e;
		}
	}

	private static function add_changed_directory( $zip, $root, $backup_dir, $since, $exclude_uploads = false, $zip_prefix = 'wordpress/' ) { if ( ! is_dir( $root ) ) return; $iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::LEAVES_ONLY ); $root = trailingslashit( wp_normalize_path( $root ) ); $backup_dir = trailingslashit( wp_normalize_path( $backup_dir ) ); foreach ( $iterator as $entry ) { if ( ! $entry->isFile() || $entry->isLink() || ( $since && $entry->getMTime() <= $since ) ) continue; $path = wp_normalize_path( $entry->getPathname() ); $relative = ltrim( substr( $path, strlen( $root ) ), '/' ); if ( 0 === strpos( $path, $backup_dir ) || false !== strpos( $path, '/.git/' ) || false !== strpos( $path, '/node_modules/' ) || false !== strpos( $path, '/cache/' ) || ( $exclude_uploads && 0 === strpos( $path, trailingslashit( wp_normalize_path( WP_CONTENT_DIR . '/uploads' ) ) ) ) || ( $exclude_uploads && 'wp-config.php' === $relative ) ) continue; self::zip_add_file( $zip, $path, $zip_prefix . $relative ); } }
	private static function restore_panel( $history ) { $local = array_filter( (array) $history, function( $item ) { return 'local' === ( $item['destination'] ?? 'local' ) && in_array( $item['scope'] ?? '', array( 'network', 'installation' ), true ) && 'full' === ( $item['backup_type'] ?? 'full' ) && is_file( trailingslashit( self::local_directory() ) . ( $item['file'] ?? '' ) ); } ); echo '<section class="digitalisimo-backups-card"><h2>Restaurar respaldo local</h2><p>Antes de reemplazar la instalación, se creará y bloqueará un respaldo de seguridad actual. La restauración reemplaza la base de datos y los archivos incluidos. Escribe <code>RESTAURAR</code> para habilitarla.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( self::ACTION_RESTORE ); echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_RESTORE ) . '"><p><select name="backup_file"><option value="">Elige un respaldo de Digitalisimo</option>'; foreach ( $local as $item ) echo '<option value="' . esc_attr( $item['file'] ) . '">' . esc_html( $item['date'] . ' · ' . $item['file'] ) . '</option>'; echo '</select></p><p><label>Confirmación <input type="text" name="confirmation" placeholder="RESTAURAR" autocomplete="off"></label></p><p><button class="button button-primary">Restaurar respaldo seleccionado</button></p></form></section>'; }
	public static function restore_request() { if ( ! self::can_manage() ) wp_die( 'No autorizado.' ); check_admin_referer( self::ACTION_RESTORE ); @set_time_limit( 0 ); if ( 'RESTAURAR' !== strtoupper( trim( (string) ( $_POST['confirmation'] ?? '' ) ) ) ) self::redirect( false, 'Escribe RESTAURAR para confirmar una operación destructiva.' ); try { if ( ! empty( $_POST['updraft'] ) ) self::restore_updraft_set( sanitize_text_field( wp_unslash( $_POST['updraft_set'] ?? '' ) ) ); else { $file = sanitize_file_name( wp_unslash( $_POST['backup_file'] ?? '' ) ); $path = self::local_path( $file ); if ( ! $path ) throw new Exception( 'El respaldo local solicitado no está disponible.' ); self::restore_digitalisimo_zip( $path ); } self::redirect( true, 'Restauración terminada. Entra de nuevo y revisa enlaces permanentes.' ); } catch ( Exception $e ) { self::redirect( false, 'La restauración se detuvo: ' . $e->getMessage() ); } }
	private static function local_path( $file ) { $file = sanitize_file_name( $file ); $root = realpath( self::local_directory() ); $path = $root ? realpath( trailingslashit( $root ) . $file ) : false; return $path && 0 === strpos( wp_normalize_path( $path ), trailingslashit( wp_normalize_path( $root ) ) ) && is_file( $path ) ? $path : ''; }
	private static function restore_digitalisimo_zip( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) throw new Exception( 'El servidor no tiene ZipArchive.' );
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path, ZipArchive::CHECKCONS ) ) throw new Exception( 'No se puede abrir el ZIP.' );
		try {
			self::validate_zip_entries( $zip );
			self::verify_zip_contents( $zip );
			$manifest = $zip->getFromName( 'manifest.json' );
			$migration = $zip->getFromName( 'migration.json' );
			$metadata = false !== $manifest ? $manifest : $migration;
			$data = json_decode( $metadata, true );
			if ( ! is_array( $data ) || JSON_ERROR_NONE !== json_last_error() ) throw new Exception( 'La metadata del respaldo no es válida.' );
			if ( in_array( $data['type'] ?? '', array( 'incremental', 'database' ), true ) ) throw new Exception( 'Este paquete parcial no admite restauración completa sin su cadena de respaldo.' );
			if ( 'site' === ( $data['scope'] ?? '' ) ) throw new Exception( 'Una exportación anterior de subsitio no puede reemplazar una instalación completa.' );
			if ( ! in_array( $data['scope'] ?? '', array( 'network', 'installation' ), true ) ) throw new Exception( 'El alcance del respaldo completo no es compatible.' );
			if ( isset( $data['multisite'] ) && (bool) $data['multisite'] !== is_multisite() ) throw new Exception( 'No se puede restaurar directamente entre WordPress individual y Multisite.' );
			if ( is_multisite() && (int) get_current_blog_id() !== (int) get_main_site_id() ) throw new Exception( 'La red completa sólo puede restaurarse desde su sitio principal.' );
			if ( isset( $data['table_prefix'] ) && $data['table_prefix'] !== $GLOBALS['wpdb']->base_prefix ) throw new Exception( 'El prefijo de tablas difiere; la migración de prefijo necesita su propio proceso seguro.' );
			$sql_stat = $zip->statName( 'database.sql' );
			if ( ! $sql_stat || empty( $sql_stat['size'] ) ) throw new Exception( 'El ZIP no contiene una base de datos válida.' );
			$item = self::history_item( wp_basename( $path ) );
			if ( ! empty( $item['sha256'] ) ) {
				$checksum = @hash_file( 'sha256', $path );
				if ( false === $checksum || ! hash_equals( $item['sha256'], $checksum ) ) throw new Exception( 'El SHA-256 del respaldo ya no coincide con el archivo registrado.' );
			}
			$safety = self::create_network();
			$protected = dirname( $safety ) . '/safety-before-restore-' . wp_basename( $safety );
			if ( ! @rename( $safety, $protected ) ) throw new Exception( 'No se pudo proteger el respaldo previo a la restauración.' );
			$safety = $protected;
			$policy = array( 'id' => 'pre-restore', 'type' => 'full' );
			self::remember( $safety, 'local', is_multisite() ? 'network' : 'installation', $policy, array(), 0, true );
			$created_files = array();
			try {
				self::import_zip_sql( $zip );
				self::extract_digitalisimo_files( $zip, $created_files );
			} catch ( Throwable $failure ) {
				try {
					self::rollback_from_safety( $safety );
					self::remove_new_restore_files( $created_files );
					throw new Exception( 'La restauración falló. Se recuperaron la base de datos y los archivos anteriores desde ' . wp_basename( $safety ) . ' y se retiraron los archivos nuevos: ' . $failure->getMessage(), 0, $failure );
				} catch ( Throwable $rollback_error ) {
					if ( $rollback_error->getPrevious() === $failure ) throw $rollback_error;
					throw new Exception( 'La restauración falló y la reversión también falló. Conserva ' . wp_basename( $safety ) . ' para recuperación manual: ' . $rollback_error->getMessage(), 0, $failure );
				}
			} finally {
				// El SQL restaurado puede reemplazar el historial que acabamos de escribir.
				self::remember( $safety, 'local', is_multisite() ? 'network' : 'installation', $policy, array(), 0, true );
			}
		} finally {
			$zip->close();
		}
	}
	/** Sólo borra archivos creados por este intento y que no cambiaron desde que se escribieron. */
	private static function remove_new_restore_files( $created_files ) {
		$real_root = realpath( ABSPATH );
		if ( false === $real_root ) throw new Exception( 'No se puede comprobar la ruta de los archivos nuevos.' );
		$root = trailingslashit( wp_normalize_path( $real_root ) );
		foreach ( $created_files as $path => $expected_hash ) {
			$normalized = wp_normalize_path( $path );
			if ( 0 !== strpos( $normalized, $root ) || is_link( $path ) ) throw new Exception( 'Un archivo nuevo quedó fuera de la ruta segura de restauración.' );
			if ( ! file_exists( $path ) ) continue;
			$actual_hash = is_file( $path ) ? @hash_file( 'sha256', $path ) : false;
			if ( false === $actual_hash || ! hash_equals( $expected_hash, $actual_hash ) ) throw new Exception( 'Un archivo nuevo cambió durante la reversión y requiere revisión manual: ' . $path );
			if ( ! @unlink( $path ) ) throw new Exception( 'No se pudo retirar un archivo nuevo durante la reversión: ' . $path );
		}
	}
	/** Reintenta la instalación anterior sin crear otra copia ni entrar en recursión. */
	private static function rollback_from_safety( $path ) {
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path, ZipArchive::CHECKCONS ) ) throw new Exception( 'No se pudo abrir la copia de seguridad previa.' );
		try {
			self::validate_zip_entries( $zip );
			self::verify_zip_contents( $zip );
			$sql_stat = $zip->statName( 'database.sql' );
			if ( ! $sql_stat || empty( $sql_stat['size'] ) ) throw new Exception( 'La copia previa no contiene SQL.' );
			self::import_zip_sql( $zip );
			self::extract_digitalisimo_files( $zip );
		} finally {
			$zip->close();
		}
	}

	private static function validate_zip_entries( $zip ) {
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$name = str_replace( '\\', '/', (string) $zip->getNameIndex( $i ) );
			if ( '' === $name || '/' === substr( $name, 0, 1 ) || preg_match( '#(^|/)\.\.?(/|$)#', $name ) || preg_match( '/^[a-zA-Z]:/', $name ) || false !== strpos( $name, "\0" ) ) throw new Exception( 'El ZIP contiene una ruta no permitida.' );
		}
	}
	private static function extract_digitalisimo_files( $zip, &$created_files = null ) {
		$real_root = realpath( ABSPATH );
		if ( false === $real_root ) throw new Exception( 'No se pudo resolver la instalación de destino.' );
		$root = trailingslashit( wp_normalize_path( $real_root ) );
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$name = str_replace( '\\', '/', (string) $zip->getNameIndex( $i ) );
			if ( 0 !== strpos( $name, 'wordpress/' ) || 'wordpress/wp-config.php' === $name || '/' === substr( $name, -1 ) ) continue;
			$relative = substr( $name, strlen( 'wordpress/' ) );
			if ( ! $relative || 0 === strpos( $relative, '.git/' ) ) continue;
			$destination = $root . $relative;
			$current = rtrim( $root, '/' );
			foreach ( explode( '/', dirname( $relative ) ) as $part ) {
				if ( '.' === $part || '' === $part ) continue;
				$current .= '/' . $part;
				if ( is_link( $current ) ) throw new Exception( 'Una carpeta de restauración es un enlace simbólico: ' . $relative );
			}
			if ( is_link( $destination ) ) throw new Exception( 'Un archivo de restauración es un enlace simbólico: ' . $relative );
			$was_present = file_exists( $destination );
			if ( ! wp_mkdir_p( dirname( $destination ) ) ) throw new Exception( 'No se pudo preparar una carpeta de destino segura.' );
			$real_parent = realpath( dirname( $destination ) );
			if ( false === $real_parent || 0 !== strpos( trailingslashit( wp_normalize_path( $real_parent ) ), $root ) ) throw new Exception( 'La carpeta de destino sale de WordPress.' );
			$stat = $zip->statName( $name );
			$input = $zip->getStream( $name );
			$temp = $destination . '.digitalisimo-restore-' . wp_generate_uuid4();
			$output = @fopen( $temp, 'wb' );
			if ( ! $stat || ! $input || ! $output ) { if ( $input ) fclose( $input ); if ( $output ) fclose( $output ); @unlink( $temp ); throw new Exception( 'No se pudo preparar el archivo ' . $relative . ' para restaurarlo.' ); }
			$written = stream_copy_to_stream( $input, $output );
			$closed = fclose( $output );
			fclose( $input );
			$crc = @hash_file( 'crc32b', $temp );
			if ( false === $written || ! $closed || $written !== (int) $stat['size'] || false === $crc || $crc !== sprintf( '%08x', $stat['crc'] ) ) { @unlink( $temp ); throw new Exception( 'El archivo restaurado ' . $relative . ' quedó incompleto.' ); }
			$created_hash = ! $was_present && is_array( $created_files ) ? @hash_file( 'sha256', $temp ) : null;
			if ( false === $created_hash ) { @unlink( $temp ); throw new Exception( 'No se pudo verificar el archivo nuevo ' . $relative . '.' ); }
			if ( ! @rename( $temp, $destination ) ) { @unlink( $temp ); throw new Exception( 'No se pudo reemplazar el archivo ' . $relative . ' durante la restauración.' ); }
			if ( ! $was_present && is_array( $created_files ) ) $created_files[ $destination ] = $created_hash;
		}
	}

	private static function import_sql( $sql ) { global $wpdb; $statements = self::sql_statements( $sql ); if ( ! $statements ) throw new Exception( 'La base de datos del respaldo está vacía.' ); foreach ( $statements as $statement ) if ( false === $wpdb->query( $statement ) ) throw new Exception( 'Falló una sentencia SQL: ' . $wpdb->last_error ); }
	/** Lee el SQL del ZIP por fragmentos y ejecuta una sentencia a la vez. */
	private static function import_zip_sql( $zip ) {
		global $wpdb;
		$stream = $zip->getStream( 'database.sql' );
		if ( ! $stream ) throw new Exception( 'No se pudo leer la base de datos del ZIP.' );
		$current = '';
		$quote = '';
		$escaped = false;
		$count = 0;
		try {
			while ( ! feof( $stream ) ) {
				$chunk = fread( $stream, 65536 );
				if ( false === $chunk || ( '' === $chunk && ! feof( $stream ) ) ) throw new Exception( 'La base de datos del ZIP está truncada.' );
				$length = strlen( $chunk );
				for ( $i = 0; $i < $length; $i++ ) {
					$char = $chunk[ $i ];
					if ( $quote ) {
						$current .= $char;
						if ( $escaped ) { $escaped = false; continue; }
						if ( '\\' === $char ) { $escaped = true; continue; }
						if ( $char === $quote ) $quote = '';
						continue;
					}
					if ( "'" === $char || '"' === $char || '`' === $char ) { $quote = $char; $current .= $char; continue; }
					if ( ';' === $char ) {
						$statement = trim( $current );
						if ( $statement && 0 !== strpos( $statement, '--' ) ) {
							if ( false === $wpdb->query( $statement ) ) throw new Exception( 'Falló una sentencia SQL: ' . $wpdb->last_error );
							$count++;
						}
						$current = '';
						continue;
					}
					$current .= $char;
				}
			}
			if ( $quote ) throw new Exception( 'La base de datos del ZIP termina con una cadena SQL incompleta.' );
			$statement = trim( $current );
			if ( $statement && 0 !== strpos( $statement, '--' ) ) { if ( false === $wpdb->query( $statement ) ) throw new Exception( 'Falló una sentencia SQL: ' . $wpdb->last_error ); $count++; }
			if ( ! $count ) throw new Exception( 'La base de datos del respaldo está vacía.' );
		} finally {
			fclose( $stream );
		}
	}
	private static function sql_statements( $sql ) { $out = array(); $current = ''; $quote = ''; $escaped = false; $length = strlen( $sql ); for ( $i = 0; $i < $length; $i++ ) { $char = $sql[ $i ]; if ( $quote ) { $current .= $char; if ( $escaped ) { $escaped = false; continue; } if ( '\\' === $char ) { $escaped = true; continue; } if ( $char === $quote ) $quote = ''; continue; } if ( "'" === $char || '"' === $char || '`' === $char ) { $quote = $char; $current .= $char; continue; } if ( ';' === $char ) { $statement = trim( $current ); if ( $statement && 0 !== strpos( $statement, '--' ) ) $out[] = $statement; $current = ''; continue; } $current .= $char; } $statement = trim( $current ); if ( $statement ) $out[] = $statement; return $out; }
	private static function restore_updraft_set( $id ) { $sets = self::detect_updraft_sets(); if ( empty( $sets[ $id ] ) || true !== self::validate_backup_set( $sets[ $id ] ) ) throw new Exception( 'El conjunto UpdraftPlus no está completo, es cifrado o no se puede leer.' ); $set = $sets[ $id ]; $database = $set['files']['db'][0]['path']; $sql = 'gz' === strtolower( pathinfo( $database, PATHINFO_EXTENSION ) ) ? @gzdecode( (string) file_get_contents( $database ) ) : @file_get_contents( $database ); if ( ! $sql ) throw new Exception( 'No se pudo descomprimir la base de datos de UpdraftPlus.' ); self::import_sql( $sql ); foreach ( array( 'plugins' => WP_PLUGIN_DIR, 'themes' => get_theme_root(), 'uploads' => wp_upload_dir()['basedir'], 'others' => WP_CONTENT_DIR ) as $component => $root ) foreach ( (array) ( $set['files'][ $component ] ?? array() ) as $part ) self::extract_updraft_zip( $part['path'], $root, $component ); }
	private static function extract_updraft_zip( $path, $root, $component ) { if ( 'zip' !== strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) throw new Exception( 'El archivo UpdraftPlus de ' . $component . ' no es ZIP.' ); $zip = new ZipArchive(); if ( true !== $zip->open( $path ) ) throw new Exception( 'No se pudo abrir una pieza UpdraftPlus.' ); self::validate_zip_entries( $zip ); for ( $i = 0; $i < $zip->numFiles; $i++ ) { $name = str_replace( '\\', '/', (string) $zip->getNameIndex( $i ) ); if ( substr( $name, -1 ) === '/' ) continue; $relative = preg_replace( '#^(wp-content/)?' . preg_quote( $component, '#' ) . '/#', '', $name ); if ( ! $relative || 0 === strpos( $relative, 'wp-config.php' ) ) continue; $destination = trailingslashit( $root ) . $relative; if ( ! wp_mkdir_p( dirname( $destination ) ) ) { $zip->close(); throw new Exception( 'No se pudo crear una carpeta para UpdraftPlus.' ); } $input = $zip->getStream( $name ); $output = @fopen( $destination, 'wb' ); if ( ! $input || ! $output ) { $zip->close(); throw new Exception( 'No se pudo restaurar un archivo UpdraftPlus.' ); } stream_copy_to_stream( $input, $output ); fclose( $input ); fclose( $output ); } $zip->close(); }
	private static function history_item( $file ) { foreach ( (array) get_option( self::HISTORY, array() ) as $item ) if ( hash_equals( (string) ( $item['file'] ?? '' ), $file ) ) return $item; return array(); }
	private static function remove_history( $file ) { $history = array_values( array_filter( (array) get_option( self::HISTORY, array() ), function( $row ) use ( $file ) { return ! hash_equals( (string) ( $row['file'] ?? '' ), $file ); } ) ); update_option( self::HISTORY, $history, false ); }
	private static function download_remote( $item ) { $remote = (array) ( $item['remote'] ?? array() ); $provider = $remote['provider'] ?? ''; $settings = self::settings(); if ( ! $provider ) wp_die( 'Este respaldo remoto fue creado antes de guardar su identificador. Conserva la copia remota o genera un respaldo nuevo.' ); if ( 'sftp' === $provider ) { $connection = self::sftp_connection( $settings ); $sftp = ssh2_sftp( $connection ); $stream = @fopen( 'ssh2.sftp://' . intval( $sftp ) . (string) $remote['path'], 'rb' ); if ( ! $stream ) wp_die( 'No se pudo leer el respaldo SFTP.' ); nocache_headers(); header( 'Content-Type: application/zip' ); header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $item['file'] ) . '"' ); fpassthru( $stream ); fclose( $stream ); return; } $token = self::token( 'google' === $provider ? 'https://oauth2.googleapis.com/token' : 'https://login.microsoftonline.com/common/oauth2/v2.0/token', $settings, $provider ); $url = 'google' === $provider ? 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $remote['id'] ) . '?alt=media' : 'https://graph.microsoft.com/v1.0/me/drive/items/' . rawurlencode( $remote['id'] ) . '/content'; $response = wp_remote_get( $url, array( 'timeout' => 120, 'redirection' => 5, 'headers' => array( 'Authorization' => 'Bearer ' . $token ) ) ); if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) wp_die( 'No se pudo descargar el respaldo remoto.' ); nocache_headers(); header( 'Content-Type: application/zip' ); header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $item['file'] ) . '"' ); echo wp_remote_retrieve_body( $response ); }
	private static function delete_remote( $item ) { $remote = (array) ( $item['remote'] ?? array() ); $provider = $remote['provider'] ?? ''; $settings = self::settings(); if ( ! $provider ) throw new Exception( 'Este respaldo remoto no tiene identificador para eliminarse desde WordPress.' ); if ( 'sftp' === $provider ) { $connection = self::sftp_connection( $settings ); $sftp = ssh2_sftp( $connection ); if ( ! @ssh2_sftp_unlink( $sftp, (string) $remote['path'] ) ) throw new Exception( 'No se pudo eliminar el archivo SFTP.' ); return; } $token = self::token( 'google' === $provider ? 'https://oauth2.googleapis.com/token' : 'https://login.microsoftonline.com/common/oauth2/v2.0/token', $settings, $provider ); $url = 'google' === $provider ? 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $remote['id'] ) : 'https://graph.microsoft.com/v1.0/me/drive/items/' . rawurlencode( $remote['id'] ); $response = wp_remote_request( $url, array( 'method' => 'DELETE', 'timeout' => 60, 'headers' => array( 'Authorization' => 'Bearer ' . $token ) ) ); if ( is_wp_error( $response ) || ! in_array( wp_remote_retrieve_response_code( $response ), array( 200, 204 ), true ) ) throw new Exception( 'El proveedor remoto no confirmó la eliminación.' ); }
	private static function sftp_connection( $s ) {
		if ( ! function_exists( 'ssh2_connect' ) || ! function_exists( 'ssh2_fingerprint' ) || empty( $s['sftp_host'] ) || empty( $s['sftp_user'] ) || empty( $s['sftp_password'] ) ) throw new Exception( 'Completa la conexión SFTP para gestionar este respaldo.' );
		$expected = strtoupper( str_replace( ':', '', trim( (string) ( $s['sftp_fingerprint'] ?? '' ) ) ) );
		if ( ! preg_match( '/^[A-F0-9]{40}$/', $expected ) ) throw new Exception( 'Configura y verifica la huella SHA-1 de la clave SSH del servidor antes de usar SFTP.' );
		$connection = @ssh2_connect( $s['sftp_host'], (int) $s['sftp_port'] );
		if ( ! $connection ) throw new Exception( 'No se pudo conectar al servidor SFTP.' );
		$actual = @ssh2_fingerprint( $connection, SSH2_FINGERPRINT_SHA1 | SSH2_FINGERPRINT_HEX );
		if ( ! is_string( $actual ) || ! hash_equals( $expected, strtoupper( $actual ) ) ) throw new Exception( 'La huella de la clave SSH del servidor SFTP no coincide con la configurada.' );
		if ( ! @ssh2_auth_password( $connection, $s['sftp_user'], $s['sftp_password'] ) ) throw new Exception( 'No se pudo autenticar en SFTP.' );
		return $connection;
	}
	private static function destination_label( $destination ) { return array( 'local' => 'Hosting / local', 'sftp' => 'SFTP', 'google' => 'Google Drive', 'onedrive' => 'OneDrive' )[ $destination ] ?? 'Local'; }
	public static function save_server_catalog() { if ( ! current_user_can( 'manage_options' ) ) wp_die( 'No autorizado.' ); check_admin_referer( 'digitalisimo_backups_server' ); $input = (array) ( $_POST['digitalisimo_backup_server'] ?? array() ); $type = sanitize_key( $input['type'] ?? '' ); $name = sanitize_text_field( $input['name'] ?? '' ); if ( ! $name || ! in_array( $type, array( 'sftp', 'google', 'onedrive' ), true ) ) wp_die( 'Nombre o tipo de servidor inválido.' ); $servers = self::servers(); $servers[] = array( 'id' => 'server-' . wp_generate_uuid4(), 'type' => $type, 'name' => $name, 'verified' => false ); update_option( self::SERVERS, $servers, false ); wp_safe_redirect( self::admin_url() ); exit; }
}
