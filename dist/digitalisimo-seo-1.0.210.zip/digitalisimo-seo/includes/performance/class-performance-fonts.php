<?php
defined( 'ABSPATH' ) || exit;

/** Inventario administrativo de Kit y fuentes locales. No filtra fuentes en frontend. */
class Digitalisimo_Integrations_Performance_Fonts {
	const OPTION = 'digitalisimo_performance_font_inventory';

	public static function init() {
		add_action( 'admin_post_digitalisimo_performance_scan_fonts', array( __CLASS__, 'scan_action' ) );
	}

	private static function kit_settings() {
		if ( ! class_exists( '\\Elementor\\Plugin' ) || ! isset( \Elementor\Plugin::$instance->kits_manager ) ) return array( 0, array() );
		$manager = \Elementor\Plugin::$instance->kits_manager;
		if ( ! method_exists( $manager, 'get_active_kit_for_frontend' ) ) return array( 0, array() );
		$kit = $manager->get_active_kit_for_frontend();
		if ( ! is_object( $kit ) || ! method_exists( $kit, 'get_id' ) ) return array( 0, array() );
		$id = absint( $kit->get_id() );
		$settings = method_exists( $kit, 'get_settings' ) ? $kit->get_settings() : array();
		if ( ! is_array( $settings ) || ! $settings ) $settings = get_post_meta( $id, '_elementor_page_settings', true );
		return array( $id, is_array( $settings ) ? $settings : array() );
	}

	/** Extrae familias y variantes, incluida la tipografía global; no presume que el Kit cubra todo el frontend. */
	public static function families_from_settings( $settings ) {
		$families = array();
		$walk = function( $node ) use ( &$walk, &$families ) {
			if ( ! is_array( $node ) ) return;
			foreach ( $node as $key => $value ) {
				if ( is_string( $key ) && preg_match( '/(?:^|_)font_family$/', $key ) && is_string( $value ) && '' !== trim( $value ) ) {
					$family = trim( $value );
					$base = substr( $key, 0, -strlen( 'font_family' ) );
					$weight = trim( (string) ( $node[ $base . 'font_weight' ] ?? '' ) );
					$style = trim( (string) ( $node[ $base . 'font_style' ] ?? '' ) );
					$index = strtolower( $family );
					if ( ! isset( $families[ $index ] ) ) $families[ $index ] = array( 'family' => $family, 'weights' => array(), 'styles' => array(), 'unknown_weight' => false, 'unknown_style' => false );
					if ( $weight ) $families[ $index ]['weights'][ $weight ] = true;
					else $families[ $index ]['unknown_weight'] = true;
					if ( $style ) $families[ $index ]['styles'][ $style ] = true;
					else $families[ $index ]['unknown_style'] = true;
				} elseif ( is_array( $value ) ) $walk( $value );
			}
		};
		$walk( (array) $settings );
		foreach ( $families as &$row ) { $row['weights'] = $row['unknown_weight'] ? array() : array_keys( $row['weights'] ); $row['styles'] = $row['unknown_style'] ? array() : array_keys( $row['styles'] ); unset( $row['unknown_weight'], $row['unknown_style'] ); }
		return array_values( $families );
	}

	/**
	 * Variantes que pinta el primer render: cuerpo y H1 del Kit, y las tipografías
	 * globales «text» y «primary» que Elementor usa cuando no hay una explícita.
	 * Un cuerpo sin peso declarado usa el 400 del CSS; un H1 sin peso no se
	 * adivina, porque su peso real depende del tema.
	 */
	public static function critical_from_settings( $settings ) {
		$settings = (array) $settings;
		$critical = array();
		$add = function( $family, $weight, $style, $role, $body ) use ( &$critical ) {
			$family = trim( (string) $family );
			if ( '' === $family ) return;
			$weight = strtolower( trim( (string) $weight ) );
			if ( '' === $weight || 'normal' === $weight ) $weight = $body ? '400' : '';
			if ( 'bold' === $weight ) $weight = '700';
			if ( ! preg_match( '/^[1-9]00$/', $weight ) ) return;
			$style = strtolower( trim( (string) $style ) );
			if ( '' === $style ) $style = 'normal';
			if ( ! in_array( $style, array( 'normal', 'italic', 'oblique' ), true ) ) return;
			$key = strtolower( $family ) . '|' . $weight . '|' . $style;
			if ( ! isset( $critical[ $key ] ) ) $critical[ $key ] = array( 'family' => $family, 'weight' => $weight, 'style' => $style, 'role' => $role, 'body' => (bool) $body );
		};
		$system = array();
		foreach ( (array) ( $settings['system_typography'] ?? array() ) as $item ) if ( is_array( $item ) && ! empty( $item['_id'] ) ) $system[ $item['_id'] ] = $item;
		$add( $settings['body_typography_font_family'] ?? '', $settings['body_typography_font_weight'] ?? '', $settings['body_typography_font_style'] ?? '', 'Cuerpo', true );
		if ( isset( $system['text'] ) ) $add( $system['text']['typography_font_family'] ?? '', $system['text']['typography_font_weight'] ?? '', $system['text']['typography_font_style'] ?? '', 'Texto global', true );
		$add( $settings['h1_typography_font_family'] ?? '', $settings['h1_typography_font_weight'] ?? '', $settings['h1_typography_font_style'] ?? '', 'H1', false );
		if ( isset( $system['primary'] ) ) $add( $system['primary']['typography_font_family'] ?? '', $system['primary']['typography_font_weight'] ?? '', $system['primary']['typography_font_style'] ?? '', 'Principal global', false );
		return array_values( $critical );
	}

	/** Negritas y cursivas escritas en el contenido: el navegador las pinta en 700 e italic. */
	public static function inline_formatting( $text ) {
		$text = (string) $text;
		return array(
			'bold'   => (bool) preg_match( '/(?:<|\\\\u003c)(?:strong|b)(?:[\s>\/]|\\\\u003e)/i', $text ),
			'italic' => (bool) preg_match( '/(?:<|\\\\u003c)(?:em|i)(?:[\s>\/]|\\\\u003e)/i', $text ),
		);
	}

	/** Contenido publicado fuera de Elementor (entradas de bloques o clásicas). */
	private static function posts_inline_formatting() {
		global $wpdb;
		$found = array( 'bold' => false, 'italic' => false );
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'get_var' ) || ! function_exists( 'get_post_types' ) ) return $found;
		$types = array_values( get_post_types( array( 'public' => true ), 'names' ) );
		if ( ! $types ) return $found;
		$in = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$patterns = array( 'bold' => array( '%<strong%', '%<b>%', '%<b %' ), 'italic' => array( '%<em>%', '%<em %', '%<i>%', '%<i %' ) );
		foreach ( $patterns as $key => $likes ) {
			$where = implode( ' OR ', array_fill( 0, count( $likes ), 'post_content LIKE %s' ) );
			// LIMIT 1: basta un caso para saber que la variante se usa.
			$found[ $key ] = (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in) AND ( $where ) LIMIT 1", array_merge( $types, $likes ) ) );
		}
		return $found;
	}

	/**
	 * Un <strong> en un párrafo usa la familia del cuerpo en 700, y un <em> la
	 * usa en italic: son variantes realmente usadas aunque el Kit no las declare.
	 */
	public static function inline_families( $critical, $inline ) {
		$rows = array();
		foreach ( (array) $critical as $row ) {
			if ( empty( $row['body'] ) ) continue;
			$weights = array( (string) $row['weight'] );
			$styles  = array( (string) $row['style'] );
			if ( ! empty( $inline['bold'] ) ) $weights[] = '700';
			if ( ! empty( $inline['italic'] ) ) $styles[] = 'italic';
			if ( count( $weights ) > 1 || count( $styles ) > 1 ) $rows[] = array( 'family' => $row['family'], 'weights' => array_values( array_unique( $weights ) ), 'styles' => array_values( array_unique( $styles ) ) );
		}
		return $rows;
	}

	/** Une el Kit con las tipografías configuradas en contenido Elementor publicado. */
	public static function merge_families( $groups ) {
		$merged = array();
		foreach ( $groups as $group ) foreach ( (array) $group as $row ) {
			$name = trim( (string) ( $row['family'] ?? '' ) );
			if ( '' === $name ) continue;
			$key = strtolower( $name );
			if ( ! isset( $merged[ $key ] ) ) $merged[ $key ] = array( 'family' => $name, 'weights' => array(), 'styles' => array(), 'unknown_weight' => false, 'unknown_style' => false );
			foreach ( array( 'weights' => 'unknown_weight', 'styles' => 'unknown_style' ) as $field => $unknown ) {
				$values = (array) ( $row[ $field ] ?? array() );
				if ( ! $values ) $merged[ $key ][ $unknown ] = true;
				foreach ( $values as $value ) {
					$value = strtolower( trim( (string) $value ) );
					if ( 'weights' === $field && 'normal' === $value ) $value = '400';
					if ( 'weights' === $field && 'bold' === $value ) $value = '700';
					if ( '' !== $value ) $merged[ $key ][ $field ][ $value ] = true;
				}
			}
		}
		foreach ( $merged as &$row ) { $row['weights'] = $row['unknown_weight'] ? array() : array_keys( $row['weights'] ); $row['styles'] = $row['unknown_style'] ? array() : array_keys( $row['styles'] ); unset( $row['unknown_weight'], $row['unknown_style'] ); }
		return array_values( $merged );
	}

	/** Escaneo acotado a 500 documentos; un inventario parcial nunca autoriza excluir familias desconocidas. */
	public static function content_families() {
		if ( ! function_exists( 'get_posts' ) || ! function_exists( 'get_post_types' ) ) return array( array(), 0, false, array( 'bold' => false, 'italic' => false ) );
		$types = array_values( array_unique( array_merge( array_values( get_post_types( array( 'public' => true ), 'names' ) ), array( 'elementor_library' ) ) ) );
		$groups = array(); $count = 0; $complete = true; $inline = array( 'bold' => false, 'italic' => false );
		for ( $page = 0; $page < 5; ++$page ) {
			$ids = get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'meta_key' => '_elementor_edit_mode', 'meta_value' => 'builder', 'fields' => 'ids', 'posts_per_page' => 100, 'offset' => $page * 100, 'orderby' => 'ID', 'order' => 'ASC', 'no_found_rows' => true, 'suppress_filters' => false ) );
			if ( ! is_array( $ids ) ) { $complete = false; break; }
			foreach ( $ids as $id ) {
				++$count;
				$data = get_post_meta( (int) $id, '_elementor_data', true );
				if ( ! is_string( $data ) || strlen( $data ) > 1024 * 1024 ) { $complete = false; continue; }
				if ( false !== stripos( $data, 'font-family' ) ) $complete = false; // CSS libre no se puede clasificar como una tipografía Elementor.
				foreach ( self::inline_formatting( $data ) as $kind => $used ) if ( $used ) $inline[ $kind ] = true;
				$decoded = json_decode( $data, true );
				if ( ! is_array( $decoded ) ) { $complete = false; continue; }
				$groups[] = self::families_from_settings( $decoded );
				$settings = get_post_meta( (int) $id, '_elementor_page_settings', true );
				if ( is_array( $settings ) ) $groups[] = self::families_from_settings( $settings );
			}
			if ( count( $ids ) < 100 ) break;
			if ( 4 === $page ) $complete = false;
		}
		return array( self::merge_families( $groups ), $count, $complete, $inline );
	}

	/** Sólo lee CSS generado dentro de uploads del sitio actual, con límites estrictos. */
	private static function local_faces() {
		$uploads = wp_upload_dir();
		$root = realpath( $uploads['basedir'] ?? '' );
		$directory = realpath( trailingslashit( $uploads['basedir'] ?? '' ) . 'elementor/google-fonts/css' );
		if ( ! $root || ! $directory || 0 !== strpos( $directory, trailingslashit( $root ) ) ) return array();
		$files = glob( $directory . '/*.css' );
		if ( ! is_array( $files ) ) return array();
		$faces = array();
		$files = array_values( array_filter( $files, function( $path ) { return 0 !== strpos( basename( $path ), 'digitalisimo-' ); } ) );
		foreach ( array_slice( $files, 0, 50 ) as $path ) {
			$real = realpath( $path );
			if ( ! $real || 0 !== strpos( $real, trailingslashit( $directory ) ) || ! is_file( $real ) || ! is_readable( $real ) || filesize( $real ) > 512 * KB_IN_BYTES ) continue;
			$css = file_get_contents( $real );
			if ( ! is_string( $css ) || ! preg_match_all( '/@font-face\s*\{([^}]*)\}/i', $css, $blocks ) ) continue;
			foreach ( array_slice( $blocks[1], 0, 300 ) as $block ) {
				if ( ! preg_match( '/font-family\s*:\s*([^;]+)/i', $block, $family ) ) continue;
				$row = array( 'family' => trim( $family[1], " \t\n\r\0\x0B'\"" ), 'weight' => '', 'style' => '', 'format' => '', 'unicode_range' => '', 'css' => basename( $real ), 'url' => '' );
				foreach ( array( 'font-weight' => 'weight', 'font-style' => 'style' ) as $property => $field ) if ( preg_match( '/' . $property . '\s*:\s*([^;]+)/i', $block, $match ) ) $row[ $field ] = trim( $match[1] );
				if ( preg_match( '/unicode-range\s*:\s*([^;]+)/i', $block, $range ) ) $row['unicode_range'] = trim( $range[1] );
				if ( preg_match( '/format\(\s*[\'\"]?([^\'\")]+)/i', $block, $format ) ) $row['format'] = trim( $format[1] );
				if ( preg_match( '/url\(\s*[\'\"]?([^\'\")]+\.woff2)(?:\?[^\'\")]+)?[\'\"]?\s*\)/i', $block, $source ) ) {
					$font_source = $source[1];
					$base_url = trailingslashit( $uploads['baseurl'] ?? '' );
					if ( preg_match( '~^https?://~i', $font_source ) ) {
						$relative = 0 === strpos( $font_source, $base_url ) ? substr( $font_source, strlen( $base_url ) ) : '';
						$font_path = $relative && false === strpos( $relative, '..' ) && preg_match( '~^elementor/google-fonts/fonts/[a-zA-Z0-9._/-]+\.woff2$~', $relative ) ? realpath( trailingslashit( $root ) . $relative ) : false;
					} else $font_path = realpath( dirname( $real ) . '/' . $font_source );
					if ( $font_path && 0 === strpos( $font_path, trailingslashit( $root ) ) && is_file( $font_path ) ) $row['url'] = trailingslashit( $uploads['baseurl'] ) . str_replace( DIRECTORY_SEPARATOR, '/', substr( $font_path, strlen( trailingslashit( $root ) ) ) );
				}
				$faces[] = $row;
				if ( count( $faces ) >= 500 ) break 2;
			}
		}
		return $faces;
	}

	public static function scan() {
		list( $kit_id, $settings ) = self::kit_settings();
		list( $content_families, $documents, $complete, $inline ) = self::content_families();
		foreach ( self::posts_inline_formatting() as $kind => $used ) if ( $used ) $inline[ $kind ] = true;
		$kit_families = self::families_from_settings( $settings );
		if ( false !== stripos( (string) json_encode( $settings ), 'font-family' ) ) $complete = false;
		if ( function_exists( 'wp_get_custom_css' ) && false !== stripos( (string) wp_get_custom_css(), 'font-family' ) ) $complete = false;
		if ( class_exists( 'Digitalisimo_Integrations_SEO_Resolver' ) && false !== stripos( (string) Digitalisimo_Integrations_SEO_Resolver::option( 'perf_custom_css' ), 'font-family' ) ) $complete = false;
		$uploads = wp_upload_dir();
		$faces = self::local_faces();
		$css_files = glob( trailingslashit( $uploads['basedir'] ?? '' ) . 'elementor/google-fonts/css/*.css' );
		if ( is_array( $css_files ) ) $css_files = array_filter( $css_files, function( $path ) { return 0 !== strpos( basename( $path ), 'digitalisimo-' ); } );
		if ( ( is_array( $css_files ) && count( $css_files ) > 50 ) || count( $faces ) >= 500 ) $complete = false;
		$critical = self::critical_from_settings( $settings );
		$report = array( 'kit_id' => $kit_id, 'kit_families' => $kit_families, 'critical' => $critical, 'inline' => $inline, 'families' => self::merge_families( array( $kit_families, $content_families, self::inline_families( $critical, $inline ) ) ), 'documents' => $documents, 'complete' => $complete && $kit_id > 0 && $documents > 0, 'faces' => $faces, 'uploads_baseurl' => trailingslashit( $uploads['baseurl'] ?? '' ), 'scanned_at' => current_time( 'mysql' ) );
		update_option( self::OPTION, $report, false );
		Digitalisimo_Integrations_Performance_Cache::set( 'fonts', $report, 3600 );
		return $report;
	}

	public static function scan_action() {
		$network = ! empty( $_POST['network_context'] );
		if ( $network ? ! is_multisite() || ! current_user_can( 'manage_network_options' ) : ! current_user_can( 'manage_options' ) ) wp_die( 'No autorizado.' );
		$site_id = absint( $_POST['site_id'] ?? 0 );
		if ( ! $site_id || ( $network ? ! get_site( $site_id ) : $site_id !== get_current_blog_id() ) ) wp_die( 'Sitio inválido.' );
		check_admin_referer( 'digitalisimo_performance_scan_fonts_' . $site_id );
		$switched = $site_id !== get_current_blog_id();
		if ( $switched ) switch_to_blog( $site_id );
		try { Digitalisimo_Integrations_Performance_Font_Guard::recalculate(); }
		finally { if ( $switched ) restore_current_blog(); }
		$target = $network ? network_admin_url( 'admin.php?page=digitalisimo-network-performance&section=fonts&site_id=' . $site_id ) : admin_url( 'admin.php?page=digitalisimo-performance&section=fonts' );
		wp_safe_redirect( $target );
		exit;
	}

	public static function render( $network = false ) {
		$site_id = $network ? absint( $_GET['site_id'] ?? get_current_blog_id() ) : get_current_blog_id();
		if ( $network && ! get_site( $site_id ) ) $site_id = get_current_blog_id();
		$action = admin_url( 'admin-post.php' );
		$switched = $site_id !== get_current_blog_id();
		if ( $switched ) switch_to_blog( $site_id );
		try {
			$report = get_option( self::OPTION, array() );
			$guard  = Digitalisimo_Integrations_Performance_Font_Guard::class;
			$status = $guard::status();
			$modes  = array( 'off' => 'Apagado', 'auto' => 'Seguro', 'strict' => 'Estricto', 'manual' => 'Manual' );
			if ( $network ) { echo '<h2>Todos los sitios</h2>'; $guard::render_network_recalculate(); }
			echo '<h2>Fuentes de este sitio</h2><p>Sitio: <code>' . esc_html( home_url( '/' ) ) . '</code>. Cada sitio detecta sus propias familias, estilos y pesos en el Kit y en el contenido Elementor publicado, y genera su CSS sólo con las variantes autorizadas. Los originales no se modifican y los icon fonts nunca se filtran.</p>';
			if ( isset( $_GET['font_guard_error'] ) ) echo '<div class="notice notice-error"><p>' . esc_html( wp_unslash( $_GET['font_guard_error'] ) ) . '</p></div>';
			if ( isset( $_GET['font_guard_optimized'] ) ) echo '<div class="notice notice-success"><p>Modo seguro activado para este sitio. Reglas @font-face omitidas: ' . esc_html( absint( $_GET['font_guard_optimized'] ) ) . '.</p></div>';
			if ( isset( $_GET['font_guard_recalculated'] ) ) echo '<div class="notice notice-success"><p>Fuentes recalculadas con el modo vigente. Reglas @font-face omitidas: ' . esc_html( absint( $_GET['font_guard_recalculated'] ) ) . '.</p></div>';

			echo '<form method="post" action="' . esc_url( $action ) . '" style="display:inline-block;margin-right:8px"><input type="hidden" name="action" value="digitalisimo_performance_optimize_fonts"><input type="hidden" name="network_context" value="' . ( $network ? '1' : '0' ) . '"><input type="hidden" name="site_id" value="' . esc_attr( $site_id ) . '">';
			wp_nonce_field( 'digitalisimo_performance_optimize_fonts_' . $site_id );
			submit_button( 'Detectar y optimizar (modo seguro)', 'primary', 'submit', false );
			echo '</form>';
			$guard::render_recalculate( $network, $site_id );
			echo '<p class="description">«Detectar y optimizar» activa el modo Seguro en este sitio. «Recalcular fuentes» vuelve a detectar y regenera el CSS y los preloads con el modo que tenga configurado. El recálculo también ocurre solo al editar en Elementor, cambiar la política o limpiar la caché de rendimiento.</p>';

			if ( is_array( $report ) && ! empty( $report['scanned_at'] ) ) {
				$names = array();
				foreach ( (array) ( $report['families'] ?? array() ) as $row ) if ( ! empty( $row['family'] ) ) $names[] = $row['family'];
				echo '<table class="widefat striped" style="max-width:900px"><tbody>';
				echo '<tr><th>Modo efectivo</th><td>' . esc_html( $modes[ $status['mode'] ] ?? $status['mode'] ) . '</td></tr>';
				echo '<tr><th>Familias detectadas</th><td>' . esc_html( $names ? implode( ', ', $names ) : 'Ninguna' ) . '</td></tr>';
				$inline = (array) ( $report['inline'] ?? array() );
				$formats = array_keys( array_filter( array( 'negritas (700)' => ! empty( $inline['bold'] ), 'cursivas (italic)' => ! empty( $inline['italic'] ) ) ) );
				echo '<tr><th>Formato en el contenido</th><td>' . esc_html( $formats ? 'Se encontraron ' . implode( ' y ', $formats ) . ': se autorizan para la familia del texto.' : 'Sin negritas ni cursivas detectadas.' ) . '</td></tr>';
				echo '<tr><th>Inventario</th><td>' . esc_html( (int) ( $report['documents'] ?? 0 ) . ' documentos Elementor · ' . ( ! empty( $report['complete'] ) ? 'completo' : 'parcial' ) . ' · ' . $report['scanned_at'] ) . '</td></tr>';
				echo '<tr><th>CSS generado</th><td>' . esc_html( $status['remote'] ? 'Google Fonts remoto: la URL de fonts.googleapis.com se reescribe con las variantes autorizadas.' : ( $status['copies'] ? $status['copies'] . ' copias activas · ' . $status['removed'] . ' reglas omitidas' : 'Sin copias activas: se sirve el CSS original.' ) ) . '</td></tr>';
				if ( $status['undetected'] ) echo '<tr><th>Conservadas sin detectar</th><td>' . esc_html( implode( ', ', $status['undetected'] ) ) . ' <span class="description">— el modo Seguro las mantiene y las registra aquí.</span></td></tr>';
				echo '</tbody></table>';
				if ( 'strict' === $status['mode'] && empty( $report['complete'] ) ) echo '<div class="notice notice-warning inline"><p>Modo Estricto con inventario parcial: las familias que la detección no alcanzó a ver se eliminan del CSS. Revisa el sitio o agrega excepciones manuales.</p></div>';
				if ( $status['stale'] ) echo '<div class="notice notice-info inline"><p>La política cambió y el CSS aún no se regeneró. Mientras tanto se sirve el original; pulsa «Recalcular fuentes» o espera al recálculo programado.</p></div>';
				if ( $status['error'] ) echo '<div class="notice notice-error inline"><p>Última generación: ' . esc_html( $status['error'] ) . '</p></div>';
				if ( $status['invalid'] ) echo '<div class="notice notice-error inline"><p>' . esc_html( $status['invalid'] ) . ' copia(s) no superaron la validación y no se sirven. Consulta el detalle en Debug.</p></div>';
			}

			echo '<details><summary>Ver inventario detallado</summary>';
			if ( ! is_array( $report ) || empty( $report['scanned_at'] ) ) { echo '<p>Sin inventario todavía. Pulsa «Recalcular fuentes».</p></details>'; return; }
			echo '<p>Kit activo: ' . esc_html( (string) ( $report['kit_id'] ?? 0 ) ) . '</p>';
			echo '<table class="widefat striped"><thead><tr><th>Familia declarada en Kit o contenido</th><th>Pesos</th><th>Estilos</th></tr></thead><tbody>';
			foreach ( (array) ( $report['families'] ?? array() ) as $row ) echo '<tr><td>' . esc_html( $row['family'] ?? '' ) . '</td><td>' . esc_html( implode( ', ', (array) ( $row['weights'] ?? array() ) ) ?: 'Todos' ) . '</td><td>' . esc_html( implode( ', ', (array) ( $row['styles'] ?? array() ) ) ?: 'Todos' ) . '</td></tr>';
			echo '</tbody></table>';
			if ( ! empty( $report['critical'] ) ) {
				echo '<h3>Variantes críticas</h3><p>Las que pinta el primer render según el Kit. Son las candidatas a preload automático.</p><table class="widefat striped"><thead><tr><th>Uso</th><th>Familia</th><th>Peso</th><th>Estilo</th></tr></thead><tbody>';
				foreach ( (array) $report['critical'] as $row ) echo '<tr><td>' . esc_html( $row['role'] ?? '' ) . '</td><td>' . esc_html( $row['family'] ?? '' ) . '</td><td>' . esc_html( $row['weight'] ?? '' ) . '</td><td>' . esc_html( $row['style'] ?? '' ) . '</td></tr>';
				echo '</tbody></table>';
			}
			echo '<p>El estado de cada variante (permitida, bloqueada, crítica, preload) está en la sección Debug.</p></details>';
		} finally { if ( $switched ) restore_current_blog(); }
	}
}
