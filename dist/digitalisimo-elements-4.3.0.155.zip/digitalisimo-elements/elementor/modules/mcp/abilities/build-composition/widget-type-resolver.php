<?php

namespace Elementor\Modules\Mcp\Abilities\Build_Composition;

use Elementor\Modules\Mcp\Abilities\Utils\Default_Children_Utils;
use Elementor\Modules\Mcp\Abilities\Utils\Widget_Context_Helper;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Widget_Type_Resolver {

	private Xml_Parser $xml_parser;

	public function __construct( Xml_Parser $xml_parser ) {
		$this->xml_parser = $xml_parser;
	}

	/**
	 * @return array<string, array>|\WP_Error
	 */
	public function collect_used( \DOMDocument $dom ) {
		$configs = [];

		foreach ( $this->xml_parser->iterate_all_descendants( $dom ) as $node ) {
			$tag = $this->xml_parser->get_tag_name( $node );

			if ( isset( $configs[ $tag ] ) ) {
				continue;
			}

			$config = $this->resolve_type_config( $tag );
			if ( is_wp_error( $config ) ) {
				return $config;
			}
			$configs[ $tag ] = $config;
		}

		return $configs;
	}

	/**
	 * @return array{configs: array<string, array>, unknown_tag_errors: string[]}
	 */
	public function collect_referenced_widget_configs( \DOMDocument $dom ): array {
		$configs = [];
		$unknown_tag_errors = [];
		$seen_unknown = [];

		foreach ( $this->xml_parser->iterate_all_descendants( $dom ) as $node ) {
			$tag = $this->xml_parser->get_tag_name( $node );

			if ( isset( $configs[ $tag ] ) || isset( $seen_unknown[ $tag ] ) ) {
				continue;
			}

			$config = $this->resolve_type_config( $tag );
			if ( is_wp_error( $config ) ) {
				$seen_unknown[ $tag ] = true;
				$unknown_tag_errors[] = $config->get_error_message();
				continue;
			}
			$configs[ $tag ] = $config;
		}

		return [
			'configs' => $configs,
			'unknown_tag_errors' => $unknown_tag_errors,
		];
	}

	/**
	 * @return string[]
	 */
	public function collect_child_type_and_required_child_errors( \DOMDocument $dom, array $widget_configs ): array {
		$root = $this->xml_parser->get_root( $dom );
		if ( ! $root ) {
			return [];
		}

		$errors = [];
		$this->collect_child_type_errors( $root, $widget_configs, $errors );
		$this->collect_required_child_errors( $root, $widget_configs, $errors );

		return $errors;
	}

	/**
	 * @return \WP_Error|null
	 */
	public function validate_child_types( \DOMDocument $dom, array $widget_configs ) {
		$root = $this->xml_parser->get_root( $dom );
		if ( ! $root ) {
			return null;
		}

		$errors = [];
		$this->collect_child_type_errors( $root, $widget_configs, $errors );
		$this->collect_required_child_errors( $root, $widget_configs, $errors );

		if ( empty( $errors ) ) {
			return null;
		}

		return new \WP_Error(
			'elementor_invalid_child_type',
			implode( ' ', $errors ),
			[ 'status' => \WP_Http::BAD_REQUEST ]
		);
	}

	public function get_props_schema( ?string $tag, array $widget_configs ): ?array {
		if ( ! $tag ) {
			return null;
		}

		$class = $widget_configs[ $tag ]['class'] ?? null;
		if ( ! $class || ! method_exists( $class, 'get_props_schema' ) ) {
			return null;
		}

		return $class::get_props_schema();
	}

	/**
	 * @return array|\WP_Error  ['elType', 'widgetType', 'allowed_child_types', 'class', 'controls']
	 */
	public function resolve_type_config( string $type ) {
		$widget = Plugin::$instance->widgets_manager->get_widget_types( $type );
		if ( $widget ) {
			$config = $widget->get_config();
			$resolved = [
				'elType' => 'widget',
				'widgetType' => $type,
				'allowed_child_types' => $config['allowed_child_types'] ?? [],
				'default_children' => $config['default_children'] ?? [],
				'class' => get_class( $widget ),
			];

			if ( Widget_Context_Helper::is_v3_allowlisted( $type ) ) {
				$resolved['controls'] = (array) $widget->get_controls();
			}

			return $resolved;
		}

		$element = Plugin::$instance->elements_manager->get_element_types( $type );
		if ( $element ) {
			$config = $element->get_config();
			return [
				'elType' => $type,
				'widgetType' => null,
				'allowed_child_types' => $config['allowed_child_types'] ?? [],
				'default_children' => $config['default_children'] ?? [],
				'class' => get_class( $element ),
			];
		}

		return new \WP_Error(
			'elementor_unknown_type',
			/* translators: %s: element type */
			sprintf( __( 'Unknown element type: %s.', 'elementor' ), $type ),
			[ 'status' => \WP_Http::BAD_REQUEST ]
		);
	}

	private function collect_child_type_errors( \DOMElement $node, array $widget_configs, array &$errors ): void {
		$parent_tag = $this->xml_parser->get_tag_name( $node );
		$parent_config = $widget_configs[ $parent_tag ] ?? null;
		$allowed = $parent_config['allowed_child_types'] ?? [];
		$is_leaf_widget = $parent_config && 'widget' === ( $parent_config['elType'] ?? null );

		foreach ( $this->xml_parser->get_child_elements( $node ) as $child ) {
			$child_tag = $this->xml_parser->get_tag_name( $child );

			if ( $is_leaf_widget ) {
				$errors[] = sprintf(
					/* translators: 1: parent tag 2: child tag */
					__( '"%1$s" is a leaf widget and cannot have children. "%2$s" is not allowed as a child of "%1$s".', 'elementor' ),
					$parent_tag,
					$child_tag
				);
			} elseif ( ! empty( $allowed ) && ! in_array( $child_tag, $allowed, true ) ) {
				$errors[] = sprintf(
					/* translators: 1: child tag 2: parent tag 3: allowed types */
					__( '"%1$s" is not allowed as a child of "%2$s". Allowed: %3$s.', 'elementor' ),
					$child_tag,
					$parent_tag,
					implode( ', ', $allowed )
				);
			}

			$this->collect_child_type_errors( $child, $widget_configs, $errors );
		}
	}

	private function collect_required_child_errors( \DOMElement $node, array $widget_configs, array &$errors ): void {
		$parent_tag = $this->xml_parser->get_tag_name( $node );
		$parent_config = $widget_configs[ $parent_tag ] ?? null;
		$default_children = is_array( $parent_config ) ? ( $parent_config['default_children'] ?? [] ) : [];
		$required_types = Default_Children_Utils::get_required_child_types( $default_children );

		if ( ! empty( $required_types ) ) {
			$actual_child_types = array_map(
				fn( \DOMElement $child ) => $this->xml_parser->get_tag_name( $child ),
				$this->xml_parser->get_child_elements( $node )
			);

			foreach ( $required_types as $required_type ) {
				if ( ! in_array( $required_type, $actual_child_types, true ) ) {
					$errors[] = sprintf(
						/* translators: 1: parent tag 2: required child tag */
						__( '"%1$s" requires a direct child "%2$s".', 'elementor' ),
						$parent_tag,
						$required_type
					);
				}
			}
		}

		foreach ( $this->xml_parser->get_child_elements( $node ) as $child ) {
			$this->collect_required_child_errors( $child, $widget_configs, $errors );
		}
	}
}
